from django.urls import path
from . import views

urlpatterns = [
            path('aiciba',views.aiciba,name = 'aiciba'),
            path('youdao',views.youdao,name = 'youdao'),
            path('bing',views.bing,name = 'bing')
               ]