import json

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from . spider import aiciba_single,thread_datas,youdao_single,bing_single

# Create your views here.
def aiciba(request):
    words = request.GET.get("words")
    split = words.split(",")
    thread_datas.data = set()
    for word in split:
        aiciba_single("http://dj.iciba.com/" + word + "-1-" + '1' + '-%01-0-0.html', None)
    print(thread_datas.data)
    return HttpResponse(json.dumps(list(thread_datas.data),ensure_ascii=False))

def youdao(request):
    words = request.GET.get("words")
    split = words.split(",")
    thread_datas.data = set()
    for word in split:
        youdao_single("http://www.youdao.com/example/" + word,None)
    print(thread_datas.data)
    return HttpResponse(json.dumps(list(thread_datas.data),ensure_ascii=False))

def bing(request):
    words = request.GET.get("words")
    split = words.split(",")
    thread_datas.data = set()
    for word in split:
        bing_single("https://cn.bing.com/dict/service?q=" + word + "&offset=10&dtype=sen",None)
    print(thread_datas.data)
    return HttpResponse(json.dumps(list(thread_datas.data),ensure_ascii=False))