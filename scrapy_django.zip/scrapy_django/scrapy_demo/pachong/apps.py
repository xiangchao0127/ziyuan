from django.apps import AppConfig


class PachongConfig(AppConfig):
    name = 'pachong'
