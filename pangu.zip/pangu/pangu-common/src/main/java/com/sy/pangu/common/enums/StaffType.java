package com.sy.pangu.common.enums;


/**
 * 员工类型
 */
public enum StaffType {

    专职(1),
    兼职(2),
    ;

    private Integer staffType;

    public Integer getStaffType() {
        return staffType;
    }

    public void setStaffType(Integer staffType) {
        this.staffType = staffType;
    }

    StaffType(Integer staffType) {
        this.staffType = staffType;
    }
}
