package com.sy.pangu.common.util.aop;


import com.sy.pangu.common.entity.vo.CommonDataVO;
import com.sy.pangu.common.entity.vo.CommonWithDataVO;
import com.sy.pangu.common.enums.annotation.ParamValidate;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.regex.Pattern;


/**
 * @author XiangChao
 * @date 2018/10/12
 */
@SuppressWarnings("ALL")
@Component
@Aspect
public class ResponseAop {

    Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    ExceptionHandle exceptionHandle;

    @Pointcut("execution(public * com.sy.pangu.*.controller..*.*(..))")
    public void reponseDo() {

    }

    @Before("reponseDo()")
    public void deBefore(JoinPoint joinPoint) throws Throwable {
        // 接收到请求，记录请求内容
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        // 记录下请求内容
        logger.info("URL : " + request.getRequestURL().toString());
        logger.info("HTTP_METHOD : " + request.getMethod());
        logger.info("IP : " + request.getRemoteAddr());
        logger.info("CLASS_METHOD : " + joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName());
        logger.info("ARGS : " + Arrays.toString(joinPoint.getArgs()));
    }

    @AfterReturning(returning = "ret", pointcut = "reponseDo()")
    public void doAfterReturning(Object ret) throws Throwable {
        // 处理完请求，返回内容
        logger.info("METHOD_RETURN : " + ret);
    }

    @Around("reponseDo()")
    public Object doAroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object[] args = proceedingJoinPoint.getArgs();
        for (Object obj : args) {
            if (obj == null) {
                continue;
            }
            Object object = paramsValidate(obj);
            if (object instanceof ResponseEntity) {
                return object;
            }
        }
        Object result;
        logger.info("AROUND_TARGET_METHOD : " + proceedingJoinPoint.getSignature().getName());
        try {
            result = proceedingJoinPoint.proceed();
        } catch (Exception e) {
            logger.error(e.getStackTrace());
            e.printStackTrace();
            // TODO: 2018/10/12 全局异常捕获封装
            logger.info(exceptionHandle.handle(e));
            return ResponseEntity.ok().body(exceptionHandle.handle(e));
        }
        if (result instanceof ResponseEntity) {
            Object body = ((ResponseEntity) result).getBody();
            return parseResult(body);
        }
        return result;
    }

    private Object paramsValidate(Object obj) {
        if (obj == null) {
            return true;
        }
        if (obj instanceof String || obj instanceof Boolean || obj instanceof Number) {
            return true;
        }
        Field[] fileds = obj.getClass().getDeclaredFields();
        for (Field field : fileds) {
            ParamValidate paramValidate = field.getAnnotation(ParamValidate.class);
            if (paramValidate != null) {
                field.setAccessible(true);
                boolean isNull = paramValidate.nullAvaible();
                String name = paramValidate.name();
                String regex = paramValidate.regex();
                String desc = paramValidate.desc();
                try {
                    if (isNull) {
                        if (field.get(obj) == null) {
                            return true;
                        }
                    }
                    boolean matches = Pattern.compile(regex).matcher((String) field.get(obj)).matches();
                    if (!matches) {
                        return parseResultParam(name);
                    }
                } catch (IllegalAccessException e) {
                    logger.error(e.getStackTrace());
                    e.printStackTrace();
                }

            }
        }
        return true;
    }

    /**
     * 结果统一封装
     *
     * @param body
     * @return
     */
    private ResponseEntity parseResult(Object body) {
        if (body instanceof Integer && (int) body == 1) {
            body = new CommonDataVO() {{
                this.setCode("200");
                this.setMessage("success");
            }};
            return ResponseEntity.ok().body(body);
        } else {
            CommonWithDataVO commonWithDataVO = new CommonWithDataVO();
            commonWithDataVO.setData(body);
            commonWithDataVO.setCode("200");
            commonWithDataVO.setMessage("success");
            return ResponseEntity.ok().body(commonWithDataVO);
        }
    }

    public static void main(String[] args) {
        Integer i= 1;
        if(i instanceof Integer){

        }
    }


    /**
     * 参数验证结果返回
     *
     * @param body
     * @return
     */
    private ResponseEntity parseResultParam(String name) {
        CommonDataVO commonWithDataVO = new CommonDataVO();
        commonWithDataVO.setCode(ExceptionEnum.PARAM_EXCEPTION.getCode());
        commonWithDataVO.setMessage("填写的" + name + "不符合规定");
        return ResponseEntity.ok().body(commonWithDataVO);
    }
}
