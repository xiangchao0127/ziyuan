package com.sy.pangu.common.util;

import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;

import java.lang.reflect.Field;
import java.util.Optional;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/7
 * Time:11:29
 */
public class EntityUtil {
    public static <K> K getEntityById(String id, JpaRepository<K, String> dao) {
        Optional<K> op = dao.findById(id);
        if (!op.isPresent()) {
            throw new CustomException(ExceptionEnum.ID_EXCEPTION, "未找到记录");
        }
        return op.get();
    }

    public static <T> void copyUpdateField(T newValues,T entity) {
        try {
            Class clazz = newValues.getClass();
            Field[] fields = clazz.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                fields[i].setAccessible(true);
                Object value = null;

                value = fields[i].get(newValues);

                if (value == null) {
                    continue;
                }
                if (value instanceof String && StringUtils.isEmpty((String) value)) {
                    continue;
                }
                fields[i].set(entity, value);
                String name = fields[i].getName();
                String name2="";
                if(name.length()>1){
                    name2 = name.substring(1);
                }
                name = Character.toUpperCase(name.charAt(0))+name2;
                clazz.getMethod("set"+name,fields[i].getType()).invoke(entity,value);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomException(ExceptionEnum.Other_Exception,"系统异常，请联系管理员");
        }
    }






}
