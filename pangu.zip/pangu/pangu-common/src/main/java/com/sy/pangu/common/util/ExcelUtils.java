package com.sy.pangu.common.util;

import com.sy.pangu.common.entity.dto.CustomException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


/**
 * @author XiangChao
 * @date 2018/11/7
 */
public class ExcelUtils {
    private static final String EXCEL_XLS = "xls";
    private static final String EXCEL_XLSX = "xlsx";

    /**
     * 根据内容填充excel并保存到本地
     * @param filePath 文件路径
     * @param dataList 数据集合
     * @param heads 表头
     * @param <T>
     */
    public static <T> void writeExcel(String filePath, List<T> dataList,List<String> heads){
        // 创建工作薄
        XSSFWorkbook workbook = new XSSFWorkbook();
        // 创建工作表
        XSSFSheet sheet = workbook.createSheet("sheet1");
        XSSFRow rowHead = sheet.createRow(0);
        // 向工作表中添加数据
        for (int i = 0; i < heads.size(); i++) {
            rowHead.createCell(i).setCellValue(heads.get(i));
        }
        Field[] declaredFields = dataList.get(0).getClass().getDeclaredFields();
        for (int row = 1; row < dataList.size() + 1; row++) {
            XSSFRow rows = sheet.createRow(row);
            for (int i = 0; i < declaredFields.length ; i++) {
                declaredFields[i].setAccessible(true);
                String value = null;
                try {
                    value = String.valueOf(declaredFields[i].get(dataList.get(row-1)));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    throw new CustomException("生成excel错误");
                }
                if(value.equals("null")){
                    value="";
                }
                rows.createCell(i).setCellValue(value);
            }
            // 向工作表中添加数据
        }
        File xlsFile = new File(filePath);
        FileOutputStream xlsStream = null;
        try {
            xlsStream = new FileOutputStream(xlsFile);
            workbook.write(xlsStream);
            xlsStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomException("生成excel错误");
        }

    }


    /**
     * 判断Excel的版本,获取Workbook
     *
     * @return
     * @throws IOException
     */
    public static Workbook getWorkbok(File file) throws IOException {
        Workbook wb = null;
        FileInputStream in = new FileInputStream(file);
        if (file.getName().endsWith(EXCEL_XLS)) {     //Excel&nbsp;2003
            wb = new HSSFWorkbook(in);
        } else if (file.getName().endsWith(EXCEL_XLSX)) {    // Excel 2007/2010
            wb = new XSSFWorkbook(in);
        }
        return wb;
    }

    /**
     * 判断Excel的版本,获取Workbook
     * @param inputStream 输入流
     * @param excelType xls  xlsx
     * @return
     * @throws IOException
     */
    public static Workbook getWorkbok(InputStream inputStream, String excelType) throws IOException {
        Workbook wb = null;
        if (excelType.endsWith(EXCEL_XLS)) {     //Excel&nbsp;2003
            wb = new HSSFWorkbook(inputStream);
        } else if (excelType.endsWith(EXCEL_XLSX)) {    // Excel 2007/2010
            wb = new XSSFWorkbook(inputStream);
        }
        return wb;
    }


    /**
     * 获取文件内容
     *
     * @param excelPath 文件路径
     * @return List<List       <       String>>
     */
    public static List<List<String>> read(String excelPath) {
        Workbook wb = null;
        try {
            wb = getWorkbok(new File(excelPath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return getContent(wb);
    }

    /**
     *
     * @param inputStream 输入流 输出流
     * @param excelType xls xlsx
     * @return
     */
    public static List<List<String>> read(InputStream inputStream,String excelType) {
        Workbook wb = null;
        try {
            wb = getWorkbok(inputStream,excelType);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return getContent(wb);
    }

    /**
     * 获取内容
     * @param wb
     * @return
     */
    public static List<List<String>> getContent(Workbook wb){
        List<List<String>> dataList = new ArrayList<List<String>>();
        /** 得到第一个shell */
        Sheet sheet = wb.getSheetAt(0);
        /** 得到Excel的总行数 */
        int rowCount = sheet.getPhysicalNumberOfRows();
        /** 循环Excel的行 */
        for (int i = 0; i < rowCount; i++) {
            Row row = sheet.getRow(i);
            if (null == row) {
                continue;
            }
            List<String> rowList = new ArrayList<String>();
            /** 循环Excel的列 */
            for (int c = 0; c < row.getLastCellNum(); c++) {
                Cell cell = row.getCell(c);
                String cellValue = getCellValue(cell);
                // System.out.print(cellValue + "\t");
                rowList.add(cellValue);
            }
            dataList.add(rowList);
        }
        return dataList;
    }


    /**
     * 根据cell类型获取cell值
     * @param cell
     * @return
     */
    private static String getCellValue(Cell cell){
        String cellValue = "";
        if (cell != null) {
            switch (cell.getCellType()) {
                case STRING:
                    cellValue = cell.getStringCellValue();
                    break;
                case _NONE:
                    if (org.apache.poi.ss.usermodel.DateUtil
                            .isCellDateFormatted(cell)) {
                        SimpleDateFormat fmt = new SimpleDateFormat(
                                "yyyy-MM-dd");
                        cellValue = fmt.format(cell.getDateCellValue());
                    } else {
                        Double d = cell.getNumericCellValue();
                        cellValue = d.toString();
                        // 解决1234.0 去掉后面的.0
                        if (null != cellValue
                                && !"".equals(cellValue.trim())) {
                            String[] item = cellValue.split("[.]");
                            if (1 < item.length && "0".equals(item[1])) {
                                cellValue = item[0];
                            }
                        }
                    }
                    break;
                case BOOLEAN:
                    cellValue = String.valueOf(cell.getBooleanCellValue());
                    break;
                case BLANK:
                    cellValue = cell.getStringCellValue();
                    break;
                case ERROR:
                    cellValue = "";
                    break;
                case FORMULA:
                    cellValue = cell.getStringCellValue();
                    break;
                case NUMERIC:
                    cellValue = String.valueOf(cell.getNumericCellValue());
                    break;
                default:
                    cellValue = cell.getStringCellValue();
            }
        }
        return cellValue;
    }

    public static void main(String[] args) {
        List<List<String>> read = read("d:\\qq记录\\RM_翻译题_模板.xlsx");
        System.out.println(read);
    }

}
