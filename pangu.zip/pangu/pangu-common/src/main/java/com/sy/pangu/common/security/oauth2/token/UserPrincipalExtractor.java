package com.sy.pangu.common.security.oauth2.token;

import com.alibaba.fastjson.JSON;

import com.sy.pangu.permission.model.User;
import org.springframework.boot.autoconfigure.security.oauth2.resource.FixedPrincipalExtractor;
import org.springframework.boot.autoconfigure.security.oauth2.resource.PrincipalExtractor;

import java.util.Map;

/**
 * @author SHUYI
 * @date 2018-4-14
 **/
public class UserPrincipalExtractor implements PrincipalExtractor {

    private FixedPrincipalExtractor fixedPrincipalExtractor = new FixedPrincipalExtractor();

    @Override
    public Object extractPrincipal(Map<String, Object> map) {
        Map<String, Object> authentication = (Map<String, Object>) map.get("userAuthentication");
        if (authentication != null) {
            Map<String, Object> principal = (Map<String, Object>) authentication.get("principal");
            User user = JSON.parseObject(JSON.toJSONString(principal.get("user")), User.class);
            return user;
        } else {
            Object principal = this.fixedPrincipalExtractor.extractPrincipal(map);
            return (principal == null ? "unknown" : principal);
        }
    }
}
