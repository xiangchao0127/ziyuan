package com.sy.pangu.common.entity.domain;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/3/19
 * Time:9:29
 */
@Data
@Entity
@Table(name = "request_url")
public class RequestUrl {
    @Id
    @GenericGenerator(name = "jpa-uuid", strategy = "uuid")
    @GeneratedValue(generator = "jpa-uuid")
    private String id;
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer id;
    private String methodDesc;
    private String methodName;
    private String methodClassName;
    private String methodType;
    private String methodUrl;
    private Boolean isLogin;
}
