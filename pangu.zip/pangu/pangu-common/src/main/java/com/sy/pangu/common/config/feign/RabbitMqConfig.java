package com.sy.pangu.common.config.feign;

import com.sy.pangu.common.security.access.SecurityAccessMetadataSource;
import lombok.Data;


import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;

import java.util.UUID;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/5/17
 * Time:13:25
 */
@Data
public class RabbitMqConfig {
    @Autowired
    @Qualifier("queueId")
    private String queueId;
    public static String exchangeName = "fanoutExchange";
    @Autowired
    SecurityAccessMetadataSource securityAccessMetadataSource;

    @Bean
    public Queue createRabbitQueue(){
        return new Queue(queueId,false,false,true);
    }
    @Bean
    public FanoutExchange fanoutExchange(){
        return new FanoutExchange(exchangeName);
    }
    @Bean
    public Binding bindingExchangeMessage(){
        return BindingBuilder.bind(createRabbitQueue()).to(fanoutExchange());
    }
    @RabbitListener(queues = "#{queueId}")
    public void refreshCache(Object object){
        securityAccessMetadataSource.loadUrlRoleMapping();
    }

}
