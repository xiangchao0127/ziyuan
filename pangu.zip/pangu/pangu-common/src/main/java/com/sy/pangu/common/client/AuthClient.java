package com.sy.pangu.common.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/23
 * Time:16:17
 */
@FeignClient(name = "auth-service", path = "/auth")
public interface AuthClient {
    @GetMapping("/current")
    Principal getUser();

    @GetMapping("/cache/refreshFileterCache")
    void refreshFileterCache();

    @GetMapping("/sysInfo/urls")
    ResponseEntity getAllRequestUrl();
}
