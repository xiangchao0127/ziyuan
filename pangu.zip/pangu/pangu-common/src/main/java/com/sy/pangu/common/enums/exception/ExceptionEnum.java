package com.sy.pangu.common.enums.exception;

/**
 * create by XiangChao on 2018/10/11
 */
public enum ExceptionEnum {
    /**
     * 文件未找到异常
     */
    FILE_NOT_FOUND("001", "文件未找到"),


    /**
     * 用户已存在
     */
    USER_ALREADY_EXISTS("002", "用户已存在"),

    /**
     * 用户不存在
     */
    USER_NOT_FOUND("003", "用户不存在"),

    /**
     * 老密码错误
     */
    OLD_PASSWORD_ERROR("004", "原密码错误"),

    /**
     * 验证码错误
     */
    VERIFICATION_CODE_ERROR("005", "验证码错误"),
    /**
     * 验证码错误
     */
    VERIFICATION_CODE_NOT_SEND("005", "验证码发送失败"),
    /**
     * 手机号已存在
     */
    PHONE_ALREADY_EXISTS("006", "手机号已存在"),

    /**
     * 文件类型不符合要求
     */
    File_Type_Error("007", "文件类型不符合要求"),

    Params_Empty("008", "参数为空"),
    /**
     * es操作异常
     */
    ES_EXCEPTION("009", "es异常"),
    /**
     * es操作异常
     */
    PARAMTER_EXCEPTION("009", "es异常"),
    /**
     * 根据id未找到记录
     */
    ID_EXCEPTION("011", "未查询到记录"),
    /**
     * excel数据类型错误
     */
    EXCEL_DATA_TYPE_EXCEPTION("012", "excel数据类型错误"),
    /**
     * 参数验证未通过
     */
    PARAM_EXCEPTION("099", "参数验证未通过"),
    /**
     * 参数过长
     */
    PARAM_TOO_LONG_EXCEPTION("099", "参数过长"),
    /**
     * 图片大小超过限制
     */
    PICTURE_SIZE_EXCEED_EXCEPTION("013", "图片大小超过限制"),

    NICK_NAME_EXISTS("014", "昵称已经存在"),

    IDENTITY_CARD_ID_NOT_PASSED("015", "身份认证失败"),

    BANK_CARD_ID_NOT_PASSED("016", "银行卡验证未通过"),

    EMAIL_FORMAT_ERROR("017", "邮箱格式不正确"),

    FILE_UPLOAD_ERROR("018", "文件上传失败"),

    Other_Exception("100", "其他异常");


    private String code;
    private String message;

    ExceptionEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
