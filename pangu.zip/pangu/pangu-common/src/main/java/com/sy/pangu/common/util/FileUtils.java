package com.sy.pangu.common.util;

import com.google.common.io.Files;
import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import org.apache.commons.codec.binary.Base64;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/11/20
 * Time:17:37
 */
public class FileUtils {
    /**
     * 将字符串写入到文件
     *
     * @param filepath 文件全路径
     * @param str      字符串
     * @throws Exception
     */
    public static void write(String filepath, String str) throws Exception {
        makeFile(filepath);
        FileWriter writerEnglish = new FileWriter(filepath);
        BufferedWriter bwEn = new BufferedWriter(writerEnglish);

        bwEn.write(str);
        bwEn.close();
        writerEnglish.close();
    }

    /**
     * 将文件流写入到指定文件
     *
     * @param filepath 文件全路径
     * @param fin      输入流
     */
    public static void write(String filepath, InputStream fin) {
        try {
            OutputStream out = getFileOutputStream(filepath);
            byte[] buffer = new byte[1024 * 8];

            int readlength = -1;
            while ((readlength = fin.read(buffer)) != -1) {
                out.write(buffer, 0, readlength);
            }
            fin.close();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 获取指定路径下的输出流
     *
     * @param filepath 文件全路径
     * @return
     */
    public static FileOutputStream getFileOutputStream(String filepath) {
        File file = makeFile(filepath);
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream(file);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fout;
    }


    /**
     * 创建文件
     *
     * @param filepath
     */
    public static File makeFile(String filepath) {
        try {
            File file = new File(filepath);
            if (!file.exists()) {
                String dir = filepath.substring(0, filepath.lastIndexOf(File.separator));
                File dirFile = new File(dir);
                dirFile.mkdirs();
                file.createNewFile();
            }
            return file;
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomException(ExceptionEnum.FILE_NOT_FOUND, "创建文件异常");
        }
    }


    /**
     * 删除文件
     *
     * @param filepath
     */
    public static boolean deleteFile(String filepath) {
        try {
            File file = new File(filepath);
            if (!file.exists()) {
                throw new CustomException(ExceptionEnum.FILE_NOT_FOUND);
            }
            file.delete();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public static void main(String[] args) {
        System.out.println(ConfUtils.getInstance().getConfig("pangu-file.ip"));
    }

    public static void uploadOneFile(MultipartFile file, String filepath) {
        try {
            Files.write(file.getBytes(), FileUtils.makeFile(filepath));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomException(ExceptionEnum.FILE_NOT_FOUND, "上传文件有问题");
        }
    }

    /**
     * 获取图片并转为base64String
     *
     * @param filePath 文件路径
     * @return
     */
    public static String getImgBase64String(String filePath) {
        try {
            if (!StringUtils.notEmpty(filePath)) {
                return null;
            }
            File file = new File(filePath);
            if (!file.exists()) {
                return null;
            }
            String base64str = Base64.encodeBase64String(Files.toByteArray(file));
            return base64str;
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomException(ExceptionEnum.FILE_NOT_FOUND, "文件未找到");
        }
    }

    /**
     * 追加内容
     * @param fileName
     * @param conent
     */
    public static void append(String fileName, String conent) {
       append(new File(fileName),conent);
    }

    public static void append(File fileName, String conent) {
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName, true)));
            out.newLine();
            out.write(conent);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if(out != null){
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
