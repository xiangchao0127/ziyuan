
package com.sy.pangu.common.security.access;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cache")
public class CacheController {
    @Autowired
    SecurityAccessMetadataSource securityAccessMetadataSource;

    @GetMapping("/refreshFileterCache")
    public void refreshFileterCache() {

        securityAccessMetadataSource.loadUrlRoleMapping();
    }
}

