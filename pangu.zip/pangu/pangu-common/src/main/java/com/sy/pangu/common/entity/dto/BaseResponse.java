package com.sy.pangu.common.entity.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 返回值基类
 *
 * @author Q00596
 */
@Data
public class BaseResponse implements Serializable {

    private String code;
    private String msg;
    private Object obj;

}
