package com.sy.pangu.common.util;


import com.sy.pangu.common.entity.dto.CustomException;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author XiangChao
 * @date 2018/10/16
 */
public final class DateUtils extends org.apache.commons.lang3.time.DateUtils {
    static final SimpleDateFormat SIMPLE_DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    static final SimpleDateFormat SIMPLE_DATEFORMAT_ORDER = new SimpleDateFormat("yyyyMMddHHmm");

    /**
     * 获取当前时间
     *
     * @return
     */
    public static Timestamp getCurrentTimeStamp() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        return timestamp;
    }

    /**
     * 日期转字符串
     * @param date
     * @return
     */
    public static String dateToString(Date date){
        return SIMPLE_DATEFORMAT.format(date);
    }

    /**
     * 获取明年当前时间
     *
     * @return
     */
    public static Timestamp getNextYeartCurrentTimeStamp() {
        Timestamp timestamp = null;
        synchronized (SIMPLE_DATEFORMAT) {
            timestamp = new Timestamp(System.currentTimeMillis() + 3600 * 24 * 365 * 1000L);
        }
        return timestamp;
    }

    public static String timeStamp2Str(Timestamp timestamp) {
        String format = null;
        synchronized (SIMPLE_DATEFORMAT) {
            format = SIMPLE_DATEFORMAT.format(timestamp);
        }
        return format;
    }

    /**
     * 字符串转date
     * @param dateStr "yyyy-MM-dd HH:mm:ss"
     * @return
     */
    public static Date strToDate(String dateStr){
        Date date = null;
        try {
            date = SIMPLE_DATEFORMAT.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
            throw new CustomException("日期格式错误");
        }
        return date;
    }

    public static String timeStamp2StrForOrderNum(Timestamp timestamp) {
        String format = null;
        synchronized (SIMPLE_DATEFORMAT_ORDER) {
            format = SIMPLE_DATEFORMAT_ORDER.format(timestamp);
        }
        String num = "";
        int i = 0;
        for (; i < 3; i++) {
            num += (int) (Math.random() * 9);
        }
        return format + num;
    }

    /**
     * 字符串转为TimeStamp
     * 字符串必须为yyyy-mm-dd hh:mm:ss
     *
     * @param strDate
     * @return
     */
    public static Timestamp strToTimestamp(String strDate) {
        //SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return Timestamp.valueOf(strDate);
    }

    /**
     * 获取yyyy-MM-dd HH:mm:ss中的yyyy-MM-dd
     *
     * @param strDate
     * @return
     */
    public static String getYearMonthDay(String strDate) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(formatter.parse(strDate));
        int month = calendar.get(Calendar.MONDAY)+1;
        return  calendar.get(Calendar.YEAR)+"-"+month+"-"+calendar.get(Calendar.DAY_OF_MONTH);
    }


    /**
     * 将yyyy-MM-dd HH:mm:ss中的yyyy-MM
     *
     * @param strDate
     * @return
     * @throws ParseException
     */
    public static String getYearMonth(String strDate) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(formatter.parse(strDate));
        int month = calendar.get(Calendar.MONDAY)+1;
        return  calendar.get(Calendar.YEAR)+"-"+month;
    }

    /**
     * 比较时间是否超过15分钟
     * @param time
     * @return
     */
    public static boolean cmpTime(String time) {
        long tempTime = Long.parseLong(time);
        //在获取现在的时间
        Calendar calendar = Calendar.getInstance();
        Long date = calendar.getTime().getTime();            //获取毫秒时间

        if(date - tempTime > 900000 ) {   //15分钟
            return false;
        } else {
            return true;
        }
    }

    /**
     * 获取cron表达式
     * @param date "yyyy-MM-dd HH:mm:ss"
     * @return
     */
    public static String getCron(String date){
        String h = date.split(" ")[1].split(":")[0];
        String m = date.split(" ")[1].split(":")[1];
        String s = date.split(" ")[1].split(":")[2];
        String M = date.split(" ")[0].split("-")[1];
        String d = date.split(" ")[0].split("-")[2];
        String cron = s + " " + m + " " + h + " " + d + " " + M + " " + "?";
        return cron;
    }



    /**
     * 将yyyy-MM-dd HH:mm:ss中的yyyy-MM
     *
     * @return
     * @throws ParseException
     */
    public static String getNowTime() {
        String dateTime = "";
        try {
            dateTime = SIMPLE_DATEFORMAT.parse(new Date().toString()).toString();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateTime;
    }

}
