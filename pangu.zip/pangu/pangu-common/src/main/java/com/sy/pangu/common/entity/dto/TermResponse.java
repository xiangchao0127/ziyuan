package com.sy.pangu.common.entity.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 一条术语
 */
@Data
public class TermResponse implements Serializable {

    /**
     * 原文
     */
    private String sourceText;
    /**
     * 术语
     */
    private String targetText;
    /**
     * 释义
     */
    private String sourceDesc;

    /**
     * 释义
     */
    private String targetDesc;


}
