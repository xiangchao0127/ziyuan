package com.sy.pangu.common.entity.vo;

import lombok.Data;
import org.apache.poi.ss.formula.functions.T;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/11/23
 * Time:13:58
 */
@Data
public class CommonWithDataVO {
    /**
     * 编码
     */
    private String code;

    /**
     * 信息
     */
    private String message;
    /**
     * 返回数据
     */
    private Object data;
}
