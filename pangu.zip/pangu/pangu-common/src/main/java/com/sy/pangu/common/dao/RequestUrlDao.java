package com.sy.pangu.common.dao;


import com.sy.pangu.common.entity.domain.RequestUrl;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/3/19
 * Time:13:20
 */
public interface RequestUrlDao extends JpaRepository<RequestUrl, String>, JpaSpecificationExecutor<RequestUrl> {
    List<RequestUrl> findAllByIsLogin(Boolean isLogin);
}
