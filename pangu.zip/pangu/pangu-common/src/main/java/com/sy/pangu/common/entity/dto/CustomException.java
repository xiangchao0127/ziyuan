package com.sy.pangu.common.entity.dto;

import com.sy.pangu.common.enums.exception.ExceptionEnum;
import lombok.Data;

/**
 * @author XiangChao
 * @date 2018/10/12
 */
@Data
public class CustomException extends RuntimeException {
    /**
     * 编码
     */
    private String code;

    /**
     * 信息
     */
    private String msg;

    public CustomException(ExceptionEnum exceptionEnum, String explain) {
        this.code = exceptionEnum.getCode();
        this.msg = exceptionEnum.getMessage() + ":" + explain;
    }

    public CustomException(ExceptionEnum exceptionEnum) {
        this.code = exceptionEnum.getCode();
        this.msg = exceptionEnum.getMessage();
    }

    public CustomException(Exception exception) {
        this.code = "99";
        this.msg = exception.getMessage();
    }

    public CustomException(String desc) {
        this.code = "120";
        this.msg = desc;
    }
}
