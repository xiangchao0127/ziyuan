package com.sy.pangu.common.entity.vo;


import lombok.Data;

/**
 * @author XiangChao
 * @date 2018/10/11
 */
@Data
public class CommonDataVO {
    /**
     * 编码
     */
    private String code;

    /**
     * 信息
     */
    private String message;
}
