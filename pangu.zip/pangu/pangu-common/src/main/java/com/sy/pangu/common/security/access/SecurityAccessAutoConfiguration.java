package com.sy.pangu.common.security.access;

import com.sy.pangu.common.dao.RequestUrlDao;
import com.sy.pangu.common.entity.domain.RequestUrl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author SHUYI
 * @date 2018-4-10
 **/
@Slf4j
public class SecurityAccessAutoConfiguration {

    @Autowired
    private CacheManager cacheManager;
    @Value("${spring.application.name:}")
    private String serviceId;
    @Autowired
    private RequestUrlDao requestUrlDao;

    @Bean
    SecurityAccessMetadataSource securityAccessMetadataSource() {
        SecurityAccessMetadataSource s = new SecurityAccessMetadataSource();
        s.setCacheManager(cacheManager);
        s.setServiceId(serviceId);
        s.setRequestUrlDao(requestUrlDao);
        return s;
    }


    @Bean
    @Primary
    public FilterSecurityInterceptor securityAccessInterceptor() {
        FilterSecurityInterceptor securityInterceptor = new FilterSecurityInterceptor();
        securityInterceptor.setAccessDecisionManager(new SecurityAccessDecisionManager());
        securityInterceptor.setSecurityMetadataSource(this.securityAccessMetadataSource());
        return securityInterceptor;
    }
    @Bean("queueId")
    public String queueId(){
        return serviceId+":"+UUID.randomUUID().toString();
    }


    @Configuration
    @Conditional(EnableResourceServerCondition.class)
    private class ResourceServerSecurityAccessConfiguration extends ResourceServerConfigurerAdapter {
        @Autowired
        private RequestUrlDao requestUrlDao;
        public ResourceServerSecurityAccessConfiguration() {

        }

        @Override
        public void configure(HttpSecurity http) throws Exception {
            http.headers().frameOptions().disable();
            List<RequestUrl> requestUrls =  requestUrlDao.findAllByIsLogin(false);
            List<String> urls = new ArrayList<>();
            for(RequestUrl requestUrl:requestUrls){
                urls.add(requestUrl.getMethodUrl());
            }
            //排除Swagger文档
            http.authorizeRequests().antMatchers(urls.toArray(new String[0])).permitAll().and().csrf().disable()
                    .authorizeRequests().anyRequest().authenticated().filterSecurityInterceptorOncePerRequest(false)
                    .and().addFilterAfter(securityAccessInterceptor(), FilterSecurityInterceptor.class);
            log.info("Security Access Control is enabled on Resource Server Application");
        }

    }

    @Configuration
    @Conditional(EnableWebSecurityCondition.class)
    private class WebSecurityAccessConfiguration extends WebSecurityConfigurerAdapter {
        @Autowired
        private RequestUrlDao requestUrlDao;

        public WebSecurityAccessConfiguration() {

        }

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http.headers().frameOptions().disable();
            List<RequestUrl> requestUrls =  requestUrlDao.findAllByIsLogin(false);
            List<String> urls = new ArrayList<>();
            for(RequestUrl requestUrl:requestUrls){
                urls.add(requestUrl.getMethodUrl());
            }

            //排除Swagger文档
            //"/v2/api-docs","/term/downloadTermFileModel","/machineScrapy/downloadScrapyModel","/machineScrapy/downLoadsScrapyContent"
            http.authorizeRequests().antMatchers(urls.toArray(new String[0])).permitAll().and().csrf().disable()
                    .authorizeRequests().anyRequest().authenticated().filterSecurityInterceptorOncePerRequest(false)
                    .and().addFilterAfter(securityAccessInterceptor(), FilterSecurityInterceptor.class);
            log.info("Security Access Control is enabled on Web Application");
        }


    }

}
