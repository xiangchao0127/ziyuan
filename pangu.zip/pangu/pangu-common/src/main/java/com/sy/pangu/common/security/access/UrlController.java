package com.sy.pangu.common.security.access;

import com.sy.pangu.common.dao.RequestUrlDao;
import com.sy.pangu.common.entity.domain.RequestUrl;
import com.sy.pangu.common.util.StringUtils;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/25
 * Time:9:35
 */
@RestController
@Api(tags = {"请求路径"})
@RequestMapping("/sysInfo")
public class UrlController {
    @Autowired
    WebApplicationContext applicationContext;
    @Autowired
    private RequestUrlDao requestUrlDao;
    @GetMapping("/urls")
    public ResponseEntity<List<Map<String,String>>> getAllRequestUrl() {
        RequestMappingHandlerMapping mapping = applicationContext.getBean(RequestMappingHandlerMapping.class);
        // 获取url与类和方法的对应信息
        Map<RequestMappingInfo, HandlerMethod> map = mapping.getHandlerMethods();
        List<Map<String, String>> list = new ArrayList<>();
        for (Map.Entry<RequestMappingInfo, HandlerMethod> m : map.entrySet()) {
            Map<String, String> map1 = new HashMap<>();
            RequestMappingInfo info = m.getKey();
            HandlerMethod method = m.getValue();
            PatternsRequestCondition p = info.getPatternsCondition();
            for (String url : p.getPatterns()) {
                map1.put("url", url);
            }
            map1.put("className", method.getMethod().getDeclaringClass().getName()); // 类名
            map1.put("method", method.getMethod().getName()); // 方法名
            RequestMethodsRequestCondition methodsCondition = info.getMethodsCondition();
            for (RequestMethod requestMethod : methodsCondition.getMethods()) {
                map1.put("type", requestMethod.toString());
            }

            list.add(map1);
        }
        return ResponseEntity.ok().body(list);
    }
    @GetMapping("/updateUrls")
    public ResponseEntity<Integer> updateUrls(){
        ResponseEntity responseEntity = this.getAllRequestUrl();
        List<Map<String,String>> list = (List<Map<String,String>>)responseEntity.getBody();
        List<RequestUrl> requestUrls = new ArrayList<>();
        for(Map<String,String> message:list){
            RequestUrl requestUrl = new RequestUrl();
            if(StringUtils.notEmpty(message.get("className"))){
                requestUrl.setMethodClassName(message.get("className"));
            }
            if(StringUtils.notEmpty(message.get("method"))){
                requestUrl.setMethodName(message.get("method"));
            }
            if(StringUtils.notEmpty(message.get("type"))){
                requestUrl.setMethodType(message.get("type"));
            }
            if(StringUtils.notEmpty(message.get("url"))){
                requestUrl.setMethodUrl(message.get("url"));
            }
            if(!requestUrlDao.findOne(Example.of(requestUrl)).isPresent()){
                requestUrl.setIsLogin(true);
                requestUrls.add(requestUrl);
            }
        }
        if(requestUrls.size()>0){
            requestUrlDao.saveAll(requestUrls);
        }
        return ResponseEntity.ok().body(1);
    }

}
