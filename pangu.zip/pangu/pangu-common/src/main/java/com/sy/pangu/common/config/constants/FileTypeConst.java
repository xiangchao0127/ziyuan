package com.sy.pangu.common.config.constants;

/**
 * 文件类型
 *
 * @author Q00596
 */
public class FileTypeConst {
    /**
     * DOC文档
     */
    public static final String DOC = "doc";
    /**
     * DOCX文档
     */
    public static final String DOCX = "docx";
    /**
     * PDF文档
     */
    public static final String PDF = "pdf";
    /**
     * XLS文档
     */
    public static final String XLS = "xls";
    /**
     * XLSX文档
     */
    public static final String XLSX = "xlsx";
    /**
     * 国际通用术语格式标准
     */
    public static final String TBX = "tbx";
    /**
     * trados术语文件格式
     */
    public static final String SDLTB = "sdltb";
    /**
     * txt文档
     */
    public static final String TXT = "txt";
    /**
     * csv文档
     */
    public static final String CSV = "csv";
}
