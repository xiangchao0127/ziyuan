package com.sy.pangu.common.config.constants;

/**
 * @author SHUYI
 * @date 2018-4-10
 **/
public class ResourceCacheConstant {
    public static final String RESOURCE_HIERARCHY_CACHE = "resource_hierarchy";
    public static final String URL_ROLE_MAPPING_CACHE = "url_role_mapping";
    public static final String URL_RESOURCE = "url_resource";
}
