package com.sy.pangu.common.util;

import com.aliasi.sentences.IndoEuropeanSentenceModel;
import com.aliasi.sentences.SentenceModel;
import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;
import com.aliasi.tokenizer.Tokenizer;
import com.aliasi.tokenizer.TokenizerFactory;
import com.sy.pangu.common.entity.dto.StatementMessage;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * @author XiangChao
 * @date 2018/11/2
 */
public class SegmentationUtils {
    static final TokenizerFactory TOKENIZER_FACTORY = IndoEuropeanTokenizerFactory.INSTANCE;
    static final SentenceModel SENTENCE_MODEL = new IndoEuropeanSentenceModel();

    //这里我选择了好多典型例子，属于正则表达式筛选会有问题的，你们的正则如果都能处理你牛逼，请留言给我，我也想要
    public static void main(String[] args) {
        SegmentationUtils s = new SegmentationUtils();
        String str1 = "Water-splashing Festival is one of the most important festivals in the world, which is popular among Dai people of China and the southeast Asia. It has been celebrated by people for more than 700 years and now this festival is an necessary way for people to promote the cooperation and communication among countries.";
        String str2 = "This is how I tried to split a paragraph into a sentence. But, there is a problem. My paragraph includes dates like Jan.13, 2014 , words like U.S and numbers like 2.2. They all got split by the above code.";
        String str3 = "My friend holds a Msc. in Computer Science.";
        String str4 = "This is a test? This is a T.L.A. test!";
        String text = "50 Cent XYZ120 DVD Player 50 Cent lawyer. Person is john, he is a lawyer.";
        String str5 = "\"I do not ask for your forgiveness,\" he said, in a tone that became more firm and forceful. \"I have no illusions, and I am convinced that death is waiting for me: it is just.\"";
        String str6 = "\"The Times have.had.too much influence on me.\" He laughed bitterly and said to himself, \"it is only two steps away from death. Alone with me, I am still hypocritical... Ah, the 19th century!\"";
        String str7 = "泼水节是世界上最重要节日之一，深受中国傣族和东南亚人民的喜爱。七百多年来，人们一直在庆祝这个节日，现在这个节日是促进国家间合作和交流的必要方式。";
//        System.out.println(splitfuhao(str6));
        Set<String> sl = getKeySet(str2, 5);
//        if (sl.isEmpty()) {
//            System.out.println("没有识别到句子");
//        }
//        for (String row : sl) {
//            System.out.println(row);
//        }
    }

    public static Set<String> getKeySet(String text, Integer maxLength) {
        Set<String> keySet = new LinkedHashSet<>();
        List<String> tokenList = new ArrayList<>();
        List<String> whiteList = new ArrayList<>();
        Tokenizer tokenizer = TOKENIZER_FACTORY.tokenizer(text.toCharArray(),
                0, text.length());
        tokenizer.tokenize(tokenList, whiteList);
        String[] tokens = new String[tokenList.size()];
        String[] whites = new String[whiteList.size()];
        tokenList.toArray(tokens);
        whiteList.toArray(whites);
        int[] sentenceBoundaries = SENTENCE_MODEL.boundaryIndices(tokens,
                whites);
        int sentStartTok = 0;
        int sentEndTok;

        for (int i = 0; i < sentenceBoundaries.length; ++i) {
            sentEndTok = sentenceBoundaries[i];
            for (int j = sentStartTok; j <= sentEndTok; j++) {
                int k = j;
                int end = sentEndTok - 1;
                int max = j + maxLength;
                while (k < end && k < max) {
                    StringBuilder sb = new StringBuilder();
                    for (int m = j, n = k; m <= n; m++) {
                        if (j == m) {
                            sb.append(tokens[m]);
                        } else {
                            sb.append(" ").append(tokens[m]);
                        }
                    }
                    keySet.add(sb.toString());
                    k++;
                }
            }
            sentStartTok = sentEndTok + 1;
        }
        return keySet;
    }


    //这个是引用句子识别的方法，找了好多资料，在一个用它做文本分析里的找到的
    //https://blog.csdn.net/textboy/article/details/45580009
    public static List<String> testChunkSentences(String text) {
        List<String> result = new ArrayList<String>();
        List<String> tokenList = new ArrayList<String>();
        List<String> whiteList = new ArrayList<String>();
        Tokenizer tokenizer = TOKENIZER_FACTORY.tokenizer(text.toCharArray(),
                0, text.length());
        tokenizer.tokenize(tokenList, whiteList);
        String[] tokens = new String[tokenList.size()];
        String[] whites = new String[whiteList.size()];
        tokenList.toArray(tokens);
        whiteList.toArray(whites);
        int[] sentenceBoundaries = SENTENCE_MODEL.boundaryIndices(tokens,
                whites);
        int sentStartTok = 0;
        int sentEndTok = 0;

        for (int i = 0; i < sentenceBoundaries.length; ++i) {
            System.out.println("Sentense " + (i + 1) + ", sentense's length(from 0):" + (sentenceBoundaries[i]));
            StringBuilder sb = new StringBuilder();
            sentEndTok = sentenceBoundaries[i];
            for (int j = sentStartTok; j <= sentEndTok; j++) {
                sb.append(tokens[j]).append(whites[j + 1]);
            }
            sentStartTok = sentEndTok + 1;
            result.add(sb.toString());
        }
        //System.out.println("Final result:" + result);
        return result;
    }

    public static List<String> testChunkSentences(String text, List<String> result, List<StatementMessage> mgList, int paragraphIndex) {
        List<String> tokenList = new ArrayList<String>();
        List<String> whiteList = new ArrayList<String>();
        Tokenizer tokenizer = TOKENIZER_FACTORY.tokenizer(text.toCharArray(),
                0, text.length());
        //拆分为单词和空白符号
        tokenizer.tokenize(tokenList, whiteList);
        String[] tokens = new String[tokenList.size()];
        String[] whites = new String[whiteList.size()];
        //复制一份
        tokenList.toArray(tokens);
        whiteList.toArray(whites);
        //获取边界符号
        int[] sentenceBoundaries = SENTENCE_MODEL.boundaryIndices(tokens, whites);
        int sentStartTok = 0;
        int sentEndTok = 0;
        int length = sentenceBoundaries.length;
        if (tokens.length == 0) {
            return result;
        }
        if (length == 0) {
            combinStatement(result, mgList, paragraphIndex, tokens, whites, sentStartTok, tokens.length - 1);
        } else {
            for (int i = 0; i < length; ++i) {
                sentEndTok = sentenceBoundaries[i];
                if ("\"".equals(tokens[sentEndTok]) && (sentEndTok != tokens.length - 1)) {
                    continue;
                }
                combinStatement(result, mgList, paragraphIndex, tokens, whites, sentStartTok, sentEndTok);
                sentStartTok = sentEndTok + 1;
            }
            if (sentStartTok < tokens.length) {
                combinStatement(result, mgList, paragraphIndex, tokens, whites, sentStartTok, tokens.length - 1);
            }
        }
        return result;
    }

    private static void combinStatement(List<String> result, List<StatementMessage> mgList, int paragraphIndex, String[] tokens, String[] whites, int start, int end) {
        StringBuilder sb = new StringBuilder();
        StringBuilder feature = new StringBuilder();
        StatementMessage statementMessage = new StatementMessage();
        int mgListSize = mgList.size();
        if (mgListSize > 0) {
            //获取上级信息
            StatementMessage last = mgList.get(mgListSize - 1);
            if (paragraphIndex == last.getParagraph()) {
                statementMessage.setParagraphOffset(last.getParagraphOffset() + 1);
            } else {
                statementMessage.setParagraphOffset(1);
            }
        } else {
            statementMessage.setParagraphOffset(1);
        }
        statementMessage.setParagraph(paragraphIndex);
        for (int i = start; i <= end; i++) {
            sb.append(tokens[i]).append(whites[i + 1]);
            if (tokens[i].length() == 1 && tokens[i].charAt(0) < 65 && tokens[i].charAt(0) != 39 && tokens[i].charAt(0) != 45) {
                feature.append(tokens[i]);
            }
        }
        if (tokens[end].length() <= 1) {
            //空格和不间断空格
            int cr = tokens[end].charAt(0);
            if (cr == 32 || cr > 127) {
                statementMessage.setEndSymbol(null);
            } else {
                statementMessage.setEndSymbol(tokens[end]);
            }
        } else {
            statementMessage.setEndSymbol(null);
        }
        statementMessage.setFeature(feature.toString());
        mgList.add(statementMessage);
        result.add(sb.toString());
    }

    //替换中文标点符号，用于检测是否识别中文分句
    public static String splitfuhao(String str) {
        String[] ChineseInterpunction = {"“", "”", "‘", "’", "。", "，", "；", "：", "？", "！", "……", "—", "～", "（", "）", "《", "》", "、"};
        String[] EnglishInterpunction = {"\"", "\"", "'", "'", ".", ",", ";", ":", "?", "!", "…", "-", "~", "(", ")", "<", ">", ","};
        for (int j = 0; j < ChineseInterpunction.length; j++) {
            str = str.replace(ChineseInterpunction[j], EnglishInterpunction[j] + " ");
        }
        return str;
    }
}
