package com.sy.pangu.common.enums.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.regex.Pattern;

/**
 * @author XiangChao
 * @date 2019/1/31
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface ParamValidate {
    String name() default "";

    String regex() default "";

    String desc() default "";

    boolean nullAvaible() default false;
}
