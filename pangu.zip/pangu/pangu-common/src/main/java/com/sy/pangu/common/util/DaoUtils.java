package com.sy.pangu.common.util;

import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 * dao工具类
 *
 * @author XiangChao
 * @date 2019/4/10
 */
public class DaoUtils {
    /**
     *  根据id查询记录，没查询到抛错
     * @param dao
     * @param id
     * @param <T>
     * @return
     */
    public static <T> T getOne(JpaRepository<T, String> dao, String id) {
        T one = dao.getOne(id);
        if (one == null) {
            throw new CustomException(ExceptionEnum.ID_EXCEPTION);
        }
        return one;
    }

    public static <T> void deleteOne(JpaRepository<T, String> dao,String id){
        T one = dao.getOne(id);
        if (one == null) {
            throw new CustomException(ExceptionEnum.ID_EXCEPTION);
        }
        dao.deleteById(id);
    }
}
