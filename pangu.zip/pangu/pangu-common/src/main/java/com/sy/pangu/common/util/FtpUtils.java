package com.sy.pangu.common.util;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author XiangChao
 * @date 2019/5/14
 */
public class FtpUtils {
    private static final Logger LOG = LoggerFactory.getLogger(FtpUtils.class);

    public static void main(String[] args) throws FileNotFoundException {
       upload("192.168.2.202", 22, "root", "root", new FileInputStream(new File("")),"/opt");
    }

    /**
     * 上传文件
     *
     * @param host        ip
     * @param port        端口（默认22）
     * @param username    用户名
     * @param password    密码
     * @param inputStream 输入流
     * @param dst         目标地址
     * @return
     */
    public static boolean upload(String host, int port, String username, final String password, InputStream inputStream, String dst)
    {
        ChannelSftp sftp = null;
        Channel channel = null;
        Session sshSession = null;
        try {
            JSch jsch = new JSch();
            jsch.getSession(username, host, port);
            sshSession = jsch.getSession(username, host, port);
            sshSession.setPassword(password);
            Properties sshConfig = new Properties();
            sshConfig.put("StrictHostKeyChecking", "no");
            sshSession.setConfig(sshConfig);
            sshSession.connect();
            LOG.debug("Session connected!");
            channel = sshSession.openChannel("sftp");
            channel.connect();
            LOG.debug("Channel connected!");
            sftp = (ChannelSftp) channel;
            sftp.put(inputStream, dst);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeChannel(sftp);
            closeChannel(channel);
            closeSession(sshSession);
        }
        return true;
    }

    /**
     * 下载文件
     * @param host  ip
     * @param port  端口
     * @param username 用户名
     * @param password 密码
     * @param dst 目标资源
     * @return
     */
    public static InputStream download(String host, int port, String username, final String password, String dst) {
        ChannelSftp sftp = null;
        Channel channel = null;
        Session sshSession = null;
        InputStream inputStream = null;
        try {
            JSch jsch = new JSch();
            jsch.getSession(username, host, port);
            sshSession = jsch.getSession(username, host, port);
            sshSession.setPassword(password);
            Properties sshConfig = new Properties();
            sshConfig.put("StrictHostKeyChecking", "no");
            sshSession.setConfig(sshConfig);
            sshSession.connect();
            LOG.debug("Session connected!");
            channel = sshSession.openChannel("sftp");
            channel.connect();
            LOG.debug("Channel connected!");
            sftp = (ChannelSftp) channel;
            inputStream = sftp.get(dst);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            closeChannel(sftp);
            closeChannel(channel);
            closeSession(sshSession);
        }
        return inputStream;
    }

    private static void closeChannel(Channel channel) {
        if (channel != null) {
            if (channel.isConnected()) {
                channel.disconnect();
            }
        }
    }

    private static void closeSession(Session session) {
        if (session != null) {
            if (session.isConnected()) {
                session.disconnect();
            }
        }
    }
}
