package com.sy.pangu.common.entity.dto;

import lombok.Data;

@Data
public class StatementMessage {
    private String endSymbol;
    private int RowIndex;
    private String feature;
    private int paragraph;
    private int paragraphOffset;
}
