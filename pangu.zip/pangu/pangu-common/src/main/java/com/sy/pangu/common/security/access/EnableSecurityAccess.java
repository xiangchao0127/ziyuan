package com.sy.pangu.common.security.access;

import com.sy.pangu.common.config.feign.RabbitMqConfig;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * 开启安全访问，根据UPM中权限进行判断
 *
 * @author SHUYI
 * @date 2018-4-11
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({SecurityAccessAutoConfiguration.class, RabbitMqConfig.class})
public @interface EnableSecurityAccess {
}
