package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

/**
 * 个人信息扩展表
 */
@Getter
@Setter
@Entity
@Table(name = "center_user_extension")
public class UserExtension {
    @Id
    @GenericGenerator(name = "jpa-uuid", strategy = "uuid")
    @GeneratedValue(generator = "jpa-uuid")
    private String id;
    /**
     * 用户编号
     */
    private String userId;

    /**
     * 真实姓名
     */
    private String realName;


    /**
     * 译员ID，专职格式为：T10000
     * 兼职译员ID：
     */
    private String translatorId;

    /**
     * 译员类型(专职1，兼职2)
     */
    private Integer translatorType;
    /**
     * 国籍
     */
    private String nationality;
    /**
     * 母语
     */
    private String motherTongue;
    /**
     * 生日(年-月-日)
     */
    private Timestamp birthday;
    /**
     * 翻译年限(单位：年)
     */
    private String translateYear;
    /**
     * 认证类型（身份证,护照）
     */
    private String certificateType;
    /**
     * 认证号码
     */
    private String certificateNum;

    /**
     * 模糊处理
     */
    private String certificateNumFuzzy;

    /**
     * 剩余认证次数
     */
    private Integer remainFrequency;

    /**
     * 认证是否通过（1：通过；0：未通过）
     */
    private Integer certificatePassed;

    /**
     * 个性化标签
     * 比如可提供排版；可对照图片进行翻译；可听译
     */
    private String individualization;

    /**
     * 擅长领域，最多选择5个
     */
    private String area;

    /**
     * 所属组别
     */
    private String ownGroup;

    /**
     * 岗位
     */
    private String station;

    /**
     * 职位
     */
    private String duty;

    /**
     * 在职 离职
     */
    private Integer onLeave;
    /**
     * 邀请码（四位）
     */
    private String invitationCode;
    /**
     * 记录创建时间
     */
    private Timestamp gmtCreate;
    /**
     * 更新时间
     */
    private Timestamp gmtUpdate;
    /**
     * 是否删除(1 为删除;0 为不删除)
     */
    private int deleted;

/*
    @OneToOne
    @JoinColumn(name = "userId")
    private  UserDOForPM userDOForPM;
*/

}
