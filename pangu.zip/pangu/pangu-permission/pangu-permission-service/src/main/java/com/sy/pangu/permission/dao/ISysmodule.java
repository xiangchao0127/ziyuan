package com.sy.pangu.permission.dao;

import com.sy.pangu.permission.domain.SysModuleDO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/20
 * Time:11:32
 */
public interface ISysmodule extends JpaRepository<SysModuleDO, String> {
    List<SysModuleDO> findAllByOrderByOrderAsc();
}
