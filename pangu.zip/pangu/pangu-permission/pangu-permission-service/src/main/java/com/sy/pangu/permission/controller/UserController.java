package com.sy.pangu.permission.controller;


import com.sy.pangu.common.util.BeanUtils;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.permission.domain.RoleDO;
import com.sy.pangu.permission.domain.UserDO;
import com.sy.pangu.permission.model.PageUtil;
import com.sy.pangu.permission.model.User;
import com.sy.pangu.permission.model.UserForPMParam;
import com.sy.pangu.permission.service.CustomerService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/14
 * Time:15:19
 */
@RestController
@RequestMapping("/user")
@Api(value = "/user", tags = "系统用户管理")
public class UserController {

    @Autowired
    private com.sy.pangu.permission.dao.IUser IUser;

    @Autowired
    CustomerService customerService;

    @ApiOperation("通过用户名查找用户")
    @PostMapping("/findUserByUsername/{username}")
    public User findUserByUserName(@PathVariable("username") String username) {
        UserDO userDO = IUser.findByAccount(username);
        if (userDO.getDeleted() != null && userDO.getDeleted()) {
            return null;
        }
        User user = new User();
        BeanUtils.copy(userDO, user);
        Set<RoleDO> roles = new HashSet<>();
        List<String> roleCodeList = new ArrayList<>();
        user.setRoleCodeList(roleCodeList);
        userDO.getOrgnizes().forEach(e -> roles.addAll(e.getRoleDOList()));
        userDO.getPositions().forEach(e -> roles.addAll(e.getRoleDOList()));
        roles.addAll(userDO.getRoleList());
        roles.forEach(e -> roleCodeList.add(e.getRoleCode()));
        return user;
    }

    @PostMapping("fingdByUserId/{id}")
    public User findUserById(@PathVariable("id") String id) {
        UserDO userDO = IUser.findById(id).get();
        User user = new User();
        BeanUtils.copy(userDO, user);
        return user;
    }

    @RequestMapping(value = "updateUserById", method = RequestMethod.POST)
    public User updateUserById(@RequestBody User user) {
        UserDO userDO = new UserDO();
        userDO.setId(user.getId());
        userDO.setAccount(user.getTelephone());
        userDO.setNickName(user.getNickName());
        userDO.setUserCode(user.getUserCode());
        userDO.setTelephone(user.getTelephone());
        userDO.setEmail(user.getEmail());
        userDO.setSex(user.getSex());
        userDO.setGmtUpdate(DateUtils.getCurrentTimeStamp());
        userDO.setQq(user.getQq());
        UserDO updatedUserDO = IUser.save(userDO);
        User updatedUser = new User();
        BeanUtils.copy(updatedUserDO, updatedUser);
        return updatedUser;
    }
    @ApiOperation("判断昵称是否存在")
    @PostMapping("findUserByNickName/{nickName}")
    public Integer findUserByNickName(@PathVariable("nickName") String nickName) {
        UserDO userDO = IUser.findByNickName(nickName);
        return null == userDO ? 0 : 1;
    }

    @ApiOperation("判断用户是否登录")
    @PostMapping("judgeUserLogin/{nickName}")
    public Integer judgeUserLogin(@PathVariable("nickName") String nickName){
        UserDO userDO = IUser.findByNickName(nickName);
        return null == userDO ? 0 : 1;
    }


    @ApiOperation("查询所有人员信息")
    @PostMapping("/getAllUserInfo")
    public PageUtil getAllUserInfo(UserForPMParam userForPMParam) {
        return customerService.getALlUserInfo(userForPMParam) ;
    }

}
