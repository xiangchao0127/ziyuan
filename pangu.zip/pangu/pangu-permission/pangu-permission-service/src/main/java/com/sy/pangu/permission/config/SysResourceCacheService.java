package com.sy.pangu.permission.config;

import com.sy.pangu.common.config.constants.ResourceCacheConstant;
import com.sy.pangu.common.event.SysResourceCacheRefreshEvent;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.dao.IPermisson;
import com.sy.pangu.permission.domain.PermissionDO;
import com.sy.pangu.permission.domain.RoleDO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * 平台资源权限配置
 *
 * @author LIQIU
 * @date 2018-1-8
 **/
@Component
@EnableCaching
@Slf4j
@CacheConfig(cacheNames = {
        ResourceCacheConstant.RESOURCE_HIERARCHY_CACHE,
        ResourceCacheConstant.URL_ROLE_MAPPING_CACHE,
        ResourceCacheConstant.URL_RESOURCE})
public class SysResourceCacheService implements InitializingBean, ApplicationEventPublisherAware {
    @Autowired
    private IPermisson permissonDao;
    @Autowired
    private CacheManager cacheManager;

    private ApplicationEventPublisher applicationEventPublisher;

    /**
     * 刷新缓存次数
     */
    private int cacheCount = 0;

    @Override
    @Transactional
    public void afterPropertiesSet() {
        this.doCacheAll();
    }

    /**
     * 加载系统缓存
     */
    public void doCacheAll() {
        log.info("Start load Resource,Role,Authority Cache, CacheManager:" + this.cacheManager);
        this.cacheAll();
        cacheCount++;
        if (cacheCount > 0) {
            this.applicationEventPublisher.publishEvent(new SysResourceCacheRefreshEvent(this));
        }
        log.info("Cache load finished");
    }

    private void cacheAll() {
        List<PermissionDO> list = permissonDao.findAll();
        Cache urlsCache = cacheManager.getCache(ResourceCacheConstant.URL_RESOURCE);
        urlsCache.clear();
        List<String> urlList = new ArrayList<>();
        Map<String, Set<String>> map = new HashMap<>();
        Cache urlRoleCache = cacheManager.getCache(ResourceCacheConstant.URL_ROLE_MAPPING_CACHE);
        urlRoleCache.clear();
        for (PermissionDO p : list) {
            if (!StringUtils.notEmpty(p.getPermissionUrl())) {
                continue;
            }
            urlList.add(p.getPermissionUrl());
            List<RoleDO> roles = p.getRoleDOList();
            int size = roles.size();
            Set<String> values = new HashSet<>(size);
            for (RoleDO role : roles) {
                values.add(role.getRoleCode());
            }
            map.put(p.getPermissionUrl(), values);
        }
        urlRoleCache.put(ResourceCacheConstant.URL_ROLE_MAPPING_CACHE, map);
        urlsCache.put(ResourceCacheConstant.URL_RESOURCE, urlList);
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.applicationEventPublisher = applicationEventPublisher;
    }
}
