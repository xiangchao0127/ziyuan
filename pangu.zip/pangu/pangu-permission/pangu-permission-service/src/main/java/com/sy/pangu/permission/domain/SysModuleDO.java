package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "sys_module")
@Getter
@Setter
@GenericGenerator(name = "jpa-uuid", strategy = "uuid")
public class SysModuleDO {
    /**
     * id
     */
    @Id
    @GeneratedValue(generator = "jpa-uuid")
    @Column(length = 32)
    private String id;
    /**
     * 模块code
     */
    private String moduleCode;
    /**
     * 模块名
     */
    private String moduleName;
    /**
     * 排序
     */
    private Integer order;

    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY, mappedBy = "sysModule")
    private List<PermissionDO> perMissions;


}
