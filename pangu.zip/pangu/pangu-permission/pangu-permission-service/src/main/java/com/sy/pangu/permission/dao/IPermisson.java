package com.sy.pangu.permission.dao;


import com.sy.pangu.permission.domain.PermissionDO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IPermisson extends JpaRepository<PermissionDO, String> {
    List<PermissionDO> findAllByBelongModuleId(String moduleId);

    List<PermissionDO> findAllByPermissionType(String type);
}
