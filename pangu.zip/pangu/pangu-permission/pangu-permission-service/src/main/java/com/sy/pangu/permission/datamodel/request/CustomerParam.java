package com.sy.pangu.permission.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class CustomerParam implements Serializable {
    /**
     * 电话号码
     */
    private String telephone;
    /**
     * 验证码
     */
    private String validateCode;
    /**
     * 密码
     */
    private String password;
    /**
     * 确认密码
     */
    private String rePassword;

    /**
     * 邀请码
     */
    private String invitationCode;
}
