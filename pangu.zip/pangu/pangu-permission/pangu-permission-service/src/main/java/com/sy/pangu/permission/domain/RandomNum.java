package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 随机数表 用于生成译员ID
 */
@Entity
@Table(name = "random_num")
@Getter
@Setter
public class RandomNum implements Serializable {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(length = 6)
    private Long id;
    private Integer used;
    private Timestamp gmtCreate;
    private Timestamp gmtUpdate;
}
