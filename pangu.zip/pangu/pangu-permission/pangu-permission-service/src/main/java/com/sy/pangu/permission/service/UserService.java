package com.sy.pangu.permission.service;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/25
 * Time:10:55
 */
public interface UserService {
}
