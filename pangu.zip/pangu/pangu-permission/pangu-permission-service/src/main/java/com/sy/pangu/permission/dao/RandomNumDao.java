package com.sy.pangu.permission.dao;

import com.sy.pangu.permission.domain.RandomNum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RandomNumDao extends JpaRepository<RandomNum,String>, JpaSpecificationExecutor<RandomNum> {

}
