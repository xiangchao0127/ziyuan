package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "sys_permission")
@Getter
@Setter
@GenericGenerator(name = "jpa-uuid", strategy = "uuid")
public class PermissionDO {
    /**
     * id
     */
    @Id
    @GeneratedValue(generator = "jpa-uuid")
    @Column(length = 32)
    private String id;

    private String permissionCode;
    private String permissionName;
    private String permissionUrl;
    private String permissionType;
    private String belongModuleId;

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER)
    @JoinTable(name = "sys_role_permission", joinColumns = {@JoinColumn(name = "permission_id")}, inverseJoinColumns = {@JoinColumn(name = "role_id")})
    private List<RoleDO> roleDOList;
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    @JoinColumn(name = "belongModuleId", insertable = false, updatable = false)
    private SysModuleDO sysModule;

    @Override
    public String toString() {
        return "PermissionDO{" +
                "id='" + id + '\'' +
                ", permissionCode='" + permissionCode + '\'' +
                ", permissionName='" + permissionName + '\'' +
                ", permissionUrl='" + permissionUrl + '\'' +
                ", permissionType='" + permissionType + '\'' +
                ", belongModuleId='" + belongModuleId + '\'' +
                ", roleDOList=" + roleDOList +
                '}';
    }
}
