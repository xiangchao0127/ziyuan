package com.sy.pangu.permission.service.impl;

import com.google.common.cache.Cache;
import com.sy.pangu.common.client.AuthClient;
import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.ConfUtils;
import com.sy.pangu.common.util.SmsUtils;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.dao.IUser;
import com.sy.pangu.permission.datamodel.request.UserRegisterParam;
import com.sy.pangu.permission.datamodel.request.UserUpdateInfoParam;
import com.sy.pangu.permission.domain.UserDO;
import com.sy.pangu.permission.model.UserDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Optional;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/23
 * Time:15:55
 */
public class UserServiceImpl {
    @Autowired
    IUser iUser;
    //    @Autowired
    JavaMailSender jms;
    @Autowired
    Cache<String, String> mailCache;
    //@Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;
    @Autowired
    AuthClient authClient;

    //@Override
    public int sendCode(String accountNum) {
        if (StringUtils.isPhone(accountNum)) {
            return this.sendTelCode(accountNum);
        } else if (StringUtils.isEmail(accountNum)) {
            return this.sendEmailCode(accountNum);
        } else {
            throw new CustomException(ExceptionEnum.VERIFICATION_CODE_NOT_SEND, "账号格式错误");
        }
    }

    public int sendTelCode(String telephone) {
        String randomVcode = SmsUtils.createRandomVcode();
        // TODO: 2018/12/4  对接短信接口
        //将验证码放入缓存
        mailCache.put(telephone, randomVcode);
        return 1;
    }

    //@Override
    public int sendEmailCode(String email) {
        //建立邮件消息
        SimpleMailMessage mainMessage = new SimpleMailMessage();
        String userFrom = ConfUtils.getInstance().getConfig("mail.username");
        //发送者
        mainMessage.setFrom(userFrom);
        //接收者
        mainMessage.setTo(email);
        //发送的标题
        mainMessage.setSubject("注册验证码");
        String code = SmsUtils.createRandomVcode();
        //发送的内容
        mainMessage.setText("验证码:" + code);
        mailCache.put(email, code);
        jms.send(mainMessage);
        return 1;
    }

    //@Override
    public int register(UserRegisterParam userRegisterParam, Boolean verifyCode) {
        if (verifyCode) {
            String code = mailCache.getIfPresent(userRegisterParam.getAccount());
            if (StringUtils.isEmpty(code)) {
                throw new CustomException(ExceptionEnum.VERIFICATION_CODE_NOT_SEND);
            }
            if (!"code".equals(userRegisterParam.getCode())) {
                throw new CustomException(ExceptionEnum.VERIFICATION_CODE_ERROR);
            }
        }
        String account = userRegisterParam.getAccount();
        Optional<UserDO> optionalUserDO = this.isEnableUserAccount(account);
        if (optionalUserDO.isPresent()) {
            throw new CustomException(ExceptionEnum.USER_ALREADY_EXISTS, "用户已被注册");
        }
        UserDO user = new UserDO();
        user.setUserType("客户");
        user.setAccount(userRegisterParam.getAccount());
        if (StringUtils.isPhone(account)) {
            user.setTelephone(account);
        } else if (StringUtils.isEmail(account)) {
            user.setEmail(account);
        }
        user.setPassword(bCryptPasswordEncoder.encode(userRegisterParam.getPassword()));
        iUser.save(user);
        return 1;
    }

    //@Override
    public int updateUser(UserUpdateInfoParam userUpdateInfoParam) {
        UserDetail userDetail = (UserDetail) authClient.getUser();
        UserDO user = iUser.getOne(userDetail.getUser().getId());
        user.setUserName(userUpdateInfoParam.getUserName());
//        user.setBusinessType(userUpdateInfoParam.getBusinessType());
//        user.setCompanyName(userUpdateInfoParam.getCompanyName());
        user.setSex(userUpdateInfoParam.getSex());
        user.setPicturePath(userUpdateInfoParam.getPicturePath());
        user.setNickName(userUpdateInfoParam.getNickName());
        iUser.save(user);
        return 1;
    }

    //@Override
    public int associationQQ(String qq) {
        return 0;
    }

    //@Override
    public int associationWeiXin(String weixin) {
        return 0;
    }

    //@Override
    public int associationAccount(String account) {
        return 0;
    }

    private Optional<UserDO> isEnableUserAccount(String account) {
        UserDO userDO = null;
        if (StringUtils.isMobile(account)) {
            userDO = iUser.findByTelephone(account);
            return Optional.of(userDO);
        } else if (StringUtils.isEmail(account)) {
            userDO = iUser.findByEmail(account);
            return Optional.of(userDO);
        }
        userDO = iUser.findByAccount(account);
        return Optional.of(userDO);

    }

    private Optional<UserDO> getUserByAccount(String account, String type) {
        UserDO userDO = null;
        if (StringUtils.isMobile(account)) {
            userDO = iUser.findByTelephoneAndUserTypeAndDeleted(account, type, false);
            return Optional.of(userDO);
        } else if (StringUtils.isEmail(account)) {
            userDO = iUser.findByEmailAndUserTypeAndDeleted(account, type, false);
            return Optional.of(userDO);
        }
        userDO = iUser.findByAccountAndUserTypeAndDeleted(account, type, false);
        return Optional.of(userDO);
    }

    private <K> K getEntity(String id, JpaRepository<K, String> dao) {
        K t = dao.getOne(id);
        if (t == null) {
            throw new CustomException(ExceptionEnum.ID_EXCEPTION, "未找到记录");
        }
        Class clazz = t.getClass();
        try {
            Method method = clazz.getMethod("getUserId");
            String userid = (String) method.invoke(t);
            UserDetail userDetail = (UserDetail) authClient.getUser();
            if (userDetail.getUser().getId() != userid) {
                throw new CustomException(ExceptionEnum.ID_EXCEPTION, "记录不属于该用户");
            }
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
        return t;
    }

}
