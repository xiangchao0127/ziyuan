package com.sy.pangu.permission.datamodel.request;

import lombok.Data;

/**
 * @author XiangChao
 * @date 2019/3/11
 */
@Data
public class CustomerRegisterParam {
    /**
     * 用户名
     */
    private String userName;
    /**
     * email
     */
    private String email;
    /**
     * 电话号码
     */
    private String telephone;
    /**
     * 验证码
     */
    private String validateCode;
    /**
     * 密码
     */
    private String password;
    /**
     * 确认密码
     */
    private String rePassword;


    /**
     * 邀请码
     */
    private  String invitationCode;
}
