package com.sy.pangu.permission.dao;




import com.sy.pangu.permission.domain.OrgnizeDO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/19
 * Time:15:14
 */
public interface IOrgnize extends JpaRepository<OrgnizeDO, String> {
    List<OrgnizeDO> findAllByParentId(String parentId);
}
