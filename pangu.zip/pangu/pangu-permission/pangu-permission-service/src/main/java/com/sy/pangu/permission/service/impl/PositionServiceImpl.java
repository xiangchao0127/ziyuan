package com.sy.pangu.permission.service.impl;

import com.sy.pangu.permission.dao.IPosition;
import com.sy.pangu.permission.domain.PositionDO;
import com.sy.pangu.permission.domain.RoleDO;
import com.sy.pangu.permission.domain.UserDO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/20
 * Time:15:08
 */
@Service
public class PositionServiceImpl {
    @Autowired
    private IPosition iPosition;

    //角色集合
    public List<RoleDO> getRoles(String positionId) {
        return iPosition.getOne(positionId).getRoleDOList();
    }

    //用户列表
    public List<UserDO> listUsers(String positionId) {
        return iPosition.getOne(positionId).getUsers();
    }

    //添加职位
    public int addPosition(PositionDO position) {
        iPosition.save(position);
        return 1;
    }

    //更新职位
    public int updatePosition(PositionDO position) {
        iPosition.save(position);
        return 1;
    }

    //删除职位
    public int deletePosition(String positionId) {
        iPosition.delete(iPosition.getOne(positionId));
        return 1;
    }

}
