package com.sy.pangu.permission.dao;


import com.sy.pangu.permission.domain.RoleDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IRole extends JpaRepository<RoleDO, String> {
    RoleDO findByRoleCode(String roleCode);

    RoleDO findByRoleName(String roleName);

    @Query(nativeQuery = true, value = "insert into sys_role_permission (role_id,permission_id) values (?,?)")
    void addPermissionInRole(String roleId, String permissionId);

    @Query(nativeQuery = true, value = "delete from sys_role_permission where role_id=? and permission_id=?")
    void deletePermissionInRole(String roleId, String permissionId);

    @Query(nativeQuery = true, value = "insert into sys_role_orgnize (role_id,orgnize_id) values (?,?)")
    void addOrgnizeInRole(String roleId, String orgnizeId);

    @Query(nativeQuery = true, value = "delete from sys_role_orgnize where role_id=? and orgnize_id=?")
    void deleteOrgnizeInRole(String roleId, String orgnizeId);

    @Query(nativeQuery = true, value = "insert into sys_role_position (role_id,position_id) values (?,?)")
    void addPositionInRole(String roleId, String positionId);

    @Query(nativeQuery = true, value = "delete from sys_role_position where role_id=? and position_id=?")
    void deletePositionInRole(String roleId, String positionId);


}
