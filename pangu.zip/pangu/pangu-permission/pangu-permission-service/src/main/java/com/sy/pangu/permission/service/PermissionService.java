package com.sy.pangu.permission.service;

import com.sy.pangu.permission.domain.PermissionDO;
import com.sy.pangu.permission.domain.SysModuleDO;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/25
 * Time:10:55
 */
public interface PermissionService {
    /**
     * 所有系统模块
     *
     * @return
     */
    List<SysModuleDO> listAllSysmodule();

    /**
     * 新增模块
     *
     * @param sysModule
     * @return
     */
    int saveNewModule(SysModuleDO sysModule);

    /**
     * 模块新增权限
     *
     * @param moduleId
     * @param permission
     * @return
     */
    int saveNewPermissionInModule(String moduleId, PermissionDO permission);

    /**
     * 绑定权限
     *
     * @param moduleId
     * @param permissionId
     * @return
     */
    int bandPermissionInModule(String moduleId, String permissionId);

    /**
     * 解除绑定
     *
     * @param moduleId
     * @param permissionId
     * @return
     */
    int removePermissionInModule(String moduleId, String permissionId);


    /**
     * 模块删除权限
     *
     * @param permissionId
     * @return
     */
    int deletePermission(String permissionId);

    /**
     * 删除模块
     *
     * @param id
     * @return
     */
    int deleteModule(String id);

    /**
     * 更新模块
     *
     * @param sysModule
     * @return
     */
    int updateModule(SysModuleDO sysModule);

    /**
     * 更新权限
     *
     * @param permission
     * @return
     */
    int updatePermission(PermissionDO permission);

    /**
     * 所有权限
     *
     * @return
     */
    List<PermissionDO> listAllPermissions();

    /**
     * 模块下权限
     *
     * @param moduleId
     * @return
     */
    List<PermissionDO> listModulePermissions(String moduleId);

}
