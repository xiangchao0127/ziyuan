package com.sy.pangu.permission.service.impl;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.dao.IRole;
import com.sy.pangu.permission.dao.IUser;
import com.sy.pangu.permission.domain.UserDO;
import com.sy.pangu.permission.service.SystemUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author XiangChao
 * @date 2019/2/12
 */
@SuppressWarnings("ALL")
@Component
public class SystemUserServiceImpl implements SystemUserService {
    @Autowired
    IUser iUser;
    @Autowired
    IRole iRole;

    BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

    @Override
    public Page<UserDO> listUsers(String department, String role, String name, int pageNo, int pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return iUser.findAll((root, cq, cb) -> {
            List<Predicate> list = new ArrayList<>();
            if (StringUtils.notEmpty(name)) {
                list.add(cb.equal(root.get("userName"), name));
            }
            if (StringUtils.notEmpty(department)) {
                list.add(cb.equal(root.get("department"), department));
            }
            if (StringUtils.notEmpty(role)) {
                list.add(cb.equal(root.get("roleList").get("roleName"), role));
            }
            list.add(cb.equal(root.get("userType"), "1"));
            cq.where(list.toArray(new Predicate[0])).orderBy(cb.desc(root.get("gmtCreate")));
            return cq.getRestriction();
        }, pageable);
    }

   /* @Override
    public int addSystemUser(AddSystemUserParam addSystemUserParam) {
        UserDO userDOByUserName = iUser.findUserDOByUserName(addSystemUserParam.getName());
        if (userDOByUserName != null) {
            throw new CustomException(ExceptionEnum.USER_ALREADY_EXISTS);
        }
        List<RoleDO> rolees = new ArrayList<>();
        addSystemUserParam.getRoles().forEach(r -> {
            RoleDO byRoleName = iRole.findByRoleName(r);
            rolees.add(byRoleName);
        });
        UserDO user = new UserDO();
        user.setUserName(addSystemUserParam.getName());
        user.setTelephone(addSystemUserParam.getTelephone());
        user.setDepartment(addSystemUserParam.getDepartment());
        user.setPassword("{bcrypt}" + bCryptPasswordEncoder.encode(addSystemUserParam.getPassword()));
        user.setRoleList(rolees);
        iUser.save(user);
        return 1;
    }*/

   /* @Override
    public int updateSystemUser(AddSystemUserParam addSystemUserParam) {
        UserDO user = iUser.getOne(addSystemUserParam.getId());
        if (user == null) {
            throw new CustomException(ExceptionEnum.USER_NOT_FOUND);
        }
        List<RoleDO> rolees = new ArrayList<>();
        addSystemUserParam.getRoles().forEach(r -> {
            RoleDO byRoleName = iRole.findByRoleName(r);
            rolees.add(byRoleName);
        });
        user.setUserName(addSystemUserParam.getName());
        user.setTelephone(addSystemUserParam.getTelephone());
        user.setDepartment(addSystemUserParam.getDepartment());
        user.setPassword("{bcrypt}" + bCryptPasswordEncoder.encode(addSystemUserParam.getPassword()));
        user.setRoleList(rolees);
        iUser.save(user);
        return 1;
    }*/

    @Override
    public int deleteSystemUser(String id) {
        iUser.isDeleted(id);
        return 1;
    }

    @Override
    public int isEnable(String id, String code) {
        iUser.isEnabled(id, code);
        return 1;
    }
}
