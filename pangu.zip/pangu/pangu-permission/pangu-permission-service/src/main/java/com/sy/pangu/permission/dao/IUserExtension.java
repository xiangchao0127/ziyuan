package com.sy.pangu.permission.dao;

import com.sy.pangu.permission.domain.UserExtension;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IUserExtension extends JpaRepository<UserExtension, String>, JpaSpecificationExecutor<UserExtension> {
}
