package com.sy.pangu.permission.dao;

import com.sy.pangu.permission.domain.PermissionDO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissonDao extends JpaRepository<PermissionDO, String> {


}
