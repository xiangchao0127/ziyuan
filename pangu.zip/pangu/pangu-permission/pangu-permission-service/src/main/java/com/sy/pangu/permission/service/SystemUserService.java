package com.sy.pangu.permission.service;

import com.sy.pangu.permission.domain.UserDO;
import org.springframework.data.domain.Page;

/**
 * @author XiangChao
 * @date 2019/2/12
 */
public interface SystemUserService {
    /**
     * 后台用户列表
     *
     * @param department 部门
     * @param role       角色
     * @param name       名字
     * @return
     */
    Page<UserDO> listUsers(String department, String role, String name, int pageNo, int pageSize);

    /**
     * 添加后台用户
     */
    //int addSystemUser(AddSystemUserParam addSystemUserParam);

    /**
     * 编辑后台用户
     */
    //int updateSystemUser(AddSystemUserParam addSystemUserParam);

    /**
     * 删除后台用户
     *
     * @param id
     * @return
     */
    int deleteSystemUser(String id);

    /**
     * 是否启用
     *
     * @param id
     * @param code 1 启用  0 禁用
     * @return
     */
    int isEnable(String id, String code);
}
