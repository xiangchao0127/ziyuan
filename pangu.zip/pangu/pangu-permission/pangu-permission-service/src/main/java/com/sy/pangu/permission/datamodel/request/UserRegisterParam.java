package com.sy.pangu.permission.datamodel.request;

import lombok.Data;

/**
 * @author XiangChao
 * @date 2018/12/4
 */
@Data
public class UserRegisterParam {
    /**
     * 账号
     */
    private String account;
    /**
     * 密码
     */
    private String password;
    /**
     * 验证码
     */
    private String code;
}
