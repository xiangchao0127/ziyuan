package com.sy.pangu.permission.datamodel.request;

import com.sy.pangu.common.enums.annotation.ParamValidate;
import com.sy.pangu.common.util.StringUtils;
import lombok.Data;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/2/13
 */
@Data
public class AddSystemUserParam {
    /**
     * id
     */
    String id;
    /**
     * 名字
     */
    String name;
    /**
     * 电话号码
     */
    @ParamValidate(name = "电话", regex = StringUtils.PHONE)
    String telephone;
    /**
     * 部门
     */
    String department;
    /**
     * 角色列表
     */
    List<String> roles;
    /**
     * 登录密码
     */
    String password;

}
