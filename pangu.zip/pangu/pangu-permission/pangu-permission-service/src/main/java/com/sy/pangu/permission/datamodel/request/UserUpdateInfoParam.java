package com.sy.pangu.permission.datamodel.request;

import lombok.Data;

/**
 * create with idea
 *
 * @author lhang
 * @date 2018/12/11
 * time 15:43
 */
@Data
public class UserUpdateInfoParam {
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 用户名
     */
    private String userName;
    /**
     * 性别
     */
    private String sex;
    /**
     * 头像路径
     */
    private String picturePath;
    /**
     * 业务类型
     */
    private Integer businessType;
    /**
     * 公司名称
     */
    private String companyName;
}
