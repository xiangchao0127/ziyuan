package com.sy.pangu.permission.controller;

import com.sy.pangu.permission.datamodel.request.CustomerRegisterParam;
import com.sy.pangu.permission.service.CustomerService;
import com.sy.pangu.rm.client.NoticeClient;
import com.sy.pangu.rm.model.LevelRelation;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customer")
@Api(value = "/customer", tags = "前端用户注册")
public class CustomerController {

    @Autowired
    com.sy.pangu.rm.client.LevelRelationClient levelRelationClient;


    @Autowired
    CustomerService customerService;

    /**
     * 用户注册
     */
    @PostMapping("/customerRegister")
    @ApiOperation("用户注册")
    public ResponseEntity<Integer> customerRegister(CustomerRegisterParam customerRegisterParam) {
        return ResponseEntity.ok().body(customerService.customerRegister(customerRegisterParam));
    }

    /**
     * 发送短信验证码
     */
    @GetMapping("/sendCode")
    @ApiOperation("发送短信验证码")
    public ResponseEntity<Integer> sendCode(String telephone) {
        return ResponseEntity.ok().body(customerService.sendCode(telephone));
    }

    /**
     * @param newPawwword 确认密码
     * @return
     */
    @PutMapping("/setNewPassword")
    @ApiOperation("重置密码第二步")
    public ResponseEntity<Integer> retrievePassword(String newPawwword) {
        return ResponseEntity.ok().body(customerService.setNewPassword(newPawwword));
    }

    @PutMapping("/resetPassword")
    @ApiOperation("重置密码第一步")
    public ResponseEntity<Integer> resetPassword(String tel, String verifyCode) {
        return ResponseEntity.ok().body(customerService.resetPassword(tel, verifyCode));
    }

    @Autowired
    NoticeClient noticeClient;

    @PutMapping("/hello")
    @ApiOperation("向某人发消息测试")
    public void tee(String sendPerson, String personId, String messageType, String content) {
        ResponseEntity.ok().body(noticeClient.sendToSomeOne(sendPerson, personId, messageType, content));
    }

    /**
     * 修改登录密码
     *
     * @param newPassword
     * @param renewPassword
     * @return
     */
    @ApiOperation("修改登录密码")
    @PutMapping("/renewPassword")
    public ResponseEntity<Integer> updatePassword(String oldPassword, String newPassword, String renewPassword) {
        return ResponseEntity.ok().body(customerService.updatePassword(oldPassword, newPassword, renewPassword));
    }

    @ApiOperation("test")
    @GetMapping("/test")
    public void test() {
        List<LevelRelation> xx = levelRelationClient.listAllLevelRelation();
        System.out.println(xx.size());
    }

}
