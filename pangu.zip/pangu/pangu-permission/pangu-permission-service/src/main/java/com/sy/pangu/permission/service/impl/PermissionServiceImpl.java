package com.sy.pangu.permission.service.impl;


import com.sy.pangu.permission.dao.IPermisson;
import com.sy.pangu.permission.dao.ISysmodule;
import com.sy.pangu.permission.domain.PermissionDO;
import com.sy.pangu.permission.domain.SysModuleDO;
import com.sy.pangu.permission.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/20
 * Time:11:30
 */
@Service
public class PermissionServiceImpl implements PermissionService {
    @Autowired
    private IPermisson iPermisson;
    @Autowired
    private ISysmodule iSysmodule;

    //所有模块
    public List<SysModuleDO> listAllSysmodule() {
        return iSysmodule.findAllByOrderByOrderAsc();
    }

    //保存新模块
    public int saveNewModule(SysModuleDO sysModule) {
        SysModuleDO newSysModule = new SysModuleDO();
        newSysModule.setModuleCode(sysModule.getModuleCode());
        newSysModule.setModuleName(sysModule.getModuleName());
        newSysModule.setOrder(sysModule.getOrder());
        iSysmodule.save(newSysModule);
        return 1;
    }

    //模块中添加新权限
    public int saveNewPermissionInModule(String moduleId, PermissionDO permission) {
        SysModuleDO sysModule = iSysmodule.getOne(moduleId);
        permission.setSysModule(sysModule);
        iPermisson.save(permission);
        return 1;
    }

    //模块中绑定权限
    public int bandPermissionInModule(String moduleId, String permissionId) {
        SysModuleDO sysModule = iSysmodule.getOne(moduleId);
        PermissionDO permission = iPermisson.getOne(permissionId);
        if (sysModule == null || permission == null) {
            return 0;
        }
        permission.setBelongModuleId(moduleId);
        iPermisson.save(permission);
        return 1;
    }

    //模块中解除绑定
    public int removePermissionInModule(String moduleId, String permissionId) {
        SysModuleDO sysModule = iSysmodule.getOne(moduleId);
        PermissionDO permission = iPermisson.getOne(permissionId);
        if (sysModule == null || permission == null || !moduleId.equals(permission.getBelongModuleId())) {
            return 0;
        }
        permission.setBelongModuleId(null);
        iPermisson.save(permission);
        return 1;
    }

    //删除权限
    public int deletePermission(String permissionId) {
        iPermisson.delete(iPermisson.getOne(permissionId));
        return 1;
    }

    //删除模块
    public int deleteModule(String id) {
        iSysmodule.delete(iSysmodule.getOne(id));
        return 1;
    }

    //更新模块
    public int updateModule(SysModuleDO sysModule) {
        iSysmodule.save(sysModule);
        return 1;
    }

    //更新权限
    public int updatePermission(PermissionDO permission) {
        iPermisson.save(permission);
        return 1;
    }

    //所有权限
    public List<PermissionDO> listAllPermissions() {
        return iPermisson.findAll();
    }

    //模块下permission
    public List<PermissionDO> listModulePermissions(String moduleId) {
        return iPermisson.findAllByBelongModuleId(moduleId);
    }

}
