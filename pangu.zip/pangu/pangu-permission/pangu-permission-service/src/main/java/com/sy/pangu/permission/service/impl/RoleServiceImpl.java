package com.sy.pangu.permission.service.impl;


import com.sy.pangu.permission.dao.IPermisson;
import com.sy.pangu.permission.dao.IRole;
import com.sy.pangu.permission.domain.PermissionDO;
import com.sy.pangu.permission.domain.RoleDO;
import com.sy.pangu.permission.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/20
 * Time:14:12
 */
@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private IRole iRole;
    @Autowired
    private IPermisson iPermisson;

    //所有角色
    public List<RoleDO> listAllRole() {
        return iRole.findAll();
    }

    //根据角色代码查找
    public RoleDO findOneByRoleCode(String roleCode) {
        return iRole.findByRoleCode(roleCode);
    }

    //根据角色名称查找
    public RoleDO findOneByRoleName(String roleName) {
        return iRole.findByRoleName(roleName);
    }

    //角色权限集合
    public List<PermissionDO> listRolePermissions(String roleId) {
        RoleDO role = iRole.getOne(roleId);
        return role.getPermissionDOList();
    }


    //添加新角色
    public int saveNewRole(RoleDO role) {
        iRole.save(role);
        return 1;
    }

    //删除角色
    public int deleteRole(String roleId) {
        iRole.delete(iRole.getOne(roleId));
        return 1;
    }

    //为角色添加权限
    public int addPermissionInRole(String roleId, String permissionId) {
        iRole.addPermissionInRole(roleId, permissionId);
        return 1;
    }

    //删除角色中权限
    public int deletePermissionInRole(String roleId, String permissionId) {
        iRole.deletePermissionInRole(roleId, permissionId);
        return 1;
    }

    //添加角色组织
    public int addOrgnizeInRole(String roleId, String orgnizeId) {
        iRole.addOrgnizeInRole(roleId, orgnizeId);
        return 1;
    }

    //删除角色组织
    public int deleteOrgnizeInRole(String roleId, String orgnizeId) {
        iRole.deleteOrgnizeInRole(roleId, orgnizeId);
        return 1;
    }

    //添加角色岗位
    public int addPositionInRole(String roleId, String positionId) {
        iRole.addPositionInRole(roleId, positionId);
        return 1;
    }

    //删除角色岗位
    public int deletePositionInRole(String roleId, String positionId) {
        iRole.deletePositionInRole(roleId, positionId);
        return 1;
    }
}
