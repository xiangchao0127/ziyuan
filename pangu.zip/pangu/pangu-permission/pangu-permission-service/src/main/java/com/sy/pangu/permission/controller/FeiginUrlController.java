package com.sy.pangu.permission.controller;

import com.sy.pangu.common.client.AuthClient;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/25
 * Time:11:06
 */
@RestController
@Api(tags = {"请求路径feigin"})
@RequestMapping("/sysInfo")
public class FeiginUrlController {
    @Autowired
    private AuthClient authClient;

    @GetMapping("/authUrls")
    public ResponseEntity getAllRequestUrl() {
        return authClient.getAllRequestUrl();
    }

}
