package com.sy.pangu.permission.controller;

import com.sy.pangu.common.client.AuthClient;
import com.sy.pangu.common.config.feign.RabbitMqConfig;
import com.sy.pangu.common.security.access.SecurityAccessMetadataSource;
import com.sy.pangu.permission.config.SysResourceCacheService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sys")
@Api(tags = {"系统设置"})
public class SystemController {
    @Autowired
    private SysResourceCacheService sysResourceCacheService;
    @Autowired
    private SecurityAccessMetadataSource securityAccessMetadataSource;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private AuthClient authClient;

    @GetMapping("/refreshCache")
    @ApiOperation("更新权限缓存")
    public ResponseEntity<Integer> reCacheRoleUrls() {
        sysResourceCacheService.doCacheAll();
        rabbitTemplate.convertAndSend(RabbitMqConfig.exchangeName,"","refresh");
        return ResponseEntity.ok().body(1);
    }

    @Async
    public void refreshClients() {
        securityAccessMetadataSource.loadUrlRoleMapping();
        authClient.refreshFileterCache();
    }
}
