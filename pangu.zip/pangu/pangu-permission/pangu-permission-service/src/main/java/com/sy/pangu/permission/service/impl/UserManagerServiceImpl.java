package com.sy.pangu.permission.service.impl;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.dao.IOrgnize;
import com.sy.pangu.permission.dao.IPosition;
import com.sy.pangu.permission.dao.IUser;
import com.sy.pangu.permission.domain.OrgnizeDO;
import com.sy.pangu.permission.domain.PositionDO;
import com.sy.pangu.permission.domain.RoleDO;
import com.sy.pangu.permission.domain.UserDO;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/28
 * Time:10:39
 */
public class UserManagerServiceImpl {
    @Autowired
    private IUser iUser;
    @Autowired
    private IPosition iPosition;
    @Autowired
    private IOrgnize iOrgnize;

    //用户本身角色
    public List<RoleDO> getUserRoles(String userId) {
        return iUser.getOne(userId).getRoleList();
    }

    //用户所有角色
    public Set<RoleDO> getAllRoles(String userId) {
        UserDO user = iUser.getOne(userId);
        Set<RoleDO> result = new HashSet<>();
        user.getPositions().forEach(e -> result.addAll(e.getRoleDOList()));
        user.getOrgnizes().forEach(e -> result.addAll(e.getRoleDOList()));
        result.addAll(user.getRoleList());
        return result;
    }

    public UserDO getUser(String userAccount) {
        return iUser.findByAccount(userAccount);
    }

    //搜索用户
    public List<UserDO> findUsers(String account, String userName) {
        List<UserDO> users = iUser.findAll((root, cq, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (StringUtils.notEmpty(account)) {
                predicates.add(cb.like(root.get("account"), account));
            }
            if (StringUtils.notEmpty(userName)) {
                predicates.add(cb.like(root.get("userName"), userName));
            }
            cq.where(predicates.toArray(new Predicate[0]));
            return cq.getRestriction();
        });
        return users;
    }

    //添加角色
    public int addRole(String userId, String roleId) {
        iUser.addRole(userId, roleId);
        return 1;
    }

    //移除角色
    public int removeRole(String userId, String roleId) {
        iUser.deleteRole(userId, roleId);
        return 1;
    }

    //列举职位
    public List<PositionDO> listPositions(String uesrId) {
        return iUser.getOne(uesrId).getPositions();
    }

    //添加职位
    public int addPosition(String userId, String positionId) {
        iUser.addPosition(userId, positionId);
        return 1;
    }

    //移除职位
    public int removePosition(String userId, String positionId) {
        iUser.deletePosition(userId, positionId);
        return 1;
    }

    //列举组织
    public List<OrgnizeDO> listOrgnizes(String userId) {
        return iUser.getOne(userId).getOrgnizes();
    }

    //添加组织
    public int addOrgnize(String userId, String orgnizeId) {
        iUser.addOrgnize(userId, orgnizeId);
        return 1;
    }

    //移除组织
    public int removeOrgnize(String userId, String orgnizeId) {
        iUser.deleteOrgnize(userId, orgnizeId);
        return 1;
    }


}
