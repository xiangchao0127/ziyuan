package com.sy.pangu.permission.service.impl;

import com.sy.pangu.permission.dao.IOrgnize;
import com.sy.pangu.permission.domain.OrgnizeDO;
import com.sy.pangu.permission.domain.RoleDO;
import com.sy.pangu.permission.domain.UserDO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/19
 * Time:14:53
 */
public class OrgnizeServiceImpl {
    @Autowired
    private IOrgnize iOrgnize;

    // 根据父id获取子列表
    public List<OrgnizeDO> getOrgByParentId(String pId) {
        return iOrgnize.findAllByParentId(pId);
    }


    // 根据id获取详情,包含父组织
    public Object getOrgById(String id) {
        //todo
        return null;
    }

    //组织角集合
    public List<RoleDO> getRoles(String orgnizeId) {
        return iOrgnize.getOne(orgnizeId).getRoleDOList();
    }

    //用户列表
    public List<UserDO> listUsers(String orgnizeId) {
        return iOrgnize.getOne(orgnizeId).getUsers();
    }


    // 获取完整的组织机构树 递归算法
    public List<OrgnizeDO> getOrgTree() {
        List<OrgnizeDO> list = iOrgnize.findAll();
        if (list == null || list.isEmpty()) {
            return list;
        }
        List<OrgnizeDO> rootOrgs = list.stream().filter(e -> e.getParentId().equals("0")).collect(Collectors.toList());
        return recOrgTree(rootOrgs, list);
    }

    //hashmap
    public List<OrgnizeDO> getOrgTree2() {
        List<OrgnizeDO> list = iOrgnize.findAll();
        if (list == null || list.isEmpty()) {
            return list;
        }
        Map<String, OrgnizeDO> map = new HashMap<>();
        List<OrgnizeDO> root = new ArrayList<>();
        list.forEach(e -> {
            e.setChildren(new ArrayList<>());
            map.put(e.getId(), e);
            if (e.getParentId().equals("0")) {
                root.add(e);
            }
        });
        for (Map.Entry<String, OrgnizeDO> entry : map.entrySet()) {
            OrgnizeDO orgnize = entry.getValue();
            String parentid = orgnize.getParentId();
            OrgnizeDO parent = map.get(parentid);
            if (parent == null) {
                continue;
            }
            List<OrgnizeDO> children = parent.getChildren();
            children.add(orgnize);
        }
        return root;
    }

    //添加组织
    public int saveOrgnize(OrgnizeDO orgnize) {
        iOrgnize.save(orgnize);
        return 1;
    }

    //更新组织
    public int updateOrgnize(OrgnizeDO orgnize) {
        iOrgnize.save(orgnize);
        return 1;
    }

    //删除组织
    public int deleteOrgnize(String orgnizeId) {
        iOrgnize.delete(iOrgnize.getOne(orgnizeId));
        return 1;
    }

    private List<OrgnizeDO> recOrgTree(List<OrgnizeDO> orgs, List<OrgnizeDO> src) {
        for (OrgnizeDO child : orgs) {
            List<OrgnizeDO> cd = src.stream().filter(e -> e.getParentId().equals(child.getId())).collect(Collectors.toList());
            recOrgTree(cd, src);
            child.setChildren(cd);
        }
        return orgs;
    }

    //测试
//    public static void main(String[] args) {
//        String json = "[\n" +
//                "{\"id\":\"1\",\"parentId\":\"0\"},\n" +
//                "{\"id\":\"2\",\"parentId\":\"0\"},\n" +
//                "{\"id\":\"3\",\"parentId\":\"1\"},\n" +
//                "{\"id\":\"4\",\"parentId\":\"1\"},\n" +
//                "{\"id\":\"5\",\"parentId\":\"2\"},\n" +
//                "{\"id\":\"6\",\"parentId\":\"5\"},\n" +
//                "{\"id\":\"7\",\"parentId\":\"3\"}\n" +
//                "]";
//        List<OrgnizeDO> list1 = JSON.parseArray(json,OrgnizeDO.class);
//        List<OrgnizeDO> list2 = JSON.parseArray(json,OrgnizeDO.class);
//        for (OrgnizeDO o : list1){
//            System.out.println(o.getId()+":"+o.getParentId());
//        }
//        OrgnizeServiceImpl oi = new OrgnizeServiceImpl();
//        List list11 = oi.getOrgTree(list1);
//        List list22 = oi.getOrgTree2(list2);
//
//        System.out.println(JSON.toJSONString(list11));
//        System.out.println(JSON.toJSONString(list22));
//    }


}
