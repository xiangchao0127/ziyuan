package com.sy.pangu.permission.datamodel.request;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class FetchUserW3Param implements Serializable {

    /**
     * 工号
     */
    private String staffId;
    /**
     * 姓名
     */
    private String realName;
    /**
     * 组别
     */
    private String ownGroup;

    /**
     * 岗位
     */
    private String station;

    /**
     * 职务
     */
    private String duty;

    /**
     * 语言对1
     */
    private String languagePair1;

    /**
     * 等级1
     */
    private String level1;

    /**
     * 领域1(顿号分隔)
     */
    private String area1;


    /**
     * 语言对2
     */
    private String languagePair2;


    /**
     * 等级2
     */
    private String level2;


    /**
     * 领域2
     */
    private String area2;


    /**
     * 离职（0）、在职（1）
     */
    private Integer onLeave;
}
