package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/19
 * Time:14:11
 * 岗位表
 */
@Entity
@Table(name = "sys_position")
@Getter
@Setter
@GenericGenerator(name = "jpa-uuid", strategy = "uuid")
public class PositionDO {
    /**
     * id
     */
    @Id
    @GeneratedValue(generator = "jpa-uuid")
    @Column(length = 32)
    private String id;
    private String parentId;
    /**
     * 组织id
     */
    private String orgId;
    /**
     * 岗位名称
     */
    private String name;
    /**
     * 岗位代码
     */
    private String code;
    /**
     * 备注
     */
    private String remark;


    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    @JoinTable(name = "sys_role_position", joinColumns = {@JoinColumn(name = "position_id")}, inverseJoinColumns = {@JoinColumn(name = "role_id")})
    private List<RoleDO> roleDOList;


    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    @JoinTable(name = "sys_user_position", joinColumns = {@JoinColumn(name = "position_id")}, inverseJoinColumns = {@JoinColumn(name = "user_id")})
    private List<UserDO> users;

}
