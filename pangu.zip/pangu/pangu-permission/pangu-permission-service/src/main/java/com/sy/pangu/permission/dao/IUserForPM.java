package com.sy.pangu.permission.dao;


import com.sy.pangu.permission.domain.UserDOForPM;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/15
 * Time:10:20
 */
public interface IUserForPM extends JpaRepository<UserDOForPM, String>, JpaSpecificationExecutor<UserDOForPM> {



}
