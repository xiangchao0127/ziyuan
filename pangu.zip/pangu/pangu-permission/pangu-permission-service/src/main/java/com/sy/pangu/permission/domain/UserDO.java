package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

/**
 * 用户
 *
 * @author XiangChao
 * @date 2018/12/4
 */
@Entity
@Table(name = "sys_user")
@Getter
@Setter
//@GenericGenerator(name = "jpa-uuid", strategy = "uuid")
public class UserDO {
    /**
     * id
     */
    @Id
    @GenericGenerator(name = "jpa-uuid", strategy = "uuid")
    @GeneratedValue(generator = "jpa-uuid")
    private String id;
    /**
     * 创建时间
     */
    private Timestamp gmtCreate;
    /**
     * 更新时间
     */
    private Timestamp gmtUpdate;
    /**
     * 是否删除 (0:false  1:true)
     */
    private Boolean deleted;
    /**
     * 最后登录时间
     */
    private Timestamp lastLoginTime;
    /**
     * 部门名称
     */
    private String department;
    /**
     * 编号
     */
    private String userCode;
    /**
     * 名称
     */
    private String userName;
    /**
     * 账号
     */
    private String account;
    /**
     * 密码
     */
    private String password;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 地址
     */
    private String address;
    /**
     * email
     */
    private String email;
    /**
     * 头像路径
     */
    private String picturePath;
    /**
     * 性别
     */
    private String sex;
    /**
     * 身份证
     */
    private String idCard;
    /**
     * 微信
     */
    private String weixin;
    /**
     * qq
     */
    private String qq;
    /**
     * 电话
     */
    private String telephone;
    /**
     * 用户类型（后台，前台）
     */
    private String userType;
    /**
     * 是否启用(1:启用 0:禁用)
     */
    private Boolean isEnabled;
    /**
     * 角色
     */
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "sys_role_user", joinColumns = {@JoinColumn(name = "user_id")}, inverseJoinColumns = {@JoinColumn(name = "role_id")})
    private List<RoleDO> roleList;
    /**
     * 组织
     */
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "sys_user_orgnize", joinColumns = {@JoinColumn(name = "user_id")}, inverseJoinColumns = {@JoinColumn(name = "orgnize_id")})
    private List<OrgnizeDO> orgnizes;
    /**
     * 岗位
     */
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "sys_user_position", joinColumns = {@JoinColumn(name = "user_id")}, inverseJoinColumns = {@JoinColumn(name = "position_id")})
    private List<PositionDO> positions;

}
