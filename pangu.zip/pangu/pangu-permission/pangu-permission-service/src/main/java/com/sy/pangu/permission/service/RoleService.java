package com.sy.pangu.permission.service;

import com.sy.pangu.permission.domain.RoleDO;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/28
 * Time:10:31
 */
public interface RoleService {
    /**
     * 所有角色
     *
     * @return
     */
    List<RoleDO> listAllRole();

    /**
     * 精确匹配
     *
     * @param roleCode
     * @return
     */
    RoleDO findOneByRoleCode(String roleCode);

    /**
     * 添加角色
     *
     * @param role
     * @return
     */
    int saveNewRole(RoleDO role);

    /**
     * 删除角色
     *
     * @param roleId
     * @return
     */
    int deleteRole(String roleId);

    /**
     * 添加角色权限
     *
     * @param roleId
     * @param permissionId
     * @return
     */
    int addPermissionInRole(String roleId, String permissionId);

    /**
     * 删除角色权限
     *
     * @param roleId
     * @param permissionId
     * @return
     */
    int deletePermissionInRole(String roleId, String permissionId);

    /**
     * 添加角色组织
     *
     * @param roleId
     * @param orgnizeId
     * @return
     */
    int addOrgnizeInRole(String roleId, String orgnizeId);

    /**
     * 删除角色组织
     *
     * @param roleId
     * @param orgnizeId
     * @return
     */
    int deleteOrgnizeInRole(String roleId, String orgnizeId);

    /**
     * 添加角色岗位
     *
     * @param roleId
     * @param positionId
     * @return
     */
    int addPositionInRole(String roleId, String positionId);

    /**
     * 删除角色岗位
     *
     * @param roleId
     * @param positionId
     * @return
     */
    int deletePositionInRole(String roleId, String positionId);
}
