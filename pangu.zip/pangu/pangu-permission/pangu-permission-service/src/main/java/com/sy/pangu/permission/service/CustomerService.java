package com.sy.pangu.permission.service;

import com.sy.pangu.permission.datamodel.request.CustomerRegisterParam;
import com.sy.pangu.permission.model.PageUtil;
import com.sy.pangu.permission.model.UserForPMParam;

public interface CustomerService {


    /**
     * 用户注册
     */
    int customerRegister(CustomerRegisterParam customerRegisterParam);

    /**
     * 发送短信验证码
     */
    int sendCode(String telephone);

    /**
     * 重置密码
     */
    int setNewPassword(String newPawwword);


    int resetPassword(String tel,String verifyCode);


    int updatePassword(String oldPassword,String newPassword,String renewPassword);


  PageUtil getALlUserInfo(UserForPMParam userForPMParam);


}
