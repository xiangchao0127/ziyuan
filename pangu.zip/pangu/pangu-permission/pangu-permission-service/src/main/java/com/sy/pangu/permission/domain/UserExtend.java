package com.sy.pangu.permission.domain;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "center_user_extend")
public class UserExtend implements Serializable {
    @Id
    @GenericGenerator(name = "jpa-uuid", strategy = "uuid")
    @GeneratedValue(generator = "jpa-uuid")
    private String id;
    private String userId;

    private String sourceLangauge;

    private String targetLangauge;

    private String levelId;

    private String levelName;

    private String areaId;

    private String areaName;

    private String serviceId;

    private String serviceName;

    private Timestamp gmtCreate;
    /**
     * 更新时间
     */
    private Timestamp gmtUpdate;
    /**
     * 是否删除
     */
    private Integer deleted;


    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private UserDOForPM userDOForPM;

}
