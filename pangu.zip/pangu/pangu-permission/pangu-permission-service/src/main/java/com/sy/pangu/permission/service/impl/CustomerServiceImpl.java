package com.sy.pangu.permission.service.impl;

import com.google.common.cache.Cache;
import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.StaffType;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.common.util.SecurityUtils;
import com.sy.pangu.common.util.SmsUtils;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.dao.IUser;
import com.sy.pangu.permission.dao.IUserExtension;
import com.sy.pangu.permission.dao.IUserForPM;
import com.sy.pangu.permission.dao.RandomNumDao;
import com.sy.pangu.permission.datamodel.request.CustomerRegisterParam;
import com.sy.pangu.permission.domain.RandomNum;
import com.sy.pangu.permission.domain.UserDO;
import com.sy.pangu.permission.domain.UserDOForPM;
import com.sy.pangu.permission.domain.UserExtension;
import com.sy.pangu.permission.model.PageUtil;
import com.sy.pangu.permission.model.UserExtend;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.permission.model.UserForPMParam;
import com.sy.pangu.permission.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    IUser iUser;

    @Autowired
    IUserForPM iUserForPM;

    @Autowired
    Cache<String, String> cache;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    RandomNumDao randomNumDao;

    @Autowired
    IUserExtension iUserExtension;

    @Override
    public int customerRegister(CustomerRegisterParam customerParam) {
        String telphone = customerParam.getTelephone();
        //判断手机号是否正确
        if (StringUtils.isEmpty(telphone) || !StringUtils.isMobile(telphone)) {
            throw new CustomException("手机号不正确");
        }
        if (customerParam.getPassword().length() < 6) {
            throw new CustomException("密码长度不符合要求");
        }
        UserDO byTelephone = iUser.findByTelephone(telphone);
        if (byTelephone != null) {
            throw new CustomException(ExceptionEnum.PHONE_ALREADY_EXISTS);
        }
        //比较验证码是否存在以及是否过期
        String validateCode = customerParam.getValidateCode();
        if (!validateCode.equals(cache.getIfPresent(telphone))) {
            throw new CustomException(ExceptionEnum.VERIFICATION_CODE_ERROR);
        }
        RandomNum randomNum = new RandomNum();
        randomNum.setUsed(1);
        RandomNum savedRandomNum = randomNumDao.save(randomNum);
        UserDO userDO = new UserDO();
        String userCode = "T" + String.format("%06d", savedRandomNum.getId());
        userDO.setUserCode(userCode);
        userDO.setIsEnabled(true);
        userDO.setGmtCreate(DateUtils.getCurrentTimeStamp());
        //userDO.setUserName(telphone);
        userDO.setAccount(telphone);
        userDO.setUserType("0");
        userDO.setTelephone(telphone);
        userDO.setPassword("{bcrypt}" + bCryptPasswordEncoder.encode(customerParam.getPassword()));
        UserDO savedUserDO = iUser.save(userDO);
        UserExtension userExtension = new UserExtension();
        userExtension.setTranslatorId(userCode);
        userExtension.setUserId(savedUserDO.getId());
        userExtension.setTranslatorType(StaffType.兼职.getStaffType());
        iUserExtension.save(userExtension);
        return 1;
    }

    @Override
    public int sendCode(String telephone) {
        if (!StringUtils.isMobile(telephone)) {
            throw new CustomException("无效的手机号");
        }
        String randomVcode = SmsUtils.createRandomVcode();
        SmsUtils.send(randomVcode, telephone);
        cache.put(telephone, randomVcode);
        return 1;
    }

    @Override
    public int setNewPassword(String newPawwword) {
        if (newPawwword.length() < 6) {
            throw new CustomException("两次输入密码不一致");
        }
        UserDO userDOByUserName = iUser.findUserDOByUserName(SecurityUtils.getUsername());
        userDOByUserName.setPassword("{bcrypt}" + bCryptPasswordEncoder.encode(newPawwword));
        iUser.save(userDOByUserName);
        return 1;
    }


    @Override
    public int resetPassword(String tel, String verifyCode) {
        if (!StringUtils.isMobile(tel)) {
            throw new CustomException("短信号格式步正确");
        }
        if (!verifyCode.equals(cache.getIfPresent(tel))) {
            throw new CustomException(ExceptionEnum.VERIFICATION_CODE_ERROR);
        }
        return 1;
    }


    @Override
    public int updatePassword(String oldPassword,String newPassword, String renewPassword) {
        UserDO userDOByUserName = iUser.findUserDOByUserName(SecurityUtils.getUsername());
        if (userDOByUserName!=null&&userDOByUserName.getPassword()!=null){
            if (!bCryptPasswordEncoder.matches(oldPassword,userDOByUserName.getPassword().replace("{bcrypt}",""))){
                throw new CustomException(ExceptionEnum.OLD_PASSWORD_ERROR);
            }
        }
        if (!newPassword.equals(renewPassword)) {
            throw new CustomException("两次输入密码不一致");
        }
        userDOByUserName.setPassword("{bcrypt}" + bCryptPasswordEncoder.encode(newPassword));
        iUser.save(userDOByUserName);
        return 1;
    }


    @Override
    public PageUtil getALlUserInfo(UserForPMParam userForPMParam) {
        List<UserForPM> userForPMLst = new ArrayList<>();
        PageUtil pageUtil = new PageUtil();
        if (userForPMParam.getPageNo() == null || userForPMParam.getPageSize() == null) {
            List<UserDOForPM> userDOForPMList = iUserForPM.findAll();
            for (UserDOForPM userDOForPM : userDOForPMList) {
                UserForPM userForPM = new UserForPM();
                userForPM.setUserCode(userDOForPM.getUserCode());
                if (null != userDOForPM.getUserExtension()) {
                    userForPM.setRealName(userDOForPM.getUserExtension().getRealName());
                    userForPM.setTranslateType(userDOForPM.getUserExtension().getTranslatorType());
                    List<UserExtend> userExtendList = new ArrayList<>();
                    if (userDOForPM.getUserExtendList() != null && userDOForPM.getUserExtendList().size() > 0) {
                        for (com.sy.pangu.permission.domain.UserExtend userExtend : userDOForPM.getUserExtendList()) {
                            UserExtend newUserExtend = new UserExtend(userExtend.getId(), userExtend.getUserId(), userExtend.getSourceLangauge(),
                                    userExtend.getTargetLangauge(), userExtend.getLevelId(), userExtend.getLevelName(), userExtend.getAreaId(), userExtend.getAreaName(),
                                    userExtend.getServiceId(), userExtend.getServiceName());
                            userExtendList.add(newUserExtend);
                        }
                    }
                    userForPM.setUserExtendList(userExtendList);
                }
                userForPMLst.add(userForPM);
            }
            pageUtil.setList(userForPMLst);
            pageUtil.setTotalRow(userDOForPMList.size());
        }
        else{
                Integer startPage = userForPMParam.getPageNo();
                Integer limit = userForPMParam.getPageSize();
                Pageable pageable = PageRequest.of(startPage, limit);
                List<Predicate> predicateList = new ArrayList<>();
                Specification<UserDOForPM> userForPMSpecification = (Specification<UserDOForPM>) (root, criteriaQuery, criteriaBuilder) -> {
                    Join<UserDOForPM, UserExtension> joinUserExtension = root.join("userExtension", JoinType.LEFT);
                    Join<UserDOForPM, com.sy.pangu.permission.domain.UserExtend> joinUserExtend = root.join("userExtendList", JoinType.LEFT);
                    //姓名
                    if (userForPMParam.getUserRealName() != null) {
                        Predicate userNamePredicate = criteriaBuilder.equal(root.get("userName"), userForPMParam.getUserRealName());
                        predicateList.add(userNamePredicate);
                    }
                    //专职、兼职
                    if (userForPMParam.getWorkType() != null) {
                        Predicate translatorTypePredicate = criteriaBuilder.equal(joinUserExtension.get("translatorType"), userForPMParam.getWorkType());
                        predicateList.add(translatorTypePredicate);
                    }
                    //源语言
                    if (userForPMParam.getSourceLanguageCode() != null) {
                        Predicate sourceLanguageCodePredicate = criteriaBuilder.equal(joinUserExtension.get("sourceLangauge"), userForPMParam.getSourceLanguageCode());
                        predicateList.add(sourceLanguageCodePredicate);
                    }
                    //目标语言
                    if (userForPMParam.getTargetLanguageCode() != null) {
                        Predicate targetLanguageCodePredicate = criteriaBuilder.equal(joinUserExtension.get("targetLangauge"), userForPMParam.getTargetLanguageCode());
                        predicateList.add(targetLanguageCodePredicate);
                    }
                    //领域
                    if (userForPMParam.getArea() != null) {
                        Predicate areaPredicate = criteriaBuilder.like(joinUserExtension.get("areaName"), userForPMParam.getArea());
                        predicateList.add(criteriaBuilder.or(areaPredicate));
                    }
                    //等级
                    if (userForPMParam.getLevel() != null) {
                        Predicate levelPredicate = criteriaBuilder.equal(joinUserExtension.get("levelName"), userForPMParam.getLevel());
                        predicateList.add(levelPredicate);
                    }
                    //工号
                    if (userForPMParam.getUserCode() != null) {
                        Predicate userCodePredicate = criteriaBuilder.equal(root.get("userCode"), userForPMParam.getUserCode());
                        predicateList.add(userCodePredicate);
                    }
                    Predicate[] predicates = new Predicate[predicateList.size()];
                    return criteriaBuilder.and(predicateList.toArray(predicates));
                };
                Page<UserDOForPM> userDOForPMPage = iUserForPM.findAll(userForPMSpecification, pageable);
                List<UserDOForPM> userForPMS = userDOForPMPage.getContent();
                for (UserDOForPM userDOForPM : userForPMS) {
                    UserForPM userForPM = new UserForPM();
                    userForPM.setUserCode(userDOForPM.getUserCode());
                    if (null != userDOForPM.getUserExtension()) {
                        userForPM.setRealName(userDOForPM.getUserExtension().getRealName());
                        userForPM.setTranslateType(userDOForPM.getUserExtension().getTranslatorType());
                        List<UserExtend> userExtendList = new ArrayList<>();
                        if (userDOForPM.getUserExtendList() != null && userDOForPM.getUserExtendList().size() > 0) {
                            for (com.sy.pangu.permission.domain.UserExtend userExtend : userDOForPM.getUserExtendList()) {
                                UserExtend newUserExtend = new UserExtend(userExtend.getId(), userExtend.getUserId(), userExtend.getSourceLangauge(),
                                        userExtend.getTargetLangauge(), userExtend.getLevelId(), userExtend.getLevelName(), userExtend.getAreaId(), userExtend.getAreaName(),
                                        userExtend.getServiceId(), userExtend.getServiceName());
                                userExtendList.add(newUserExtend);
                            }
                        }
                        userForPM.setUserExtendList(userExtendList);
                    }
                    userForPMLst.add(userForPM);
                }
                pageUtil.setList(userForPMLst);
                pageUtil.setTotalPage(userDOForPMPage.getTotalPages());
                pageUtil.setTotalRow(userDOForPMPage.getContent().size());
                pageUtil.setPage(startPage + 1);
                pageUtil.setLimit(limit);
            }


            return pageUtil;
        }
    }
