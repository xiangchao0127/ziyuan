package com.sy.pangu.permission.dao;

import com.sy.pangu.permission.domain.PositionDO;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/28
 * Time:11:11
 */
public interface IPosition extends JpaRepository<PositionDO, String> {
}
