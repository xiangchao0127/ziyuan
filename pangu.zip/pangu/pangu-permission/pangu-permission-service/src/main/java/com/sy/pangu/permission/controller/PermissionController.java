package com.sy.pangu.permission.controller;

import com.sy.pangu.permission.domain.PermissionDO;
import com.sy.pangu.permission.domain.SysModuleDO;
import com.sy.pangu.permission.service.PermissionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/25
 * Time:10:54
 */
@RestController
@RequestMapping("/permission")
@Api(tags = {"权限操作"})
public class PermissionController {
    @Autowired
    private PermissionService permissionService;

    @GetMapping("/allSysModule")
    @ApiOperation("列举所有模块")
    public ResponseEntity<List<SysModuleDO>> listAllSysmodule() {
        return ResponseEntity.ok().body(permissionService.listAllSysmodule());
    }

    @PostMapping("/addModule")
    @ApiOperation("添加模块")
    public ResponseEntity<Integer> saveNewModule(SysModuleDO sysModule) {
        return ResponseEntity.ok(permissionService.saveNewModule(sysModule));
    }

    @GetMapping("/allPermissions")
    @ApiOperation("列举权限")
    public ResponseEntity<List<PermissionDO>> listAllPerMissions() {
        return ResponseEntity.ok().body(permissionService.listAllPermissions());
    }

    @PostMapping("/addPermissionInModule")
    @ApiOperation("模块中新增权限")
    public ResponseEntity<Integer> saveNewPermissionInModule(String moduleId, PermissionDO permission) {
        return ResponseEntity.ok().body(permissionService.saveNewPermissionInModule(moduleId, permission));
    }

    @PostMapping("/bandPermissionInModule")
    @ApiOperation("模块中绑定权限")
    public ResponseEntity<Integer> bandPermissionInModule(String moduleId, String permissionId) {
        return ResponseEntity.ok().body(permissionService.bandPermissionInModule(moduleId, permissionId));
    }


    @PostMapping("/removePermissionInModule")
    @ApiOperation("模块中移除权限")
    public ResponseEntity<Integer> removePermissionInModule(String moduleId, String permissionId) {
        return ResponseEntity.ok().body(permissionService.removePermissionInModule(moduleId, permissionId));
    }


}
