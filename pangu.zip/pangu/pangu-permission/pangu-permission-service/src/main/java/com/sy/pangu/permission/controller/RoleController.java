package com.sy.pangu.permission.controller;

import com.sy.pangu.permission.domain.RoleDO;
import com.sy.pangu.permission.service.RoleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/25
 * Time:14:23
 */
@RestController
@RequestMapping("/role")
@Api(tags = {"角色操作"})
public class RoleController {
    @Autowired
    private RoleService roleService;

    @GetMapping("/listAll")
    @ApiOperation("所有角色")
    public ResponseEntity<List<RoleDO>> listAllRole() {
        return ResponseEntity.ok().body(roleService.listAllRole());
    }

    @GetMapping("/getByCode")
    @ApiOperation("根据角色code匹配")
    public ResponseEntity<RoleDO> findOneByRoleCode(String roleCode) {
        return ResponseEntity.ok().body(roleService.findOneByRoleCode(roleCode));
    }

    @PostMapping("/add")
    @ApiOperation("添加角色")
    public ResponseEntity<Integer> addRole(RoleDO role) {
        return ResponseEntity.ok().body(roleService.saveNewRole(role));
    }

    @DeleteMapping("/delete")
    @ApiOperation("删除角色")
    public ResponseEntity<Integer> deleteRole(String roleId) {
        return ResponseEntity.ok().body(roleService.deleteRole(roleId));
    }

    @PostMapping("/addPermission")
    @ApiOperation("添加权限")
    public ResponseEntity<Integer> addPermissionInRole(String roleId, String permissionId) {
        return ResponseEntity.ok().body(roleService.addPermissionInRole(roleId, permissionId));
    }

    @DeleteMapping("/deletePermission")
    @ApiOperation("删除权限")
    public ResponseEntity<Integer> deletePermissionInRole(String roleId, String permissionId) {
        return ResponseEntity.ok().body(roleService.deletePermissionInRole(roleId, permissionId));
    }

    @PostMapping("/addOrgnize")
    @ApiOperation("添加组织拥有角色")
    public ResponseEntity<Integer> addOrgnizeInRole(String roleId, String orgnizeId) {
        return ResponseEntity.ok().body(roleService.addOrgnizeInRole(roleId, orgnizeId));
    }

    @DeleteMapping("/deleteOrgnize")
    @ApiOperation("删除组织拥有角色")
    public ResponseEntity<Integer> deleteOrgnizeInRole(String roleId, String orgnizeId) {
        return ResponseEntity.ok().body(roleService.deleteOrgnizeInRole(roleId, orgnizeId));
    }

    @PostMapping("/addPosition")
    @ApiOperation("添加职位拥有角色")
    public ResponseEntity<Integer> addPositionInRole(String roleId, String positionId) {
        return ResponseEntity.ok().body(roleService.addPositionInRole(roleId, positionId));
    }

    @DeleteMapping("/deletePosition")
    @ApiOperation("删除职位拥有角色")
    public ResponseEntity<Integer> deletePositionInRole(String roleId, String positionId) {
        return ResponseEntity.ok().body(roleService.deletePositionInRole(roleId, positionId));
    }

}
