package com.sy.pangu.permission.client;

import com.sy.pangu.permission.model.PageUtil;
import com.sy.pangu.permission.model.User;
import com.sy.pangu.permission.model.UserForPMParam;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;


@FeignClient(name = "permission-service", path = "/permission")
public interface UserClient {

    @PostMapping("/user/fingdByUserId/{id}")
    User findUserById(@PathVariable("id") String id);

    @RequestMapping(value = "/user/updateUserById", method = RequestMethod.POST)
    User updateUser(@RequestBody User user);


    @PostMapping("/user/findUserByNickName/{nickName}")
    Integer findUserByNickName(@PathVariable("nickName") String nickName);


    @PostMapping("/user/getAllUserInfo")
    PageUtil getAllUserInfo(UserForPMParam userForPMParam);

}
