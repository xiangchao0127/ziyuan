package com.sy.pangu.permission.client;


import org.springframework.cloud.openfeign.FeignClient;
import com.sy.pangu.permission.model.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/14
 * Time:15:26
 */
@FeignClient(name = "permission-service", path = "/permission")
public interface PermissionClient {
    @PostMapping("/user/findUserByUsername/{username}")
    User findUserByUserName(@PathVariable("username") String username);

    @GetMapping("/cache/refreshFileterCache")
    void refreshFileterCache();
}
