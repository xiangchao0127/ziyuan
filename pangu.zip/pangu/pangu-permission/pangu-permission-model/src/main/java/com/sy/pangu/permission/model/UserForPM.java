package com.sy.pangu.permission.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * 提供给PM系统实体
 */
@Getter
@Setter
public class UserForPM implements Serializable {

    /**
     * 工号
     */
    private String userCode;
    /**
     * 真实姓名
     */
    private String realName;
    /**
     * 译员类型
     */
    private Integer translateType;


    private List<UserExtend> userExtendList;


}
