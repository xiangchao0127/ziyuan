package com.sy.pangu.permission.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class UserExtend implements Serializable {

    public UserExtend(String id, String userId, String sourceLangauge, String targetLangauge, String levelId, String levelName, String areaId, String areaName, String serviceId, String serviceName) {
        this.id = id;
        this.userId = userId;
        this.sourceLangauge = sourceLangauge;
        this.targetLangauge = targetLangauge;
        this.levelId = levelId;
        this.levelName = levelName;
        this.areaId = areaId;
        this.areaName = areaName;
        this.serviceId = serviceId;
        this.serviceName = serviceName;
    }

    private String id;
    /**
     * 用户Id
     */
    private String userId;

    /**
     * 源语言Code
     */
    private String sourceLangauge;

    /**
     * 目标语言Code
     */
    private String targetLangauge;

    /**
     * 等级Id
     */
    private String levelId;

    /**
     * 等级名称
     */
    private String levelName;

    /**
     * 领域id
     */
    private String areaId;

    /**
     * 领域名字
     */
    private String areaName;

    /**
     * 审校/QA/翻译等ID
     */
    private String serviceId;

    /**
     * 审校/QA/翻译等ID
     */
    private String serviceName;

}
