package com.sy.pangu.permission.model;

import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/15
 * Time:10:17
 */
@Data
public class User implements Serializable {

    private String id;
    /**
     * 创建时间
     */
    private Timestamp gmtCreate;
    /**
     * 更新时间
     */
    private Timestamp gmtUpdate;
    /**
     * 是否删除 (0:false  1:true)
     */
    private Boolean deleted;
    /**
     * 编号
     */
    private String userCode;
    /**
     * 名称
     */
    private String userName;
    /**
     * 账号
     */
    private String account;
    /**
     * 密码
     */
    private String password;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 地址
     */
    private String address;
    /**
     * email
     */
    private String email;
    /**
     * 头像路径
     */
    private String picturePath;
    /**
     * 性别
     */
    private String sex;
    /**
     * 身份证
     */
    private String idCard;
    /**
     * 微信
     */
    private String weixin;
    /**
     * qq
     */
    private String qq;

    /**
     * 部门
     */
    private  String department;
    /**
     * 电话
     */
    private String telephone;
    /**
     * 用户类型（后台，前台）
     */
    private String userType;


    private List<String> roleCodeList;
}
