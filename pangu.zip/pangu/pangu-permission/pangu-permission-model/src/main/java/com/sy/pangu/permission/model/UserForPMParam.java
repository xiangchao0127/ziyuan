package com.sy.pangu.permission.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Q00596
 * 提供PM人员信息查询参数
 */
@Getter
@Setter
public class UserForPMParam implements Serializable {

    /**
     * 页码
     */
    private Integer pageNo;
    /**
     * 每页大小
     */
    private Integer pageSize;
    /**
     * 工号
     */
    private String userCode;

    /**
     * 工作类型 专职(1) 兼职(2)
     */
    private Integer workType;
    /**
     * 等级
     */
    private String level;
    /**
     * 领域
     */
    private String area;

    /**
     * 源语言
     */
    private String sourceLanguageCode;

    /**
     * 目标语言
     */
    private String targetLanguageCode;

    /**
     * 译员姓名
     */
    private String userRealName;


}
