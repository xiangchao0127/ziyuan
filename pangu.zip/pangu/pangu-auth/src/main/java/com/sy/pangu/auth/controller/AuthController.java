package com.sy.pangu.auth.controller;

import com.alibaba.fastjson.JSON;
import com.sy.pangu.common.util.SecurityUtils;
import com.sy.pangu.permission.model.User;
import com.sy.pangu.rm.client.CommentAndLogClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

/**
 * @author SHUYI
 * @date 2018-3-8
 **/
@RestController
@Api(tags = "认证接口")
public class AuthController {

    //    @Autowired
//    private VerificationCodeClient verificationCodeClient;
    @Autowired
    CommentAndLogClient commentAndLogClient;

    @GetMapping("/current")
    @ApiOperation("获取当前用户信息")
    public Principal getUser(Principal principal) {
        return principal;
    }

    //    @PostMapping("/sms/token")
//    @ApiOperation("获取短信登录Token")
//    public Result<String> getToken(String phoneNumber){
//        return verificationCodeClient.getToken(6,null,"0",phoneNumber,true);
//    }
    @GetMapping("/testCommentAndLog")
    @ApiOperation("测试评论及日志feign")
    public String testCommentAndLog(String hello) {
        System.out.println(commentAndLogClient.addBussinessLog("111","111","content"));
        System.out.println(commentAndLogClient.getBussinessLogs("111",0,10));
        System.out.println( commentAndLogClient.addComment("111","xiangchao","asdfasdf"));
        System.out.println( commentAndLogClient.addCommentReply("402883ce6a974542016a975249dd0000","xc","ling","asdfdfas"));
        System.out.println(commentAndLogClient.getCommentAndReply("111",0,10));
        return null;
    }

}
