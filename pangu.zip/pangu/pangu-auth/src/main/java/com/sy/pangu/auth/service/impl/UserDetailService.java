package com.sy.pangu.auth.service.impl;

import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.permission.client.PermissionClient;
import com.sy.pangu.permission.model.User;
import com.sy.pangu.permission.model.UserDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/14
 * Time:15:41
 */
@SuppressWarnings("ALL")
@Service("userDetailsService")
public class UserDetailService implements UserDetailsService {

    @Autowired
    private PermissionClient permissionClient;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = permissionClient.findUserByUserName(username);
        if (user == null) {
            throw new CustomException(ExceptionEnum.USER_NOT_FOUND, "用户名或密码错误");
        }
        UserDetail userDetail = new UserDetail(user);
        return userDetail;
    }
}
