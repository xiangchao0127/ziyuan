package com.sy.pangu.auth;

import com.sy.pangu.common.security.access.EnableSecurityAccess;
import com.sy.pangu.common.security.oauth2.feign.EnableOAuth2ClientFeign;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@SpringCloudApplication
@EnableResourceServer
@EnableCaching
@EnableOAuth2Client
@EnableOAuth2ClientFeign
@EnableFeignClients("com.sy.pangu")
@ComponentScan("com.sy.pangu")
@EnableJpaRepositories(basePackages ={ "com.sy.pangu"})
@EntityScan(basePackages ={ "com.sy.pangu"})
@EnableSecurityAccess
public class AuthServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthServerApplication.class, args);
    }
}
