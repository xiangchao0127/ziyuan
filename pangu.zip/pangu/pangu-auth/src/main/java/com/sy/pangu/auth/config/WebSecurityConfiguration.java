package com.sy.pangu.auth.config;/*
package com.sy.knowledge.authserver.config;

import com.sy.knowledge.authserver.service.impl.UserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.GlobalAuthenticationConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;

*/
/**
 * @author XiangChao
 * @date 2019/1/16
 *//*

@Configuration
public class WebSecurityConfiguration extends GlobalAuthenticationConfigurerAdapter {
    @Autowired
    private  UserDetailService userService;

    @Autowired
    public WebSecurityConfiguration(UserDetailService userService) {
        this.userService = userService;
    }

    @Override
    public void init(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userService);

    }

}*/
