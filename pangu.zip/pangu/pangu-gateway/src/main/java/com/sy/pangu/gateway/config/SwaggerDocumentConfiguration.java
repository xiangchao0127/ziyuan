package com.sy.pangu.gateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.zuul.filters.ZuulProperties;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author SHUYI
 * @date 2018-3-8
 **/
@Component
@Primary
public class SwaggerDocumentConfiguration implements SwaggerResourcesProvider {
    private String version = "2.0";
    private String suffix = "/v2/api-docs";
    @Autowired
    ZuulProperties zuulProperties;

    @Override
    public List<SwaggerResource> get() {
        List resources = new ArrayList<>();
        Map<String, ZuulProperties.ZuulRoute> map = zuulProperties.getRoutes();
        Set<Map.Entry<String, ZuulProperties.ZuulRoute>> set = map.entrySet();
        for (Map.Entry<String, ZuulProperties.ZuulRoute> entry : set) {
            String path = entry.getValue().getPath();
            path = path.substring(0, path.lastIndexOf("/"));
            resources.add(swaggerResource(entry.getKey(), path + suffix, version));
        }
        return resources;
    }

    private SwaggerResource swaggerResource(String name, String location, String version) {
        SwaggerResource swaggerResource = new SwaggerResource();
        swaggerResource.setName(name);
        swaggerResource.setLocation(location);
        swaggerResource.setSwaggerVersion(version);
        return swaggerResource;
    }
}
