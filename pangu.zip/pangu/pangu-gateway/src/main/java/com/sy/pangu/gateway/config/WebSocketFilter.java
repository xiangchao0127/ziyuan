package com.sy.pangu.gateway.config;

import com.github.mthizo247.cloud.netflix.zuul.web.socket.ZuulPropertiesResolver;
import com.github.mthizo247.cloud.netflix.zuul.web.socket.ZuulWebSocketProperties;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.DefaultServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.zuul.filters.ZuulProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.http.HttpServletRequest;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/5/20
 * Time:16:21
 */
@Configuration
public class WebSocketFilter extends ZuulFilter{
    @Autowired
    private DiscoveryClient discoveryClient;
    @Autowired
    private ZuulProperties zuulProperties;
    @Override
    public String filterType() {
        return "pre";
    }
    @Override
    public int filterOrder() {
        return 0;
    }
    @Override
    public boolean shouldFilter() {
        return true;
    }
    @Override
    public Object run() {
        RequestContext context = RequestContext.getCurrentContext();
        HttpServletRequest request = context.getRequest();
        String upgradeHeader = request.getHeader("Upgrade");
        if (null == upgradeHeader) {
            upgradeHeader = request.getHeader("upgrade");
        }
        if (null != upgradeHeader && "websocket".equalsIgnoreCase(upgradeHeader)) {
            context.addZuulRequestHeader("connection", "Upgrade");
        }
        return null;
    }
    @Bean
    public ZuulPropertiesResolver zuulPropertiesResolver() {
        return new ZuulPropertiesResolver(){
            @Override
            public String getRouteHost(ZuulWebSocketProperties.WsBrokerage wsBrokerage) {
                String url = discoveryClient.getInstances(wsBrokerage.getId()).stream().findAny()
                        .orElseGet(() -> new DefaultServiceInstance("", "", 0, false))
                .getUri().toString();
                String webcontext = zuulProperties.getRoutes().get(wsBrokerage.getId()).getUrl();
                return url+webcontext;
            }
        };
    }
}
