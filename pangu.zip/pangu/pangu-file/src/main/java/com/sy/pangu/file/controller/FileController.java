package com.sy.pangu.file.controller;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.entity.dto.BaseResponse;
import com.sy.pangu.common.util.ExcelUtils;
import com.sy.pangu.common.util.FileUtils;
import com.sy.pangu.common.util.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/12
 */
@Api(tags = {"上传文件"})
@RestController
public class FileController {
    @Value("${pangu-file.ip}")
    private String fileIp;
    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    /**
     * 文件上传
     *
     * @param multipartFile
     * @param path          文件路径
     * @return nginx文件路径
     */
    @ApiOperation("文件上传")
    @PostMapping("/feign/fileUpload")
    public String fileUpload(MultipartFile multipartFile, String path) {
        logger.info("----------------------------->" + path);
        System.out.println("----------------------------->" + path);
        FileUtils.uploadOneFile(multipartFile, path);
        return fileIp + StringUtils.filePathToNginxPath(path);
    }

    /**
     * 获取excel文件内容
     *
     * @param path 文件路径
     * @return
     */
    @ApiOperation("获取excel内容")
    @PostMapping("/feign/getExcelContent")
    public List<List<String>> getExcelContent(String path) {
        logger.info("----------------------------->" + path);
        System.out.println("----------------------------->" + path);
        return ExcelUtils.read(path);
    }


    @ApiOperation("获取文件流")
    @PostMapping("/feign/getFileInputstream")
    public BaseResponse getFileInputstream(String path) {
        logger.info("----------------------------->" + path);
        File file = new File(path);
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setMsg("200");
        baseResponse.setCode("200");
        baseResponse.setObj(fileInputStream);
//        new FileInputStream()
        return baseResponse;
    }

    @ApiOperation("test")
    @PostMapping("/feign/test")
    public BaseResponse test(@RequestBody BaseResponse baseResponse) {
        System.out.println(baseResponse);
        return baseResponse;
    }

    public static void main(String[] args) throws Exception {
        FileInputStream fileInputStream = new FileInputStream(new File("D:\\opt\\docker\\nginx\\html\\rm\\images\\qq.jpg"));
        System.out.println(fileInputStream);
    }

}
