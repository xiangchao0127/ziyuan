package com.sy.pangu.file;

import org.springframework.boot.SpringApplication;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/11
 * Time:15:39
 */
//@SpringBootApplication(exclude = {OAuth2ClientAutoConfiguration.class, SecurityAutoConfiguration.class, DataSourceAutoConfiguration.class})
//OAuth2ClientAutoConfiguration.class, SecurityAutoConfiguration.class,
//@ComponentScan(basePackages = {"com.sy.common.config","com.sy.knowledge.apigateway"})
//@SpringBootApplication
//@EnableOAuth2Client
//@EnableSecurityAccess
//@EnableOAuth2ClientFeign
//@EnableResourceServer
//@ComponentScan(basePackages = {"com.sy.pangu"})
//@EnableFeignClients(basePackages = {"com.sy.pangu"})
//@EnableJpaRepositories(basePackages ={ "com.sy.pangu"})
//@EntityScan(basePackages ={ "com.sy.pangu"})
//@EnableSwagger2
//@EnableDiscoveryClient
//@EnableAsync
public class FileApplication {
    public static void main(String[] args) {
        SpringApplication.run(FileApplication.class, args);
    }
}
