package com.sy.pangu.file.client;

import com.sy.pangu.common.entity.dto.BaseResponse;
import feign.codec.Encoder;
import feign.form.spring.SpringFormEncoder;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


/**
 * @author XiangChao
 * @date 2019/4/12
 */
@FeignClient(name = "pangu-file", path = "/file",configuration = FileClient.MultipartSupportConfig.class)
public interface FileClient {
    /**
     *
     * @param multipartFile /opt/docker/nginx/html/rm
     * @param path 型如 d:\pangu\rm\articleImage\qq.jpg   /opt/docker/nginx/html/rm/articleImage/qq.jpg   方便nginx部署
     * @return 返回nginx文件路径  方便下载
     */
    @PostMapping(value = "/feign/fileUpload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    String fileUpload(@RequestPart("multipartFile")MultipartFile multipartFile, @RequestParam("path")String path);

    /**
     * 测试实体类传参
     * @param baseResponse
     * @return
     */
    @PostMapping(value = "/feign/test",consumes = MediaType.APPLICATION_JSON_VALUE)
    BaseResponse getTest(@RequestBody BaseResponse baseResponse);

    /**
     * 获取excel文件内容
     * @param path 文件路径
     * @return
     */
    @PostMapping(value = "/feign/getExcelContent")
    List<List<String>> getExcelContent(@RequestParam("path") String path);



    @Configuration
    class MultipartSupportConfig {
        @Autowired
        private ObjectFactory<HttpMessageConverters> messageConverters;

        @Bean
        public Encoder feignFormEncoder() {
            return new SpringFormEncoder(new SpringEncoder(messageConverters));
        }
    }


}
