package com.sy.pangu.pm.model;

import lombok.Data;

@Data
public class ResultModel {

	/**
	 * 结果状态
	 */
	private boolean success;

	/**
	 * 结果备注信息
	 */
	private String msg;

	/**
	 * 返回结果
	 */
	private Object data;
}
