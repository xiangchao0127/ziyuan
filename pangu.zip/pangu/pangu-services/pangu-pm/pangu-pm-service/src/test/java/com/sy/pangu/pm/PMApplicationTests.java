package com.sy.pangu.pm;

import com.netflix.discovery.converters.Auto;
import com.sy.pangu.permission.client.UserClient;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.vo.TaskInfoVo;
import com.sy.pangu.pm.mapper.PmFileMapper;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.service.IInitParamService;
import com.sy.pangu.pm.service.IPMTaskSpiltService;
import com.sy.pangu.pm.service.ITransTaskService;
import com.sy.pangu.pm.utils.PageUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import ch.qos.logback.classic.Logger;
import org.springframework.test.context.web.WebAppConfiguration;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public class PMApplicationTests {

    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
    @Autowired
    private ITransTaskService transTaskService;
    @Autowired
    private PmFileMapper fileMapper;
    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
    @Autowired
    private IPMTaskSpiltService spiltService;
    @Value("${file-upload-path}")
    private String fileUploadPath;

    @Autowired
    private UserClient userClient;
    @Autowired
    private IInitParamService initParamService;

    @Test
    public void contextLoads() {
//        method3();
//        transTaskService.receiveCompleteTask("1","16");
//        List<UserForPM> allUserInfo = userClient.getAllUserInfo();
//        logger.info(allUserInfo.size()+"");
        logger.info("返回的主键ID：{}",123);
        method4();
    }

    public void method4(){
        spiltService.getTaskSpiltList("CSYWD190200001111");
    }


    public void method1(){
        PmFile file = new PmFile();
        file.setFileName("测试");
        file.setIsDel("0");//未删除
        file.setFileType("00");//TODO
        int fileId = fileMapper.insertSelectKey(file);
        logger.info("返回的主键ID：{}",file.getFileId());
    }


    public void method2(){
        Thread thread1 = new Thread(() -> {
            /*
             * try { Thread.sleep(100); }catch (Exception e) { }
             */
            transTaskService.receiveCompleteTask("jzj", "0001");
        });

        Thread thread2 = new Thread(() -> {
            transTaskService.receiveCompleteTask("ahhh", "0001");
        });
        Thread thread3 = new Thread(() -> {
            transTaskService.receiveCompleteTask("abc", "0001");
        });

        thread1.setName("jzj");
        thread2.setName("ahhh");
        thread3.setName("abc");

        thread1.start();
        thread2.start();
        thread3.start();


        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
        }
    }

    public void method3(){
        PageUtil pageinfo = new PageUtil();
        pageinfo.getLink().put("staffNum","3");
        pageinfo.getLink().put("skillLv","7");
        pageinfo.setPage(1);
        pageinfo.setLimit(20);
       List<TaskInfoVo> taskInfos = taskInfoMapper.selectPageNotReceiveTask(pageinfo);
//               taskInfoMapper.getTest();
       logger.info("大小:{}",taskInfos.size());
    }

    public static void main(String[] args) {
        List<String> list = Arrays.asList("11","2","3","12","32","7","81","4");
        List<String> stringStream = list.stream().filter(x -> Integer.parseInt(x) > 12).collect(Collectors.toList());
        stringStream.forEach(System.out::println);
        list.forEach(System.out::println);
//        System.out.println();
    }
}
