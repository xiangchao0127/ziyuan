
package com.sy.pangu.pm.service.impl;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.*;
import com.sy.pangu.pm.entity.example.PmAutomatchingExample;
import com.sy.pangu.pm.entity.example.PmDefaultFlowExample;
import com.sy.pangu.pm.entity.example.PmDistributeExample;
import com.sy.pangu.pm.entity.example.SysMatchingPmExample;
import com.sy.pangu.pm.entity.vo.*;
import com.sy.pangu.pm.mapper.*;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.AutoRuleService;
import com.sy.pangu.pm.utils.MathUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


/**
 * @author ：lhaotian
 * date ：Created in 2019/4/10 14:09
 */
@Service(value = "autoRuleService")
public class AutoRuleServiceImpl implements AutoRuleService {

    protected static final Logger logger = LoggerFactory.getLogger(AutoRuleServiceImpl.class);

    /**
     * 默认节点
     */
    protected static final int DEFAULT_FLOW_ID = 0;



    /**
     * 分领规则节点占比值总和必须等于100
     */
    protected static final double MAX_TIME_PER = 100d;

    protected static final String FILE_EXT_XLS = "xls";

    protected static final String FILE_EXT_XLSX = "xlsx";

    protected static final String FILE_EXT_TEXT = "txt";

    protected static final String FILE_EXT_DOC = "doc";

    protected static final String FILE_EXT_DOCX = "docx";

    protected static final String FILE_EXT_PDF = "pdf";

    protected static final String FILE_EXT_RTF = "rtf";


    @Autowired
    private PmDefaultFlowMapper pmDefaultFlowMapper;

    @Autowired
    private PmAutomatchingMapper pmAutomatchingMapper;

    @Autowired
    private PmSysTaskMapper pmSysTaskMapper;

    @Autowired
    private PmDistributeMapper pmDistributeMapper;


    @Autowired
    private PmFileFlowMapper fileFlowMapper;

    @Autowired
    private SysMatchingPmMapper sysMatchingPmMapper;



    @Override
    public boolean setDefaultFlow(String orderType, String qualityLvl, String defaultCat, List<String> workFlow) {
        delDefaultFlow(orderType, qualityLvl, defaultCat);
        List<PmDefaultFlow> flowList = new ArrayList<>();
        String id = orderType + qualityLvl + defaultCat;
        for(int index = 0; index < workFlow.size(); index ++) {
            PmDefaultFlow first = new PmDefaultFlow();
            first.setOrderType(orderType);
            first.setDefaultCat(defaultCat);
            first.setOrderGrade(qualityLvl);
            first.setNodeId(Integer.parseInt(workFlow.get(index)));
            first.setId(id);
            if(index == 0)
            {
                first.setLastFlow(DEFAULT_FLOW_ID);
            } else {
                first.setLastFlow(Integer.parseInt(workFlow.get(index - 1)));
            }
            if(index == workFlow.size() - 1) {
                first.setNextFlow(DEFAULT_FLOW_ID);
            } else {
                first.setNextFlow(Integer.parseInt(workFlow.get(index + 1)));
            }
            //插入数据库
            flowList.add(first);

        }
        pmDefaultFlowMapper.insertBatch(flowList);
        return true;
    }


    @Override
    public FlowQueryVo getFlow(FlowQueryVo flowModel) {
        PmDefaultFlowExample example = new PmDefaultFlowExample();
        String path = "";
        String msg = "查找成功";
        if (!StringUtils.notEmpty(flowModel.getQualityLvl())) {
            ResultModel.Fail("缺少订单等级", null);
        }
        if (!StringUtils.notEmpty(flowModel.getOrderType())) {
            ResultModel.Fail("缺少订单类型", null);
        }
        try {
        example.createCriteria().andOrderGradeEqualTo(flowModel.getQualityLvl()).andOrderTypeEqualTo(flowModel.getOrderType()).andDefaultCatEqualTo(flowModel.getDefaultCat());
        List<PmDefaultFlow> flows = pmDefaultFlowMapper.selectByExample(example);
        if (flows.size() == 0) {
            return null;
        }
        PmDefaultFlow flow = flows.stream().filter(x -> x.getLastFlow() == DEFAULT_FLOW_ID).findFirst().get();
        path = getNodePath(flow, flows);
        } catch (Exception e) {
            msg = "节点查找失败,节点数据为：";
            logger.error(msg);
            throw new RuntimeException(msg);
        }

        flowModel.setWorkFlow(path);
        return flowModel;
    }

    @Override
    public ResultModel listFlow() {
        PmDefaultFlowExample example = new PmDefaultFlowExample();
        String msg = "查找成功";
        List<PmDefaultFlow> flows = pmDefaultFlowMapper.selectByExample(example);
        return ResultModel.SuccessForMsg(msg, getFlowList(flows));
    }

    /**
     * 获取下一节点
     * @param flow 起点
     * @param flows
     * @return
     */
    private PmDefaultFlow getNextNode(PmDefaultFlow flow, List<PmDefaultFlow> flows) {
        if (!flows.stream().filter(x -> x.getLastFlow().equals(flow.getNodeId())).findFirst().isPresent()) {
            System.out.println(flow.getNodeId());
        }
        PmDefaultFlow nextNode = flows.stream().filter(x -> x.getLastFlow().equals(flow.getNodeId())).findFirst().get();
        return nextNode;
    }

    /**
     * 对全部流程进行分组并拼接出流程路径
     * @param flows 数据库查出的全部流程
     * @return 返回页面展示结果
     */
    private List<FlowQueryVo> getFlowList(List<PmDefaultFlow> flows) {
        List<String> ids = pmDefaultFlowMapper.getDistinctId();
        List<FlowQueryVo> modelList = new ArrayList<>();
        try {
        for(String id : ids) {
            FlowQueryVo model = new FlowQueryVo();
            List<PmDefaultFlow> list = flows.stream().filter(x -> x.getId().equals(id)).collect(Collectors.toList());
            PmDefaultFlow flow = list.stream().filter(x -> x.getLastFlow() == DEFAULT_FLOW_ID).findFirst().get();
            model.setQualityLvl(flow.getOrderGrade());
            model.setOrderType(flow.getOrderType());
            model.setWorkFlow(getNodePath(flow, list));
            model.setDefaultCat(flow.getDefaultCat());
            modelList.add(model);
            System.out.println(id);
        }
        }catch (Exception e) {
            e.printStackTrace();
        }

        return modelList;
    }

    /**
     * 获取流程路径
     * @param flow 第一层
     * @param flows 流程列表
     * @return 流程路径
     */
    private String getNodePath(PmDefaultFlow flow,List<PmDefaultFlow> flows) {
        if (flow.getNextFlow() != 0) {
            PmDefaultFlow next = getNextNode(flow, flows);
            String path = flow.getNodeId().toString() + "->" + next.getNodeId().toString();
            while (next.getNextFlow() != 0) {
                next = getNextNode(next, flows);
                if(next.getNodeId() != 0) {
                    path += "->" + next.getNodeId().toString();
                }
            }
            return path;
        }
        return flow.getNodeId().toString();

    }

    /**
     * 用于添加节点
     * @param nodeId
     * @param nodeName
     * @param nodeType
     */
    public void insertPmSysTask(Integer nodeId, String nodeName, String nodeType) {
        PmSysTask task = new PmSysTask();
        task.setId(nodeId);
        task.setTaskName(nodeName);
        task.setTaskType(nodeType);
        task.setIsUse(true);
        int success = pmSysTaskMapper.insert(task);
        if (success == 1) {
            DataBaseStartUpRunner.initPmSysTask.add(task);
        }
    }

    @Override
    public ResultModel setAutoRules(AutoRuleQuery autoRuleVos) {
        for (AutoRuleVo autoRuleVo : autoRuleVos.getAutoRuleVos()) {
            if (autoRuleVo.getCusType() == "") {
                return ResultModel.FailWithNoData("请选择对应客户");
            }
            PmAutomatchingExample example = new PmAutomatchingExample();
            example.createCriteria()
                    .andCusTypeEqualTo(autoRuleVo.getCusType())
                    .andOrderLvlEqualTo(autoRuleVo.getOrderLvl())
                    .andOrderTypeEqualTo(autoRuleVo.getOrderType());
            List<PmAutomatching> defaultPmMatchRule = pmAutomatchingMapper.selectByExample(example);
            for(PmAutomatching automatching : defaultPmMatchRule) {
                pmAutomatchingMapper.deleteByPrimaryKey(automatching.getId());
            }
            for (DistributeQueryParam distributeQueryParam : autoRuleVo.getAutomatchingList()) {
                FlowQueryVo flow = new FlowQueryVo();
                flow.setOrderType(autoRuleVo.getOrderType());
                flow.setQualityLvl(autoRuleVo.getOrderLvl());
                flow.setDefaultCat(autoRuleVo.getDefaultCat());
                FlowQueryVo flowModel = getFlow(flow);
                if (flowModel == null) {
                    return ResultModel.Fail("请设置该订单等级/类型的默认流程", null);
                }
                if (StringUtils.isEmpty(flowModel.getWorkFlow())) {
                    return ResultModel.Fail("请设置该订单等级/类型的默认流程", null);
                }
                PmAutomatching pmAutomatching = new PmAutomatching();
                pmAutomatching.setCusType(autoRuleVo.getCusType());
                pmAutomatching.setUseAuto(distributeQueryParam.getUseAuto());
                pmAutomatching.setHigherCount(distributeQueryParam.getHigherCount());
                pmAutomatching.setLowerCount(distributeQueryParam.getLowerCount());
                pmAutomatching.setMatchingOutsaler(distributeQueryParam.getMatchingOutsaler());
                pmAutomatching.setMatchingPm(distributeQueryParam.getMatchingPm());
                pmAutomatching.setMatchingTranspm(distributeQueryParam.getMatchingTranspm());
                pmAutomatching.setOrderLvl(autoRuleVo.getOrderLvl());
                pmAutomatching.setOrderType(autoRuleVo.getOrderType());
                try {
                    pmAutomatchingMapper.insert(pmAutomatching);
                    //此处调用R2接口保存项目设置
                    //
                    //
                } catch (Exception e) {
                    e.printStackTrace();
                    return ResultModel.FailWithNoData("保存失败:" + pmAutomatching.getCusType());
                }
            }
        }
        return ResultModel.Success();
    }

    @Override
    public List<AutoRuleVo> autoRuleList(String orderType, String qualityLvl) {
        return pmAutomatchingMapper.ruleMatchList(orderType, qualityLvl);
    }

    @Override
    public List<Map<String,String>> ruleMatchTypes() {
        return pmAutomatchingMapper.ruleMatchTypes();
    }

    @Override
    public void updateRules(AutoRuleQuery autoRuleVos) {
        for (AutoRuleVo autoRuleVo : autoRuleVos.getAutoRuleVos()) {
            if (autoRuleVo.getCusType() == "") {

            }
            for (DistributeQueryParam distributeQueryParam : autoRuleVo.getAutomatchingList()) {
                FlowQueryVo flow = new FlowQueryVo();
                flow.setOrderType(autoRuleVo.getOrderType());
                flow.setQualityLvl(autoRuleVo.getOrderLvl());
                flow.setDefaultCat(autoRuleVo.getDefaultCat());
                FlowQueryVo flowModel = getFlow(flow);
                if (flowModel == null) {

                }
                if (StringUtils.isEmpty(flowModel.getWorkFlow())) {

                }
                PmAutomatching pmAutomatching = new PmAutomatching();
                pmAutomatching.setCusType(autoRuleVo.getCusType());
                pmAutomatching.setUseAuto(distributeQueryParam.getUseAuto());
                pmAutomatching.setHigherCount(distributeQueryParam.getHigherCount());
                pmAutomatching.setLowerCount(distributeQueryParam.getLowerCount());
                pmAutomatching.setMatchingOutsaler(distributeQueryParam.getMatchingOutsaler());
                pmAutomatching.setMatchingPm(distributeQueryParam.getMatchingPm());
                pmAutomatching.setMatchingTranspm(distributeQueryParam.getMatchingTranspm());
                pmAutomatching.setOrderLvl(autoRuleVo.getOrderLvl());
                pmAutomatching.setOrderType(autoRuleVo.getOrderType());
                pmAutomatching.setId(distributeQueryParam.getId());
                pmAutomatchingMapper.updateByPrimaryKey(pmAutomatching);
            }
        }
    }

    @Override
    public boolean delDefaultFlow(String orderType, String orderLvl, String defaultCat) {
        PmDefaultFlowExample pmDefaultFlowExample = new PmDefaultFlowExample();
        pmDefaultFlowExample.createCriteria().
                andOrderTypeEqualTo(orderType).
                andDefaultCatEqualTo(defaultCat).
                andOrderGradeEqualTo(orderLvl);
        pmDefaultFlowMapper.deleteByExample(pmDefaultFlowExample);
        return true;
    }

    @Override
    public ResultModel setDistributeRule(DistributeQueryVo distributes) {
        try {
            double totalTimePer = 0d;
            String flowId = distributes.getFlowId();
            PmDistributeExample example = new PmDistributeExample();
            example.setDistinct(true);
            if ( pmDistributeMapper.selectId(example).contains(flowId)) {
                pmDistributeMapper.deleteByFlowId(distributes.getFlowId());
            }
            List<PmDistribute> distributeList = new ArrayList<>();
            for (PmDistributeVo pmDistribute : distributes.getDistributes()) {
                if (pmDistribute.getFreeStaffLvl().length == 0 && pmDistribute.getFullStaffLvl().length == 0) {
                    return ResultModel.FailWithNoData("请选择对应的等级");
                }
                PmDistribute distribute = new PmDistribute();
                distribute.setFlowId(distributes.getFlowId());
                distribute.setNodeId(pmDistribute.getNodeId());
                distribute.setTimePer(pmDistribute.getTimePer());
                StringBuilder fullResult = new StringBuilder();
                StringBuilder freeResult = new StringBuilder();
                totalTimePer += pmDistribute.getTimePer();
                for (String oneStr : pmDistribute.getFullStaffLvl()) {
                    fullResult.append("|").append(oneStr).append("|,");
                }
                distribute.setFullStaffLvl(fullResult.toString());
                for (String oneStr : pmDistribute.getFreeStaffLvl()) {
                    freeResult.append("|").append(oneStr).append("|,");
                    distribute.setFreeStaffLvl(freeResult.toString());
                }
                distributeList.add(distribute);
            }
            if(totalTimePer != MAX_TIME_PER) {
                return ResultModel.Fail("时间占比总和必须等于100", null);
            }
            pmDistributeMapper.insertBatch(distributeList);
        } catch (Exception e) {
            throw new RuntimeException("插入分领规则出错");
        }
        return ResultModel.SuccessForMsg("设置成功", null);
    }

    @Override
    public ResultModel getDistributeRule() {
        PmDistributeExample example = new PmDistributeExample();
        List<DistributeResponseParams> params = new ArrayList<>();
        example.setDistinct(true);
        List<String> ids = pmDistributeMapper.selectId(example);
        List<PmDistribute> distributes = pmDistributeMapper.selectByExample(example);
        for (String id : ids) {
            StringBuilder workFlow = new StringBuilder();
            String[] idArray = id.split("");
            List<PmDistribute> distributeList = distributes.stream().filter(x -> id.equals(x.getFlowId())).collect(Collectors.toList());
            DistributeResponseParams param = new DistributeResponseParams();
            for (PmDistribute distribute : distributeList) {
                workFlow.append("->").append(distribute.getNodeId());
                if (distribute.getFreeStaffLvl() == null) {
                    distribute.setFreeStaffLvl("");
                } else {
                    distribute.setFreeStaffLvl(distribute.getFreeStaffLvl().substring(0, distribute.getFreeStaffLvl().lastIndexOf(',')).replaceAll("\\|", ""));
                }
                if (distribute.getFullStaffLvl() == null) {
                    distribute.setFullStaffLvl("");
                } else {
                    distribute.setFullStaffLvl(distribute.getFullStaffLvl().substring(0, distribute.getFullStaffLvl().lastIndexOf(',')).replaceAll("\\|", ""));
                }
            }
            workFlow.delete(0,2);
            param.setDistributes(distributeList);
            param.setWorkFlow(workFlow.toString());
            param.setOrderType(idArray[0]);
            param.setQualityLvl(idArray[1]);
            params.add(param);
        }
        return ResultModel.SuccessForMsg("查询成功", params);
    }

    @Override
    public ResultModel updateDistributeRule(List<PmDistribute> distributes) {
        if (distributes.size() < 1) {
            return ResultModel.FailWithNoData("缺少参数");
        }
        String flowId = distributes.get(0).getFlowId();
        PmDistributeExample example = new PmDistributeExample();
        example.createCriteria().andFlowIdEqualTo(flowId);
        List<PmDistribute> listdis = pmDistributeMapper.selectByExample(example);
        for (PmDistribute distribute : distributes) {
            for (PmDistribute dis : listdis) {
                if (dis.getNodeId().equals(distribute.getNodeId())) {
                    distribute = dis;
                }
            }
        }
        double total = 0;
        for (PmDistribute distribute : distributes) {
            total += distribute.getTimePer();
        }
        if (total < MAX_TIME_PER) {
            return ResultModel.FailWithNoData("时间占比总和必须等于100");
        }
        pmDistributeMapper.updateBatch(distributes);
        return ResultModel.Success();
    }

    @Override
    public ResultModel allNode() {
        return ResultModel.SuccessForMsg("查询成功",pmSysTaskMapper.selectByExample(null));
    }

    /**
     *
     * @param params
     * @return
     */
    @Override
    public Map<String, List<String>> judgeFlow(CreateProjectParams params) {
        Map<String,List<String>> resultMap = new HashMap<>(16);
        FlowQueryVo model = new FlowQueryVo();
        model.setOrderType(params.getOrderType());
        model.setQualityLvl(params.getQualityGrade());
        switch (params.getOrderType()) {
            case "1":
                model.setDefaultCat("1");
                break;
            default:
                model.setDefaultCat("2");
                break;
        }
        model = getFlow(model);
        String[] flowPath = model.getWorkFlow().split("->");
        if (flowPath.length == 0) {
            throw new RuntimeException("查找流程失败");
        }

        List<PmFileFlow> fileFlows = new ArrayList<>();
        for (FileWordNumVo file : params.getFileList()) {
            PmFileFlow flow = new PmFileFlow();
            flow.setProjectId(params.getProjectId());
            flow.setFileId(file.getFileId());
            List<String> pathList = judgeDtp(file.getFileName(), file.isHasPic(), params.isTransPic(), params.isPs(), flowPath);
            for (String pathId : pathList) {
                flow.setFlowId(pathId);
                fileFlows.add(flow);
            }
            resultMap.put(file.getFileId(), pathList);
        }
        fileFlowMapper.insertBatch(fileFlows);
        return resultMap;
    }

    /**
     *  判断dtp流程
     * @param fileName 文件名
     * @param hasPic 是否有图片
     * @param isTransWord 是否需要翻译图片文字
     * @param isPs 是否译后P图
     * @param flowPath 该订单的默认流程
     * @return 处理完的流程
     */
    private List<String> judgeDtp(String fileName, boolean hasPic, boolean isTransWord, boolean isPs, String[] flowPath) {
        ArrayList<String> arrayList = new ArrayList<>(Arrays.asList(flowPath));
        String ext = fileName.substring(fileName.lastIndexOf(".") + 1);
        if (ext.contains(FILE_EXT_RTF)) {
            //工程格式
        } else if (ext.contains(FILE_EXT_PDF)) {
            //判断图片：三个条件为且关系，任意不满足则删除译后
            if(!hasPic || !isTransWord || !isPs) {
                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskName().equalsIgnoreCase("译后DTP")).collect(Collectors.toList()));
            }
        } else if (FILE_EXT_XLS.equalsIgnoreCase(ext) || FILE_EXT_XLSX.equalsIgnoreCase(ext) || FILE_EXT_TEXT.equalsIgnoreCase(ext) || FILE_EXT_DOC.equalsIgnoreCase(ext) || FILE_EXT_DOCX.equalsIgnoreCase(ext)) {
            if (!hasPic) {
                //删除译前译后
                arrayList.remove("译前DTP");
                arrayList.remove("译后DTP");
            } else if (!isTransWord) {
                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskType().equalsIgnoreCase("DTP")).collect(Collectors.toList()));
            } else if (!isPs) {
                //删除译后
                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskName().equalsIgnoreCase("译后DTP")).collect(Collectors.toList()));
            }
        }
        return arrayList;
    }

    /**
     * 判断对应领域的PM/众包
     * @param domain
     * @return
     */
    @Override
    public SysMatchingPm judgeTerm(String domain) {
        SysMatchingPmExample example = new SysMatchingPmExample();
        example.createCriteria()
                .andDomainEqualTo(domain);
        List<SysMatchingPm> pmList = sysMatchingPmMapper.selectByExample(example);
        if (pmList.size() > 1) {
            //如果同一领域有多个PM。随机选择一名
            return pmList.get(MathUtil.getRoundNum(pmList.size() - 1, 0));
        } else {
            return pmList.get(0);
        }
    }

    /**
     * 判断项目的匹配规则
     */
    @Override
    public PmAutomatching judgeMatchRule(String orderType, String orderLvl, String cusType, int wordNum) {
        /**
         * 1、读取匹配规则：根据订单类型+订单等级
         * 2、查询对应的规则实体
         */
        PmAutomatchingExample example = new PmAutomatchingExample();
        example.createCriteria()
                .andOrderLvlEqualTo(orderLvl)
                .andOrderTypeEqualTo(orderType)
                .andCusTypeEqualTo(cusType);
        List<PmAutomatching> pmAutomatchingList = pmAutomatchingMapper.selectByExample(example);
        PmAutomatching defaultmatch = null;
        if (pmAutomatchingList.size() >= 1) {
            for (PmAutomatching pmAutomatching : pmAutomatchingList) {
                int highCount = pmAutomatching.getHigherCount();
                int lowCount = pmAutomatching.getLowerCount();
                if (highCount == 0 && lowCount == 0) {
                    defaultmatch = pmAutomatching;
                }
                //最大字数不为0时，则认为是双边都有值的区间，字数必须处于区间内部,最大字数为0时，只需大于等于最小字数即可
                if(highCount != 0) {
                    if (wordNum < highCount && wordNum >= lowCount) {
                       return pmAutomatching;
                    }
                } else {
                    if (wordNum >= lowCount) {
                        return pmAutomatching;
                    }
                }
            }
        }
        return defaultmatch;
    }



}
