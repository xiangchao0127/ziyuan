package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 18:59
 */
@Data
public class DistributeQueryParam {
    /**
     * 是否自动分配
     */
    private Integer useAuto;

    /**
     * 是否匹配pm
     */
    private Integer matchingPm;

    /**
     * 是否匹配翻译经理
     */
    private Integer matchingTranspm;

    /**
     * 是否匹配外包工作人员
     */
    private Integer matchingOutsaler;

    /**
     * 默认翻译工具
     */
    private String defaultCat;

    /**
     * 字数范围(上限）
     */
    private Integer higherCount;

    /**
     * 字数范围(下限）
     */
    private Integer lowerCount;

    /**
     *
     */
    private String remark;

    /**
     * 主键
     */
    private Integer id;
}
