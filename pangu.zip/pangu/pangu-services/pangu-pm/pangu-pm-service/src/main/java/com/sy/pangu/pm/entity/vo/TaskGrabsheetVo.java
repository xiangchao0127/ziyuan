package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmGrabsheet;
import com.sy.pangu.pm.entity.PmTaskInfo;

import java.util.List;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 **/

public class TaskGrabsheetVo {
   private PmTaskInfo pmTaskInfos;
   private PmGrabsheet pmGrabsheets;

    public PmTaskInfo getPmTaskInfos() {
        return pmTaskInfos;
    }

    public void setPmTaskInfos(PmTaskInfo pmTaskInfos) {
        this.pmTaskInfos = pmTaskInfos;
    }

    public PmGrabsheet getPmGrabsheets() {
        return pmGrabsheets;
    }

    public void setPmGrabsheets(PmGrabsheet pmGrabsheets) {
        this.pmGrabsheets = pmGrabsheets;
    }
}
