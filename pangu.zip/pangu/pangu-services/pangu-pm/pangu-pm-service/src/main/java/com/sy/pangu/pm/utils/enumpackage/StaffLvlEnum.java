package com.sy.pangu.pm.utils.enumpackage;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/16 10:26
 */
public enum StaffLvlEnum {

    /**
     * 工作类型：DTP
     */
    TASK_TYPE_BF_DTP("1", "译前DTP"),

    /**
     * 工作类型：翻译
     */
    TASK_TYPE_TRANS("2", "翻译"),

    /**
     * 工作类型：审校
     */
    TASK_TYPE_PROOFREADING("3", "审校"),

    /**
     * 工作类型：质检
     */
    TASK_TYPE_QA("4", "质检"),

    /**
     * 工作类型：DTP
     */
    TASK_TYPE_AF_DTP("5", "译后DTP"),

    /**
     * 工作类型：排版
     */
    TASK_TYPE_TYPESETTING("6", "排版"),

    /**
     * 工作类型：交付
     */
    TASK_TYPE_DELIVER("10", "交付"),

    //以上节点信息中value值保持与数据库id一致


    /**
     * 专职类型
     */
    STAFF_TYPE_FULLJOB("fulltime", "专职"),

    /**
     * 兼职
     */
    STAFF_TYPE_PARTTIMEJOB("freelancer", "兼职");


    private String value;
    private String desc;

    private StaffLvlEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(StaffLvlEnum data : StaffLvlEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知类型";
    }

    public static void main(String[] args) {

        System.out.println(getDescByValue("01"));
    }
}
