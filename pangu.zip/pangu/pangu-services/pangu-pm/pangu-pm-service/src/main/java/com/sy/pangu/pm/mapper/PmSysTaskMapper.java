package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmSysTask;
import java.util.List;

import com.sy.pangu.pm.entity.example.PmSysTaskExample;
import org.apache.ibatis.annotations.Param;

public interface PmSysTaskMapper {
    long countByExample(PmSysTaskExample example);

    int deleteByExample(PmSysTaskExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmSysTask record);

    int insertSelective(PmSysTask record);

    List<PmSysTask> selectByExample(PmSysTaskExample example);

    PmSysTask selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmSysTask record, @Param("example") PmSysTaskExample example);

    int updateByExample(@Param("record") PmSysTask record, @Param("example") PmSysTaskExample example);

    int updateByPrimaryKeySelective(PmSysTask record);

    int updateByPrimaryKey(PmSysTask record);

    List<PmSysTask> selectAll();
}