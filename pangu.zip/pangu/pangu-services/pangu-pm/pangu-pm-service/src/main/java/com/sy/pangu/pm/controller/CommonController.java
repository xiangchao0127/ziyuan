package com.sy.pangu.pm.controller;

import com.sy.pangu.permission.client.UserClient;
//import com.sy.pangu.pm.model.CustInfo;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.permission.model.UserForPMParam;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.utils.CatUtils;
import com.sy.pangu.rm.client.DomainClient;
import com.sy.pangu.rm.client.LanguageClient;
import com.sy.pangu.rm.client.LevelRelationClient;
import com.sy.pangu.rm.model.LevelRelation;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/15 10:15
 */
@RestController
@RequestMapping("/common")
@Api(tags = "公共接口")
@CrossOrigin
public class CommonController {

    protected static final Logger logger = LoggerFactory.getLogger(CommonController.class);

    @Autowired
    private DomainClient domainClient;

    @Autowired
    private LanguageClient languageClient;

    @Autowired
    private UserClient userClient;

    @Autowired
    private LevelRelationClient levelRelationClient;

    @ApiOperation("从RM获取一级领域数据")
    @GetMapping("/domainList")
    public ResultModel domainList() {
        logger.info("向RM请求领域信息：");
        return ResultModel.SuccessForMsg("", domainClient.listDomain());
    }

    @ApiOperation("获取语言对数据")
    @GetMapping("/languageList")
    public ResultModel languageList() {
        logger.info("向RM请求语言对信息：");
        return  ResultModel.SuccessForMsg("", languageClient.listLanguage());
    }

//    @ApiOperation("根据角色筛选人员")
//    @PostMapping("/userList")
//    public ResultModel userList(String roleCode) {
//        return ResultModel.SuccessForMsg("", userClient.getAllUserInfo(null));
//    }

    @ApiOperation("客户等级")
    @PostMapping("/custLevel")
    public ResultModel customType() {
        Map<Integer, String> cusType = new HashMap<>(4);
        cusType.put(0, "普通客户");
        cusType.put(1, "重要客户");
        cusType.put(2, "大客户");
        cusType.put(3, "VIP客户");
        return ResultModel.SuccessForMsg("", cusType);
    }

    @ApiOperation("等级列表")
    @PostMapping("/levelList")
    public ResultModel levelList() {
        return ResultModel.SuccessForMsg("", levelRelationClient.listAllLevelRelation());
    }

    @ApiOperation("人员列表")
    @GetMapping("/userList")
    public ResultModel userList(UserForPMParam userForPMParam) {
        return ResultModel.SuccessForMsg("", userClient.getAllUserInfo(userForPMParam));
    }

}
