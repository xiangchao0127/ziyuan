package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmTaskData;
import com.sy.pangu.pm.entity.example.PmTaskDataExample;
import java.util.List;
import java.util.Map;

import com.sy.pangu.pm.entity.vo.WorkLoadVo;
import org.apache.ibatis.annotations.Param;

public interface PmTaskDataMapper {
    long countByExample(PmTaskDataExample example);

    int deleteByExample(PmTaskDataExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmTaskData record);

    int insertSelective(PmTaskData record);

    List<PmTaskData> selectByExample(PmTaskDataExample example);

    PmTaskData selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmTaskData record, @Param("example") PmTaskDataExample example);

    int updateByExample(@Param("record") PmTaskData record, @Param("example") PmTaskDataExample example);

    int updateByPrimaryKeySelective(PmTaskData record);

    int updateByPrimaryKey(PmTaskData record);

    Map<String,Integer> selectTotalWord(String projectId);

    List<WorkLoadVo> selectDTPLoadInfo(@Param("projectId")String projectId,
                                       @Param("taskStatus")String taskStatus,
                                       @Param("list")String[] dtpTypes);

    List<WorkLoadVo> selectTransLoadInfo(@Param("projectId")String projectId,
                                         @Param("taskStatus")String taskStatus,
                                         @Param("list")String[] dtpTypes);
}