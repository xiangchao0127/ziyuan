package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmAutomatching;
import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 */
@Data
public class AutoRuleQuery {
    List<AutoRuleVo> autoRuleVos;
}
