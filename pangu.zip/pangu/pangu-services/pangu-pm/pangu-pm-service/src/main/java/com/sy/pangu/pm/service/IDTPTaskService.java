package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmTaskInfo;

/**
 * @author ：jzj
 * date ：Created in 2019/4/17 15:30
 */
public interface IDTPTaskService {
    /**
     * 领取译后dpt
     * @param taskId
     */
    public void getAfterDTPTask(String taskId) throws Exception;

    /**
     * 是否有领取译后的条件
     * @param taskId
     * @return
     */
    public boolean hasPermissionsForAfterDTPTask(String taskId) throws Exception;

    /**
     * 设置工作量
     * @param taskId
     * @param wordload
     */
    public void setWordLoad(String taskId, String wordload);
}
