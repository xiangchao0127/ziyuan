package com.sy.pangu.pm.utils;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author XiangChao
 * @date 2019/5/14
 */
public class FtpUtils {
    private static final Logger LOG = LoggerFactory.getLogger(FtpUtils.class);

    public static void main(String[] args) throws IOException {
//       upload("192.168.2.202", 22, "root", "root", new FileInputStream(new File("D:\\工作文档\\数据库设计文档V2.0.doc")),"/opt/docker/file-upload/pm/20/test/1/2/数据库设计文档V2.0.doc");

    }

    /**
     * 上传文件
     *
     * @param host        ip
     * @param port        端口（默认22）
     * @param username    用户名
     * @param password    密码
     * @param inputStream 输入流
     * @param dst         目标地址
     * @return
     */
    public static boolean upload(String host, int port, String username, final String password, InputStream inputStream, String dst) {
        ChannelSftp sftp = null;
        Channel channel = null;
        Session sshSession = null;
        try {
            JSch jsch = new JSch();
            jsch.getSession(username, host, port);
            sshSession = jsch.getSession(username, host, port);
            sshSession.setPassword(password);
            Properties sshConfig = new Properties();
            sshConfig.put("StrictHostKeyChecking", "no");
            sshSession.setConfig(sshConfig);
            sshSession.connect();
            LOG.debug("Session connected!");
            channel = sshSession.openChannel("sftp");
            channel.connect();
            LOG.debug("Channel connected!");
            sftp = (ChannelSftp) channel;
            isDirExist(sftp, dst);
            sftp.put(inputStream, dst);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeChannel(sftp);
            closeChannel(channel);
            closeSession(sshSession);
        }
        return true;
    }

    /**
     * 下载文件
     * @param host  ip
     * @param port  端口
     * @param username 用户名
     * @param password 密码
     * @param dst 目标资源
     * @return
     */
    public static boolean download(String host, int port, String username, final String password, String dst, String dstTemp) {
        ChannelSftp sftp = null;
        Channel channel = null;
        Session sshSession = null;
        InputStream inputStream = null;
        try {
            JSch jsch = new JSch();
            jsch.getSession(username, host, port);
            sshSession = jsch.getSession(username, host, port);
            sshSession.setPassword(password);
            Properties sshConfig = new Properties();
            sshConfig.put("StrictHostKeyChecking", "no");
            sshSession.setConfig(sshConfig);
            sshSession.connect();
            LOG.debug("Session connected!");
            channel = sshSession.openChannel("sftp");
            channel.connect();
            LOG.debug("Channel connected!");
            sftp = (ChannelSftp) channel;
            inputStream = sftp.get(dst);
            File targetFile = new File(dstTemp);
            FileUtils.copyInputStreamToFile(inputStream, targetFile);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeChannel(sftp);
            closeChannel(channel);
            closeSession(sshSession);
        }
        return true;
    }

    private static void closeChannel(Channel channel) {
        if (channel != null) {
            if (channel.isConnected()) {
                channel.disconnect();
            }
        }
    }

    private static void closeSession(Session session) {
        if (session != null) {
            if (session.isConnected()) {
                session.disconnect();
            }
        }
    }

    /**
     * 判断目录是否存在  不存在 - 创建
     * @param sftp
     * @param dir
     */
    public static void isDirExist(ChannelSftp sftp, String dir){
        dir = dir.substring(0, dir.lastIndexOf("/"));

        String[] dirs = dir.split("/");
        String exDir = "";
        for(int i = 0; i<dirs.length; i++){
            exDir = exDir + dirs[i] + "/";
            try{
                sftp.cd(exDir);
            } catch (SftpException e) {
                LOG.error("目录不存在，开始创建目录：{}",exDir);
                try {
                    sftp.mkdir(exDir);
                } catch (SftpException ex) {
                    LOG.error("创建目录失败：{}",exDir);
                }
            }
        }
    }
}
