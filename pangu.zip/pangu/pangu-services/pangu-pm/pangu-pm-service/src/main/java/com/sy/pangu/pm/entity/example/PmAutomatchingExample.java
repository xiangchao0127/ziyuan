package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class PmAutomatchingExample {
    /**
     * pm_automatching
     */
    protected String orderByClause;

    /**
     * pm_automatching
     */
    protected boolean distinct;

    /**
     * pm_automatching
     */
    protected List<Criteria> oredCriteria;

    public PmAutomatchingExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_automatching null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOrderLvlIsNull() {
            addCriterion("order_lvl is null");
            return (Criteria) this;
        }

        public Criteria andOrderLvlIsNotNull() {
            addCriterion("order_lvl is not null");
            return (Criteria) this;
        }

        public Criteria andOrderLvlEqualTo(String value) {
            addCriterion("order_lvl =", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlNotEqualTo(String value) {
            addCriterion("order_lvl <>", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlGreaterThan(String value) {
            addCriterion("order_lvl >", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlGreaterThanOrEqualTo(String value) {
            addCriterion("order_lvl >=", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlLessThan(String value) {
            addCriterion("order_lvl <", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlLessThanOrEqualTo(String value) {
            addCriterion("order_lvl <=", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlLike(String value) {
            addCriterion("order_lvl like", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlNotLike(String value) {
            addCriterion("order_lvl not like", value, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlIn(List<String> values) {
            addCriterion("order_lvl in", values, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlNotIn(List<String> values) {
            addCriterion("order_lvl not in", values, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlBetween(String value1, String value2) {
            addCriterion("order_lvl between", value1, value2, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderLvlNotBetween(String value1, String value2) {
            addCriterion("order_lvl not between", value1, value2, "orderLvl");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIsNull() {
            addCriterion("order_type is null");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIsNotNull() {
            addCriterion("order_type is not null");
            return (Criteria) this;
        }

        public Criteria andOrderTypeEqualTo(String value) {
            addCriterion("order_type =", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotEqualTo(String value) {
            addCriterion("order_type <>", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeGreaterThan(String value) {
            addCriterion("order_type >", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeGreaterThanOrEqualTo(String value) {
            addCriterion("order_type >=", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLessThan(String value) {
            addCriterion("order_type <", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLessThanOrEqualTo(String value) {
            addCriterion("order_type <=", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLike(String value) {
            addCriterion("order_type like", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotLike(String value) {
            addCriterion("order_type not like", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIn(List<String> values) {
            addCriterion("order_type in", values, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotIn(List<String> values) {
            addCriterion("order_type not in", values, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeBetween(String value1, String value2) {
            addCriterion("order_type between", value1, value2, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotBetween(String value1, String value2) {
            addCriterion("order_type not between", value1, value2, "orderType");
            return (Criteria) this;
        }

        public Criteria andCusTypeIsNull() {
            addCriterion("cus_type is null");
            return (Criteria) this;
        }

        public Criteria andCusTypeIsNotNull() {
            addCriterion("cus_type is not null");
            return (Criteria) this;
        }

        public Criteria andCusTypeEqualTo(String value) {
            addCriterion("cus_type =", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeNotEqualTo(String value) {
            addCriterion("cus_type <>", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeGreaterThan(String value) {
            addCriterion("cus_type >", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeGreaterThanOrEqualTo(String value) {
            addCriterion("cus_type >=", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeLessThan(String value) {
            addCriterion("cus_type <", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeLessThanOrEqualTo(String value) {
            addCriterion("cus_type <=", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeLike(String value) {
            addCriterion("cus_type like", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeNotLike(String value) {
            addCriterion("cus_type not like", value, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeIn(List<String> values) {
            addCriterion("cus_type in", values, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeNotIn(List<String> values) {
            addCriterion("cus_type not in", values, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeBetween(String value1, String value2) {
            addCriterion("cus_type between", value1, value2, "cusType");
            return (Criteria) this;
        }

        public Criteria andCusTypeNotBetween(String value1, String value2) {
            addCriterion("cus_type not between", value1, value2, "cusType");
            return (Criteria) this;
        }

        public Criteria andWordCountIsNull() {
            addCriterion("word_count is null");
            return (Criteria) this;
        }

        public Criteria andWordCountIsNotNull() {
            addCriterion("word_count is not null");
            return (Criteria) this;
        }

        public Criteria andWordCountEqualTo(Integer value) {
            addCriterion("word_count =", value, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountNotEqualTo(Integer value) {
            addCriterion("word_count <>", value, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountGreaterThan(Integer value) {
            addCriterion("word_count >", value, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("word_count >=", value, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountLessThan(Integer value) {
            addCriterion("word_count <", value, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountLessThanOrEqualTo(Integer value) {
            addCriterion("word_count <=", value, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountIn(List<Integer> values) {
            addCriterion("word_count in", values, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountNotIn(List<Integer> values) {
            addCriterion("word_count not in", values, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountBetween(Integer value1, Integer value2) {
            addCriterion("word_count between", value1, value2, "wordCount");
            return (Criteria) this;
        }

        public Criteria andWordCountNotBetween(Integer value1, Integer value2) {
            addCriterion("word_count not between", value1, value2, "wordCount");
            return (Criteria) this;
        }

        public Criteria andUseAutoIsNull() {
            addCriterion("use_auto is null");
            return (Criteria) this;
        }

        public Criteria andUseAutoIsNotNull() {
            addCriterion("use_auto is not null");
            return (Criteria) this;
        }

        public Criteria andUseAutoEqualTo(Integer value) {
            addCriterion("use_auto =", value, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoNotEqualTo(Integer value) {
            addCriterion("use_auto <>", value, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoGreaterThan(Integer value) {
            addCriterion("use_auto >", value, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoGreaterThanOrEqualTo(Integer value) {
            addCriterion("use_auto >=", value, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoLessThan(Integer value) {
            addCriterion("use_auto <", value, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoLessThanOrEqualTo(Integer value) {
            addCriterion("use_auto <=", value, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoIn(List<Integer> values) {
            addCriterion("use_auto in", values, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoNotIn(List<Integer> values) {
            addCriterion("use_auto not in", values, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoBetween(Integer value1, Integer value2) {
            addCriterion("use_auto between", value1, value2, "useAuto");
            return (Criteria) this;
        }

        public Criteria andUseAutoNotBetween(Integer value1, Integer value2) {
            addCriterion("use_auto not between", value1, value2, "useAuto");
            return (Criteria) this;
        }

        public Criteria andMatchingPmIsNull() {
            addCriterion("matching_pm is null");
            return (Criteria) this;
        }

        public Criteria andMatchingPmIsNotNull() {
            addCriterion("matching_pm is not null");
            return (Criteria) this;
        }

        public Criteria andMatchingPmEqualTo(Integer value) {
            addCriterion("matching_pm =", value, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmNotEqualTo(Integer value) {
            addCriterion("matching_pm <>", value, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmGreaterThan(Integer value) {
            addCriterion("matching_pm >", value, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmGreaterThanOrEqualTo(Integer value) {
            addCriterion("matching_pm >=", value, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmLessThan(Integer value) {
            addCriterion("matching_pm <", value, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmLessThanOrEqualTo(Integer value) {
            addCriterion("matching_pm <=", value, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmIn(List<Integer> values) {
            addCriterion("matching_pm in", values, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmNotIn(List<Integer> values) {
            addCriterion("matching_pm not in", values, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmBetween(Integer value1, Integer value2) {
            addCriterion("matching_pm between", value1, value2, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingPmNotBetween(Integer value1, Integer value2) {
            addCriterion("matching_pm not between", value1, value2, "matchingPm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmIsNull() {
            addCriterion("matching_transpm is null");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmIsNotNull() {
            addCriterion("matching_transpm is not null");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmEqualTo(Integer value) {
            addCriterion("matching_transpm =", value, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmNotEqualTo(Integer value) {
            addCriterion("matching_transpm <>", value, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmGreaterThan(Integer value) {
            addCriterion("matching_transpm >", value, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmGreaterThanOrEqualTo(Integer value) {
            addCriterion("matching_transpm >=", value, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmLessThan(Integer value) {
            addCriterion("matching_transpm <", value, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmLessThanOrEqualTo(Integer value) {
            addCriterion("matching_transpm <=", value, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmIn(List<Integer> values) {
            addCriterion("matching_transpm in", values, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmNotIn(List<Integer> values) {
            addCriterion("matching_transpm not in", values, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmBetween(Integer value1, Integer value2) {
            addCriterion("matching_transpm between", value1, value2, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingTranspmNotBetween(Integer value1, Integer value2) {
            addCriterion("matching_transpm not between", value1, value2, "matchingTranspm");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerIsNull() {
            addCriterion("matching_outsaler is null");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerIsNotNull() {
            addCriterion("matching_outsaler is not null");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerEqualTo(Integer value) {
            addCriterion("matching_outsaler =", value, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerNotEqualTo(Integer value) {
            addCriterion("matching_outsaler <>", value, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerGreaterThan(Integer value) {
            addCriterion("matching_outsaler >", value, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerGreaterThanOrEqualTo(Integer value) {
            addCriterion("matching_outsaler >=", value, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerLessThan(Integer value) {
            addCriterion("matching_outsaler <", value, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerLessThanOrEqualTo(Integer value) {
            addCriterion("matching_outsaler <=", value, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerIn(List<Integer> values) {
            addCriterion("matching_outsaler in", values, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerNotIn(List<Integer> values) {
            addCriterion("matching_outsaler not in", values, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerBetween(Integer value1, Integer value2) {
            addCriterion("matching_outsaler between", value1, value2, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andMatchingOutsalerNotBetween(Integer value1, Integer value2) {
            addCriterion("matching_outsaler not between", value1, value2, "matchingOutsaler");
            return (Criteria) this;
        }

        public Criteria andDefaultCatIsNull() {
            addCriterion("default_cat is null");
            return (Criteria) this;
        }

        public Criteria andDefaultCatIsNotNull() {
            addCriterion("default_cat is not null");
            return (Criteria) this;
        }

        public Criteria andDefaultCatEqualTo(String value) {
            addCriterion("default_cat =", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotEqualTo(String value) {
            addCriterion("default_cat <>", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatGreaterThan(String value) {
            addCriterion("default_cat >", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatGreaterThanOrEqualTo(String value) {
            addCriterion("default_cat >=", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatLessThan(String value) {
            addCriterion("default_cat <", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatLessThanOrEqualTo(String value) {
            addCriterion("default_cat <=", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatLike(String value) {
            addCriterion("default_cat like", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotLike(String value) {
            addCriterion("default_cat not like", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatIn(List<String> values) {
            addCriterion("default_cat in", values, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotIn(List<String> values) {
            addCriterion("default_cat not in", values, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatBetween(String value1, String value2) {
            addCriterion("default_cat between", value1, value2, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotBetween(String value1, String value2) {
            addCriterion("default_cat not between", value1, value2, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andHigherCountIsNull() {
            addCriterion("higher_count is null");
            return (Criteria) this;
        }

        public Criteria andHigherCountIsNotNull() {
            addCriterion("higher_count is not null");
            return (Criteria) this;
        }

        public Criteria andHigherCountEqualTo(Integer value) {
            addCriterion("higher_count =", value, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountNotEqualTo(Integer value) {
            addCriterion("higher_count <>", value, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountGreaterThan(Integer value) {
            addCriterion("higher_count >", value, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("higher_count >=", value, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountLessThan(Integer value) {
            addCriterion("higher_count <", value, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountLessThanOrEqualTo(Integer value) {
            addCriterion("higher_count <=", value, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountIn(List<Integer> values) {
            addCriterion("higher_count in", values, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountNotIn(List<Integer> values) {
            addCriterion("higher_count not in", values, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountBetween(Integer value1, Integer value2) {
            addCriterion("higher_count between", value1, value2, "higherCount");
            return (Criteria) this;
        }

        public Criteria andHigherCountNotBetween(Integer value1, Integer value2) {
            addCriterion("higher_count not between", value1, value2, "higherCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountIsNull() {
            addCriterion("lower_count is null");
            return (Criteria) this;
        }

        public Criteria andLowerCountIsNotNull() {
            addCriterion("lower_count is not null");
            return (Criteria) this;
        }

        public Criteria andLowerCountEqualTo(Integer value) {
            addCriterion("lower_count =", value, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountNotEqualTo(Integer value) {
            addCriterion("lower_count <>", value, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountGreaterThan(Integer value) {
            addCriterion("lower_count >", value, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("lower_count >=", value, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountLessThan(Integer value) {
            addCriterion("lower_count <", value, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountLessThanOrEqualTo(Integer value) {
            addCriterion("lower_count <=", value, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountIn(List<Integer> values) {
            addCriterion("lower_count in", values, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountNotIn(List<Integer> values) {
            addCriterion("lower_count not in", values, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountBetween(Integer value1, Integer value2) {
            addCriterion("lower_count between", value1, value2, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andLowerCountNotBetween(Integer value1, Integer value2) {
            addCriterion("lower_count not between", value1, value2, "lowerCount");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }
    }

    /**
     * pm_automatching
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_automatching null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}