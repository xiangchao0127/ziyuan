package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 **/
@Data
public class ManuscriptToEcVo {
    /**
     * 文件id
     */
    private int fileId;
    /**
     * 译文下载id
     */
    private int uploadFileId;
    /**
     * 文件名字
     */
    private String fileName;
    /**
     * 文件大小
     */
    private String fileSize;
    /**
     * 实际翻译量
     */
    private int translationNnum;
    /**
     * 项目经理id
     */
    private String pmId;
    /**
     * 项目经理名字
     */
    private String pmName;
    /**
     * 要求返稿时间
     */
    private String deliveryTime;
    /**
     * 翻译完成时间
     */
    private String realCompletTime;
    /**
     * 翻译文件下dpt的任务信息
     */
    List<DTPtoECOfFileVo> dtptoECOfFileVos ;

}
