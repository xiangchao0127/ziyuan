package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/9 18:37
 */
@Data
public class ProjectProgressResponse {
    private String projectId;
    private float progressValue;
}
