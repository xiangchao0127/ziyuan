package com.sy.pangu.pm.utils.enumpackage;

public enum ApplyRecordEnum {

    /**
     * 申请类型：退稿
     */
    APPLY_TYPE_CANCEL_TASK("00","退稿"),
    /**
     * 申请类型：再次编辑
     */
    APPLY_TYPE_EDIT_AGAIN("01","再次编辑"),
    /**
     *申请状态：申请中
     */
    APPLY_SATUS_ING("11","申请中"),
    /**
     *申请状态：通过
     */
    APPLY_SATUS_AGREE("12","通过"),
    /**
     *申请状态：驳回
     */
    APPLY_SATUS_REJECT("13","驳回");

    private String value;
    private String desc;

    private ApplyRecordEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(ApplyRecordEnum data : ApplyRecordEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知状态";
    }

    public static void main(String[] args) {
        for(int i=0;i<200;i++){

            new Thread(() ->{
                int key = test();
            }).start();
        }
        try {
            Thread.sleep(1000*30);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static int index = 0;
    synchronized static int test(){
        System.out.println(index);
        index = index + 1;
        return index;
    }
}
