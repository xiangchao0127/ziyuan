package com.sy.pangu.pm.utils;

import java.util.Random;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/18 14:43
 */
public class MathUtil {

    public static int getRoundNum(int maxNum, int minNum) {
        return (int)(minNum + Math.random() * (maxNum - minNum + 1));
    }
}
