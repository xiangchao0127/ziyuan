package com.sy.pangu.pm.entity;

public class PmGettaskid {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private Integer taskId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }
}