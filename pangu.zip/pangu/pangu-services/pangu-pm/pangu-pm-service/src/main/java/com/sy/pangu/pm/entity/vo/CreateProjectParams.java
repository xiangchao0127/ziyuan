package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/14 15:49
 */
@Data
public class CreateProjectParams {
    /**
     * 文件列表
     */
    private List<FileWordNumVo> fileList;
    /**
     * 是否翻译图片文字
     */
    private boolean isTransPic;
    /**
     * 是否译后P图
     */
    private boolean isPs;

    /**
     * 是否有术语表
     */
    private boolean hasTermFile;
    /**
     * 客户类型
     */
    private String cusType;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 客户id
     */
    private String customerId;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 预估字数
     */
    private String estimateWord;

    /**
     * 质量等级/订单等级（标准0，出版级1，职业母审2）
     */
    private String qualityGrade;

    /**
     * 订单类型 /稿件类型  （文档翻译0，证件翻译1，图书翻译2，非译订单3）
     */
    private String orderType;

    /**
     * 订单备注
     */
    private String orderRemake;

    /**
     * 源语种
     */
    private String sourceLan;

    /**
     * 目标语种
     */
    private String targetLan;

    /**
     * 下单人
     */
    private String orderPeople;

    /**
     * 下单时间
     */
    private String orderTime;

    /**
     * 返稿时间
     */
    private String deliveryTime;

    /**
     * 专业领域
     */
    private String domain;
}
