package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/25 13:47
 */
@Data
public class UnitPriceVo {
    /**
     * 员工类型：fulltime，freelancer
     */
    private String staffType;
    /**
     * 等级：专职传等级，兼职传订单等级
     */
    private String level;
    private String sourceLan;
    private String targetLan;
    private BigDecimal unitPrice;
    /**
     * 任务类型：翻译审校质检等
     */
    private String taskType;
    /**
     * 工作类型：证件图书文档非译等
     */
    private String workType;
}
