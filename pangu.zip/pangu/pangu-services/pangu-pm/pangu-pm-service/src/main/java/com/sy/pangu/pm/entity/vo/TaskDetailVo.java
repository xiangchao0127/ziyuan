package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmFileFlow;

import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/4/15 11:36
 */
public class TaskDetailVo {

    private String taskId;
    private String taskName;
    private String pmId;
    private String pmName;

    private String tranmgrId;
    private String tranmgrName;

    private String remark;

    private List<PmFileFlow> flows;

    private List<PmFile> files;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getPmId() {
        return pmId;
    }

    public void setPmId(String pmId) {
        this.pmId = pmId;
    }

    public String getPmName() {
        return pmName;
    }

    public void setPmName(String pmName) {
        this.pmName = pmName;
    }

    public String getTranmgrId() {
        return tranmgrId;
    }

    public void setTranmgrId(String tranmgrId) {
        this.tranmgrId = tranmgrId;
    }

    public String getTranmgrName() {
        return tranmgrName;
    }

    public void setTranmgrName(String tranmgrName) {
        this.tranmgrName = tranmgrName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<PmFileFlow> getFlows() {
        return flows;
    }

    public void setFlows(List<PmFileFlow> flows) {
        this.flows = flows;
    }

    public List<PmFile> getFiles() {
        return files;
    }

    public void setFiles(List<PmFile> files) {
        this.files = files;
    }
}
