package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/9 9:35
 */
@Data
public class AutoRuleVo {
    /**
     * 订单等级
     */
    private String orderLvl;

    /**
     *
     */
    private String orderType;

    /**
     * 客户类型
     */
    private String cusType;

    private String defaultCat;
    List<DistributeQueryParam> automatchingList;
}
