package com.sy.pangu.pm.entity;

public class SysStaffLvl {
    /**
     * 等级值
     */
    private Integer lvlNum;

    /**
     * 等级名字
     */
    private String lvlName;

    /**
     * 等级类型（兼职：1，专职：0）
     */
    private String lvlType;

    /**
     * 等级类型（审校，QA，翻译,DTP等）
     */
    private String taskType;

    public Integer getLvlNum() {
        return lvlNum;
    }

    public void setLvlNum(Integer lvlNum) {
        this.lvlNum = lvlNum;
    }

    public String getLvlName() {
        return lvlName;
    }

    public void setLvlName(String lvlName) {
        this.lvlName = lvlName == null ? null : lvlName.trim();
    }

    public String getLvlType() {
        return lvlType;
    }

    public void setLvlType(String lvlType) {
        this.lvlType = lvlType == null ? null : lvlType.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }
}