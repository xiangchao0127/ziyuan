package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/7 15:33
 */
@Data
public class WorkLoadQueryDto {
    private String taskName;
    private String taskType;
    private String userCode;
    private String startTime;
    private String requestComTime;
    private String realComTime;
    private String workLoad;
    private String ratio;
    private String unitPrice;
    private String projectId;
}
