package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmTaskWorkload;
import com.sy.pangu.pm.entity.example.PmTaskWorkloadExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmTaskWorkloadMapper {
    long countByExample(PmTaskWorkloadExample example);

    int deleteByExample(PmTaskWorkloadExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmTaskWorkload record);

    int insertSelective(PmTaskWorkload record);

    List<PmTaskWorkload> selectByExample(PmTaskWorkloadExample example);

    PmTaskWorkload selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmTaskWorkload record, @Param("example") PmTaskWorkloadExample example);

    int updateByExample(@Param("record") PmTaskWorkload record, @Param("example") PmTaskWorkloadExample example);

    int updateByPrimaryKeySelective(PmTaskWorkload record);

    int updateByPrimaryKey(PmTaskWorkload record);

    int insertBatch(List<PmTaskWorkload> workloads);
}