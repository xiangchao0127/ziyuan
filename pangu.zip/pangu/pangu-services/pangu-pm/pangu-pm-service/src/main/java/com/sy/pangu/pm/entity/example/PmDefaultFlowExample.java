package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class PmDefaultFlowExample {
    /**
     * pm_default_flow
     */
    protected String orderByClause;

    /**
     * pm_default_flow
     */
    protected boolean distinct;

    /**
     * pm_default_flow
     */
    protected List<Criteria> oredCriteria;

    public PmDefaultFlowExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_default_flow null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andFlowIsNull() {
            addCriterion("flow is null");
            return (Criteria) this;
        }

        public Criteria andFlowIsNotNull() {
            addCriterion("flow is not null");
            return (Criteria) this;
        }

        public Criteria andFlowEqualTo(String value) {
            addCriterion("flow =", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowNotEqualTo(String value) {
            addCriterion("flow <>", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowGreaterThan(String value) {
            addCriterion("flow >", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowGreaterThanOrEqualTo(String value) {
            addCriterion("flow >=", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowLessThan(String value) {
            addCriterion("flow <", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowLessThanOrEqualTo(String value) {
            addCriterion("flow <=", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowLike(String value) {
            addCriterion("flow like", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowNotLike(String value) {
            addCriterion("flow not like", value, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowIn(List<String> values) {
            addCriterion("flow in", values, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowNotIn(List<String> values) {
            addCriterion("flow not in", values, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowBetween(String value1, String value2) {
            addCriterion("flow between", value1, value2, "flow");
            return (Criteria) this;
        }

        public Criteria andFlowNotBetween(String value1, String value2) {
            addCriterion("flow not between", value1, value2, "flow");
            return (Criteria) this;
        }

        public Criteria andNodeIdIsNull() {
            addCriterion("node_id is null");
            return (Criteria) this;
        }

        public Criteria andNodeIdIsNotNull() {
            addCriterion("node_id is not null");
            return (Criteria) this;
        }

        public Criteria andNodeIdEqualTo(Integer value) {
            addCriterion("node_id =", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotEqualTo(Integer value) {
            addCriterion("node_id <>", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdGreaterThan(Integer value) {
            addCriterion("node_id >", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("node_id >=", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdLessThan(Integer value) {
            addCriterion("node_id <", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdLessThanOrEqualTo(Integer value) {
            addCriterion("node_id <=", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdIn(List<Integer> values) {
            addCriterion("node_id in", values, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotIn(List<Integer> values) {
            addCriterion("node_id not in", values, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdBetween(Integer value1, Integer value2) {
            addCriterion("node_id between", value1, value2, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("node_id not between", value1, value2, "nodeId");
            return (Criteria) this;
        }

        public Criteria andLastFlowIsNull() {
            addCriterion("last_flow is null");
            return (Criteria) this;
        }

        public Criteria andLastFlowIsNotNull() {
            addCriterion("last_flow is not null");
            return (Criteria) this;
        }

        public Criteria andLastFlowEqualTo(Integer value) {
            addCriterion("last_flow =", value, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowNotEqualTo(Integer value) {
            addCriterion("last_flow <>", value, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowGreaterThan(Integer value) {
            addCriterion("last_flow >", value, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowGreaterThanOrEqualTo(Integer value) {
            addCriterion("last_flow >=", value, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowLessThan(Integer value) {
            addCriterion("last_flow <", value, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowLessThanOrEqualTo(Integer value) {
            addCriterion("last_flow <=", value, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowIn(List<Integer> values) {
            addCriterion("last_flow in", values, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowNotIn(List<Integer> values) {
            addCriterion("last_flow not in", values, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowBetween(Integer value1, Integer value2) {
            addCriterion("last_flow between", value1, value2, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andLastFlowNotBetween(Integer value1, Integer value2) {
            addCriterion("last_flow not between", value1, value2, "lastFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowIsNull() {
            addCriterion("next_flow is null");
            return (Criteria) this;
        }

        public Criteria andNextFlowIsNotNull() {
            addCriterion("next_flow is not null");
            return (Criteria) this;
        }

        public Criteria andNextFlowEqualTo(Integer value) {
            addCriterion("next_flow =", value, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowNotEqualTo(Integer value) {
            addCriterion("next_flow <>", value, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowGreaterThan(Integer value) {
            addCriterion("next_flow >", value, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowGreaterThanOrEqualTo(Integer value) {
            addCriterion("next_flow >=", value, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowLessThan(Integer value) {
            addCriterion("next_flow <", value, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowLessThanOrEqualTo(Integer value) {
            addCriterion("next_flow <=", value, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowIn(List<Integer> values) {
            addCriterion("next_flow in", values, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowNotIn(List<Integer> values) {
            addCriterion("next_flow not in", values, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowBetween(Integer value1, Integer value2) {
            addCriterion("next_flow between", value1, value2, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andNextFlowNotBetween(Integer value1, Integer value2) {
            addCriterion("next_flow not between", value1, value2, "nextFlow");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIsNull() {
            addCriterion("order_type is null");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIsNotNull() {
            addCriterion("order_type is not null");
            return (Criteria) this;
        }

        public Criteria andOrderTypeEqualTo(String value) {
            addCriterion("order_type =", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotEqualTo(String value) {
            addCriterion("order_type <>", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeGreaterThan(String value) {
            addCriterion("order_type >", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeGreaterThanOrEqualTo(String value) {
            addCriterion("order_type >=", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLessThan(String value) {
            addCriterion("order_type <", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLessThanOrEqualTo(String value) {
            addCriterion("order_type <=", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLike(String value) {
            addCriterion("order_type like", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotLike(String value) {
            addCriterion("order_type not like", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIn(List<String> values) {
            addCriterion("order_type in", values, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotIn(List<String> values) {
            addCriterion("order_type not in", values, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeBetween(String value1, String value2) {
            addCriterion("order_type between", value1, value2, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotBetween(String value1, String value2) {
            addCriterion("order_type not between", value1, value2, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderGradeIsNull() {
            addCriterion("order_grade is null");
            return (Criteria) this;
        }

        public Criteria andOrderGradeIsNotNull() {
            addCriterion("order_grade is not null");
            return (Criteria) this;
        }

        public Criteria andOrderGradeEqualTo(String value) {
            addCriterion("order_grade =", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeNotEqualTo(String value) {
            addCriterion("order_grade <>", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeGreaterThan(String value) {
            addCriterion("order_grade >", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeGreaterThanOrEqualTo(String value) {
            addCriterion("order_grade >=", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeLessThan(String value) {
            addCriterion("order_grade <", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeLessThanOrEqualTo(String value) {
            addCriterion("order_grade <=", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeLike(String value) {
            addCriterion("order_grade like", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeNotLike(String value) {
            addCriterion("order_grade not like", value, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeIn(List<String> values) {
            addCriterion("order_grade in", values, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeNotIn(List<String> values) {
            addCriterion("order_grade not in", values, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeBetween(String value1, String value2) {
            addCriterion("order_grade between", value1, value2, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andOrderGradeNotBetween(String value1, String value2) {
            addCriterion("order_grade not between", value1, value2, "orderGrade");
            return (Criteria) this;
        }

        public Criteria andDefaultCatIsNull() {
            addCriterion("default_cat is null");
            return (Criteria) this;
        }

        public Criteria andDefaultCatIsNotNull() {
            addCriterion("default_cat is not null");
            return (Criteria) this;
        }

        public Criteria andDefaultCatEqualTo(String value) {
            addCriterion("default_cat =", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotEqualTo(String value) {
            addCriterion("default_cat <>", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatGreaterThan(String value) {
            addCriterion("default_cat >", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatGreaterThanOrEqualTo(String value) {
            addCriterion("default_cat >=", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatLessThan(String value) {
            addCriterion("default_cat <", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatLessThanOrEqualTo(String value) {
            addCriterion("default_cat <=", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatLike(String value) {
            addCriterion("default_cat like", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotLike(String value) {
            addCriterion("default_cat not like", value, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatIn(List<String> values) {
            addCriterion("default_cat in", values, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotIn(List<String> values) {
            addCriterion("default_cat not in", values, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatBetween(String value1, String value2) {
            addCriterion("default_cat between", value1, value2, "defaultCat");
            return (Criteria) this;
        }

        public Criteria andDefaultCatNotBetween(String value1, String value2) {
            addCriterion("default_cat not between", value1, value2, "defaultCat");
            return (Criteria) this;
        }
    }

    /**
     * pm_default_flow
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_default_flow null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}