package com.sy.pangu.pm.service.impl;

import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.service.IDTPTaskService;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/4/17 15:33
 */
@Service
public class DTPTaskServiceImpl implements IDTPTaskService {

    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
    @Autowired
    TransTaskServiceImpl taskService;

    /**
     * 领取译后dpt
     * @param taskId
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor = Exception.class)
    public void getAfterDTPTask(String taskId) throws Exception {
        PmTaskInfo taskInfo = taskService.getTaskInfoByTaskId(taskId);
        String staffnum = taskInfo.getStaffNum();

        //设置更新条件
        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andProjectIdEqualTo(taskInfo.getProjectId())
                .andFileIdEqualTo(taskInfo.getFileId())
                .andTaskTypeEqualTo(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())
                .andStaffNumEqualTo(ParamStatic.TASK_DEFAULT_STAFFNUM)
                .andTaskStatusEqualTo(TaskInfoEnum.TASK_STATUS_INIT.getValue());

        //更新人员工号
        PmTaskInfo taskInfoUp = new PmTaskInfo();
        taskInfoUp.setStaffNum(staffnum);
//        taskInfoUp.setTaskStatus(TaskInfoEnum.TASK_STATUS_NOT_OPEN.getValue());
        taskInfoUp.setTaskStatus(TaskInfoEnum.TASK_STATUS_ING.getValue());
        int res = taskInfoMapper.updateByExampleSelective(taskInfoUp,example);
        if(res != 1){//更新记录不是1
            //回滚
            throw new Exception("领取译后DTP失败 -- >>>>>>>>>> 更新数据量："+res);
        }
    }

    /**
     * 是否有领取译后的条件
     *
     * @return
     */
    @Override
    public boolean hasPermissionsForAfterDTPTask(String taskId) throws RuntimeException {

        PmTaskInfo taskInfo = taskService.getTaskInfoByTaskId(taskId);

        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andProjectIdEqualTo(taskInfo.getProjectId())
                .andFileIdEqualTo(taskInfo.getFileId())
                .andTaskTypeEqualTo(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())
                .andStaffNumEqualTo(ParamStatic.TASK_DEFAULT_STAFFNUM)
                .andTaskStatusEqualTo(TaskInfoEnum.TASK_STATUS_INIT.getValue());

        List<PmTaskInfo> taskInfos = taskInfoMapper.selectByExample(example);
        return taskInfos.size() == 1;
    }

    /**
     * 设置工作量
     *
     * @param taskId
     * @param wordload
     */
    @Override
    public void setWordLoad(String taskId, String wordload) {
        PmTaskInfo taskInfo = new PmTaskInfo();
        taskInfo.setWorkLoad(wordload);

        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andTaskIdEqualTo(taskId);

        taskInfoMapper.updateByExampleSelective(taskInfo,example);
    }
}
