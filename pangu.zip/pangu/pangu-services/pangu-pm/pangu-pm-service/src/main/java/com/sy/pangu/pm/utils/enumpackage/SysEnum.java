package com.sy.pangu.pm.utils.enumpackage;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/29 10:29
 * 保存一些很多地方会使用到的系统字段
 */
public enum  SysEnum {
    AUTO_ALLOT("01","自动分配"),
    HAND_ALLOT("02", "手动分配"),
    JOB_FULL("1","专职"),
    JOB_PART("2", "兼职"),
    /**
     * 字段中的修改人/添加人为系统自动添加时
     */
    SYS_NAME("SYS", "PM系统"),

    SYS_EC_NAME("EC", "EC系统"),

    /**
     * 待添加，也许会没用
     */
    CURRENCY_CNY("CNY", "人民币");


    private String value;
    private String desc;

    private SysEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(SysEnum data : SysEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知状态";
    }

    public static void main(String[] args) {

        System.out.println(getDescByValue("01"));
    }
}
