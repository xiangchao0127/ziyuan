package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmTaskSplit;
import com.sy.pangu.pm.entity.example.PmTaskSplitExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmTaskSplitMapper {
    long countByExample(PmTaskSplitExample example);

    int deleteByExample(PmTaskSplitExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmTaskSplit record);

    int insertSelective(PmTaskSplit record);

    List<PmTaskSplit> selectByExample(PmTaskSplitExample example);

    PmTaskSplit selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmTaskSplit record, @Param("example") PmTaskSplitExample example);

    int updateByExample(@Param("record") PmTaskSplit record, @Param("example") PmTaskSplitExample example);

    int updateByPrimaryKeySelective(PmTaskSplit record);

    int updateByPrimaryKey(PmTaskSplit record);
}