package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：jzj
 * @date ：Created in 2019/5/10 14:14
 */
@Data
public class DomainVo{
    /**
     * 领域id
     */
    private String areaId;

    /**
     * 领域名字
     */
    private String areaName;

    List<LanguageAndLv> lvs;

}
