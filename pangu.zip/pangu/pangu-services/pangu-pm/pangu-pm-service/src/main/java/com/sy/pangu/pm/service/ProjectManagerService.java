package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.SysMatchingPm;
import com.sy.pangu.pm.entity.SysTransmanagerInfo;
import com.sy.pangu.pm.entity.vo.PmQueryVo;
import com.sy.pangu.pm.entity.vo.TransManagerVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.utils.PageUtil;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/24 14:18
 */
public interface ProjectManagerService {

    /**
     * 获取领域及pm的对应表
     * @return
     */
    ResultModel pmList(PageUtil pageUtil, PmQueryVo pmVo);

    int setPm(SysMatchingPm sysMatchingPm);

    int updatePm(SysMatchingPm sysMatchingPm);

    int setTransManager(TransManagerVo transManagerVo);

    PageUtil transManagerList(PageUtil pageUtil, SysTransmanagerInfo sysTransManagerInfo);

    int updateTransManager(TransManagerVo transManagerVo);

    String getTransManager(String sourceLan, String targetLan, String domain);
}
