package com.sy.pangu.pm.entity;

public class PmFile {
    /**
     * 
     */
    private Integer fileId;

    /**
     * 项目id
     */
    private String projectsId;

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 文件地址
     */
    private String filePath;

    /**
     * 任务类型
     */
    private String taskType;

    /**
     * 是否删除 0未删 ， 1已删
     */
    private String isDel;

    /**
     * 文件类型
     */
    private String fileType;

    /**
     * 上传时间
     */
    private String uploadTime;

    /**
     * 上传人
     */
    private String uploadSuff;

    /**
     * 文件大小(单位kb)
     */
    private String fileSize;

    public Integer getFileId() {
        return fileId;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }

    public String getProjectsId() {
        return projectsId;
    }

    public void setProjectsId(String projectsId) {
        this.projectsId = projectsId == null ? null : projectsId.trim();
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName == null ? null : fileName.trim();
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath == null ? null : filePath.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getIsDel() {
        return isDel;
    }

    public void setIsDel(String isDel) {
        this.isDel = isDel == null ? null : isDel.trim();
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType == null ? null : fileType.trim();
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime == null ? null : uploadTime.trim();
    }

    public String getUploadSuff() {
        return uploadSuff;
    }

    public void setUploadSuff(String uploadSuff) {
        this.uploadSuff = uploadSuff == null ? null : uploadSuff.trim();
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize == null ? null : fileSize.trim();
    }
}