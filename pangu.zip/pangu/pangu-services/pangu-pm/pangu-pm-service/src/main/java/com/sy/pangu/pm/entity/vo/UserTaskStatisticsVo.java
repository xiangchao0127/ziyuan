package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：jzj
 * date ：Created in 2019/5/5 9:42
 */
@Data
public class UserTaskStatisticsVo {

    /**
     * 工号
     */
    private String userCode;
    /**
     * name
     */
    private String userName;
    /**
     * 接单数
     */
    private String receiveOrderNum;
    /**
     * 翻译字数
     */
    private String transWorkNum;

    /**
     * 进行中项目数
     */
    private String projectNumIng;
    /**
     * 结束项目数
     */
    private String projectNumEnd;
    /**
     * 超时项目数
     */
    private String projectNumTimeOut;


}
