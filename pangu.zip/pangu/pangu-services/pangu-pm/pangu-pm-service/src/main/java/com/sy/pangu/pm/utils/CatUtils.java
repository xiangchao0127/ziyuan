package com.sy.pangu.pm.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sy.pangu.common.util.HttpUtils;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.CATParams.*;
import com.sy.pangu.pm.entity.vo.MergePackVo;
import com.sy.pangu.pm.entity.vo.RollPackVo;
import com.sy.pangu.pm.model.PackInfoModel;
import com.sy.pangu.pm.model.ResultModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 9:36
 */
public class CatUtils {

    protected static final String CAT_URL = "http://192.168.2.206:8082/";
    protected static final String TBTM_URL = "http://192.168.2.206:12345/";
    protected static final Logger logger = LoggerFactory.getLogger(CatUtils.class);

    /**
     * 调用CAT的解析接口
     * @param pretreatmentParams
     * @return true or false
     */
    public static boolean analysisDuplicateRemoval(PretreatmentParams pretreatmentParams) throws IOException {
        for (FileInfo fileInfo : pretreatmentParams.getFileInfoList()) {
            String resultFilePath = upload(fileInfo.getFilePath(), pretreatmentParams.getProjectId());
            logger.info(resultFilePath);
        }
        String data = JSONObject.toJSONString(pretreatmentParams);
        String url = "pretreatmentR1R2/AnalysisDuplicateRemoval";
        String result = HttpUtils.sendPost(CAT_URL + url, data);
        logger.info(data);
        logger.info("项目id：{}，预处理结果：{}", pretreatmentParams.getProjectId(), result);
        JSONObject resultJson = JSON.parseObject(result);
        return resultJson.getBoolean("Success");
    }

    public static String upload(String filepath, String projectId){
        try {
            String BOUNDARY = "---------7d4a6d158c9"; // 定义数据分隔线
            URL url = new URL(CAT_URL + "UplaodFile/Post?projectId=" + projectId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
            conn.setRequestProperty("Charsert", "UTF-8");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);

            OutputStream out = new DataOutputStream(conn.getOutputStream());
            byte[] end_data = ("\r\n--" + BOUNDARY + "--\r\n").getBytes();
            String fname = filepath;
            File file = new File(fname);
            StringBuilder sb = new StringBuilder();
            sb.append("--");
            sb.append(BOUNDARY);
            sb.append("\r\n");
            sb.append("Content-Disposition: form-data;name=\"fileObj"+"\";filename=\""+ file.getName() + "\"\r\n");
            sb.append("Content-Type:application/octet-stream\r\n\r\n");

            byte[] data = sb.toString().getBytes();
            out.write(data);
            DataInputStream in = new DataInputStream(new FileInputStream(file));
            int bytes = 0;
            byte[] bufferOut = new byte[1024];
            while ((bytes = in.read(bufferOut)) != -1) {
                out.write(bufferOut, 0, bytes);
            }
            out.write("\r\n".getBytes());
            in.close();
            out.write(end_data);
            out.flush();
            out.close();

            // 定义BufferedReader输入流来读取URL的响应
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                return line;
            }
            return "";

        } catch (Exception e) {
            System.out.println("发送POST请求出现异常！" + e);
            e.printStackTrace();
        }
        return "";
    }



    /**
     * 根据文件ID，查找文件的解析状态
     * @param fileId
     * @return
     */
    public static PreResultInfo preTreatmentResult(String fileId) {
        String data = "fileId={0}";
        String url = "pretreatmentR1R2/getPretreatmentStatus?";
        String postParams = MessageFormat.format(data, fileId);
        String result = HttpUtils.sendGet(CAT_URL + url + postParams, "");
        logger.info("文件id：{},解析结果：{}", fileId, result);
        try {
            PreResultInfo resultJson = JSONObject.parseObject(result,PreResultInfo.class);
            return resultJson;
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    /**
     * 为客户新建tb库
     */
    public static boolean termIndexWithCus(TmTbParam tbParam) {
        String data = JSONObject.toJSONString(tbParam);
        String url = "termindexwithcus";
        logger.info(data);
        String result = HttpUtils.sendPost(TBTM_URL + url, data, true);
        logger.info(result);
        return StringUtils.safeBoolean(result);
    }

    /**
     * 为客户新建tm库
     */
    public static boolean tmIndexWithCus(TmTbParam tbParam) {
        String data = JSONObject.toJSONString(tbParam);
        logger.info(data);
        String url = "tmindexwithcus";
        String result = HttpUtils.sendPost(TBTM_URL + url, data, true);
        logger.info(result);
        return StringUtils.safeBoolean(result);
    }

    /**
     *初始化TMTB库
     */
    public static boolean initTmAndTB(InitTParams tParams) {
        String data = JSONObject.toJSONString(tParams);
        String url = "/InitProgramSetting/initTmAndTb";
        logger.info(data);
        String result = HttpUtils.sendPost(CAT_URL + url, data, true);
        JSONObject resultJson = JSON.parseObject(result);
        logger.info(result);
        if(resultJson.containsKey("code")) {
            if (resultJson.getInteger("code").intValue() == 2000) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取原文字数（包含：原文字数，文件总字数，去重不过库字数（文件自身去重））
     * @param fileId
     * @return
     */
    public static String getOriWordCount(String fileId) {
        String data = "fileId=" + fileId;
        String url = "/wordCount/getOriWordCount?";
        return HttpUtils.sendGet(CAT_URL + url + data, "");
    }

    /**
     * 获取初次封包的包信息
     * @param projectId 项目id
     * @param fileId
     * @return
     */
    public static PrePackageRecieve getPrePackage(String projectId, String fileId) {
        try {
            String params = "projectId={0}&fileId={1}";
            String postParam = MessageFormat.format(params, projectId, fileId);
            String url = "pretreatmentR1R2/preRollPack?";
            logger.info("开始获取初次封包结果：{}", postParam);
            String results = HttpUtils.sendPost(CAT_URL + url, postParam);
            logger.info("获取初次封包结果为：{}", results);
            PrePackageRecieve resultObj = JSONObject.parseObject(results, PrePackageRecieve.class);
            return resultObj;
        } catch (Exception e) {
            logger.error("获取初次封包失败，错误原因：{}", e.getMessage());
        }
        return null;
    }
    /**
     * 合并包对CAT接口 返回为null，表示请求失败
     * @param fileId 文件id
     * @param blockIds 需要合并哪些包id集合
     * @return
     */
    public  static MergePackVo MergePack(String fileId , List<String> blockIds){
        try {
            String params = "fileId={0}&blockIds={1}";
            String postParam = MessageFormat.format(params, fileId, blockIds);
            String url = "rollPack/mergePack";
            String results = HttpUtils.sendPost(CAT_URL + url, postParam);
            Object resultObj = JSONObject.parse(results);
            if (null != resultObj) {
                if (resultObj instanceof MergePackVo) {
                    return (MergePackVo) resultObj;
                }
                return null;
            }
        }catch (Exception e) {
            logger.error("合并包失败，错误原因：{}", e.getMessage());
        }
        return null;
    }
    /**
     * 无分配人拆分包对CAT接口 返回为null，表示请求失败
     * @param   prijectId 项目id
     * @param   fileId 文件id
     * @param   packInfoList 拆分包集合
     * @param   packId 被拆分包id
     * @return
     */
    public  static RollPackVo RollPackBySentence (String prijectId, String fileId, List<PackInfoModel> packInfoList ,String packId ){
        try {
        String params = "prijectId={0}&fileId={1}&packInfoList={2}&packId{3}";
        String postParam = MessageFormat.format(params, prijectId, fileId,packInfoList,packId);
        String url = "rollPack/rollPackBySentence";
        String results = HttpUtils.sendPost(CAT_URL + url, postParam);
        Object resultObj = JSONObject.parse(results);
            if (null != resultObj) {
                if (resultObj instanceof RollPackVo) {
                    return (RollPackVo) resultObj;
                }
                return null;
            }
        }catch (Exception e) {
            logger.error("拆分包失败，错误原因：{}", e.getMessage());
        }
        return null;
    }

    public static List<ProjectProgressResponse> QueryProProgress(String userCode, String serviceType) {
        String data = "JsonStr={0}";
        String serviceId = "";
        String url = "/FilePackMsg/SelProjStatus";
        switch (serviceType) {
            case "2": serviceId = "T"; break;
            case "3": serviceId = "C"; break;
            case "4": serviceId = "Q"; break;
            case "5": serviceId = "P"; break;
            default: serviceId = "T";
        }
        try {
            Map<String,String> paramsMap = new HashMap<>(2);
            paramsMap.put("Link", serviceId);
            paramsMap.put("UserID", userCode);
            String postData = MessageFormat.format(data, JSONObject.toJSONString(paramsMap));
            String result = HttpUtils.sendPost(CAT_URL + url, postData);
            ResultModel resultModel = (ResultModel) JSONObject.parse(result);
            if (null != resultModel) {
                if (resultModel.getSuccess()) {
                    if (null != resultModel.getData()) {
                        List<ProjectProgressResponse> progressResponses = (List<ProjectProgressResponse>) resultModel.getData();
                        return progressResponses;
                    }
                }
            }
        }catch (Exception e) {
            logger.error("查询进度报错：{0}", e.getMessage());
        }
        return null;
    }

    public static List<TransWordInfo> GetTransWordNum(String projectId) {
        String data = "projectId= " + projectId;
        String url = "/wordCount/getTransWordCount";
        String result = HttpUtils.sendGet(CAT_URL + url, data);
        ResultModel resultModel = (ResultModel) JSONObject.parse(result);
        if (null != resultModel) {
            if (resultModel.getSuccess()) {
                if (null != resultModel.getData()) {
                    List<TransWordInfo> transWordInfos = (List<TransWordInfo>) resultModel.getData();
                    return transWordInfos;
                }
            }
        }
        return null;
    }



    public static void main(String[] args) throws Exception {
        InitTParams initTParams = new InitTParams();
        initTParams.setCustomerName("1234567");
        initTParams.setFiled("78");
        initTParams.setProjectId("EC20190518");
        initTParams.setSourceLanguage("zh-CN");
        initTParams.setTargetLanguage("en-US");
        TmTbParam tmTbParam = new TmTbParam();
        tmTbParam.setSource("zh-CN");
        tmTbParam.setCreator("lht");
        tmTbParam.setCustomers(new String[]{"1234567"});
        tmTbParam.setField("78");
        tmTbParam.setTarget("en-US");
        tmTbParam.setName("zhCNenUs_化工_1234567");
        tmTbParam.setId(0);
        tmTbParam.setCreateTime(0);
        tmTbParam.setRemark("");
//        CatUtils.termIndexWithCus(tmTbParam);
//        CatUtils.tmIndexWithCus(tmTbParam);
//        CatUtils.initTmAndTB(initTParams);
//        CatUtils.getPrePackage("C18070176001", "165515");
//        CatUtils.GetTransWordNum("C18070176001");
        PretreatmentParams pretreatmentParams = new PretreatmentParams();
        pretreatmentParams.setProjectId("B19050370001");
        pretreatmentParams.setUserCode("L00928");
        pretreatmentParams.setUserName("测试");
        pretreatmentParams.setWordParam(new WordParam());
        pretreatmentParams.setPptParam(new PPTParam());
        pretreatmentParams.setExcelParam(new ExcelParam());
        pretreatmentParams.setLanguagePair("zhCNenUS");
        FileInfo fileInfo = new FileInfo();
        fileInfo.setFilePath("D:\\项目\\cattest.txt");
        fileInfo.setFileName("cattest.txt");
        fileInfo.setFileId("B19050370007F");
        List<FileInfo> fileInfoList = new ArrayList<>();
        fileInfoList.add(fileInfo);
        pretreatmentParams.setFileInfoList(fileInfoList);
        CatUtils.analysisDuplicateRemoval(pretreatmentParams);
        CatUtils.preTreatmentResult("B19050370007F");
//        CatUtils.getOriWordCount("EC20190510F");
//        CatUtils.getPrePackage("EC20190510", "EC20190510F");
    }

    private static String  params = "{\n" +
            "    \"ProjectID\": \"{0}\",\n" +
            "    \"FileInfoList\": [\n" +
            "        {\n" +
            "            \"FileId\": \"{1}\",\n" +
            "            \"FileName\": \"{2}\",\n" +
            "            \"FilePath\": \"{3}\"\n" +
            "        }\n" +
            "    ],\n" +
            "    \"LanguagePair\": \"{4}\",\n" +
            "    \"UserCode\": \"{5}\",\n" +
            "    \"UserName\": \"{6}\",\n" +
            "    \"WordParam\": {\n" +
            "        \"WordHiddenText\": 0,\n" +
            "        \"WordProperty\": 0,\n" +
            "        \"WordHyperlink\": 0,\n" +
            "        \"WordCommnet\": 1,\n" +
            "        \"WordHeader\": 0,\n" +
            "        \"WordFooter\": 0,\n" +
            "        \"WordEndnote\": 0,\n" +
            "        \"WordFootnote\": 0\n" +
            "    },\n" +
            "    \"ExcelParam\": {\n" +
            "        \"ExcelComment\": 1,\n" +
            "        \"ExcelHidden\": 0,\n" +
            "        \"ExcelProperty\": 0,\n" +
            "        \"ExcelSheetName\": 0\n" +
            "    },\n" +
            "    \"PptParam\": {\n" +
            "        \"PPTComment\": 1,\n" +
            "        \"PPTNote\": 0,\n" +
            "        \"PPTProperty\": 0,\n" +
            "        \"PPTHidden\": 0\n" +
            "    }\n" +
            "}";
}
