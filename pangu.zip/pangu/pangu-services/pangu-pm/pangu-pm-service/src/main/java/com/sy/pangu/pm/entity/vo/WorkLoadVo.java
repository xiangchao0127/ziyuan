package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/5 18:06
 */
@Data
public class WorkLoadVo {
    private String taskId;
    private String taskName;
    private String taskType;
    private String handleUser;
    private String allotCode;
    private String workLoad;
    private String unitPrice;
    private String ratio;
    private Float totalRatio;
    private String disTime;
    private String requireTime;
    private String realCompleteTime;
    private String dtpType;
    private String comment;
}
