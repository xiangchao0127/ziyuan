package com.sy.pangu.pm.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PageUtil {
	private int start; // 启始条数
	private int end; // 结束条数
	private int totalPage; // 总页数
	private int page = 1; // 当前页
	private long totalRow; // 总信息数
	private int limit = 10; // 分页单位
	private Map<String, Object> link = new HashMap<String, Object>(); // 查询条件
	private List<?> list; // 当前页的数据
	private String sort;
	private String desc;

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
		//设置start
		this.start = (this.page - 1) * limit;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
		//设置start
		this.start = (this.page - 1) * limit;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public List<?> getList() {
		return list;
	}

	public void setList(List<?> list) {
		this.list = list;
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public long getTotalRow() {
		return totalRow;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public void setTotalRow(long totalRow) {
		this.totalRow = totalRow;
		this.totalPage = (int) (totalRow / limit);
		if (totalRow % limit > 0)
			this.totalPage = this.totalPage + 1;

		this.page = (page <= 0) ? 1 : page;

		if (this.page > this.totalPage)
			this.page = this.totalPage;
		if (totalPage == 0) {
			this.page = 1;
		}
		this.start = (this.page - 1) * limit;
		this.end = this.start + limit - 1;

	}

	public PageUtil() {
		super();
	}

	public Map<String, Object> getLink() {
		return link;
	}

	public void setLink(Map<String, Object> link) {
		this.link = link;
	}
}
