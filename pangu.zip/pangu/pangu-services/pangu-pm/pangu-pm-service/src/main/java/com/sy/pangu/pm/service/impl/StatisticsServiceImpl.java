package com.sy.pangu.pm.service.impl;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.pm.entity.PmProjectInfo;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.entity.vo.UserTaskStatisticsVo;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.service.IStatisticsService;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ：jzj
 * date ：Created in 2019/5/5 9:55
 */
@Service
public class StatisticsServiceImpl implements IStatisticsService {

    protected static final Logger LOGGER = (Logger) LoggerFactory.getLogger(StatisticsServiceImpl.class);

    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
    /**
     * 统计人员 任务信息
     *
     * @param vo
     */
    @Override
    public void getUserTaskStatisticsInfo(UserTaskStatisticsVo vo) throws Exception {
        try {
            int receiveOrderNum = StatisticsReceiveOrderNum(vo.getUserCode());
            vo.setReceiveOrderNum(receiveOrderNum+"");
        } catch (Exception e) {
            throw new Exception("统计抢单次数出错");
        }
        try {
            long transWorkNum =  StatisticsTransWorkNum(vo.getUserCode());
            vo.setTransWorkNum(transWorkNum+"");
        } catch (Exception e) {
            throw new Exception("统计翻译字数出错");
        }
        try {
            StatisticsProjectNum(vo);
        } catch (Exception e) {
            throw new Exception("统计项目数出错");
        }
    }

    /**
     * 统计项目数
     * @param vo
     * @throws Exception
     */
    private void StatisticsProjectNum(UserTaskStatisticsVo vo) throws Exception {
        Date date = new Date();
        List<PmProjectInfo> projectInfos = taskInfoMapper.statisticsProjectOfTask(vo);
        //正常完成的
        List projectEnds = projectInfos.stream().filter(x -> "4".equals(x.getProjectType())).collect(Collectors.toList());
        //终止的项目
        List projectTerminals = projectInfos.stream().filter(x -> "5".equals(x.getProjectType())).collect(Collectors.toList());
        //超时
        List projectTimeOuts = projectInfos.stream().filter(x -> {
            long time = Long.MAX_VALUE;
            try {
                time = ParamStatic.SIMPLE_TIMEFORMAT.parse(x.getDeliveryTime()).getTime();
            } catch (ParseException e) {
                LOGGER.error("{}", e);
            }
            return date.getTime() >= time;
        }).collect(Collectors.toList());


        vo.setProjectNumEnd(projectEnds.size() + "");
        vo.setProjectNumIng((projectInfos.size() - projectEnds.size() - projectTerminals.size()) + "");
        vo.setProjectNumTimeOut(projectTimeOuts.size() + "");
    }

    /**
     * 统计翻译字数
     * @param userCode
     * @return
     * @throws Exception
     */
    private long StatisticsTransWorkNum(String userCode) throws Exception {
        return taskInfoMapper.sumTransWorkNum(userCode);
    }

    /**
     * 统计抢单数
     * @param userCode
     * @return
     * @throws Exception
     */
    private int StatisticsReceiveOrderNum(String userCode) throws Exception {
        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andStaffNumEqualTo(userCode)
                .andTaskStatusNotIn(Arrays.asList(TaskInfoEnum.TASK_STATUS_DELETE.getValue(), TaskInfoEnum.TASK_STATUS_REJECT_FILE.getValue(), TaskInfoEnum.TASK_STATUS_TERMINATION.getValue()));
//        taskInfoMapper.getReceiveOrderList(userCode);
        return (int) taskInfoMapper.countByExample(example);
    }

    public static void main(String[] args) {
        List<String> a = Arrays.asList("12","32","22","2","53","15","7");

        List b = a.stream().filter(x -> {
            return Integer.parseInt(x) > 22;
        }).collect(Collectors.toList());

        LOGGER.info("{}",b);
    }
}
