package com.sy.pangu.pm.controller;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.SysStaffLvl;
import com.sy.pangu.pm.entity.vo.UserQueryVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.impl.StaffServiceImpl;
import com.sy.pangu.pm.utils.PageUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/15 17:55
 */
@RestController
@RequestMapping("/staff")
@Api(tags = "员工等级")
@CrossOrigin
public class StaffController {
    /**
     * TODO
     * 设置员工等级,订单单价,角色,团队职能等
     */

    @Autowired
    private StaffServiceImpl staffService;


    @PostMapping("/saveStaffLvl")
    @ApiOperation("/设置员工等级")
    public ResultModel saveStaffLvl(SysStaffLvl staffLvl) {
        if (staffLvl == null) {
            return ResultModel.FailWithNoData("请填写基本内容");
        }
        return ResultModel.SuccessForMsg("",staffService.saveStaffLvl(staffLvl));
    }

    @PostMapping("/updateStaffLvl")
    @ApiOperation("更新等级名字")
    public ResultModel updateStaffLvl(SysStaffLvl staffLvl) {
        return ResultModel.SuccessForMsg("",staffService.updateStaffLvl(staffLvl));
    }

    @DeleteMapping("/deleteStaffLvl")
    @ApiOperation("删除等级")
    public ResultModel deleteStaffLvl(SysStaffLvl staffLvl) {
        return ResultModel.SuccessForMsg("",staffService.deleteStaffLvl(staffLvl));
    }

    @GetMapping("/listStaffLvl")
    @ApiOperation("等级列表")
    public ResultModel listStaffLvl(String taskType, String lvlType) {
        return ResultModel.SuccessForMsg("",staffService.listStaffLvl(taskType, lvlType));
    }

    @PostMapping("/userList")
    @ApiOperation("获取员工信息")
    public ResultModel userList(PageUtil pageUtil, UserQueryVo userQuery) {
        if (StringUtils.isEmpty(userQuery.getStaffName())) {

        } else {

        }
        return ResultModel.Success();
    }
}
