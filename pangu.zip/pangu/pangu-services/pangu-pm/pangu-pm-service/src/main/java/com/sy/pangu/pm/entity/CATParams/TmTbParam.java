package com.sy.pangu.pm.entity.CATParams;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import org.apache.commons.net.ntp.TimeStamp;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/9 16:32
 */
@Data
public class TmTbParam {
    @JSONField(name = "Name")
    private String name;
    @JSONField(name = "Field")
    private String field;
    @JSONField(name = "Source")
    private String source;
    @JSONField(name = "Target")
    private String target;
    @JSONField(name = "Creator")
    private String creator;
    @JSONField(name = "CreateTime")
    private Integer createTime;
    @JSONField(name = "Customers")
    private String[] customers;
    @JSONField(name = "Remark")
    private String remark;
    @JSONField(name = "Id")
    private Integer id;

    public void setName() {
        this.name = source + "_" + target + "_" + customers;
    }
}
