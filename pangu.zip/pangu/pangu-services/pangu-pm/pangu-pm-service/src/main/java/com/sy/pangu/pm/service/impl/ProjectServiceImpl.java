package com.sy.pangu.pm.service.impl;

import ch.qos.logback.classic.Logger;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.permission.client.UserClient;
import com.sy.pangu.pm.entity.*;
import com.sy.pangu.pm.entity.CATParams.*;
import com.sy.pangu.pm.entity.example.PmDistributeExample;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.entity.vo.*;
import com.sy.pangu.pm.mapper.*;
import com.sy.pangu.pm.service.AutoRuleService;
import com.sy.pangu.pm.service.IProjectService;
import com.sy.pangu.pm.service.ProjectManagerService;
import com.sy.pangu.pm.utils.CatUtils;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.*;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.*;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/
@Service
public class ProjectServiceImpl implements IProjectService {

    private static final Logger logger = (Logger) LoggerFactory.getLogger(ProjectServiceImpl.class);

    @Autowired
    private PmProjectInfoMapper pmProjectInfoMapper;
    @Autowired
    private PmTaskApplyRecordMapper pmTaskApplyRecordMapper;
    @Autowired
    private PmFileMapper pmFileMapper;
    @Autowired
    private PmDistributeMapper pmDistributeMapper;
    @Autowired
    private AutoRuleService autoRuleService;
    @Autowired
    private PmTaskInfoMapper taskInfoMapper;

    @Autowired
    private PmFileFlowMapper pmFileFlowMapper;

    @Autowired
    private ProjectManagerService projectManagerService;

    @Autowired
    private PmGrabsheetMapper grabsheetMapper;
    @Autowired
    private UserClient userClient;
    @Autowired
    private PmFileMapper fileMapper;
    @Autowired
    private TransTaskServiceImpl transTaskService;

    //查询项目列表
    @Override
    public List<PmProjectInfo> listProject(ProjectSearchModel projectSearchModel ) {
        List<PmProjectInfo> listProjects = null;
        //查询待分配项目项目列表
        if ("0".equals(projectSearchModel.getPmProjectInfo().getProjectType())) {
            listProjects = pmProjectInfoMapper.listProjectBySplit(projectSearchModel);
        }
        //查询正常完成，项目终止项目列表,待交付，分配中，已分配
        else {
            String sort = "pm.order_time desc";
            if("4".equals(projectSearchModel.getPmProjectInfo().getProjectType())||"5".equals(projectSearchModel.getPmProjectInfo().getProjectType())){
                sort = "pm.reality_handfile_time";
            }
            listProjects = pmProjectInfoMapper.listProject(projectSearchModel ,sort );
        }
        return listProjects;
    }


    //插入项目表基本信息
    @Override
    public int inseretProject(PmProjectInfo pmProjectInfo) {
        return pmProjectInfoMapper.insert(pmProjectInfo);
    }


//    public int createProject(PmProjectInfo projectInfo, RuleMatchingVo ruleMatching) throws ParseException {
//        //向project表中插入数据
//        //插入成功后判断流程，将该插入的地方插入数据库
//        //1、判断流程，插入文件流程表
//        logger.info("==============开始判断订单:{}自动流程===============", projectInfo.getProjectId());
//        Map<String, List<String>> pathMap = autoRuleService.judgeFlow(projectInfo.getOrderType(),
//                projectInfo.getQualityGrade(), projectInfo.getProjectId(), ruleMatching);
//        SysMatchingPm pm = autoRuleService.judgeTerm(projectInfo.getDomain());
//        String transUserCode = projectManagerService.getTransManager(projectInfo.getSourceLan(),
//                projectInfo.getTargetLan(), projectInfo.getDomain());
//        List<FileWordNumVo> fileList = ruleMatching.getFileList();
//        if (ruleMatching.isHasTermFile()) {
//            //有术语表的项目不走自动流程，直接默认为手动流程
//            projectInfo.setPmId(pm.getPmCode());
//            projectInfo.setTranmgrId(transUserCode);
//        }
//        for (FileWordNumVo fileInfo : fileList) {
//            //插入文件表
//            insertFile(fileInfo, projectInfo);
//            PmAutomatching pmAutomatching = autoRuleService.judgeMatchRule(projectInfo.getOrderType(), projectInfo.getQualityGrade(), ruleMatching.getCusType(), fileInfo.getFileWordNum());
//            if (pmAutomatching.getMatchingOutsaler() == 1) {
//                projectInfo.setPmId(pm.getOuterCode());
//            }
//            if (pmAutomatching.getMatchingPm() == 1) {
//                projectInfo.setPmId(pm.getPmCode());
//            }
//            if (pmAutomatching.getMatchingTranspm() == 1) {
//                projectInfo.setTranmgrId(transUserCode);
//            }
//            //自动流程，计算时间占比/抢单规则，插入抢单表,项目表，如果项目没有译前dtp，调用cat接口进行预处理
//            List<String> pathList = pathMap.get(fileInfo.getFileId());
//
//
//            //插入任务表，循环新建任务模型
//            List<PmTaskInfo> tasks = new ArrayList<>();
//            List<PmGrabsheet> grabsheets = new ArrayList<>();
//            for (String nodeId : pathList) {
//                PmTaskInfo taskInfo = new PmTaskInfo();
//                taskInfo.setFileId(fileInfo.getFileId());
//                taskInfo.setFlowId(nodeId);
//                taskInfo.setProjectId(projectInfo.getProjectId());
//                //译前任务可以直接抢单，设置为初始状态
//                if (StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(nodeId)) {
//                    taskInfo.setTaskType(TaskInfoEnum.TASK_STATUS_INIT.getValue());
//                } else {
//                    //任务不可见，设置为不开启状态
//                    taskInfo.setTaskStatus(TaskInfoEnum.TASK_STATUS_NOT_OPEN.getValue());
//                }
//                taskInfo.setStartTime(projectInfo.getOrderTime());
//                taskInfo.setWorkType(WorkTypeEnum.AL_WORK_TYPE.getValue());
//                taskInfo.setTaskName(StaffLvlEnum.getDescByValue(nodeId));
//                String nowTime = DateUtils.getNowTime();
//                taskInfo.setDistributionTime(nowTime);
//                taskInfo.setTaskType(nodeId);
//                taskInfo.setCurrencyType(SysEnum.CURRENCY_CNY.getValue());
//                //默认包ID
//                taskInfo.setTaskPackageId("");
//                //TODO
//                //任务id生成规则
//                taskInfo.setTaskId(fileInfo.getFileId() + "sys" + nodeId);
//                //如果是dtp，则插入dtp工作量
//                if (nodeId.equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) || nodeId.equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
//                    taskInfo.setWorkLoad(fileInfo.getDtpWorkLoad());
//                    //如果是翻译流程则插入字数
//                } else if (nodeId.equals(StaffLvlEnum.TASK_TYPE_TRANS.getValue())
//                        || nodeId.equals(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue())
//                        || nodeId.equals(StaffLvlEnum.TASK_TYPE_QA.getValue())) {
//                    taskInfo.setWorkLoad(fileInfo.getFileWordNum().toString());
//                }
//                tasks.add(taskInfo);
//                //新建抢单表数据并插入数据库
//                if (ruleMatching.isHasTermFile() || pmAutomatching.getUseAuto() != 1) {
//                    continue;
//                }
//                long startTimeStamp;
//
//                PmDistributeExample example = new PmDistributeExample();
//                example.createCriteria().andFlowIdEqualTo(projectInfo.getOrderType() + projectInfo.getQualityGrade());
//                List<PmDistribute> distributes = pmDistributeMapper.selectByExample(example);
//                Map<String, Long> factTimePer = findDistribute(distributes, pathList);
//                long useTime = factTimePer.get(nodeId);
//                startTimeStamp =
//                        ParamStatic.SIMPLE_DATEFORMAT.parse(projectInfo.getOrderTime()).getTime() + useTime;
//                taskInfo.setRequireTime(ParamStatic.SIMPLE_TIMEFORMAT.format(new Date(startTimeStamp)));
//                PmGrabsheet grabsheet = new PmGrabsheet();
//                grabsheet.setTaskId(taskInfo.getTaskId());
//                grabsheet.setTaskStatus(taskInfo.getTaskStatus());
//                grabsheet.setAllotType(SysEnum.AUTO_ALLOT.getValue());
//                PmDistribute distribute;
//                if (distributes.stream().filter(x -> x.getNodeId().equals(nodeId)).findFirst().isPresent()) {
//                    distribute = distributes.stream().filter(x -> x.getNodeId().equals(nodeId)).findFirst().get();
//                    String chooseLv = distribute.getStaffLvl();
//                    grabsheet.setChooseLv(chooseLv);
//                    grabsheet.setNoticeHour(new BigDecimal(distribute.getNotifyTime()));
//                } else {
//                    logger.error("未找到该订单的分配等级");
//                }
//                grabsheet.setLastEditor(SysEnum.SYS_NAME.getValue());
//                grabsheet.setLastEditTime(DateUtils.getNowTime());
//                grabsheet.setIsRemind(false);
//                grabsheets.add(grabsheet);
//            }
//            //批量将任务插入数据库
//            logger.info("==============批量插入任务表/抢单表===============");
//            taskInfoMapper.insertBatch(tasks);
//            if (ruleMatching.isHasTermFile()) {
//                return inseretProject(projectInfo);
//            }
//            grabsheetMapper.insertBatch(grabsheets);
//            if (pathList.contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue())) {
//                //有dtp流程，可直接插入表后结束判断
//                logger.info("==============判断结束===============");
//                return inseretProject(projectInfo);
//            } else {
//                logger.info("==============异步调用R2接口，预处理开始===============");
//                PretreatmentParams pretreatmentParams = new PretreatmentParams();
//                ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("R2异步线程").build();
//                ThreadPoolExecutor executor = new ThreadPoolExecutor(5, 10, 200, TimeUnit.MILLISECONDS,
//                        new ArrayBlockingQueue<>(5), namedThreadFactory);
//                executor.execute(() -> {
//                    boolean success = CatUtils.analysisDuplicateRemoval(null);
//                    if (success) {
//                        while (true) {
//                            PreResultInfo preResultInfo = CatUtils.preTreatmentResult(fileInfo.getFileId());
//                            if (null != preResultInfo) {
//                                if (preResultInfo.getCode() == 3) {
//                                    PrePackageRecieve prePackageRecieve = CatUtils.getPrePackage(projectInfo.getProjectId(), fileInfo.getFileId());
//                                    PmTaskInfo taskInfo = taskInfoMapper.selectByTaskId(fileInfo.getFileId() + "sys" + StaffLvlEnum.TASK_TYPE_TRANS.getValue());
//                                    taskInfo.setTaskPackageId(prePackageRecieve.getDefaultPackId());
//                                    taskInfo.setWorkLoad(Integer.toString(prePackageRecieve.getAvailableWords()));
//                                    int result = taskInfoMapper.updateByPrimaryKey(taskInfo);
//                                    if (result < 1) {
//
//                                    } else {
//                                        break;
//                                    }
//                                }
//                            }
//                        }
//                    }
//                });
//                //无dtp流程，先调用cat预处理接口
//                return inseretProject(projectInfo);
//            }
//        }
//        return inseretProject(projectInfo);
//    }

    @Override
//    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor =
//            Exception.class)
    public int createProject(CreateProjectParams params) throws ParseException {
        logger.info("==============开始判断订单:{}自动流程===============", params.getProjectId());
        PmProjectInfo projectInfo = new PmProjectInfo();
        projectInfo.setCustomerId(params.getCustomerId());
        projectInfo.setCustomerName(params.getCustomerName());
        projectInfo.setDeliveryTime(params.getDeliveryTime());
        projectInfo.setDomain(params.getDomain());
        projectInfo.setEstimateWord(params.getEstimateWord());
        projectInfo.setProjectId(params.getProjectId());
        projectInfo.setOrderPeople(params.getOrderPeople());
        projectInfo.setOrderTime(params.getOrderTime());
        projectInfo.setOrderRemake(params.getOrderRemake());
        projectInfo.setOrderType(params.getOrderType());
        projectInfo.setProjectName(params.getProjectName());
        projectInfo.setQualityGrade(params.getQualityGrade());
        projectInfo.setSourceLan(params.getSourceLan());
        projectInfo.setTargetLan(params.getTargetLan());
        if ("4".equals(params.getCusType())) {
            TmTbParam tmTbParam = new TmTbParam();
            CatUtils.termIndexWithCus(tmTbParam);
            CatUtils.tmIndexWithCus(tmTbParam);
        }
        Map<String, List<String>> pathMap = autoRuleService.judgeFlow(params);
        SysMatchingPm pm = autoRuleService.judgeTerm(params.getDomain());
        String transUserCode = projectManagerService.getTransManager(params.getSourceLan(),
                params.getTargetLan(), params.getDomain());
        List<FileWordNumVo> fileList = params.getFileList();
        List<FileWordNumVo> noDtpFileList = new ArrayList<>();
        if (params.isHasTermFile()) {
            //有术语表的项目不走自动流程，直接默认为手动流程
            projectInfo.setResponsibilityType("1");
            projectInfo.setProjectType("0");
            projectInfo.setPmId(pm.getPmCode());
            projectInfo.setTranmgrId(transUserCode);
            for (FileWordNumVo fileInfo : fileList) {
                List<PmFileFlow> fileFlows = new ArrayList<>();
                List<PmTaskInfo> taskInfos = new ArrayList<>();
                //插入文件表
                insertFile(fileInfo, params);
                //插入项目表
                List<String> pathList = pathMap.get(fileInfo.getFileId());
                for (String node : pathList) {
                    initFileFlowList(params, fileInfo, fileFlows, node);
                    initTaskInfoList(node, fileInfo, params, taskInfos);
                }
                taskInfoMapper.insertBatch(taskInfos);
                pmFileFlowMapper.insertBatch(fileFlows);
            }
            return inseretProject(projectInfo);
        }
        for (FileWordNumVo fileInfo : fileList) {
            List<PmFileFlow> fileFlows = new ArrayList<>();
            List<PmTaskInfo> taskInfos = new ArrayList<>();
            List<PmGrabsheet> grabsheets = new ArrayList<>();
            //插入文件表
            insertFile(fileInfo, params);
            PmAutomatching pmAutomatching = autoRuleService.judgeMatchRule(params.getOrderType(), params.getQualityGrade(), params.getCusType(), fileInfo.getFileWordNum());
            if (pmAutomatching.getMatchingOutsaler() == 1) {
                projectInfo.setPmId(pm.getOuterCode());
            }
            if (pmAutomatching.getMatchingPm() == 1) {
                projectInfo.setPmId(pm.getPmCode());
            }
            if (pmAutomatching.getMatchingTranspm() == 1) {
                projectInfo.setTranmgrId(transUserCode);
            }
            //插入项目表
            List<String> pathList = pathMap.get(fileInfo.getFileId());
            if (pmAutomatching.getUseAuto() == 1) {
                projectInfo.setResponsibilityType("0");
                projectInfo.setProjectType("1");
                if (!pathList.contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue())) {
                    noDtpFileList.add(fileInfo);
                }
                for (String nodeId : pathList) {
                    initFileFlowList(params, fileInfo, fileFlows, nodeId);
//                    initTaskInfoList(nodeId, fileInfo, params, taskInfos);
                    PmTaskInfo taskInfo = new PmTaskInfo();


                    PmDistributeExample example = new PmDistributeExample();
                    example.createCriteria().andFlowIdEqualTo(params.getOrderType() + params.getQualityGrade() + "1");
                    List<PmDistribute> distributes = pmDistributeMapper.selectByExample(example);
                    Map<String, Double> factTimePer = findDistribute(distributes, pathList);
                    long useTime = factTimePer.get(nodeId).longValue();
                    long startTimeStamp =
                            ParamStatic.SIMPLE_DATEFORMAT.parse(params.getOrderTime()).getTime() + useTime;
                    Timestamp timestamp = new Timestamp(startTimeStamp);
                    String requireTime = DateUtils.timeStamp2Str(timestamp);
                    taskInfo.setFileId(fileInfo.getFileId());
                    taskInfo.setFlowId(nodeId);
                    taskInfo.setProjectId(params.getProjectId());
                    //译前任务可以直接抢单，设置为初始状态
                    if (StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(nodeId)) {
                        taskInfo.setTaskType(TaskInfoEnum.TASK_STATUS_INIT.getValue());
                    } else {
                        //任务不可见，设置为不开启状态
                        taskInfo.setTaskStatus(TaskInfoEnum.TASK_STATUS_NOT_OPEN.getValue());
                    }
                    taskInfo.setStartTime(params.getOrderTime());
                    taskInfo.setWorkType(WorkTypeEnum.AL_WORK_TYPE.getValue());
                    taskInfo.setTaskName(StaffLvlEnum.getDescByValue(nodeId));
                    String nowTime = DateUtils.getNowTime();
                    taskInfo.setDistributionTime(nowTime);
                    taskInfo.setTaskType(nodeId);
                    taskInfo.setCurrencyType(SysEnum.CURRENCY_CNY.getValue());
                    //默认包ID
                    taskInfo.setTaskPackageId(ParamStatic.TASK_PACKAGEID_TEMP);
                    taskInfo.setRequireTime(requireTime);
                    taskInfo.setStaffNum(ParamStatic.TASK_DEFAULT_STAFFNUM);
                    //TODO
                    //任务id生成规则
                    taskInfo.setTaskId(transTaskService.getTaskId());
                    //如果是dtp，则插入dtp工作量
                    if (nodeId.equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) || nodeId.equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
                        taskInfo.setWorkLoad(fileInfo.getDtpWorkLoad());
                        //如果是翻译流程则插入字数
                    } else if (nodeId.equals(StaffLvlEnum.TASK_TYPE_TRANS.getValue())
                            || nodeId.equals(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue())
                            || nodeId.equals(StaffLvlEnum.TASK_TYPE_QA.getValue())) {
                        taskInfo.setWorkLoad(fileInfo.getFileWordNum().toString());
                    }
                    taskInfo.setRequireTime(ParamStatic.SIMPLE_TIMEFORMAT.format(new Date(startTimeStamp)));
                    taskInfos.add(taskInfo);
                    PmGrabsheet grabsheet = new PmGrabsheet();
                    grabsheet.setTaskId(taskInfo.getTaskId());
                    grabsheet.setTaskStatus(taskInfo.getTaskStatus());
                    grabsheet.setAllotType(SysEnum.AUTO_ALLOT.getValue());
                    PmDistribute distribute;
                    if (distributes.stream().filter(x -> x.getNodeId().toString().equals(nodeId)).findAny().isPresent()) {
                        distribute = distributes.stream().filter(x -> x.getNodeId().toString().equals(nodeId)).findFirst().get();
                        String chooseLv = distribute.getFullStaffLvl();
                        grabsheet.setChooseLv(chooseLv);
                        grabsheet.setDatachar1(distribute.getFreeStaffLvl());
                        grabsheet.setNoticeHour(new BigDecimal(distribute.getNotifyTime()));
                    } else {
                        logger.error("未找到该订单的分配等级");
                    }
                    grabsheet.setLastEditor(SysEnum.SYS_NAME.getValue());
                    grabsheet.setLastEditTime(DateUtils.getNowTime());
                    grabsheet.setIsRemind(false);
                    grabsheets.add(grabsheet);
                    //生成抢单表数据
                }
                grabsheetMapper.insertBatch(grabsheets);
                taskInfoMapper.insertBatch(taskInfos);
            } else {
                for (String node : pathList) {
                    initFileFlowList(params, fileInfo, fileFlows, node);
                    initTaskInfoList(node, fileInfo, params, taskInfos);
                }
            }
        }
        if (noDtpFileList.size() == 0) {
            return inseretProject(projectInfo);
        }
        List<FileInfo> fileInfos = new ArrayList<>();
        for (FileWordNumVo fileInfo : noDtpFileList) {
            FileInfo catFileInfo = new FileInfo();
            catFileInfo.setFileId(fileInfo.getFileId());
            catFileInfo.setFileName(fileInfo.getFileName());
            catFileInfo.setFilePath(fileInfo.getFilePath());
            fileInfos.add(catFileInfo);
        }
        PretreatmentParams pretreatmentParams = new PretreatmentParams();
        pretreatmentParams.setFileInfoList(fileInfos);
        pretreatmentParams.setExcelParam(new ExcelParam());
        pretreatmentParams.setPptParam(new PPTParam());
        pretreatmentParams.setWordParam(new WordParam());
        pretreatmentParams.setProjectId(params.getProjectId());
        pretreatmentParams.setUserName("currentUser");
        pretreatmentParams.setUserCode("currentUser");
        pretreatmentParams.setLanguagePair(params.getSourceLan() + params.getTargetLan());
        ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("R2异步线程").build();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(5, 10, 200, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(5), namedThreadFactory);
        executor.execute(() -> {
            boolean success = false;
            try {
                InitTParams initTParams = new InitTParams();
                initTParams.setTargetLanguage(params.getTargetLan());
                initTParams.setSourceLanguage(params.getSourceLan());
                initTParams.setFiled(params.getDomain());
                initTParams.setProjectId(params.getProjectId());
                initTParams.setCustomerName(params.getCustomerName());
                if(CatUtils.initTmAndTB(initTParams)) {

                }
                success = CatUtils.analysisDuplicateRemoval(pretreatmentParams);
            } catch (Exception e) {
                e.getMessage();
            }
            int totalSuccess = 0;
            if (success) {
                while (totalSuccess < fileInfos.size()) {
                    for (FileInfo fileInfo : fileInfos) {
                        PreResultInfo preResultInfo = CatUtils.preTreatmentResult(fileInfo.getFileId());
                        if (null != preResultInfo) {
                            if (preResultInfo.getCode() == 3) {
                                PrePackageRecieve prePackageRecieve = CatUtils.getPrePackage(params.getProjectId(), fileInfo.getFileId());
                                PmTaskInfo taskInfo = taskInfoMapper.selectByTaskId(fileInfo.getFileId() + "sys" + StaffLvlEnum.TASK_TYPE_TRANS.getValue());
                                taskInfo.setTaskPackageId(prePackageRecieve.getDefaultPackId());
                                taskInfo.setWorkLoad(Integer.toString(prePackageRecieve.getAvailableWords()));
                                int result = taskInfoMapper.updateByPrimaryKey(taskInfo);
                                if (result < 1) {
                                    continue;
                                } else {
                                    totalSuccess += result;
                                }
                            }
                        }
                    }

                }
            }
        });
        return inseretProject(projectInfo);
    }

    private void initFileFlowList(CreateProjectParams params, FileWordNumVo fileInfo, List<PmFileFlow> fileFlows, String node) {
        PmFileFlow fileFlow = new PmFileFlow();
        fileFlow.setProjectId(params.getProjectId());
        fileFlow.setFlowId(node);
        fileFlow.setFileId(fileInfo.getFileId());
        fileFlows.add(fileFlow);
    }

    private void initTaskInfoList(String nodeId, FileWordNumVo fileInfo, CreateProjectParams params, List<PmTaskInfo> tasks) {
        PmTaskInfo taskInfo = new PmTaskInfo();
        taskInfo.setFileId(fileInfo.getFileId());
        taskInfo.setFlowId(nodeId);
        taskInfo.setProjectId(params.getProjectId());
        //译前任务可以直接抢单，设置为初始状态
        if (StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(nodeId)) {
            taskInfo.setTaskStatus(TaskInfoEnum.TASK_STATUS_INIT.getValue());
        } else {
            //任务不可见，设置为不开启状态
            taskInfo.setTaskStatus(TaskInfoEnum.TASK_STATUS_NOT_OPEN.getValue());
        }
        taskInfo.setStartTime(params.getOrderTime());
        taskInfo.setWorkType(WorkTypeEnum.AL_WORK_TYPE.getValue());
        taskInfo.setTaskName(StaffLvlEnum.getDescByValue(nodeId));
        String nowTime = DateUtils.getNowTime();
        taskInfo.setDistributionTime(nowTime);
        taskInfo.setTaskType(nodeId);
        taskInfo.setCurrencyType(SysEnum.CURRENCY_CNY.getValue());
        taskInfo.setStaffNum(ParamStatic.TASK_DEFAULT_STAFFNUM);
        //默认包ID
        taskInfo.setTaskPackageId(ParamStatic.TASK_PACKAGEID_TEMP);
        //TODO
        //任务id生成规则
        taskInfo.setTaskId(transTaskService.getTaskId());
        //如果是dtp，则插入dtp工作量
        if (nodeId.equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) || nodeId.equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
            taskInfo.setWorkLoad(fileInfo.getDtpWorkLoad());
            //如果是翻译流程则插入字数
        } else if (nodeId.equals(StaffLvlEnum.TASK_TYPE_TRANS.getValue())
                || nodeId.equals(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue())
                || nodeId.equals(StaffLvlEnum.TASK_TYPE_QA.getValue())) {
            taskInfo.setWorkLoad(fileInfo.getFileWordNum().toString());
        }
        tasks.add(taskInfo);
    }

    private int insertFile(FileWordNumVo fileInfo, CreateProjectParams params) {
        PmFile pmFile = new PmFile();
        pmFile.setFileName(fileInfo.getFileName());
        pmFile.setFileType(FileTypeEnum.FILE_TYPE_ORIGINAL.getValue());
        pmFile.setFilePath(fileInfo.getFilePath());
        pmFile.setProjectsId(params.getProjectId());
        pmFile.setUploadSuff(SysEnum.SYS_EC_NAME.getValue());
        pmFile.setFileSize(fileInfo.getFileSize());
        pmFile.setUploadTime(DateUtils.getNowTime());
        return fileMapper.insertSelectKey(pmFile);
    }


    /**
     * 根据文件名获取项目翻译流程
     *
     * @param fileId 文件名
     */
    @Override
    public List<PmFileFlow> getProjectTranslateFlow(Integer fileId) {
       return pmFileFlowMapper.getProjectTranslateFlow(fileId);
    }

    /**
     * @param projectId 项目id
     * @create: EC根据项目id，来下载译文
     * @return
     **/
    @Override
    public List<ManuscriptToEcVo> getManuscriptToEc(String projectId) {

        return  pmProjectInfoMapper.getManuscriptToEc(projectId);
    }

    /*
     * @create:  获取任务申请列表
     **/
    @Override
    public List<TaskApplyVo> getTaskApplyList(String pmID, String taskType, String applyType, String applySatus) throws Exception{
        return pmTaskApplyRecordMapper.getTaskApplyList(pmID,taskType,applyType,applySatus);
    }

//    /**
//     * @param pmId 项目经理id
//     * @create: 根据项目经理id查询项目议员申请列表
//     **/
//    @Override
//    public List<PmProjectInfo> getProjectListByApply(String pmId) {
//        return pmProjectInfoMapper.getProjectListByApply(pmId);
//    }

    public Map<String, Double> findDistribute(List<PmDistribute> distributes, List<String> flowList) {
        Map<String, Double> nodeTime = new HashMap<>(16);
        Map<String, Double> factTime = new HashMap<>(16);
        for (String flowId : flowList) {
            for (PmDistribute distribute : distributes) {
                if (distribute.getNodeId().toString().equalsIgnoreCase(flowId)) {
                    factTime.put(flowId, (distribute.getTimePer()));
                }
                nodeTime.put(distribute.getNodeId().toString(), distribute.getTimePer());
            }
        }
        Map<String, Double> factTimePer = calcFlowTime(nodeTime, factTime);
        return factTimePer;
    }

    /**
     * 计算节点实际占比时间
     *
     * @param timePer  默认配置的时间
     * @param factTime 实际计算的时间
     * @return 计算结果
     */
    private Map calcFlowTime(Map<String,Double> timePer, Map<String,Double> factTime) {
        //不包含译前
        if (!factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) && factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
            double time = timePer.get(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
            double total = 0d;
            for (String key : factTime.keySet()) {
                total += factTime.get(key);
            }
            for (String key : factTime.keySet()) {
                double per = factTime.get(key);
                per = per + time * (per / total);
                factTime.put(key, per);
            }
        } else if (!factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue()) && factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue())) {
            double time = timePer.get(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue());
            double total = 0d;
            for (String key : factTime.keySet()) {
                total += factTime.get(key);
            }
            for (String key : factTime.keySet()) {
                double per = factTime.get(key);
                per = per + time * (per / total);
                factTime.put(key, per);
            }
        } else if (!factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) && !factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
            double time = timePer.get(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue()) + timePer.get(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
            double total = 0d;
            for (String key : factTime.keySet()) {
                total += factTime.get(key);
            }
            for (String key : factTime.keySet()) {
                double per = factTime.get(key);
                per = per + time * (per / total);
                factTime.put(key, per);
            }
        }
        return factTime;
    }


    //根据项目id获取项目信息
    @Override
    public PmProjectInfo getPorjectById(String projectId) {

        return pmProjectInfoMapper.selectByPrimaryKey(projectId);
    }

    @Override
    public List<PmTaskApplyRecord> getTaskApplyById(String projectId) {

        return pmTaskApplyRecordMapper.getTaskApplyById(projectId);
    }

    @Override
    public List<PmFile> getProjectFileBypid(String projectId , String fileType) throws Exception {

        return  pmFileMapper.getProjectFileBypid(projectId,fileType);
    }


    //获取项目文件下所有跟流程有关的任务完成情况
    @Override
    public void getProjectFlowBypid(String projectId) {

    }

    //获取项目下所有参考文件
    @Override
    public List<PmFile> getFileReferenceList(String projectId) {

        return pmFileMapper.getFileReferenceList(projectId);
    }

    //项目详情—参考文件--删除参考文件
    @Override
    public int deleteFileReferenceById(String[] fileidList) {

        return pmFileMapper.deleteFileReferenceById(fileidList);
    }

    //项目详情——文件详情——项目转线下
    @Override
    public int updateProjectLine(String projectId, String projectType) {
        return pmProjectInfoMapper.updateProjectLine(projectId, projectType);
    }

    //项目详情——任务分配——项目终止
    @Override
    public int stopProject(String projectId, String projectType) {
        return pmProjectInfoMapper.stopProject(projectId, projectType);
    }

    /**
     * 保存审核记录结果
     *
     * @param applyRecord
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor =
            Exception.class)
    public void saveAuditResult(PmTaskApplyRecord applyRecord) throws Exception {
        //获取申请信息
        PmTaskApplyRecord recordinfo = pmTaskApplyRecordMapper.selectByPrimaryKey(applyRecord.getId());
        //获取任务信息
        PmTaskInfo taskInfo = taskInfoMapper.selectByTaskId(recordinfo.getTaskId());
        Date date = new Date();
        applyRecord.setLastUpdateTime(ParamStatic.SIMPLE_TIMEFORMAT.format(date));

        if (!ApplyRecordEnum.APPLY_SATUS_REJECT.getValue().equals(applyRecord.getApplySatus()) &&
                ApplyRecordEnum.APPLY_SATUS_AGREE.getValue().equals(applyRecord.getApplySatus())) {
            throw new RuntimeException("未知状态");
        }
        if (ApplyRecordEnum.APPLY_SATUS_REJECT.getValue().equals(applyRecord.getApplySatus())) {
            //驳回
            if(recordinfo.getApplyType().equals(ApplyRecordEnum.APPLY_TYPE_CANCEL_TASK.getValue())){
                //更新任务状态
                PmTaskInfo taskInfo_up = new PmTaskInfo();
                taskInfo_up.setTaskStatus(TaskInfoEnum.TASK_STATUS_ING.getValue());
                taskInfo_up.setId(taskInfo.getId());
                taskInfoMapper.updateByPrimaryKeySelective(taskInfo_up);
            }
            pmTaskApplyRecordMapper.updateByPrimaryKeySelective(applyRecord);
            return;
        }

        //通过
        //再次编辑
        if (ApplyRecordEnum.APPLY_TYPE_EDIT_AGAIN.getValue().equals(recordinfo.getApplyType())) {
            //解锁任务
            unlockTask(taskInfo);
        }
        //退稿
        if (ApplyRecordEnum.APPLY_TYPE_CANCEL_TASK.getValue().equals(recordinfo.getApplyType())) {
            /**
             * cat TODO
             */
            PmTaskInfo info_ins = new PmTaskInfo();
            info_ins = (PmTaskInfo) taskInfo.clone();
            info_ins.setId(null);
            info_ins.setStaffNum(ParamStatic.TASK_DEFAULT_STAFFNUM);
            info_ins.setTaskPackageId("");
            info_ins.setTaskStatus(TaskInfoEnum.TASK_STATUS_INIT.getValue());
            info_ins.setWorkLoad("");

            taskInfoMapper.insertSelective(info_ins);
        }

        //最后更新状态 -- 更新审核人  审核结果
        pmTaskApplyRecordMapper.updateByPrimaryKeySelective(applyRecord);
    }

    /**
     * 解锁任务
     *
     * @param taskInfo
     * @throws Exception
     */
    public void unlockTask(PmTaskInfo taskInfo) throws Exception {
        try {
            logger.info("任务再次编辑解锁请求cat开始 >>>>>>>>>> ");
            /**
             * cat解锁 TODO
             */
            logger.info("任务再次编辑解锁请求cat结束 >>>>>>>>>> 解锁结果：{}", 1);
            if (false) {
                throw new RuntimeException("任务解锁失败");
            }
        } catch (Exception e) {
            logger.error("任务解锁异常 >>>>>>>>>> {}", e);
            throw new RuntimeException("任务解锁异常");
        }

        List<PmTaskInfo> taskInfos_up = new ArrayList<>();
        List<String> types = new ArrayList<>();
        if (StaffLvlEnum.TASK_TYPE_TRANS.getValue().equals(taskInfo.getTaskType())) {
            //翻译解锁任务操作
            types.add(StaffLvlEnum.TASK_TYPE_TRANS.getValue());
            types.add(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
            types.add(StaffLvlEnum.TASK_TYPE_QA.getValue());

        }
        if(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue().equals(taskInfo.getTaskType())){
            // TODO 审校解锁任务操作 暂无判定流程
            //审校解锁任务操作
//            types.add(StaffLvlEnum.TASK_TYPE_TRANS.getValue());
            types.add(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
            types.add(StaffLvlEnum.TASK_TYPE_QA.getValue());
        }
        if(StaffLvlEnum.TASK_TYPE_QA.getValue().equals(taskInfo.getTaskType())){
            // TODO 质检解锁任务操作
            //质检解锁任务操作
//            types.add(StaffLvlEnum.TASK_TYPE_TRANS.getValue());
//            types.add(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
            types.add(StaffLvlEnum.TASK_TYPE_QA.getValue());
        }

        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andTaskTypeIn(types)
                .andTaskStatusNotEqualTo(TaskInfoEnum.TASK_STATUS_DELETE.getValue())
                .andTaskPackageIdEqualTo(taskInfo.getTaskPackageId());
        List<PmTaskInfo> taskInfos = taskInfoMapper.selectByExample(example);
        //修改状态为进行中
        for(PmTaskInfo temp : taskInfos){
            temp.setTaskStatus(TaskInfoEnum.TASK_STATUS_ING.getValue());
            taskInfos_up.add(temp);
        }
        taskInfoMapper.updateByTaskIdSelectiveForBatch(taskInfos_up);
    }

}
