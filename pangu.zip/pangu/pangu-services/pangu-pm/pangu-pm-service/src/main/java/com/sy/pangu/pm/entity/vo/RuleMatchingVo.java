package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/19 14:45
 * 保存判断规则需要的数据
 */
@Data
public class RuleMatchingVo {
    /**
     * 文件列表
     */
    private List<FileWordNumVo> fileList;
    /**
     * 是否翻译图片文字
     */
    private boolean isTransPic;
    /**
     * 是否译后P图
     */
    private boolean isPs;

    /**
     * 是否有术语表
     */
    private boolean hasTermFile;
    /**
     * 客户类型
     */
    private String cusType;
}
