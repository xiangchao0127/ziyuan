package com.sy.pangu.pm.utils.enumpackage;

public enum TaskInfoEnum {
	/**
	 * 匹配类型:自动
	 */
	ALLOT_TYPE_AUTO("01","自动匹配"),
	/**
	 * 匹配类型:手动
	 */
	ALLOT_TYPE_MANUAL("02","手动匹配"),

	/**
	 * 任务状态：初始状态
	 */
	TASK_STATUS_INIT("00","初始状态"),
	/**
	 * 任务状态：未开启
	 */
	TASK_STATUS_NOT_OPEN("01","未开启"),
	/**
	 * 任务状态：进行中
	 */
	TASK_STATUS_ING("10","进行中"),
	/**
	 * 任务状态：待上传
	 */
	TASK_STATUS_WAIT_UPLOAD("11","待上传"),
	/**
	 * 任务状态：待提交
	 */
	TASK_STATUS_WAIT_SUBMIT("12","待提交"),
	/**
	 * 任务状态：退稿中
	 */
	TASK_STATUS_CANCEL_TASK("13","退稿中"),
	/**
	 * 任务状态：已提交
	 */
	TASK_STATUS_SUBMIT("20","已提交"),
	/**
	 * 任务状态：已交付
	 */
	TASK_STATUS_DELIVERY("23","已交付"),
	/**
	 * 任务状态：已终止
	 */
	TASK_STATUS_TERMINATION("21","已终止"),
	/**
	 * 任务状态：已退稿
	 */
	TASK_STATUS_REJECT_FILE("22","已退稿"),
	/**
	 * 任务状态：已确认
	 */
	TASK_STATUS_CONFIRM("24","已确认"),
	/**
	 * 任务状态：删除
	 */
	TASK_STATUS_DELETE("99","删除");

	private String value;
	private String desc;
	
	private TaskInfoEnum(String value, String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}

	public static String getDescByValue(String value) {
		
		for(TaskInfoEnum data : TaskInfoEnum.values()) {
			if(data.getValue().equals(value)) {
				return data.desc;
			}
		}
		
		return "未知状态";
	}

	public static void main(String[] args) {

		System.out.println(getDescByValue("01"));
	}
}
