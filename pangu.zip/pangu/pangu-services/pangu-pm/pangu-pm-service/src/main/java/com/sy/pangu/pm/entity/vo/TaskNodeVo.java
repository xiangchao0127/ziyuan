package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import lombok.Data;

import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/5/6 17:00
 */
//@Data
public class TaskNodeVo {
    /**
     * 任务类型/节点名称
     */
    private String nodeName;
    /**
     * 任务类型/节点在流程中的id顺序
     */
    private  int fileFlowId;

    /**
     * 任务类型
     */
    private String taskType;

    /**
     * 任务状态
     */
    private String taskStatus;
    /**
     * 要求完成时间
     */
    private String requireTime;

    /**
     * 实际完成时间
     */
    private String realompletTime;

    /**
     * 抢单人列表信息
     */
    private String receiveStaffNumList;

    /**
     * 是否被抢
     */
    private String isReceive;

    /**
     * 人员信息
     */
    List<TaskSpiltStaffInfo> taskSpiltInfos;

    /**
     * 分包信息
     */
    List<TaskPackageVo> taskPackages;

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public List<TaskPackageVo> getTaskPackages() {
        return taskPackages;
    }

    public void setTaskPackages(List<TaskPackageVo> taskPackages) {
        this.taskPackages = taskPackages;
    }

    public String getReceiveStaffNumList() {
        return receiveStaffNumList;
    }

    public void setReceiveStaffNumList(String receiveStaffNumList) {
        this.receiveStaffNumList = receiveStaffNumList;
    }

    public String getIsReceive() {
        return isReceive;
    }

    public void setIsReceive(String isReceive) {
        this.isReceive = isReceive;
    }

    public int getFileFlowId() {
        return fileFlowId;
    }

    public void setFileFlowId(int fileFlowId) {
        this.fileFlowId = fileFlowId;
    }

    public String getRealompletTime() {
        return realompletTime;
    }

    public void setRealompletTime(String realompletTime) {
        this.realompletTime = realompletTime;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
        //设置nodename
        if("trans".equals(this.taskType)){
            this.nodeName = "翻译生产";
        }else {
            this.nodeName = StaffLvlEnum.getDescByValue(this.taskType);
        }
    }

    public String getRequireTime() {
        return requireTime;
    }

    public void setRequireTime(String requireTime) {
        this.requireTime = requireTime;
    }

    public List<TaskSpiltStaffInfo> getTaskSpiltInfos() {
        return taskSpiltInfos;
    }

    public void setTaskSpiltInfos(List<TaskSpiltStaffInfo> taskSpiltInfos) {
        this.taskSpiltInfos = taskSpiltInfos;
    }
}

//@Data
class TaskSpiltStaffInfo{
    private String staffNum;
    private String staffName;

    public String getStaffNum() {
        return staffNum;
    }

    public void setStaffNum(String staffNum) {
        this.staffNum = staffNum;
        //TODO 设置name
        this.staffName = "默认员工名";
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }
}
