package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 9:48
 */
@Data
public class PPTParam {
    private int pptComment;
    private int pptNode;
    private int pptProperty;
    private int pptHidden;

    public PPTParam() {
        this.pptComment = 0;
        this.pptNode = 0;
        this.pptProperty = 0;
        this.pptHidden = 0;
    }

}
