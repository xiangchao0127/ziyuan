package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmDefaultFlow;
import com.sy.pangu.pm.entity.example.PmDefaultFlowExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmDefaultFlowMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(PmDefaultFlowExample example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(PmDefaultFlowExample example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(PmDefaultFlow record);

    int insertBatch(List<PmDefaultFlow> record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(PmDefaultFlow record);

    /**
     *
     * @mbg.generated
     */
    List<PmDefaultFlow> selectByExample(PmDefaultFlowExample example);

    /**
     *
     * @mbg.generated
     */
    PmDefaultFlow selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") PmDefaultFlow record, @Param("example") PmDefaultFlowExample example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") PmDefaultFlow record, @Param("example") PmDefaultFlowExample example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(PmDefaultFlow record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(PmDefaultFlow record);

    /**
     *
     * @return
     */
    List<PmDefaultFlow> getAllFlowList();

    List<String> getDistinctId();
}