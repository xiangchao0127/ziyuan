package com.sy.pangu.pm.entity;

import java.util.List;

public class PmFileFlow {
    /**
     * 
     */
    private Integer id;

    /**
     * 任务id
     */
    private String projectId;

    /**
     * 文件id
     */
    private String fileId;

    /**
     * 流程名
     */
    private String flowName;

    /**
     * 流程id
     */
    private String flowId;

    /**
     * 上一步id
     */
    private String lastFlow;

    /**
     * 下一步id
     */
    private String nextFlow;

    /**
     * 是否启用(00:启用 01：未启用)
     */
    private String isUse;

    //任务信息
    List<PmTaskInfo> taskInfos;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public String getLastFlow() {
        return lastFlow;
    }

    public void setLastFlow(String lastFlow) {
        this.lastFlow = lastFlow;
    }

    public String getNextFlow() {
        return nextFlow;
    }

    public void setNextFlow(String nextFlow) {
        this.nextFlow = nextFlow;
    }

    public String getIsUse() {
        return isUse;
    }

    public void setIsUse(String isUse) {
        this.isUse = isUse;
    }

    public List<PmTaskInfo> getTaskInfos() {
        return taskInfos;
    }

    public void setTaskInfos(List<PmTaskInfo> taskInfos) {
        this.taskInfos = taskInfos;
    }
}