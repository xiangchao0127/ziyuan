package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：jzj
 * @date ：Created in 2019/5/10 14:00
 */
@Data
public class UserDomainVo {
    /**
     * 工号
     */
    private String userCode;
    /**
     * 真实姓名
     */
    private String realName;
    /**
     * 译员类型
     */
    private Integer translateType;

    List <DomainVo> domains;
}
