package com.sy.pangu.pm.utils;

import java.io.File;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;

import ch.qos.logback.classic.Logger;
import com.artofsolving.jodconverter.DocumentConverter;
import com.artofsolving.jodconverter.openoffice.connection.OpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.connection.SocketOpenOfficeConnection;
//import com.artofsolving.jodconverter.openoffice.converter.OpenOfficeDocumentConverter;
import com.artofsolving.jodconverter.openoffice.converter.StreamOpenOfficeDocumentConverter;
import com.google.common.io.Files;
import com.sy.pangu.common.util.HttpUtils;
import com.sy.pangu.pm.model.PropertyData;
import org.slf4j.LoggerFactory;

/**
 * @author ：jzj
 * @date ：Created in 2019/4/18 15:58
 */
public class ConvertToPdfUtil {

    private static final Logger logger = (Logger) LoggerFactory.getLogger(ConvertToPdfUtil.class);

    public ConvertToPdfUtil() {

    }

    /**
     * 转为PDF
     *
     * @param docFile
     * @param pdfFile
     * @return
     * @throws Exception
     */
/*
    public File doc2pdf(File docFile, File pdfFile) throws Exception {
        if (docFile.exists()) {
            if (!pdfFile.exists()) {
                OpenOfficeConnection connection = new SocketOpenOfficeConnection(8100);
                try {
                    connection.connect();
                    DocumentConverter converter = new OpenOfficeDocumentConverter(connection);
                    converter.convert(docFile, pdfFile);
                    // close the connection
                    connection.disconnect();
                    System.out.println("****pdf转换成功，PDF输出：" + pdfFile.getPath() + "****");
                } catch (java.net.ConnectException e) {
                    e.printStackTrace();
                    System.out.println("****swf转换器异常，openoffice服务未启动！****");
                    throw e;
                } catch (com.artofsolving.jodconverter.openoffice.connection.OpenOfficeException e) {
                    e.printStackTrace();
                    System.out.println("****swf转换器异常，读取转换文件失败****");
                    throw e;
                } catch (Exception e) {
                    e.printStackTrace();
                    throw e;
                }
            } else {
                System.out.println("****已经转换为pdf，不需要再进行转化****");
            }
        } else {
            System.out.println("****swf转换器异常，需要转换的文档不存在，无法转换****");
        }
        return pdfFile;
    }
*/

    private static String[] docFile =
            {".txt", ".doc", ".docx", ".wps", ".xls", ".xlsx", ".et", ".ppt", ".pptx", ".dps"};// office办公软件格式

    /**
     * sourceFile path 为url地址
     * @param sourceFile
     * @param destFile
     * @return
     */
    public static boolean office2PDF(String sourceFile, String destFile, PropertyData data) {
        File fileTemp = null;
        try {
            //原文件临时存放目录
            String sourceFileTemp = destFile.substring(0, destFile.lastIndexOf("/")) + sourceFile.substring(sourceFile.lastIndexOf("/")+1, sourceFile.length());
            String fileName = sourceFile.substring(sourceFile.lastIndexOf("/")+1,sourceFile.length());
            boolean res = FtpUtils.download(data.getUpfileHost(), data.getUpfilePort(), data.getUpfileUsername(), data.getUpfilePassword(), sourceFile, destFile);
            if(!res){
                return false;
            }
            fileTemp = new File(sourceFileTemp);
            InputStream inputStream = new FileInputStream(fileTemp);
//                    HttpUtils.getInputStream(sourceFile);
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);

            File inputFile = new File(ParamStatic.FILE_PATH_TEMP + fileName);
            Files.write(buffer, inputFile);
//                    new File(sourceFile);
            if (!inputFile.exists()) {
                logger.info("找不到源文件");
                return false;// 找不到源文件, 则返回-1
            }
            // 如果目标路径不存在, 则新建该路径
            File outputFile = new File(destFile);
            if (!outputFile.getParentFile().exists()) {
                outputFile.getParentFile().mkdirs();

            }
            // connect to an OpenOffice.org instance running on port 8100
//            OpenOfficeConnection conneciton = new SocketOpenOfficeConnection(ip, port);
            OpenOfficeConnection connection = new SocketOpenOfficeConnection(ParamStatic.OPEN_OFFICE_PORT);
            connection.connect();
            // convert
            DocumentConverter converter = new StreamOpenOfficeDocumentConverter(connection);
            converter.convert(inputFile, outputFile);
            // close the connection
            connection.disconnect();
            logger.info("路径：" + destFile);
            return true;
        } catch (ConnectException e) {
            logger.warn("ConnectException", e);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(fileTemp.exists()){
                fileTemp.delete();
            }
        }

        return true;
    }

    /**
     * 可解析的文件
     *
     * @param fileName
     * @return boolean
     * @author tang
     * @method isConvertible
     */
    public static boolean isConvertible(String fileName) {
        String after = fileName.substring(fileName.lastIndexOf("."),fileName.length());
        System.out.println(after);
        for (String type : docFile) {
            if (type.contains(after)) {
                return true;
            }
        }
        return false;
    }


    public static void main(String[] args) {
//        String path = "D:\\工作文档\\数据库设计文档V2.0.doc";
//        String path2 ="数据库设计文档V2.0";
//        System.out.println(System.getProperty("user.dir"));
//        String pdfPath = "pangu-services/pangu-pm/temp_file/"+path2 + ".pdf";
////        System.out.println(path2.indexOf(".pdf") == -1 && path2.indexOf(".PDF") == -1);
////        office2PDF(path,pdfPath);
//        logger.info(path);


        String a = "/opt/docker/nginx/html/pm/file-upload/"+ "abc.2.0.doc";
        String fileName = a.substring(a.lastIndexOf("/")+1,a.lastIndexOf("."));
        logger.info(fileName);
    }
}
