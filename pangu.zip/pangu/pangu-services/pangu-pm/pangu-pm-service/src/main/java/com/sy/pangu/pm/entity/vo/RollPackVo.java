package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.model.PackInfos;
import lombok.Data;

import java.util.List;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 * 用于接收CAT拆包后的数据
 **/
@Data
public class RollPackVo {
    private List<PackInfos> packInfoLst ;
    private int code;
    private String returnMsg;

}
