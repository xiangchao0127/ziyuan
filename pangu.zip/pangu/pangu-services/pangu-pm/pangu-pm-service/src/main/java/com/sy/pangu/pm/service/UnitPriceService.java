package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.SysUnitPriceDtp;
import com.sy.pangu.pm.entity.SysUnitPriceTrans;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/16 11:30
 */
public interface UnitPriceService {

    int saveUnitPriceTrans(SysUnitPriceTrans unitPriceTrans);

    int updateUnitPriceTrans(SysUnitPriceTrans unitPriceTrans);

    List<SysUnitPriceTrans> listUnitPriceTrans(String taskType, String staffType);

    int saveUnitPriceDTP(SysUnitPriceDtp unitPriceDtp);

    int updateUnitPriceDtp(SysUnitPriceDtp unitPriceDtp);

    List<SysUnitPriceDtp> listUnitPriceDtp(String taskType);

    int saveUnitPriceTypeSetting(SysUnitPriceDtp unitPriceDtp);

    List<SysUnitPriceDtp> listUnitPriceTypeSetting();
}
