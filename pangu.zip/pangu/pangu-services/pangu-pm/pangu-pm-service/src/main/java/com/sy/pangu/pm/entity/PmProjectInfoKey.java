package com.sy.pangu.pm.entity;

public class PmProjectInfoKey {
    /**
     * 
     */
    private Integer id;

    /**
     * 匹配翻译经理
     */
    private String tranmgrId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTranmgrId() {
        return tranmgrId;
    }

    public void setTranmgrId(String tranmgrId) {
        this.tranmgrId = tranmgrId == null ? null : tranmgrId.trim();
    }
}