package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.*;
import com.sy.pangu.pm.entity.vo.*;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.utils.PageUtil;

import java.util.List;
import java.util.Map;

/**
 * @author L00928
 * date 2019-04-10
 */

public interface AutoRuleService {

    /**
     *设置默认流程
     * @param orderType 订单类型
     * @param qualityLvl 订单等级
     * @param defaultCat 默认生产工具
     * @param workFlow 流程数组
     */
    boolean setDefaultFlow(String orderType, String qualityLvl, String defaultCat, List<String> workFlow);

    /**
     * 获取宣布的流程信息
     * @return
     */
    FlowQueryVo getFlow(FlowQueryVo flow);

    /**
     * 获取流程列表
     * @return
     */
    ResultModel listFlow();

    /**
     *
     * @param autoRuleVo
     * @return
     */
    ResultModel setAutoRules(AutoRuleQuery autoRuleVo);

    void updateRules(AutoRuleQuery autoRuleVo);

    /**
     * 删除指定的流程
     * @return
     */
    boolean delDefaultFlow(String orderType, String orderLvl, String defaultCat);

    /**
     *
     * @param distributes
     * @return
     */
    ResultModel setDistributeRule(DistributeQueryVo distributes);

    /**
     * 查询分领规则
     * @param flow
     * @return
     */
    ResultModel getDistributeRule();

    ResultModel updateDistributeRule(List<PmDistribute> distributes);

    /**
     * 返回流程节点信息
     */

    ResultModel allNode();

    Map<String, List<String>> judgeFlow(CreateProjectParams params);

    SysMatchingPm judgeTerm(String domain);

    PmAutomatching judgeMatchRule(String orderType, String orderLvl, String cusType, int wordNum);

    List<AutoRuleVo> autoRuleList(String orderType, String qualityLvl);

    List<Map<String,String>> ruleMatchTypes();

}
