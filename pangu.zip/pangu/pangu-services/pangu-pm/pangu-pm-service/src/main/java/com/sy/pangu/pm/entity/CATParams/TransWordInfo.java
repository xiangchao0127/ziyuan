package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/9 18:54
 */
@Data
public class TransWordInfo {
    private String fileId;
    private int transWordCount;
}
