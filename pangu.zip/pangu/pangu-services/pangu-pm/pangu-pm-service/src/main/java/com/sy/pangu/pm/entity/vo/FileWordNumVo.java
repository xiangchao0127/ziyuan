package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/19 14:50
 */
@Data
public class FileWordNumVo {
    /**
     * 文件名
     */
    private String fileName;
    /**
     * 文件路径
     */
    private String filePath;
    /**
     * 文件大小
     */
    private String fileSize;
    /**
     * 文件预估字数
     */
    private Integer fileWordNum;
    /**
     * 文件id
     */
    private String fileId;
    /**
     * 是否有图
     */
    private boolean hasPic;
    /**
     * dtp工作量
     */
    private String dtpWorkLoad;
    /**
     * 文件类型(原文，参考文件等)
     */
    private String fileType;
}
