package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmSysTask;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("sysTaskService")
public interface SysTaskService {

    public List<PmSysTask> getAllTaskService();
}
