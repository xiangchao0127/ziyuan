package com.sy.pangu.pm.utils.enumpackage;

/**
 * @author ：jzj
 * @date ：Created in 2019/4/26 14:40
 */
public enum GrabsheetEnum {

    /**
     *任务状态是否被领取：已领取
     */
    IS_RECEIVE_YES("01","已领取"),
    /**
     *任务状态是否被领取：未领取
     */
    IS_RECEIVE_NO("00","未领取"),
    /**
     *是否被提醒：是
     */
    IS_REMIND_YES("1","是"),
    /**
     *是否被提醒：否
     */
    IS_REMIND_NO("0","否");

    private String value;
    private String desc;

    private GrabsheetEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(GrabsheetEnum data : GrabsheetEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知状态";
    }

    public static void main(String[] args) {

        System.out.println(getDescByValue("01"));
    }
}
