package com.sy.pangu.pm.model;

public class ResultModel {

	/**
	 * 结果状态
	 */
	private boolean success;

	/**
	 * 结果备注信息
	 */
	private String msg;

	/**
	 * 返回结果
	 */
	private Object data;
	
	public ResultModel() {
		this.success = true;
	}
	
	public ResultModel(boolean success, String msg, Object data) {
		super();
		this.success = success;
		this.msg = msg;
		this.data = data;
	}

	public static ResultModel Success(){
    	
    	return new ResultModel();
    }
	
	public static ResultModel SuccessForMsg(String msg,Object data){
    	
    	return new ResultModel(true,msg,data);
    }
    
    public static ResultModel Fail(String msg,Object data){
    	
    	return new ResultModel(false,msg,data);
    }

	public static ResultModel FailWithNoData(String msg){

		return Fail(msg,null);
	}

	//@JsonProperty(value = "Success")
	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		success = success;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
