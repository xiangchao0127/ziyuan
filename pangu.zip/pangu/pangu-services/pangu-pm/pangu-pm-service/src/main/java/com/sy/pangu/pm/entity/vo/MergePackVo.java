package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 * 接收CAT合并包信息
 **/
@Data
public class MergePackVo {
    private String packId;
    private int wordCount;
    private int code;
    private String returnMsg;
}
