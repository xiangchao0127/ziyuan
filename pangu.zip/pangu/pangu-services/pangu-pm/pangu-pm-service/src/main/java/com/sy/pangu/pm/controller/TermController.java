package com.sy.pangu.pm.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/4/15 17:46
 */
@RestController
@RequestMapping("/term")
public class TermController {
}
