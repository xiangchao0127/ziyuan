package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 * ec返稿页面，译文的dtp信息
 *
 **/
@Data
public class DTPtoECOfFileVo {
    /**
     * 任务id
     */
    private String taskId;
    /**
     * DTP操作类型
     */
    private String handleType;
    /**
     * DTP工作量
     */
    private String final_workload;
    /**
     * DTP工作量单位
     */
    private String unit;
}
