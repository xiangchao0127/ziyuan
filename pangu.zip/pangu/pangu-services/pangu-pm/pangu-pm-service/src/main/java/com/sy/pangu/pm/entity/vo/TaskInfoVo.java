package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.utils.enumpackage.OrderTypeEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;

import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/4/24 13:41
 */

public class TaskInfoVo {
    /**
     * 任务id
     */
    private String taskId;
    /**
     * 任务名
     */
    private String taskName;
    /**
     * 项目id
     */
    private String projectId;
    /**
     * 项目名称
     */
    private String projectName;
    /**
     * 语言对
     */
    private String languageEn;
    /**
     * 语言对
     */
    private String languageZn;

    /**
     * 任务类型
     */
    private String taskType;
    /**
     * 任务类型
     */
    private String taskTypeZh;
    /**
     * 工作量
     */
    private String workLoad;
    /**
     * 原文ID
     */
    private String fileId;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 单价
     */
    private String unitPrice;
    /**
     * 要求完成时间
     */
    private String requireTime;

    /**
     * 稿件类型
     */
    private String orderType;
    /**
     * 稿件类型
     */
    private String orderTypeZh;
    /**
     * 任务状态
     */
    private String taskStatus;
    /**
     * 任务状态
     */
    private String taskStatusZh;
    /**
     * 实际完成时间
     */
    private String realCompletTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 实际工作量
     */
    private String realWorkLoad;
    /**
     * 工作类型
     */
    private String workType;
    /**
     * 上传的文件
     */
    private String uploadFileId;
    /**
     * 文件名称
     */
    private String uploadFileName;
    /**
     * 领域id
     */
    private String domain;
    /**
     * 全职
     */
    private String fullLv;
    /**
     * 兼职
     */
    private String partLv;
    /**
     * 全职
     */
    private String fullLvZh;
    /**
     * 兼职
     */
    private String partLvZh;
//    List<PmTaskInfo> taskInfos;
    /**
     * 分配类型
     */
    private String allotType;
    private String allotTypeZh;

    public String getAllotType() {
        return allotType;
    }

    public void setAllotType(String allotType) {
        this.allotType = allotType;
    }

    public String getAllotTypeZh() {
        return allotTypeZh;
    }

    public void setAllotTypeZh(String allotTypeZh) {
        this.allotTypeZh = allotTypeZh;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String getFullLvZh() {
        return fullLvZh;
    }

    public void setFullLvZh(String fullLvZh) {
        this.fullLvZh = fullLvZh;
    }

    public String getPartLvZh() {
        return partLvZh;
    }

    public void setPartLvZh(String partLvZh) {
        this.partLvZh = partLvZh;
    }

    public String getFullLv() {
        return fullLv;
    }

    public void setFullLv(String fullLv) {
        this.fullLv = fullLv;
        //TODO 设置技能等级中文

    }

    public String getPartLv() {
        return partLv;
    }

    public void setPartLv(String partLv) {
        this.partLv = partLv;
        //TODO 设置技能等级中文
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRealWorkLoad() {
        return realWorkLoad;
    }

    public void setRealWorkLoad(String realWorkLoad) {
        this.realWorkLoad = realWorkLoad;
    }

    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }

    public String getUploadFileId() {
        return uploadFileId;
    }

    public void setUploadFileId(String uploadFileId) {
        this.uploadFileId = uploadFileId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRealCompletTime() {
        return realCompletTime;
    }

    public void setRealCompletTime(String realCompletTime) {
        this.realCompletTime = realCompletTime;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
        //同步设置zh
        this.taskStatusZh = TaskInfoEnum.getDescByValue(this.taskStatus);
    }

    public String getTaskStatusZh() {
        return taskStatusZh;
    }

    public void setTaskStatusZh(String taskStatusZh) {
        this.taskStatusZh = taskStatusZh;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
        //设置ordertype时同时设置zh
        this.orderTypeZh = OrderTypeEnum.getDescByValue(this.orderType);
    }

    public String getOrderTypeZh() {
        return orderTypeZh;
    }

    public void setOrderTypeZh(String orderTypeZh) {
        this.orderTypeZh = orderTypeZh;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getTaskTypeZh() {
        return taskTypeZh;
    }

    public void setTaskTypeZh(String taskTypeZh) {
        this.taskTypeZh = taskTypeZh;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getLanguageEn() {
        return languageEn;
    }

    public void setLanguageEn(String languageEn) {
        this.languageEn = languageEn;
    }

    public String getLanguageZn() {
        return languageZn;
    }

    public void setLanguageZn(String languageZn) {
        this.languageZn = languageZn;
    }

    public String getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(String unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getRequireTime() {
        return requireTime;
    }

    public void setRequireTime(String requireTime) {
        this.requireTime = requireTime;
    }

//    public List<PmTaskInfo> getTaskInfos() {
//        return taskInfos;
//    }
//
//    public void setTaskInfos(List<PmTaskInfo> taskInfos) {
//        this.taskInfos = taskInfos;
//    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getWorkLoad() {
        return workLoad;
    }

    public void setWorkLoad(String workLoad) {
        this.workLoad = workLoad;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
}
