package com.sy.pangu.pm.service.impl;

import com.sy.pangu.pm.entity.PmBlockInfo;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.vo.FileTaskSpiltVo;
import com.sy.pangu.pm.entity.vo.TaskPackageVo;
import com.sy.pangu.pm.entity.vo.TaskSpiltVo;
import com.sy.pangu.pm.mapper.PmBlockInfoMapper;
import com.sy.pangu.pm.mapper.PmFileFlowMapper;
import com.sy.pangu.pm.mapper.PmProjectInfoMapper;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.service.IPMTaskSpiltService;
import com.sy.pangu.pm.service.IProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/
@Service
public class PMTaskSpiltServiceImpl implements IPMTaskSpiltService {
    @Autowired
    private IProjectService IProjectService;
    @Autowired
    private PmBlockInfoMapper pmBlockInfoMapper;
    @Autowired
    private PmFileFlowMapper pmFileFlowMapper;
    @Autowired
    private PmProjectInfoMapper projectInfoMapper;
    @Autowired
    private PmTaskInfoMapper pmTaskInfoMapper;

    @Override
    public List<PmBlockInfo> ListBolckByPackage(String packageIDList) {

        return pmBlockInfoMapper.ListBolckByPackage(packageIDList);
    }

    @Override
    public List<PmBlockInfo> ListBolckByPackage(String packageIDList, String fileID) {
        return pmBlockInfoMapper.ListBolckByPackageAndFid(packageIDList,fileID);
    }

    @Override
    public void deleteBolckByPackage(String packageIDList) {
        pmBlockInfoMapper.ListBolckByPackage(packageIDList);
    }

    @Override
    public void updateBolckByPackageid(int maxIndex, String taskPackageId) {
        pmBlockInfoMapper.updateBolckByPackageid(maxIndex,taskPackageId);
    }

    @Override
    public void inseretPm_block_info(PmBlockInfo pmBlockInfo) {
        pmBlockInfoMapper.insert(pmBlockInfo);
    }

    @Override
    public PmBlockInfo getBlockBypackage(String blockId) {
        return pmBlockInfoMapper.getBlockBypackage(blockId);
    }

    @Override
    public List<PmBlockInfo> ListBolckByfileID(String fileID) {
        return pmBlockInfoMapper.ListBolckByfileID(fileID);
    }

    @Override
    public void deleteFileFlowByFID(Integer fileId ,String flowID) {
        pmFileFlowMapper.deleteFileFlowByFID(fileId ,flowID );
    }


    /**
     * 任务分配列表
     *
     * @param projectId
     * @return
     */
    @Override
    public   List<FileTaskSpiltVo> getTaskSpiltList(String projectId) {
        return  projectInfoMapper.getTaskSpiltListByProjectId(projectId);
    }

    /**
     * 根据包id查询有多少任务已经分配获取放入抢单
     * @param packageIDList
     * @return
     */
    @Override
    public int countTaskSpiltByPackage(String packageIDList) {
        return pmTaskInfoMapper.countTaskSpiltByPackage(packageIDList);
    }


}
