package com.sy.pangu.pm.service.impl;

import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.*;
import com.sy.pangu.pm.entity.example.PmAutomatchingExample;
import com.sy.pangu.pm.entity.example.PmDefaultFlowExample;
import com.sy.pangu.pm.entity.example.PmDistributeExample;
import com.sy.pangu.pm.entity.example.SysMatchingPmExample;
import com.sy.pangu.pm.entity.vo.FileWordNumVo;
import com.sy.pangu.pm.entity.vo.FlowQueryVo;
import com.sy.pangu.pm.entity.vo.RuleMatchingVo;
import com.sy.pangu.pm.mapper.PmDefaultFlowMapper;
import com.sy.pangu.pm.mapper.PmFileFlowMapper;
import com.sy.pangu.pm.service.CommonService;
import com.sy.pangu.pm.utils.MathUtil;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/23 13:49
 */
@Service("commonService")
public class CommonServiceImpl implements CommonService {



//    @Autowired
//    private PmFileFlowMapper fileFlowMapper;
//
//    @Autowired
//    private PmDefaultFlowMapper pmDefaultFlowMapper;
//
//    /**
//     * 判断流程规则
//     * @param matchRule
//     */
//    public void judgeFlow(RuleMatchingVo matchRule) {
//        FlowQueryVo model = new FlowQueryVo();
//        model.setOrderType(matchRule.getOrderType());
//        model.setOrderLvl(matchRule.getOrderLvl());
//        model = (FlowQueryVo)getFlow(model).getData();
//        String[] flowPath = model.getFlowPath().split(",");
//        if (flowPath.length == 0) {
//            throw new RuntimeException("查找流程失败");
//        }
//        PmFileFlow flow = new PmFileFlow();
//        flow.setProjectId(matchRule.getProjectId());
//        for (FileWordNumVo file : matchRule.getFileList()) {
//            flow.setFileId(file.getFileId());
//            for (String pathId : judgeDtp(file.getFileName(), file.isHasPic(), matchRule.isTransPic(), matchRule.isPs(), flowPath)) {
//                flow.setFlowId(pathId);
//                fileFlowMapper.insert(flow);
//            }
//        }
//    }
//
//    private List<String> getFlow(FlowQueryVo model) {
//        PmDefaultFlowExample example = new PmDefaultFlowExample();
//        example.createCriteria().andOrderGradeEqualTo(model.getOrderLvl()).andOrderTypeEqualTo(model.getOrderType());
//        List<PmDefaultFlow> flows = pmDefaultFlowMapper.selectByExample(example);
//    }
//
//    /**
//     *  判断dtp流程
//     * @param fileName 文件名
//     * @param hasPic 是否有图片
//     * @param isTransWord 是否需要翻译图片文字
//     * @param isPs 是否译后P图
//     * @param flowPath 该订单的默认流程
//     * @return 处理完的流程
//     */
//    private List<String> judgeDtp(String fileName, boolean hasPic, boolean isTransWord, boolean isPs, String[] flowPath) {
//        ArrayList<String> arrayList = new ArrayList<>(Arrays.asList(flowPath));
//        String ext = fileName.substring(fileName.lastIndexOf(".") + 1);
//        if (ext.contains(FILE_EXT_RTF)) {
//            //工程格式
//        } else if (ext.contains(FILE_EXT_PDF)) {
//            //判断图片：三个条件为且关系，任意不满足则删除译后
//            if(!hasPic || !isTransWord || !isPs) {
//                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskName().equalsIgnoreCase("译后DTP")).collect(Collectors.toList()));
//            }
//        } else if (FILE_EXT_XLS.equalsIgnoreCase(ext) || FILE_EXT_XLSX.equalsIgnoreCase(ext) || FILE_EXT_TEXT.equalsIgnoreCase(ext) || FILE_EXT_DOC.equalsIgnoreCase(ext) || FILE_EXT_DOCX.equalsIgnoreCase(ext)) {
//            if (!hasPic) {
//                //删除译前译后
//                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskType().equalsIgnoreCase("DTP")).collect(Collectors.toList()));
//            } else if (!isTransWord) {
//                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskType().equalsIgnoreCase("DTP")).collect(Collectors.toList()));
//            } else if (!isPs) {
//                //删除译后
//                arrayList.removeAll(DataBaseStartUpRunner.initPmSysTask.stream().filter(x -> x.getTaskName().equalsIgnoreCase("译后DTP")).collect(Collectors.toList()));
//            }
//        }
//        return arrayList;
//    }
//
//    public SysMatchingPm judgeTerm(String domain) {
//        SysMatchingPmExample example = new SysMatchingPmExample();
//        example.createCriteria()
//                .andDomainEqualTo(domain);
//        List<SysMatchingPm> pmList = sysMatchingPmMapper.selectByExample(example);
//        if (pmList.size() > 1) {
//            //如果同一领域有多个PM。随机选择一名
//            return pmList.get(MathUtil.getRoundNum(pmList.size() - 1, 0));
//        } else {
//            return pmList.get(0);
//        }
//    }
//
//    /**
//     * 判断项目的匹配规则
//     */
//    public PmAutomatching judgeMatchRule(String orderType, String orderLvl, String cusType, int wordNum) {
//        /**
//         * 1、读取匹配规则：根据订单类型+订单等级
//         * 2、查询对应的规则实体
//         */
//        PmAutomatchingExample example = new PmAutomatchingExample();
//        example.createCriteria()
//                .andOrderLvlEqualTo(orderLvl)
//                .andOrderTypeEqualTo(orderType)
//                .andCusTypeEqualTo(cusType);
//        List<PmAutomatching> pmAutomatchingList = pmAutomatchingMapper.selectByExample(example);
//        PmAutomatching defaultmatch = null;
//        if (pmAutomatchingList.size() > 1) {
//            for (PmAutomatching pmAutomatching : pmAutomatchingList) {
//                int highCount = pmAutomatching.getHigherCount();
//                int lowCount = pmAutomatching.getLowerCount();
//                if (highCount == 0 && lowCount == 0) {
//                    defaultmatch = pmAutomatching;
//                }
//                //最大字数不为0时，则认为是双边都有值的区间，字数必须处于区间内部,最大字数为0时，只需大于等于最小字数即可
//                if(highCount != 0) {
//                    if (wordNum < highCount && wordNum >= lowCount) {
//                        return pmAutomatching;
//                    }
//                } else {
//                    if (wordNum >= lowCount) {
//                        return pmAutomatching;
//                    }
//                }
//            }
//        }
//        return defaultmatch;
//    }
//
//    /**
//     * 为自动分配的项目提供人员分配
//     * @param requestTime
//     * @param startTime
//     * @param orderType
//     * @param orderLvl
//     * @param flowList（主要需要节点id）
//     */
//    public void findDistribute(String requestTime, String startTime, String orderType, String orderLvl, List<String> flowList) throws ParseException {
//        PmDistributeExample example = new PmDistributeExample();
//        example.createCriteria().andFlowIdEqualTo(createCode(orderType, orderLvl));
//        List<PmDistribute> distributes = pmDistributeMapper.selectByExample(example);
//        Date startDate =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startTime);
//        Date requestDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(requestTime);
//        long nowStamp = startDate.getTime();
//        double hours = (requestDate.getTime() - startDate.getTime()) / TIME_STAMP_HOURS;
//        Map<String,Object> nodeTime = new HashMap<>(16);
//        Map<String,Object> factTime = new HashMap<>(16);
//        for (String flowId : flowList) {
//            for (PmDistribute distribute : distributes) {
//                if (distribute.getNodeId().toString().equalsIgnoreCase(flowId)) {
//                    nodeTime.put(flowId, distribute.getTimePer());
////                    nowStamp += (hours * distribute.getTimePer() / MAX_TIME_PER);
////                    String handleTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(nowStamp));
//                }
//            }
//        }
//
//    }
//
//    /**
//     * 计算节点实际占比时间
//     * @param timePer 默认配置的时间
//     * @param factTime 实际计算的时间
//     * @return 计算结果
//     */
//    private Map calcFlowTime(Map timePer, Map factTime) {
//        //不包含译前
//        if (!factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) && factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
//            double time = (double)timePer.get(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
//            double total = 0d;
//            for (Object key : factTime.keySet()) {
//                total += (double)factTime.get(key);
//            }
//            for (Object key : factTime.keySet()) {
//                double per = (double)factTime.get(key);
//                per = per + time * total;
//                factTime.put(key, per);
//            }
//        } else if (!factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue()) && factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue())) {
//            double time = (double)timePer.get(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue());
//            double total = 0d;
//            for (Object key : factTime.keySet()) {
//                total += (double)factTime.get(key);
//            }
//            for (Object key : factTime.keySet()) {
//                double per = (double)factTime.get(key);
//                per = per + time * total;
//                factTime.put(key, per);
//            }
//        } else if (!factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue()) && !factTime.keySet().contains(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())) {
//            double time = (double)timePer.get(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue()) + (double)timePer.get(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
//            double total = 0d;
//            for (Object key : factTime.keySet()) {
//                total += (double)factTime.get(key);
//            }
//            for (Object key : factTime.keySet()) {
//                double per = (double)factTime.get(key);
//                per = per + time * total;
//                factTime.put(key, per);
//            }
//        }
//        return factTime;
//    }
}
