package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/

@Data
public class FileTaskSpiltVo {
    private int fileId;
    private String fileName;
    private List<TaskNodeVo> taskNodeVos;
}

