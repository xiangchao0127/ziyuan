package com.sy.pangu.pm.controller;

import com.sy.pangu.common.util.StringUtils;
import ch.qos.logback.classic.Logger;
import com.sy.pangu.pm.entity.PmBlockInfo;
import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.vo.FileTaskSpiltVo;
import com.sy.pangu.pm.entity.vo.MergePackVo;
import com.sy.pangu.pm.entity.vo.RollPackVo;
import com.sy.pangu.pm.entity.vo.TaskGrabsheetVo;
import com.sy.pangu.pm.model.*;
import com.sy.pangu.pm.service.IPMTaskSpiltService;
import com.sy.pangu.pm.service.ITransTaskService;
import com.sy.pangu.pm.service.WorkLoadService;
import com.sy.pangu.pm.service.impl.WorkLoadServiceImpl;
import com.sy.pangu.pm.utils.CatUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program: pangu_pm  任务分配controller
 * @author: zhonglin
 * @create: 2019-04-22
 **/
@Api(tags = "项目详情——任务分配相关接口")
@RestController
@RequestMapping("/projectTaskSpilt")
public class PMTaskSpiltController {
    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ITransTaskService transTaskService;

    @Autowired
    private IPMTaskSpiltService iPMTaskSpiltService;
    @Autowired
    private  WorkLoadService workLoadService;


    /**
     * @param projectId 项目id
     * @create: 项目详情—任务分配列表
     **/
    @GetMapping("/getFileSpiltList")
    @ApiOperation("项目详情—任务分配列表")
    public ResultModel getFileSpiltList(String projectId) {
        try {
            List<FileTaskSpiltVo> fileTaskSpilts = iPMTaskSpiltService.getTaskSpiltList(projectId);
            return ResultModel.SuccessForMsg("success", fileTaskSpilts);
        } catch (Exception e) {
            logger.error("项目详情—任务分配列表查询失败", e);
            return ResultModel.FailWithNoData("项目详情—任务分配列表查询失败!");
        }
    }


    /**
     * @param operatType    1合并  2 拆分
     * @param projectID     项目id  可能用不着
     * @param packageIDList 包集合（合并包时候包集合）
     * @param ftype         3按字数拆  4 按已分配拆
     * @param fileID        文件id
     * @param blockId       拆分包时候的包id
     * @param TransFileList 拆分任务包需要拆几份的集合
     * @create: 按字数拆分，按任务包合并，拆分
     *
     **/
    @PostMapping("/splitBlockFile")
    @ApiOperation("拆包合包")
    public ResultModel splitBlockFile(String projectID, String packageIDList, int operatType, int ftype,
                                      String fileID, String blockId, List<TransFileModel> TransFileList) {
        try {
            CatUtils CatUtils = new CatUtils();
            //合并包
        if (operatType == 1) {
            packageIDList = packageIDList.replace(",", "','");
            //1只能合并同一个文件下的包   2选择的包不连续，不能合并   3拆分后的任务包都已分配不能合并(查询任务表，查询抢单表)
            //select  *  from pm_block_info where task_package_id in ('','') orderby block_increase_id
            List<PmBlockInfo> blocks = iPMTaskSpiltService.ListBolckByPackage(packageIDList);
            //从包信息中取出文件id判断是不是同一个文件下的包
            List<String> filelist =  blocks.stream().map(e -> e.getFileId()).distinct().collect(Collectors.toList());
            if (filelist.size() > 1) {
                return ResultModel.FailWithNoData("只能合并同一个文件下的包");
            }
            // 3拆分后的任务包都已分配不能合并(查询任务表，查询抢单表)
            int taskNum =  iPMTaskSpiltService.countTaskSpiltByPackage(packageIDList);
            if(taskNum>0){
                return ResultModel.FailWithNoData("选择的包已分配不能合并!");
            }
            ArrayList<String> blockIds = new ArrayList<String>();
            int maxIndex = 0;
            int correctIndex = 0;
            //下面是把选中任务包总字数加起来 没有用到？？
            int mergeBlocksWordCount = 0;
            // 2选择的包不连续，不能合并
            for (PmBlockInfo item : blocks) {
                if (maxIndex == 0) {
                    maxIndex = item.getBlockIncreaseId() - 1;
                    correctIndex = item.getBlockIncreaseId();
                }
                maxIndex++;
                if (maxIndex != item.getBlockIncreaseId()) {
                    return ResultModel.FailWithNoData("选择的包不连续，不能合并!");
                }
                blockIds.add(item.getTaskPackageId());
            }
            //开始调CAT接口进行合并 ,如果失败也要返回信息失败回滚事务
            MergePackVo mergePackVo = CatUtils.MergePack(filelist.get(0), blockIds);
            if(mergePackVo == null || mergePackVo.getCode()==9999){
                if(mergePackVo != null|| !mergePackVo.getReturnMsg().isEmpty()){
                    return ResultModel.FailWithNoData("合并失败，请求预处理合并异常!");
                }
            }
            //查出当前文件下除开合并后包的其他包信息
            // select * from pm_block_info where task_package_id not in('') and file_id=@fileid and is_delete!=1"
            List<PmBlockInfo> allBlocks = iPMTaskSpiltService.ListBolckByPackage(packageIDList, fileID);
            //把合并后的包设置为无效update pm_block_info  set state=-1 where task_package_id in('" + FileID.Replace(",","','")       // "')"
            iPMTaskSpiltService.deleteBolckByPackage(packageIDList);
            maxIndex = correctIndex + 1;//正确索引+1
            //循环当前文件下除开合并包的包信息排序按从小到大循环
            for (PmBlockInfo item : allBlocks) {
                //如果当前文件有效包的顺序不是第一个？？
                if (item.getBlockIncreaseId() < correctIndex) {
                    //修改包id对应包的顺序 update pm_block_info set block_increase_id= maxIndex where task_package_id=@bid
                    iPMTaskSpiltService.updateBolckByPackageid(maxIndex, item.getTaskPackageId());
                    //依次加1
                    maxIndex++;
                }
            }
            //存入一条新包数
            PmBlockInfo pmBlockInfoOLD = blocks.get(0);
            PmBlockInfo pmBlockInfo = new PmBlockInfo();
            pmBlockInfo.setProjectsId(pmBlockInfoOLD.getProjectsId());
            pmBlockInfo.setFileId(pmBlockInfoOLD.getFileId());
            // pmBlockInfo.setTaskId(pmBlockInfoOLD.getTaskId());
            pmBlockInfo.setTaskPackageId(mergePackVo.getPackId());
            pmBlockInfo.setBlockIncreaseId(correctIndex);
            //从CAT拿到的包字数,存到任务表，
           // pmBlockInfo.setDuplicateNum(0);
            pmBlockInfo.setIsDelete(0);
            iPMTaskSpiltService.inseretPm_block_info(pmBlockInfo);
            //通过原来包id，查出原来任务集合
            List<PmTaskInfo>  PmTaskInfos = transTaskService.getTaskInfoListByPackageList(packageIDList,"99");
            //通过新包id，创建n条任务，基本信息取原来任务的基本信息,创建任务根据返回的主键，再去创建任务工作量
            for (PmTaskInfo exam :PmTaskInfos ) {
                PmTaskInfo taskInfo = new PmTaskInfo();
                taskInfo.setProjectId(exam.getProjectId());
                taskInfo.setTaskId(transTaskService.getTaskId());
                taskInfo.setTaskPackageId(mergePackVo.getPackId());
                taskInfo.setTaskName(exam.getTaskName());
                taskInfo.setTaskType(exam.getTaskType());
                taskInfo.setTaskStatus("00");
                taskInfo.setStartTime(exam.getStartTime());
                taskInfo.setWorkLoad(String.valueOf(mergePackVo.getWordCount()));
                taskInfo.setFileId(exam.getFileId());
                taskInfo.setFlowId(exam.getFlowId());
                transTaskService.insertTaskInfo(taskInfo,null);
                //拿到任务返回的任务id，再去工作量表创建空工作量
                workLoadService.insertWorkLoad(taskInfo.getTaskId(),"11","",String.valueOf(mergePackVo.getWordCount()),"");
            }
            //通过原来包id找到任务表，把原来的包id对应任务都设置为失效，
               transTaskService.stopTaskByPackageIDlist(packageIDList);
        }
        }catch (Exception e){
            return ResultModel.FailWithNoData("拆分包失败");
        }
        try{
            //拆分包
        if (operatType == 2) {
            //先根据baoid查询这个包下有没有有效任务，判断当前包有没有任务分配  没有走正常，有走额外接口
           // List<PmTaskInfo> PmTaskInfoList = transTaskService.getTaskStatusByPackage(blockId); (改用下面查询)
            int taskNum =  iPMTaskSpiltService.countTaskSpiltByPackage(blockId);
            //拆分没有任务的包
            if (taskNum == 0) {
                //查询待拆包基本信息
                PmBlockInfo block = iPMTaskSpiltService.getBlockBypackage(blockId);
                if (block != null) {
                    fileID = block.getFileId();
                    //拿到当前文件所有有效包
                    List<PmBlockInfo> allBlocks = iPMTaskSpiltService.ListBolckByfileID(fileID);
                    int maxIndex = 0;
                    if (allBlocks != null) {
                        //拿到最大顺序引当最大顺序
                        maxIndex = allBlocks.get(0).getBlockIncreaseId();
                    }
                    //定义一个false  是否是最后一个包
                    boolean isLast = false;
                    List<PackInfoModel> packInfoList = null;
                    PackInfoModel packInfoModel = null;
                    //定义一个id，用来存顺序
                    int id = 0;
                    //循环传入的拆分集合，里面有顺序和字数
                    for (TransFileModel item : TransFileList) {
                        id++;
                        //如果id和传入的拆分集合相等，isLast=true
                        if (id == TransFileList.size()) {
                            isLast = true;
                        }
                        packInfoModel.setId(id);
                        packInfoModel.setRequireWordCount(item.getWordCount());
                        packInfoModel.setLastTask(isLast);
                        packInfoList.add(packInfoModel);
                    }
                    //调用CAT接口开始拆包，接收返回结果封装结果集到下面集合
                    RollPackVo rollPackVo = CatUtils.RollPackBySentence(projectID, block.getFileId(), packInfoList,
                            blockId);
                    if(rollPackVo == null || rollPackVo.getCode()==9999){
                        if(rollPackVo != null|| !rollPackVo.getReturnMsg().isEmpty()){
                            return ResultModel.FailWithNoData("拆分包失败，请求预处理合并异常!");
                        }
                    }
                    List<PackInfos> packInfosList = rollPackVo.getPackInfoLst();
                    //把被拆分包设置为失效
                    iPMTaskSpiltService.deleteBolckByPackage(blockId);
                    //把待拆包的顺序取出来赋值currIndex
                    int currIndex = block.getBlockIncreaseId();
                    //循环CAT返回的包信息，根据顺序排序,并把包数据存入顺序表
                    PmBlockInfo pmBlockInfo = null;
                    //查出被拆包所对应的任务
                    List<PmTaskInfo>  PmTaskInfos = transTaskService.getTaskInfoListByPackageList(packageIDList,"99");
                    for (PackInfos item : packInfosList) {
                        pmBlockInfo.setProjectsId(block.getProjectsId());
                        pmBlockInfo.setFileId(block.getFileId());
                        pmBlockInfo.setTaskPackageId(item.getPackId());
                        pmBlockInfo.setBlockIncreaseId(currIndex);
                       // pmBlockInfo.setDuplicateNum(item.getPackWordCount());
                        pmBlockInfo.setIsDelete(0);
                        iPMTaskSpiltService.inseretPm_block_info(pmBlockInfo);
                        //顺序加一
                        currIndex++;
                        //循环被拆包任务，用CAT发来包信息去，插入任务表，插入工作量表
                        for (PmTaskInfo exam :PmTaskInfos ) {
                            PmTaskInfo taskInfo = new PmTaskInfo();
                            taskInfo.setProjectId(exam.getProjectId());
                            taskInfo.setTaskId(transTaskService.getTaskId());
                            taskInfo.setTaskPackageId(item.getPackId());
                            taskInfo.setTaskName(exam.getTaskName());
                            taskInfo.setTaskType(exam.getTaskType());
                            taskInfo.setTaskStatus("00");
                            taskInfo.setStartTime(exam.getStartTime());
                            taskInfo.setWorkLoad(String.valueOf(item.getPackWordCount()));
                            taskInfo.setFileId(exam.getFileId());
                            taskInfo.setFlowId(exam.getFlowId());
                            transTaskService.insertTaskInfo(taskInfo,null);
                            //拿到任务返回的任务id，再去工作量表创建空工作量
                            workLoadService.insertWorkLoad(taskInfo.getTaskId(),"11","",taskInfo.getWorkLoad(),"");
                        }
                    //循环修改包信息表顺序，跳过被拆分包id
                    List<PmBlockInfo> chageData =
                            allBlocks.stream().filter(x -> !x.getTaskPackageId().equals(blockId)).collect(Collectors.toList());
                    for (PmBlockInfo items : chageData) {
                        iPMTaskSpiltService.updateBolckByPackageid(maxIndex, items.getTaskPackageId());
                        currIndex++;
                    }
                }
            }
            //如果有任务，先去CAT查询有多少字数可以分
           // 拆分有任务的包
            else {
                //先把有任务的包给CAT，让CAT返回需要包1的基本信息，包字数，已翻译字数，可拆分字数
              return  null;
            }
        }
        } }catch (Exception e){
            return ResultModel.FailWithNoData("合并包失败");
        }

        return null;
    }

    /**
     * @param fileId 文件id
     * @create: 终止文件不翻译，终止任务
     **/
    @GetMapping("/stopFileByFileId")
    @ApiOperation("终止文件不翻译，终止任务")
    public ResultModel stopFileByFileId(String fileId) {
        //判断文件是否已终止（该文件已终止）
        //修改文件相关任务状态为终止
        transTaskService.stopTaskByFileId(fileId);
        //传文件idCAT，CAT返回哪些任务包需要修改字数，再去修改字数
        return null;
    }
}

