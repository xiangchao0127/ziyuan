package com.sy.pangu.pm.entity;

public class PmSysTask {
    /**
     * 
     */
    private Integer id;

    /**
     * 任务类型
     */
    private String taskName;

    /**
     * 是否启用（1为启用，0为禁用）
     */
    private boolean isUse;

    /**
     * 
     */
    private String taskType;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName == null ? null : taskName.trim();
    }

    public boolean getIsUse() {
        return isUse;
    }

    public void setIsUse(boolean isUse) {
        this.isUse = isUse;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }
}