package com.sy.pangu.pm.entity;

public class PmTaskSplit {
    /**
     * 
     */
    private Integer id;

    /**
     * 节点id
     */
    private String nodeId;

    /**
     * 添加时间
     */
    private String addTime;

    /**
     * 通知时间
     */
    private String noticetime;

    /**
     * 译员等级
     */
    private String staffGrade;

    /**
     * 流程标志
     */
    private String flowSign;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId == null ? null : nodeId.trim();
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime == null ? null : addTime.trim();
    }

    public String getNoticetime() {
        return noticetime;
    }

    public void setNoticetime(String noticetime) {
        this.noticetime = noticetime == null ? null : noticetime.trim();
    }

    public String getStaffGrade() {
        return staffGrade;
    }

    public void setStaffGrade(String staffGrade) {
        this.staffGrade = staffGrade == null ? null : staffGrade.trim();
    }

    public String getFlowSign() {
        return flowSign;
    }

    public void setFlowSign(String flowSign) {
        this.flowSign = flowSign == null ? null : flowSign.trim();
    }
}