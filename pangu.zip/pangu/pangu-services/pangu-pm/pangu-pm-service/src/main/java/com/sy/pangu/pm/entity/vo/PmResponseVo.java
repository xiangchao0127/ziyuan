package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/29 16:08
 */
@Data
public class PmResponseVo {
    private List<String> outerCode;
    private List<String> pmCode;
    private String domain;
    private Integer id;
}
