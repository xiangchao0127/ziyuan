package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/9 17:09
 */
@Data
public class InitTParams {
    private String filed;
    private String sourceLanguage;
    private String targetLanguage;
    private String customerName;
    private String projectId;
}
