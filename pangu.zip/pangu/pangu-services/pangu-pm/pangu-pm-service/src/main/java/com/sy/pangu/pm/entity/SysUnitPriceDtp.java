package com.sy.pangu.pm.entity;

import java.math.BigDecimal;

public class SysUnitPriceDtp {
    /**
     * 
     */
    private Integer id;

    /**
     * 单价
     */
    private BigDecimal unitPrice;

    /**
     * 计算单位
     */
    private String unit;

    /**
     * 操作类型
     */
    private String handleType;

    /**
     * 
     */
    private String dataChar1;

    /**
     * 
     */
    private String dataChar2;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public String getHandleType() {
        return handleType;
    }

    public void setHandleType(String handleType) {
        this.handleType = handleType == null ? null : handleType.trim();
    }

    public String getDataChar1() {
        return dataChar1;
    }

    public void setDataChar1(String dataChar1) {
        this.dataChar1 = dataChar1 == null ? null : dataChar1.trim();
    }

    public String getDataChar2() {
        return dataChar2;
    }

    public void setDataChar2(String dataChar2) {
        this.dataChar2 = dataChar2 == null ? null : dataChar2.trim();
    }
}