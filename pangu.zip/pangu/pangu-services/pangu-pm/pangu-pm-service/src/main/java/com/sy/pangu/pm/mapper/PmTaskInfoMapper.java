package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmProjectInfo;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import java.util.List;

import com.sy.pangu.pm.entity.vo.TaskInfoVo;
import com.sy.pangu.pm.entity.vo.UserTaskStatisticsVo;
import com.sy.pangu.pm.model.TaskFileListModel;
import com.sy.pangu.pm.utils.PageUtil;
import org.apache.ibatis.annotations.Param;

public interface PmTaskInfoMapper {
    long countByExample(PmTaskInfoExample example);

    int deleteByExample(PmTaskInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmTaskInfo record);

    int insertSelective(PmTaskInfo record);

    List<PmTaskInfo> selectByExample(PmTaskInfoExample example);

    PmTaskInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmTaskInfo record, @Param("example") PmTaskInfoExample example);

    int updateByExample(@Param("record") PmTaskInfo record, @Param("example") PmTaskInfoExample example);

    int updateByPrimaryKeySelective(PmTaskInfo record);

    int updateByPrimaryKey(PmTaskInfo record);

    /**
     * 分页查询未领取的任务
     * @param page
     * @return
     */
    List<TaskInfoVo> selectPageNotReceiveTask(PageUtil page);

    /**
     * 统计查询未领取的任务
     * @param page
     * @return
     */
    long selectCountNotReceiveTask(PageUtil page);

    /**
     *分页查询任务信息
     * @param page
     * @return
     */
    List<TaskInfoVo> selectPageTaskListByStatus(PageUtil page);
    long selectCountTaskListByStatus(PageUtil page);
    /**
     * 项目转线下修改任务表把项目相关任务全部设置为删除状态 除开交付
     * @param projectId      项目id
     */
    int updateTaskStatusByPID(String projectId);
    //把所有跟项目先关任务设置为终止
    int  stopTaskByPId(String projectId);
    //把所有跟文件先关任务设置为终止
    void stopTaskByFileId(String fileId);
    /**
     * 根据taskId查询
     * @param taskId
     * @return
     */
    PmTaskInfo selectByTaskId(String taskId);

    /**
     * 测试方法
     * @return
     */
    List<TaskInfoVo> getTest();

    /**
     * 批量插入任务数据
     * @param taskInfoList
     * @return
     */
    int insertBatch(List<PmTaskInfo> taskInfoList);
    /**
     * 根据任务包id查询未分配任务
     * @param blockId
     * @return
     */
    List<PmTaskInfo> getTaskStatusByPackage(String blockId);

    /**
     * 根据taskid批量更新
     * @param taskInfos
     */
    void updateByTaskIdSelectiveForBatch(List<PmTaskInfo> taskInfos);
    /**
     * 根据任务实体查询任务信息
     * @param pmTaskInfo
     * @return
     */
    List<PmTaskInfo> getTaskInfoList(PmTaskInfo pmTaskInfo);

    void updateTaskStByFild(String fileId);

    /**
     * 根据staffnum获取抢单信息
     * @param userCode
     * @return
     */
    int getReceiveOrderList(String userCode);

    /**
     *根据staffnum统计翻译字数
     * @param userCode
     * @return
     */
    long sumTransWorkNum(String userCode);

    /**
     * 查询个人项目信息
     * @param vo
     * @return
     */
    List<PmProjectInfo> statisticsProjectOfTask(UserTaskStatisticsVo vo);
    /**
     * 根据原文件id，获取任务与任务文件信息集合
     * @param fileId
     */
    List<TaskFileListModel> getTaskinfoByFileid(Integer fileId);

    /**
     * 根据包ID字符串集合和状态，获取任务集合
     * @param packageIDList  包ID字符串集合
     * @param taskStatus  任务状态
     */
    List<PmTaskInfo> getTaskInfoListByPackageList(@Param("packageIDList")  String packageIDList, @Param("taskStatus") String taskStatus);
    /**
     * 根据包ID字符串把任务设置为失效
     * @param packageIDList  包ID字符串集合
     */
    void stopTaskByPackageIDlist(String packageIDList);

    /**
     * 根据包id查询有多少任务已经分配获取放入抢单
     * @param packageIDList
     * @return
     */
    int countTaskSpiltByPackage(String packageIDList);

    /**
     * 根据任务id把交付任务修改为已交付，并且更新交付时间
     * @param status 任务状态
     * @param taskId 任务id
     * @param realCompletTime  任务实际完成时间
     * @return
     */
    void updateTaskStatusByTaskID(@Param("taskId") String taskId,@Param("status")  String status, @Param("realCompletTime") String realCompletTime);

    /**
     * 根据原文件id，把文件下所有有效任务设置任务状态
     * @param fileId 原文件id
     * @param status 任务状态
     * @return
     */
    void updateTaskStatusByFileID(@Param("fileId")String fileId, @Param("status")String status);
}