package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmBlockInfo;
import com.sy.pangu.pm.entity.vo.FileTaskSpiltVo;

import java.util.List;

public interface IPMTaskSpiltService {
    /**
     * 根据包id获取包基本信息
     */
    List<PmBlockInfo> ListBolckByPackage(String packageIDList);

    List<PmBlockInfo> ListBolckByPackage(String packageIDList, String fileID);

    void deleteBolckByPackage(String packageIDList);

    void updateBolckByPackageid(int maxIndex, String taskPackageId);

    void inseretPm_block_info(PmBlockInfo pmBlockInfo);

    PmBlockInfo getBlockBypackage(String blockId);

    List<PmBlockInfo> ListBolckByfileID(String fileID);

    void deleteFileFlowByFID(Integer fileId ,String flow);

    /**
     * 任务分配列表
     * @param projectId
     * @return
     */
    public  List<FileTaskSpiltVo> getTaskSpiltList(String projectId);

    /**
     * 根据包id查询有多少任务已经分配获取放入抢单
     * @param packageIDList
     * @return
     */
    int countTaskSpiltByPackage(String packageIDList);
}
