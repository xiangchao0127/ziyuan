package com.sy.pangu.pm.service.impl;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.SysStaffLvl;
import com.sy.pangu.pm.entity.example.SysStaffLvlExample;
import com.sy.pangu.pm.entity.vo.UserCandidateVo;
import com.sy.pangu.pm.entity.vo.UserQueryVo;
import com.sy.pangu.pm.mapper.SysStaffLvlMapper;
import com.sy.pangu.pm.service.StaffService;
import com.sy.pangu.pm.utils.PageUtil;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/15 18:46
 */
@Service("staffService")
public class StaffServiceImpl implements StaffService {

    @Autowired
    private SysStaffLvlMapper sysStaffLvlMapper;

    /**
     * 新增一条员工等级，等级值按现有数量+1,以同工作类型和任务类型区分
     * @param staffLvl
     * @return
     */
    @Override
    public int saveStaffLvl(SysStaffLvl staffLvl) {
        if (staffLvl.getTaskType().equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue()) || staffLvl.getTaskType().equalsIgnoreCase(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue())) {
            staffLvl.setTaskType(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
        }
        int count = sysStaffLvlMapper.selectTypeCount(staffLvl);
        staffLvl.setLvlNum(count + 1);
        return sysStaffLvlMapper.insert(staffLvl);
    }

    @Override
    public int updateStaffLvl(SysStaffLvl staffLvl) {
        if (StringUtils.isEmpty(staffLvl.getLvlName())) {
            return 0;
        }
        //暂时只允许修改等级名字，根据类型、数值关联
        SysStaffLvlExample example = new SysStaffLvlExample();
        example.createCriteria()
                .andLvlNumEqualTo(staffLvl.getLvlNum())
                .andTaskTypeEqualTo(staffLvl.getTaskType())
                .andLvlTypeEqualTo(staffLvl.getLvlType());
        return sysStaffLvlMapper.updateByExample(staffLvl, example);
    }

    @Override
    public int deleteStaffLvl(SysStaffLvl staffLvl) {
        //先删除，再将其他的更新
        SysStaffLvlExample example = new SysStaffLvlExample();
        example.createCriteria()
                .andLvlTypeEqualTo(staffLvl.getLvlType())
                .andTaskTypeEqualTo(staffLvl.getTaskType())
                .andLvlNumEqualTo(staffLvl.getLvlNum())
                .andLvlNameEqualTo(staffLvl.getLvlName());
        sysStaffLvlMapper.deleteByExample(example);
        sysStaffLvlMapper.updateLvlNum(staffLvl);
        return 1;
    }

    @Override
    public List<SysStaffLvl> listStaffLvl(String taskType, String lvlType) {
        if (StringUtils.isEmpty(taskType)) {
            return null;
        }
        if (StringUtils.isEmpty(lvlType)) {
            return null;
        }
        SysStaffLvlExample example = new SysStaffLvlExample();
        example.createCriteria()
                .andTaskTypeEqualTo(taskType)
                .andLvlTypeEqualTo(lvlType);
        return sysStaffLvlMapper.selectByExample(example);
    }

    @Override
    public List<UserCandidateVo> userList(UserQueryVo userInfo, PageUtil pageUtil) {
        return null;
    }
}
