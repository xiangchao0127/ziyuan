package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/9 18:38
 */
@Data
public class FileProgressResponse {
    private String fileId;
    private float progressValue;
}
