package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/10 14:19
 */
@Data
public class R2ResultModel {
    private boolean Success;
    private String code;
    private String msg;
    private Object data;
}
