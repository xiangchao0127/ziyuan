package com.sy.pangu.pm.entity;

import java.math.BigDecimal;

public class PmGrabsheet {
    /**
     * 
     */
    private Integer id;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 人员
     */
    private String staffNum;

    /**
     * 状态
     */
    private String taskStatus;

    /**
     * 是否提醒
     */
    private Boolean isRemind;

    /**
     * 提醒时间（将由通知小时+生成任务包的当前时间获得）
     */
    private String remindTime;

    /**
     * 记录多少小时后通知pm无人抢单
     */
    private BigDecimal noticeHour;

    /**
     * 分配类型(01:自动，02：手动)
     */
    private String allotType;

    /**
     * 专职 - 匹配等级
     */
    private String chooseLv;

    /**
     * 最后修改时间
     */
    private String lastEditTime;

    /**
     * 最后修改人
     */
    private String lastEditor;

    /**
     * 兼职 - 匹配等级
     */
    private String datachar1;

    /**
     * 备用
     */
    private String datachar2;

    public Boolean getRemind() {
        return isRemind;
    }

    public void setRemind(Boolean remind) {
        isRemind = remind;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getStaffNum() {
        return staffNum;
    }

    public void setStaffNum(String staffNum) {
        this.staffNum = staffNum == null ? null : staffNum.trim();
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus == null ? null : taskStatus.trim();
    }

    public Boolean getIsRemind() {
        return isRemind;
    }

    public void setIsRemind(Boolean isRemind) {
        this.isRemind = isRemind;
    }

    public String getRemindTime() {
        return remindTime;
    }

    public void setRemindTime(String remindTime) {
        this.remindTime = remindTime == null ? null : remindTime.trim();
    }

    public BigDecimal getNoticeHour() {
        return noticeHour;
    }

    public void setNoticeHour(BigDecimal noticeHour) {
        this.noticeHour = noticeHour;
    }

    public String getAllotType() {
        return allotType;
    }

    public void setAllotType(String allotType) {
        this.allotType = allotType == null ? null : allotType.trim();
    }

    public String getChooseLv() {
        return chooseLv;
    }

    public void setChooseLv(String chooseLv) {
        this.chooseLv = chooseLv == null ? null : chooseLv.trim();
    }

    public String getLastEditTime() {
        return lastEditTime;
    }

    public void setLastEditTime(String lastEditTime) {
        this.lastEditTime = lastEditTime == null ? null : lastEditTime.trim();
    }

    public String getLastEditor() {
        return lastEditor;
    }

    public void setLastEditor(String lastEditor) {
        this.lastEditor = lastEditor == null ? null : lastEditor.trim();
    }

    public String getDatachar1() {
        return datachar1;
    }

    public void setDatachar1(String datachar1) {
        this.datachar1 = datachar1 == null ? null : datachar1.trim();
    }

    public String getDatachar2() {
        return datachar2;
    }

    public void setDatachar2(String datachar2) {
        this.datachar2 = datachar2 == null ? null : datachar2.trim();
    }
}