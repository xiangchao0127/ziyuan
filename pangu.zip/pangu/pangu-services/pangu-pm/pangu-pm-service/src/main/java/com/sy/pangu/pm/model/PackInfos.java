package com.sy.pangu.pm.model;

import java.util.List;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 * CAT拆包返回结果接收模型
 **/

public class PackInfos {
    private int id;
    private String packId;
    private int packWordCount;
    private int packAllWordCount;
    private int Flag;
    List<PackInfos> packInfosList ;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPackId() {
        return packId;
    }

    public void setPackId(String packId) {
        this.packId = packId;
    }

    public int getPackWordCount() {
        return packWordCount;
    }

    public void setPackWordCount(int packWordCount) {
        this.packWordCount = packWordCount;
    }

    public int getPackAllWordCount() {
        return packAllWordCount;
    }

    public void setPackAllWordCount(int packAllWordCount) {
        this.packAllWordCount = packAllWordCount;
    }

    public int getFlag() {
        return Flag;
    }

    public void setFlag(int flag) {
        Flag = flag;
    }

    public List<PackInfos> getPackInfosList() {
        return packInfosList;
    }

    public void setPackInfosList(List<PackInfos> packInfosList) {
        this.packInfosList = packInfosList;
    }
}

