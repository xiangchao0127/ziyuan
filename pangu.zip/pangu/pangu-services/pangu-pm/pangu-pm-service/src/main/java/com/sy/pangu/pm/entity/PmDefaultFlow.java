package com.sy.pangu.pm.entity;

public class PmDefaultFlow {
    /**
     * 
     */
    private String id;

    /**
     * 流程
     */
    private String flow;

    /**
     * 节点id
     */
    private Integer nodeId;

    /**
     * 上一步
     */
    private Integer lastFlow;

    /**
     * 下一步
     */
    private Integer nextFlow;

    /**
     * 订单类型
     */
    private String orderType;

    /**
     * 订单等级
     */
    private String orderGrade;

    /**
     * 客户等级
     */
    private String defaultCat;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow == null ? null : flow.trim();
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public Integer getLastFlow() {
        return lastFlow;
    }

    public void setLastFlow(Integer lastFlow) {
        this.lastFlow = lastFlow;
    }

    public Integer getNextFlow() {
        return nextFlow;
    }

    public void setNextFlow(Integer nextFlow) {
        this.nextFlow = nextFlow;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType == null ? null : orderType.trim();
    }

    public String getOrderGrade() {
        return orderGrade;
    }

    public void setOrderGrade(String orderGrade) {
        this.orderGrade = orderGrade == null ? null : orderGrade.trim();
    }

    public String getDefaultCat() {
        return defaultCat;
    }

    public void setDefaultCat(String defaultCat) {
        this.defaultCat = defaultCat == null ? null : defaultCat.trim();
    }
}