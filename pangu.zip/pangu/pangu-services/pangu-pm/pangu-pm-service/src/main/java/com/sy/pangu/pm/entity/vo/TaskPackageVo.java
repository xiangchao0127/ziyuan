package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/5/6 16:57
 */
@Data
public class TaskPackageVo {
    /**
     * 包名/任务名
     */
    private String packageName;
    /**
     * 包ID
     */
    private String packageId;
    /**
     * 包顺序
     */
    private  int packageOrder;

    /**
     * 包字数
     */
    private String workLoad;
    /**
     * 任务节点信息
     */
    private List<TaskNodeVo> taskNodes;
}
