package com.sy.pangu.pm.controller;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.client.UserClient;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.*;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.entity.vo.*;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.model.TaskFileListModel;
import com.sy.pangu.pm.service.IPMTaskSpiltService;
import com.sy.pangu.pm.service.IProjectService;
import com.sy.pangu.pm.service.ITransTaskService;
import com.sy.pangu.pm.utils.PageUtil;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.GrabsheetEnum;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import com.sy.pangu.pm.utils.enumpackage.WorkTypeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.*;
//import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/
@Api(tags = "项目列表项目详情相关接口")
@RestController
@RequestMapping("/project")
public class ProjectController {
    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IProjectService IProjectService;
    @Autowired
    private ITransTaskService transTaskService;
    @Autowired
    private IPMTaskSpiltService iPMTaskSpiltService;
    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
//    @Autowired
//    private PermissionClient permissionClient;
    @Autowired
    private UserClient userClient;

    /**
     * create: 获取项目列获取项目列表  按降序排序
     * 1、待处理项目
     * 待分配：下单时间      待交付：下单时间    变更&申请：按提交时间
     * 2、进行中项目
     * 分配中：下单时间      已分配：下单时间
     * 3、已完成项目
     * 实际完成时间
     **/
    @PostMapping("/listProjectAll")
    @ApiOperation("查询项目列表")
    public ResultModel listProject(ProjectSearchModel projectSearchModel , int pageNum, int pageSize) {
        try {
            projectSearchModel.getPmProjectInfo().setPmId("z01000");
            PageHelper.startPage(pageNum, pageSize);
            List<PmProjectInfo> pmProjectInfos = IProjectService.listProject(projectSearchModel);
            for (PmProjectInfo item :pmProjectInfos) {
                item.setPmName(DataBaseStartUpRunner.init_user_data.get(item.getPmId())== null ? "未知名字" :  DataBaseStartUpRunner.init_user_data.get(item.getPmId()).getRealName());
                item.setTranmgrName(DataBaseStartUpRunner.init_user_data.get(item.getPmId())== null ? "未知名字" : DataBaseStartUpRunner.init_user_data.get(item.getTranmgrId()).getRealName());
                item.setTranmgrName(DataBaseStartUpRunner.init_user_data.get(item.getSourceLan())== null ? "未知语言对" : DataBaseStartUpRunner.init_language_data.get(item.getSourceLan()));
                item.setTargetLanName(DataBaseStartUpRunner.init_user_data.get(item.getTargetLan())== null ? "未知语言对" :DataBaseStartUpRunner.init_language_data.get(item.getTargetLan()));
                item.setDomainName(DataBaseStartUpRunner.init_domain_data.get(item.getDomain())== null ?  "未知领域": DataBaseStartUpRunner.init_domain_data.get(item.getDomain()));
            }

            PageInfo<PmProjectInfo> pa = new PageInfo<PmProjectInfo>(pmProjectInfos);
            return ResultModel.SuccessForMsg("success", pa);
        } catch (Exception e) {
            logger.error("查询项目列表失败", e);
            return ResultModel.FailWithNoData("查询项目列表失败");
        }
    }

    /**
     * 根据项目id获取项目基本信息
     */
    @GetMapping("/getPorjectById")
    @ApiOperation("根据项目id获取项目基本信息")
    public ResultModel getPorjectById(String projectId) {
        try {
            PmProjectInfo pm = IProjectService.getPorjectById(projectId);
            pm.setPmName(DataBaseStartUpRunner.init_user_data.get(pm.getPmId())== null ? "未知名字" :DataBaseStartUpRunner.init_user_data.get(pm.getPmId()).getRealName());
            pm.setTranmgrName(DataBaseStartUpRunner.init_user_data.get(pm.getPmId())== null ? "未知名字" :DataBaseStartUpRunner.init_user_data.get(pm.getTranmgrId()).getRealName());
            pm.setSourceLanName(DataBaseStartUpRunner.init_user_data.get(pm.getSourceLan())== null ? "未知语言对" :DataBaseStartUpRunner.init_language_data.get(pm.getSourceLan()));
            pm.setTargetLanName(DataBaseStartUpRunner.init_user_data.get(pm.getTargetLan())== null ? "未知语言对" :DataBaseStartUpRunner.init_language_data.get(pm.getTargetLan()));
            pm.setDomainName(DataBaseStartUpRunner.init_domain_data.get(pm.getDomain())== null ? "未知领域" : DataBaseStartUpRunner.init_domain_data.get(pm.getDomain()));
            return ResultModel.SuccessForMsg("success",pm);

        } catch (Exception e) {
            logger.error("查询项目基本信息失败", e);
            return ResultModel.FailWithNoData("查询项目基本信息失败");
        }
    }

    /**
     * 根据项目id获取项目翻译流程
     */
    @GetMapping("/getProjectTranslateFlow")
    @ApiOperation("根据项目id获取项目翻译流程")
    public ResultModel getProjectTranslateFlow(String projectId) {
        try {
            List<PmFile> PmFileList = IProjectService.getProjectFileBypid(projectId ,"01");
            if(PmFileList.size()==0){
                return ResultModel.FailWithNoData("当前项目没有文件");
            }
            PmFile pmFile = PmFileList.get(0);
            List<PmFileFlow> pmFileFlowList = IProjectService.getProjectTranslateFlow(pmFile.getFileId());
            return ResultModel.SuccessForMsg("success", pmFileFlowList);
        } catch (Exception e) {
            logger.error("获取项目翻译流程失败", e);
            return ResultModel.FailWithNoData("获取项目翻译流程失败");
        }
    }

//    @GetMapping("/getProjectListByApply")
//    @ApiOperation("查询项目译员申请列表")   需求有变，暂时注掉
//    public ResultModel getProjectListByApply(int pageNum, int pageSize){
//        try {
//        String pmId = "z01000";
//        PageHelper.startPage(pageNum, pageSize);
//        List<PmProjectInfo> pmProjectInfos =  IProjectService.getProjectListByApply(pmId);
//        for (PmProjectInfo item :pmProjectInfos) {
//            item.setPmName(DataBaseStartUpRunner.init_user_data.get(item.getPmId())== null ? "未知名字" :  DataBaseStartUpRunner.init_user_data.get(item.getPmId()).getRealName());
//            item.setTranmgrName(DataBaseStartUpRunner.init_user_data.get(item.getPmId())== null ? "未知名字" : DataBaseStartUpRunner.init_user_data.get(item.getTranmgrId()).getRealName());
//            item.setTranmgrName(DataBaseStartUpRunner.init_user_data.get(item.getSourceLan())== null ? "未知语言对" : DataBaseStartUpRunner.init_language_data.get(item.getSourceLan()));
//            item.setTargetLanName(DataBaseStartUpRunner.init_user_data.get(item.getTargetLan())== null ? "未知语言对" :DataBaseStartUpRunner.init_language_data.get(item.getTargetLan()));
//            item.setDomainName(DataBaseStartUpRunner.init_domain_data.get(item.getDomain())== null ?  "未知领域": DataBaseStartUpRunner.init_domain_data.get(item.getDomain()));
//        }
//        PageInfo<PmProjectInfo> pa = new PageInfo<PmProjectInfo>(pmProjectInfos);
//        return ResultModel.SuccessForMsg("success", pa);
//        } catch (Exception e) {
//            logger.error("查询项目译员申请列表失败", e);
//            return ResultModel.FailWithNoData("查询项目译员申请列表失败");
//        }
//
//    }

    /**
     * 根据项目id查询申请记录
     */
    @GetMapping("/getTaskApplyById")
    @ApiOperation("根据项目id查询申请记录")
    public ResultModel getTaskApplyById(String projectId) {
        try {
            return ResultModel.Fail("success", IProjectService.getTaskApplyById(projectId));
        } catch (Exception e) {
            logger.error("查询项目申请记录失败", e);
            return ResultModel.FailWithNoData("查询项目申请记录失败");
        }
    }

    /**
     * create: 插入项目列表数据内部调用接口
     **/
    public void inseretProject(PmProjectInfo pmProjectInfo) {
        try {
            IProjectService.inseretProject(pmProjectInfo);
        } catch (Exception e) {
            logger.error("插入数据失败", e);
        }
    }

    /**
     * @param projectId 项目id
     * @param type      0 转线下 1 项目终止
     * create: 项目转线下, 或者项目终止
     **/
    @GetMapping("/SwitchWorkFlow")
    @ApiOperation("项目转线下,或者项目终止")
    public ResultModel SwitchWorkFlow(String projectId, int type) {
        try {
            // 判断是否是项目经理   (项目的项目经理才能进行此操作)
            PmProjectInfo porjectinfo = IProjectService.getPorjectById(projectId);
            //  是否已完成  (该项目已完成，不能再进行修改！)
            if(porjectinfo.getProjectType()=="4"){
                return ResultModel.FailWithNoData("该项目已完成不能操作!");
            }
            String projectType;
            if (type == 0) {
                projectType = "3";
                try {
                    // 是否已经转线下  (该项目已经转为线下！)
                    if (!porjectinfo.getIsOnline()) {
                        return ResultModel.FailWithNoData("该项目已经转为线下!");
                    }
                    //修改项目表把项目设置为线下，项目状态为待交付
                    IProjectService.updateProjectLine(projectId, projectType);
                    // 项目转线下修改任务表把项目相关任务全部设置为删除状态99（除开交付任务）
                    transTaskService.updateTaskStatusByPID(projectId);
                    //  查出当前项目下所有待翻译文件，通过文件id 修改文件流程表，只保留交付流程，删除除开交付以外的文件流程
                    List<PmFile> PmFileList = IProjectService.getProjectFileBypid(projectId, "01");
                    String flowID = "10";
                    for (PmFile item : PmFileList) {
                        iPMTaskSpiltService.deleteFileFlowByFID(item.getFileId(), flowID);
                    }

                } catch (Exception e) {
                    logger.error("项目转线下失败", e);
                    return ResultModel.FailWithNoData("项目转线下失败!");
                }
                return ResultModel.FailWithNoData("转线下成功!");
            }
            if (type == 1) {

                try {
                    //判断项目是否已终止（该项目已终止）
                    PmProjectInfo porjectInfo = IProjectService.getPorjectById(projectId);
                    if (porjectInfo.getProjectType() == "4" || porjectInfo.getProjectType() == "5") {
                        return ResultModel.FailWithNoData("该项目已终止！");
                    }
                    //修改项目表设置项目状态为项目终止
                    projectType = "5";
                    IProjectService.stopProject(projectId, projectType);
                    //项目终止把项目相关任务全部设置为终止
                    transTaskService.stopTaskByPId(projectId);
                } catch (Exception e) {
                    logger.error("项目终止失败", e);
                    return ResultModel.FailWithNoData("项目终止失败!");
                }
                return ResultModel.FailWithNoData("终止项目成功!");
            }
        }catch (Exception e){
            return ResultModel.FailWithNoData("操作异常！");
        }
        return ResultModel.FailWithNoData("操作异常！");
    }

    /**
     * @param projectId 项目id
     * @param fileId    文件id
     * create: 项目文件交付给ec，客户   ,逻辑需要重新走一遍
     **/
   // @PostMapping("/putFileToEC")
   // @ApiOperation("按项目或者文件交付")
    public void putFileToEC(String projectId, String fileId) {
        PmTaskInfo pmTaskInfo = new PmTaskInfo();
        String nowTime = DateUtils.getNowTime();
        if (!StringUtils.isEmpty(projectId)) {
            //根据项目id（查出所有交付任务状态为待交付任务）设置查询条件
            //TaskStatus 10进行中  12待提交给ec  23已交付
            pmTaskInfo.setTaskStatus("12");
            pmTaskInfo.setTaskType("10");
            pmTaskInfo.setProjectId("projectId");
            List<PmTaskInfo> pmTaskInfos = transTaskService.getTaskInfoList(pmTaskInfo);
          //  List<String> fileList = new ArrayList<String>();
            for (PmTaskInfo exam : pmTaskInfos) {
                //fileList.add(exam.getUploadFileId());
                //根据任务id把交付任务修改为已交付，并且更新交付时间
                transTaskService.updateTaskStatusByTaskID( exam.getTaskId() ,"23",nowTime );                     //根据原文件id，把文件下所有有效任务设置为已交付
                transTaskService.updateTaskStatusByFileID(exam.getFileId(),"23");
            }

        } else {
            //根据原文id，   找到交付任务，把交付任务设置为已交付，更新已完成时间
            pmTaskInfo.setTaskStatus("12");
            pmTaskInfo.setTaskType("10");
            pmTaskInfo.setFileId(fileId);
            List<PmTaskInfo> pmTaskInfos = transTaskService.getTaskInfoList(pmTaskInfo);
            for (PmTaskInfo exam : pmTaskInfos) {
                //根据任务id把交付任务修改为已交付，并且更新交付时间
                transTaskService.updateTaskStatusByTaskID( exam.getTaskId() ,"23",nowTime );
            }
            //根据原文件id，把文件下所有有效任务设置为已交付
            transTaskService.updateTaskStatusByFileID(fileId,"23");
        }

        //判断是否要修改项目表为已完成
    }

    /**
     * @param projectId 项目id
     * create: 项目详情—文件详情-原文
     **/
    @GetMapping("/getFileDetailsList")
    @ApiOperation("项目详情—文件详情-原文")
    public ResultModel getFileDetailsList(String projectId) {
        Map<PmFile, List<TaskFileListModel>> fileListMap = new HashMap<>();
        try {
            //获取项目下所有跟需要翻译的文件
            //select  * from  pm_file where projects_id = '' and is_del = 0 and file_type = '原文'
            List<PmFile> projectFileBypid = IProjectService.getProjectFileBypid(projectId, "01");
            for (PmFile exam : projectFileBypid) {
                //根据文件id，获取文件下所有有效任务
                List<TaskFileListModel> TaskFileList = transTaskService.getTaskinfoByFileid(exam.getFileId());
                fileListMap.put(exam, TaskFileList);
            }
            return ResultModel.SuccessForMsg("seucuess",fileListMap);
        } catch (Exception e) {
            logger.error("文件详情列表", e);
            return ResultModel.FailWithNoData("获取文件详情失败");
        }
    }

    /**
     * @param projectId 项目id
     * create: 项目详情—文件详情--获取参考文件
     **/
    @GetMapping("/getFileReferenceList")
    @ApiOperation("项目详情—文件详情--获取参考文件列表")
    public ResultModel getFileReferenceList(int pageNum ,int pageSize ,String projectId) {
        try {
            PageHelper.startPage(pageNum, pageSize);
            List<PmFile> fileReferenceList = IProjectService.getFileReferenceList(projectId);
            PageInfo<PmFile> page = new PageInfo<PmFile>(fileReferenceList);
            return ResultModel.SuccessForMsg("success",page);
        } catch (Exception e) {
            logger.error("获取参考文件失败", e);
            return ResultModel.FailWithNoData("获取参考文件列表失败");
        }
    }



    /**
     * @param fileidList 文件id
     * create: 项目详情—参考文件--删除参考文件
     **/
    @DeleteMapping("/deleteFileReferenceById")
    @ApiOperation("项目详情—参考文件--删除参考文件")
    public ResultModel deleteFileReferenceById(String[] fileidList) {
        try {
            IProjectService.deleteFileReferenceById(fileidList);
            return ResultModel.FailWithNoData("删除参考文件成功");
        } catch (Exception e) {
            logger.error("删除参考文件失败", e);
            return ResultModel.FailWithNoData("删除参考文件失败");
        }
    }

    /**
     项目列表--待处理--任务申请列表
     **/
    @GetMapping("/getTaskApplyList")
    @ApiOperation("项目列表--待处理--任务申请列表")
     public  ResultModel getTaskApplyList(int pageNum, int pageSize ,String taskType,String applyType ,String applySatus){
         try{
         //获取当前登录人id
         String pmID = "z01000";
         PageHelper.startPage(pageNum, pageSize);
        List<TaskApplyVo> TaskApplyLists = IProjectService.getTaskApplyList(pmID,taskType,applyType,applySatus);
         for (TaskApplyVo   item:  TaskApplyLists ) {
             item.setApplyName(DataBaseStartUpRunner.init_user_data.get(item.getApplyStaffNum())== null ? "未知名字" :  DataBaseStartUpRunner.init_user_data.get(item.getApplyStaffNum()).getRealName());
         }
         PageInfo<TaskApplyVo> pa = new PageInfo<TaskApplyVo>(TaskApplyLists);
         return ResultModel.SuccessForMsg("success", pa);
         } catch (Exception e) {
             logger.error("查询任务申请列表失败", e);
             return ResultModel.FailWithNoData("查询任务申请列表失败");
         }
     }


    /**
     * TODO
     * 审核
     *
     * @param applyRecord
     * @return
     */
    @GetMapping("/audit")
    @ApiOperation("审核")
    public ResultModel auditResult(PmTaskApplyRecord applyRecord) {
        PmTaskApplyRecord applyParam = new PmTaskApplyRecord();
        if (null == applyRecord) {
            return ResultModel.FailWithNoData("请传入参数");
        }
        if (StringUtils.isEmpty(applyRecord.getApplySatus())) {
            return ResultModel.FailWithNoData("请传入审核结果");
        }
        if (StringUtils.isEmpty(applyRecord.getAuditStaffNum())) {
            return ResultModel.FailWithNoData("请传入审核人");
        }
        if (null == applyRecord.getId()) {
            return ResultModel.FailWithNoData("请传入审核记录ID");
        }
        //组装参数
        applyParam.setId(applyRecord.getId());
        applyParam.setApplySatus(applyRecord.getApplySatus());
        applyParam.setAuditStaffNum(applyRecord.getAuditStaffNum());
        try {
            IProjectService.saveAuditResult(applyParam);
        } catch (Exception e) {
            return ResultModel.FailWithNoData(e.getMessage());
        }
        return ResultModel.Success();
    }

    /**
     * 提供给EC调用用于创建项目
     *
     * @return
     */
    @PostMapping("/createProject")
    @ApiOperation("创建项目")
    public ResultModel createProject(CreateProjectParams params) {
        int success;
        try {
            if (params.getFileList().size() == 0) {
                return ResultModel.FailWithNoData("请传入文件信息");
            }
           success = IProjectService.createProject(params);
        } catch (ParseException e) {
            logger.error("订单创建失败，订单号：{}", params.getProjectId());
            return ResultModel.FailWithNoData("订单创建失败");
        }
        if (success == 1) {
            return ResultModel.Success();
        } else {
            return ResultModel.FailWithNoData("新建订单失败");
        }
    }

//    @PostMapping("/getUserList")
//    public ResultModel getUserList(UserQueryVo userInfo, PageUtil pageUtil) {
////        logger.info("数据时：{}", userClient.getAllUserInfo());
//        Page<UserDOForPM> list = userClient.getAllUserInfo(null);
//        return ResultModel.Success();
//    }

    /**
     * 人员分配 - 直接分配到人
     *
     * @param taskId
     * @param requireTime
     * @param remark
     * @param staffNum
     * @return
     */
    @RequestMapping(value = "distributionTime", method = RequestMethod.POST)
    @ApiOperation("人员分配")
    public ResultModel distribution(String taskId, String requireTime, String remark,String staffNum) {
        Date date = new Date();
        if(StringUtils.isEmpty(taskId)){
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        if(StringUtils.isEmpty(requireTime)){
            return ResultModel.FailWithNoData("请填写要求完成时间");
        }
        if(StringUtils.isEmpty(staffNum)){
            return ResultModel.FailWithNoData("请传入经理工号");
        }

        PmTaskInfo taskInfo = transTaskService.getTaskInfoByTaskId(taskId);
        taskInfo.setRemark(remark);
        taskInfo.setRequireTime(requireTime);
        if(ParamStatic.TASK_DEFAULT_STAFFNUM.equals(taskInfo.getStaffNum())){
            taskInfo.setStaffNum(staffNum);
        }else {
            return ResultModel.FailWithNoData("该任务已分配有人");
        }
        if(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(taskInfo.getTaskType())){
            taskInfo.setTaskStatus(TaskInfoEnum.TASK_STATUS_ING.getValue());
        }

        //判断是否是协同
        if (StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(taskInfo.getTaskType())
                || StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(taskInfo.getTaskType())) {
            PmTaskInfoExample example = new PmTaskInfoExample();
            example.createCriteria().andFileIdEqualTo(taskInfo.getFileId())
                    .andProjectIdEqualTo(taskInfo.getProjectId())
                    .andTaskTypeEqualTo(taskInfo.getTaskType())
                    .andTaskStatusNotEqualTo(TaskInfoEnum.TASK_STATUS_DELETE.getValue());
            PmTaskInfo info_up = new PmTaskInfo();
            info_up.setWorkType(WorkTypeEnum.CO_WORK_TYPE.getValue());
            int res = taskInfoMapper.updateByExample(info_up, example);
            if (res > 0) {
                taskInfo.setWorkType(WorkTypeEnum.AL_WORK_TYPE.getValue());
            }
        }

        try {
            transTaskService.insertTaskInfo(taskInfo, null);
        } catch (Exception e) {
            logger.error("任务分配失败 - > {}", e);
            return ResultModel.FailWithNoData("任务分配失败");
        }
        return ResultModel.Success();
    }

    /**
     * 发送邀请 - 抢单池
     *
     * @param taskId
     * @param staffNums
     * @param noticeHour
     * @param pmStaffNum
     * @return
     */
    @RequestMapping(value = "sendInvite", method = RequestMethod.POST)
    @ApiOperation("发送邀请")
    public ResultModel sendInvite(String taskId, String requireTime, String remark, String[] staffNums, BigDecimal noticeHour, String pmStaffNum) {
        Date date = new Date();
        if(StringUtils.isEmpty(taskId)){
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        if(StringUtils.isEmpty(requireTime)){
            return ResultModel.FailWithNoData("请填写要求完成时间");
        }
        if(staffNums.length < 1){
            return ResultModel.FailWithNoData("请选择人员");
        }
        if(StringUtils.isEmpty(pmStaffNum)){
            return ResultModel.FailWithNoData("请传入经理工号");
        }

        PmTaskInfo taskInfo = transTaskService.getTaskInfoByTaskId(taskId);
        taskInfo.setRemark(remark);
        taskInfo.setRequireTime(requireTime);
        //
        PmGrabsheet grabsheet = new PmGrabsheet();
        grabsheet.setTaskId(taskInfo.getTaskId());
        grabsheet.setAllotType("02");//手动
        grabsheet.setStaffNum(Arrays.toString(staffNums));
        grabsheet.setTaskStatus(GrabsheetEnum.IS_RECEIVE_NO.getValue());
        grabsheet.setIsRemind(Boolean.parseBoolean(GrabsheetEnum.IS_REMIND_NO.getValue()));
        grabsheet.setNoticeHour(noticeHour);
        grabsheet.setChooseLv(null);
        grabsheet.setLastEditTime(taskInfo.getDistributionTime());
        grabsheet.setLastEditor(pmStaffNum);
        try {
            transTaskService.insertTaskInfo(taskInfo, grabsheet);
        } catch (Exception e) {
            logger.error("发送邀请失败 - > {}", e);
            return ResultModel.FailWithNoData("发送邀请失败");
        }
        return ResultModel.Success();
    }

    /**
     * @param projectId 项目id
     * @create: EC根据项目id，来下载译文
     **/
    @GetMapping("/getManuscriptToEc")
    @ApiOperation("EC根据项目id，来下载译文")
    public ResultModel getManuscriptToEc(String projectId){

     List<ManuscriptToEcVo>  manuscriptToEcVos = IProjectService.getManuscriptToEc(projectId);

        return ResultModel.SuccessForMsg("success",manuscriptToEcVos);
    }
    @ApiOperation("获取翻译要求与备注")
    @GetMapping("/getTranslationRequirements")
    public ResultModel getTranslationRequirements(String projectId){


        return null;
    }


}
