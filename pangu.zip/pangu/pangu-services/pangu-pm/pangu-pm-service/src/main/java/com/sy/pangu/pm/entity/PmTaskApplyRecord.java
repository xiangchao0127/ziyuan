package com.sy.pangu.pm.entity;

public class PmTaskApplyRecord {
    /**
     * 
     */
    private Integer id;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 申请人id
     */
    private String applyStaffNum;

    /**
     * 审核人id
     */
    private String auditStaffNum;

    /**
     * 申请时间
     */
    private String applyTime;

    /**
     * 最后更新时间
     */
    private String lastUpdateTime;

    /**
     * 申请状态
     */
    private String applySatus;

    /**
     * 申请类型
     */
    private String applyType;

    /**
     * 译员申请原因
     */
    private String reason;

    /**
     * 项目经理回复
     */
    private String replyReason;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId == null ? null : projectId.trim();
    }

    public String getApplyStaffNum() {
        return applyStaffNum;
    }

    public void setApplyStaffNum(String applyStaffNum) {
        this.applyStaffNum = applyStaffNum == null ? null : applyStaffNum.trim();
    }

    public String getAuditStaffNum() {
        return auditStaffNum;
    }

    public void setAuditStaffNum(String auditStaffNum) {
        this.auditStaffNum = auditStaffNum == null ? null : auditStaffNum.trim();
    }

    public String getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(String applyTime) {
        this.applyTime = applyTime == null ? null : applyTime.trim();
    }

    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime == null ? null : lastUpdateTime.trim();
    }

    public String getApplySatus() {
        return applySatus;
    }

    public void setApplySatus(String applySatus) {
        this.applySatus = applySatus == null ? null : applySatus.trim();
    }

    public String getApplyType() {
        return applyType;
    }

    public void setApplyType(String applyType) {
        this.applyType = applyType == null ? null : applyType.trim();
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason == null ? null : reason.trim();
    }

    public String getReplyReason() {
        return replyReason;
    }

    public void setReplyReason(String replyReason) {
        this.replyReason = replyReason == null ? null : replyReason.trim();
    }
}