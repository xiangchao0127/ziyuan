package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmTaskApplyRecord;
import com.sy.pangu.pm.entity.example.PmTaskApplyRecordExample;
import java.util.List;

import com.sy.pangu.pm.entity.vo.TaskApplyVo;
import org.apache.ibatis.annotations.Param;

public interface PmTaskApplyRecordMapper {
    long countByExample(PmTaskApplyRecordExample example);

    int deleteByExample(PmTaskApplyRecordExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmTaskApplyRecord record);

    int insertSelective(PmTaskApplyRecord record);

    List<PmTaskApplyRecord> selectByExample(PmTaskApplyRecordExample example);

    PmTaskApplyRecord selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmTaskApplyRecord record, @Param("example") PmTaskApplyRecordExample example);

    int updateByExample(@Param("record") PmTaskApplyRecord record, @Param("example") PmTaskApplyRecordExample example);

    int updateByPrimaryKeySelective(PmTaskApplyRecord record);

    int updateByPrimaryKey(PmTaskApplyRecord record);
    /**
     * 根据项目id查询申请记录
     */
    List<PmTaskApplyRecord> getTaskApplyById(String projectId);
    /*
     * @create:  获取任务申请列表
     **/
    List<TaskApplyVo> getTaskApplyList( @Param("pmID")String pmID,  @Param("taskType")String taskType,  @Param("applyType")String applyType,  @Param("applySatus")String applySatus);
}