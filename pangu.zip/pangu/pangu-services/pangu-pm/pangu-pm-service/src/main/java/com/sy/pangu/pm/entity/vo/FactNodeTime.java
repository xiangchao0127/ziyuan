package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/23 19:00
 */
@Data
public class FactNodeTime {
    private String nodeId;
    private String requestTime;
    private String overTime;
}
