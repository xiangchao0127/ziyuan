package com.sy.pangu.pm.entity.example;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PmGrabsheetExample {
    /**
     * pm_grabsheet
     */
    protected String orderByClause;

    /**
     * pm_grabsheet
     */
    protected boolean distinct;

    /**
     * pm_grabsheet
     */
    protected List<Criteria> oredCriteria;

    public PmGrabsheetExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_grabsheet null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("task_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("task_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("task_id =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("task_id <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("task_id >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_id >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("task_id <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("task_id <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("task_id like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("task_id not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("task_id in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("task_id not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("task_id between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("task_id not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andStaffNumIsNull() {
            addCriterion("staff_num is null");
            return (Criteria) this;
        }

        public Criteria andStaffNumIsNotNull() {
            addCriterion("staff_num is not null");
            return (Criteria) this;
        }

        public Criteria andStaffNumEqualTo(String value) {
            addCriterion("staff_num =", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotEqualTo(String value) {
            addCriterion("staff_num <>", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumGreaterThan(String value) {
            addCriterion("staff_num >", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumGreaterThanOrEqualTo(String value) {
            addCriterion("staff_num >=", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumLessThan(String value) {
            addCriterion("staff_num <", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumLessThanOrEqualTo(String value) {
            addCriterion("staff_num <=", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumLike(String value) {
            addCriterion("staff_num like", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotLike(String value) {
            addCriterion("staff_num not like", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumIn(List<String> values) {
            addCriterion("staff_num in", values, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotIn(List<String> values) {
            addCriterion("staff_num not in", values, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumBetween(String value1, String value2) {
            addCriterion("staff_num between", value1, value2, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotBetween(String value1, String value2) {
            addCriterion("staff_num not between", value1, value2, "staffNum");
            return (Criteria) this;
        }

        public Criteria andTaskStatusIsNull() {
            addCriterion("task_status is null");
            return (Criteria) this;
        }

        public Criteria andTaskStatusIsNotNull() {
            addCriterion("task_status is not null");
            return (Criteria) this;
        }

        public Criteria andTaskStatusEqualTo(String value) {
            addCriterion("task_status =", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotEqualTo(String value) {
            addCriterion("task_status <>", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusGreaterThan(String value) {
            addCriterion("task_status >", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusGreaterThanOrEqualTo(String value) {
            addCriterion("task_status >=", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusLessThan(String value) {
            addCriterion("task_status <", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusLessThanOrEqualTo(String value) {
            addCriterion("task_status <=", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusLike(String value) {
            addCriterion("task_status like", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotLike(String value) {
            addCriterion("task_status not like", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusIn(List<String> values) {
            addCriterion("task_status in", values, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotIn(List<String> values) {
            addCriterion("task_status not in", values, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusBetween(String value1, String value2) {
            addCriterion("task_status between", value1, value2, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotBetween(String value1, String value2) {
            addCriterion("task_status not between", value1, value2, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andIsRemindIsNull() {
            addCriterion("is_remind is null");
            return (Criteria) this;
        }

        public Criteria andIsRemindIsNotNull() {
            addCriterion("is_remind is not null");
            return (Criteria) this;
        }

        public Criteria andIsRemindEqualTo(Byte value) {
            addCriterion("is_remind =", value, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindNotEqualTo(Byte value) {
            addCriterion("is_remind <>", value, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindGreaterThan(Byte value) {
            addCriterion("is_remind >", value, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindGreaterThanOrEqualTo(Byte value) {
            addCriterion("is_remind >=", value, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindLessThan(Byte value) {
            addCriterion("is_remind <", value, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindLessThanOrEqualTo(Byte value) {
            addCriterion("is_remind <=", value, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindIn(List<Byte> values) {
            addCriterion("is_remind in", values, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindNotIn(List<Byte> values) {
            addCriterion("is_remind not in", values, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindBetween(Byte value1, Byte value2) {
            addCriterion("is_remind between", value1, value2, "isRemind");
            return (Criteria) this;
        }

        public Criteria andIsRemindNotBetween(Byte value1, Byte value2) {
            addCriterion("is_remind not between", value1, value2, "isRemind");
            return (Criteria) this;
        }

        public Criteria andRemindTimeIsNull() {
            addCriterion("remind_time is null");
            return (Criteria) this;
        }

        public Criteria andRemindTimeIsNotNull() {
            addCriterion("remind_time is not null");
            return (Criteria) this;
        }

        public Criteria andRemindTimeEqualTo(String value) {
            addCriterion("remind_time =", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeNotEqualTo(String value) {
            addCriterion("remind_time <>", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeGreaterThan(String value) {
            addCriterion("remind_time >", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeGreaterThanOrEqualTo(String value) {
            addCriterion("remind_time >=", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeLessThan(String value) {
            addCriterion("remind_time <", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeLessThanOrEqualTo(String value) {
            addCriterion("remind_time <=", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeLike(String value) {
            addCriterion("remind_time like", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeNotLike(String value) {
            addCriterion("remind_time not like", value, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeIn(List<String> values) {
            addCriterion("remind_time in", values, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeNotIn(List<String> values) {
            addCriterion("remind_time not in", values, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeBetween(String value1, String value2) {
            addCriterion("remind_time between", value1, value2, "remindTime");
            return (Criteria) this;
        }

        public Criteria andRemindTimeNotBetween(String value1, String value2) {
            addCriterion("remind_time not between", value1, value2, "remindTime");
            return (Criteria) this;
        }

        public Criteria andNoticeHourIsNull() {
            addCriterion("notice_hour is null");
            return (Criteria) this;
        }

        public Criteria andNoticeHourIsNotNull() {
            addCriterion("notice_hour is not null");
            return (Criteria) this;
        }

        public Criteria andNoticeHourEqualTo(BigDecimal value) {
            addCriterion("notice_hour =", value, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourNotEqualTo(BigDecimal value) {
            addCriterion("notice_hour <>", value, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourGreaterThan(BigDecimal value) {
            addCriterion("notice_hour >", value, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("notice_hour >=", value, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourLessThan(BigDecimal value) {
            addCriterion("notice_hour <", value, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourLessThanOrEqualTo(BigDecimal value) {
            addCriterion("notice_hour <=", value, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourIn(List<BigDecimal> values) {
            addCriterion("notice_hour in", values, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourNotIn(List<BigDecimal> values) {
            addCriterion("notice_hour not in", values, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("notice_hour between", value1, value2, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andNoticeHourNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("notice_hour not between", value1, value2, "noticeHour");
            return (Criteria) this;
        }

        public Criteria andAllotTypeIsNull() {
            addCriterion("allot_type is null");
            return (Criteria) this;
        }

        public Criteria andAllotTypeIsNotNull() {
            addCriterion("allot_type is not null");
            return (Criteria) this;
        }

        public Criteria andAllotTypeEqualTo(String value) {
            addCriterion("allot_type =", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeNotEqualTo(String value) {
            addCriterion("allot_type <>", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeGreaterThan(String value) {
            addCriterion("allot_type >", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeGreaterThanOrEqualTo(String value) {
            addCriterion("allot_type >=", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeLessThan(String value) {
            addCriterion("allot_type <", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeLessThanOrEqualTo(String value) {
            addCriterion("allot_type <=", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeLike(String value) {
            addCriterion("allot_type like", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeNotLike(String value) {
            addCriterion("allot_type not like", value, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeIn(List<String> values) {
            addCriterion("allot_type in", values, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeNotIn(List<String> values) {
            addCriterion("allot_type not in", values, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeBetween(String value1, String value2) {
            addCriterion("allot_type between", value1, value2, "allotType");
            return (Criteria) this;
        }

        public Criteria andAllotTypeNotBetween(String value1, String value2) {
            addCriterion("allot_type not between", value1, value2, "allotType");
            return (Criteria) this;
        }

        public Criteria andChooseLvIsNull() {
            addCriterion("choose_lv is null");
            return (Criteria) this;
        }

        public Criteria andChooseLvIsNotNull() {
            addCriterion("choose_lv is not null");
            return (Criteria) this;
        }

        public Criteria andChooseLvEqualTo(String value) {
            addCriterion("choose_lv =", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvNotEqualTo(String value) {
            addCriterion("choose_lv <>", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvGreaterThan(String value) {
            addCriterion("choose_lv >", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvGreaterThanOrEqualTo(String value) {
            addCriterion("choose_lv >=", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvLessThan(String value) {
            addCriterion("choose_lv <", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvLessThanOrEqualTo(String value) {
            addCriterion("choose_lv <=", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvLike(String value) {
            addCriterion("choose_lv like", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvNotLike(String value) {
            addCriterion("choose_lv not like", value, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvIn(List<String> values) {
            addCriterion("choose_lv in", values, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvNotIn(List<String> values) {
            addCriterion("choose_lv not in", values, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvBetween(String value1, String value2) {
            addCriterion("choose_lv between", value1, value2, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andChooseLvNotBetween(String value1, String value2) {
            addCriterion("choose_lv not between", value1, value2, "chooseLv");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeIsNull() {
            addCriterion("last_edit_time is null");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeIsNotNull() {
            addCriterion("last_edit_time is not null");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeEqualTo(String value) {
            addCriterion("last_edit_time =", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotEqualTo(String value) {
            addCriterion("last_edit_time <>", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeGreaterThan(String value) {
            addCriterion("last_edit_time >", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeGreaterThanOrEqualTo(String value) {
            addCriterion("last_edit_time >=", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeLessThan(String value) {
            addCriterion("last_edit_time <", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeLessThanOrEqualTo(String value) {
            addCriterion("last_edit_time <=", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeLike(String value) {
            addCriterion("last_edit_time like", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotLike(String value) {
            addCriterion("last_edit_time not like", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeIn(List<String> values) {
            addCriterion("last_edit_time in", values, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotIn(List<String> values) {
            addCriterion("last_edit_time not in", values, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeBetween(String value1, String value2) {
            addCriterion("last_edit_time between", value1, value2, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotBetween(String value1, String value2) {
            addCriterion("last_edit_time not between", value1, value2, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditorIsNull() {
            addCriterion("last_editor is null");
            return (Criteria) this;
        }

        public Criteria andLastEditorIsNotNull() {
            addCriterion("last_editor is not null");
            return (Criteria) this;
        }

        public Criteria andLastEditorEqualTo(String value) {
            addCriterion("last_editor =", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotEqualTo(String value) {
            addCriterion("last_editor <>", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorGreaterThan(String value) {
            addCriterion("last_editor >", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorGreaterThanOrEqualTo(String value) {
            addCriterion("last_editor >=", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorLessThan(String value) {
            addCriterion("last_editor <", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorLessThanOrEqualTo(String value) {
            addCriterion("last_editor <=", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorLike(String value) {
            addCriterion("last_editor like", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotLike(String value) {
            addCriterion("last_editor not like", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorIn(List<String> values) {
            addCriterion("last_editor in", values, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotIn(List<String> values) {
            addCriterion("last_editor not in", values, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorBetween(String value1, String value2) {
            addCriterion("last_editor between", value1, value2, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotBetween(String value1, String value2) {
            addCriterion("last_editor not between", value1, value2, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andDatachar1IsNull() {
            addCriterion("datachar1 is null");
            return (Criteria) this;
        }

        public Criteria andDatachar1IsNotNull() {
            addCriterion("datachar1 is not null");
            return (Criteria) this;
        }

        public Criteria andDatachar1EqualTo(String value) {
            addCriterion("datachar1 =", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotEqualTo(String value) {
            addCriterion("datachar1 <>", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1GreaterThan(String value) {
            addCriterion("datachar1 >", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1GreaterThanOrEqualTo(String value) {
            addCriterion("datachar1 >=", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1LessThan(String value) {
            addCriterion("datachar1 <", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1LessThanOrEqualTo(String value) {
            addCriterion("datachar1 <=", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1Like(String value) {
            addCriterion("datachar1 like", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotLike(String value) {
            addCriterion("datachar1 not like", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1In(List<String> values) {
            addCriterion("datachar1 in", values, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotIn(List<String> values) {
            addCriterion("datachar1 not in", values, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1Between(String value1, String value2) {
            addCriterion("datachar1 between", value1, value2, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotBetween(String value1, String value2) {
            addCriterion("datachar1 not between", value1, value2, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar2IsNull() {
            addCriterion("datachar2 is null");
            return (Criteria) this;
        }

        public Criteria andDatachar2IsNotNull() {
            addCriterion("datachar2 is not null");
            return (Criteria) this;
        }

        public Criteria andDatachar2EqualTo(String value) {
            addCriterion("datachar2 =", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotEqualTo(String value) {
            addCriterion("datachar2 <>", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2GreaterThan(String value) {
            addCriterion("datachar2 >", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2GreaterThanOrEqualTo(String value) {
            addCriterion("datachar2 >=", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2LessThan(String value) {
            addCriterion("datachar2 <", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2LessThanOrEqualTo(String value) {
            addCriterion("datachar2 <=", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2Like(String value) {
            addCriterion("datachar2 like", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotLike(String value) {
            addCriterion("datachar2 not like", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2In(List<String> values) {
            addCriterion("datachar2 in", values, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotIn(List<String> values) {
            addCriterion("datachar2 not in", values, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2Between(String value1, String value2) {
            addCriterion("datachar2 between", value1, value2, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotBetween(String value1, String value2) {
            addCriterion("datachar2 not between", value1, value2, "datachar2");
            return (Criteria) this;
        }
    }

    /**
     * pm_grabsheet
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_grabsheet null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}