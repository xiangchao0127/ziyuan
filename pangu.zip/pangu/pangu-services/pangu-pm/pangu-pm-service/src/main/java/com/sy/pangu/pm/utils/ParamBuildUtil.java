package com.sy.pangu.pm.utils;

import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * @author ：jzj
 * date ：Created in 2019/4/12 13:40
 */
public class ParamBuildUtil {

    private static final Logger logger = (Logger) LoggerFactory.getLogger(ParamBuildUtil.class);

    /**
     * 组建参数集合
     * 注意：对象间参数不要有重复属性，重复的会覆盖
     *
     * @param param
     * @param objs
     */
    public static void ParamBuild(Map param, Object... objs) {

        if (objs.length < 1) {
            return;
        }

        for (Object e : objs) {
            getParamByObj(param, e);
        }
    }

    public static void getParamByObj(Map param, Object e) {
        Class cla = e.getClass();
        Field[] fields = cla.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            Field f = fields[i];
            //访问private属性
            f.setAccessible(true);
            try {
                if (null != f.get(e) ) {
                    if(f.getType() == String.class && "".equals(f.get(e))) continue;

                    param.put(f.getName(), f.get(e));
                }
            } catch (IllegalAccessException ex) {
                logger.error("遍历对象属性错误 >>>>>>>>>> {}", e);
            }

        }

    }
}
