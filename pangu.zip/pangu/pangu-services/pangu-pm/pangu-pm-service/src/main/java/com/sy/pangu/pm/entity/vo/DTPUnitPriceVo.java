package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/25 16:43
 */
@Data
public class DTPUnitPriceVo {
    private String unit;
    private String handleType;
    private String dataChar1;
}
