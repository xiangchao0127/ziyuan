package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/11 17:33
 */
@Data
public class FlowQueryVo {

    /**
     * 订单类型:文档/证件/图书
     */
    private String orderType;

    /**
     * 订单等级
     */
    private String qualityLvl;

    /**
     *客户等级
     */
    private String cusType;

    /**
     * 流程路径
     */
    private String workFlow;

    private String defaultCat;
}
