package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

import java.io.Serializable;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 13:56
 */
@Data
public class PrePackageRecieve implements Serializable {
    /**
     * 项目id
     */
    private String fileId;
    private String fileName;
    /**
     * 可领取的全部字数
     */
    private int availableWords;
    /**
     * 包id
     */
    private String defaultPackId;
    /**
     *
     */
    private int allWordsCount;
}
