package com.sy.pangu.pm.entity.example;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SysUnitPriceTransExample {
    /**
     * sys_unit_price_trans
     */
    protected String orderByClause;

    /**
     * sys_unit_price_trans
     */
    protected boolean distinct;

    /**
     * sys_unit_price_trans
     */
    protected List<Criteria> oredCriteria;

    public SysUnitPriceTransExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * sys_unit_price_trans null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andStaffTypeIsNull() {
            addCriterion("staff_type is null");
            return (Criteria) this;
        }

        public Criteria andStaffTypeIsNotNull() {
            addCriterion("staff_type is not null");
            return (Criteria) this;
        }

        public Criteria andStaffTypeEqualTo(String value) {
            addCriterion("staff_type =", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeNotEqualTo(String value) {
            addCriterion("staff_type <>", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeGreaterThan(String value) {
            addCriterion("staff_type >", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeGreaterThanOrEqualTo(String value) {
            addCriterion("staff_type >=", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeLessThan(String value) {
            addCriterion("staff_type <", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeLessThanOrEqualTo(String value) {
            addCriterion("staff_type <=", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeLike(String value) {
            addCriterion("staff_type like", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeNotLike(String value) {
            addCriterion("staff_type not like", value, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeIn(List<String> values) {
            addCriterion("staff_type in", values, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeNotIn(List<String> values) {
            addCriterion("staff_type not in", values, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeBetween(String value1, String value2) {
            addCriterion("staff_type between", value1, value2, "staffType");
            return (Criteria) this;
        }

        public Criteria andStaffTypeNotBetween(String value1, String value2) {
            addCriterion("staff_type not between", value1, value2, "staffType");
            return (Criteria) this;
        }

        public Criteria andLevelIsNull() {
            addCriterion("level is null");
            return (Criteria) this;
        }

        public Criteria andLevelIsNotNull() {
            addCriterion("level is not null");
            return (Criteria) this;
        }

        public Criteria andLevelEqualTo(String value) {
            addCriterion("level =", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotEqualTo(String value) {
            addCriterion("level <>", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelGreaterThan(String value) {
            addCriterion("level >", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelGreaterThanOrEqualTo(String value) {
            addCriterion("level >=", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelLessThan(String value) {
            addCriterion("level <", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelLessThanOrEqualTo(String value) {
            addCriterion("level <=", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelLike(String value) {
            addCriterion("level like", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotLike(String value) {
            addCriterion("level not like", value, "level");
            return (Criteria) this;
        }

        public Criteria andLevelIn(List<String> values) {
            addCriterion("level in", values, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotIn(List<String> values) {
            addCriterion("level not in", values, "level");
            return (Criteria) this;
        }

        public Criteria andLevelBetween(String value1, String value2) {
            addCriterion("level between", value1, value2, "level");
            return (Criteria) this;
        }

        public Criteria andLevelNotBetween(String value1, String value2) {
            addCriterion("level not between", value1, value2, "level");
            return (Criteria) this;
        }

        public Criteria andSourceLanIsNull() {
            addCriterion("source_lan is null");
            return (Criteria) this;
        }

        public Criteria andSourceLanIsNotNull() {
            addCriterion("source_lan is not null");
            return (Criteria) this;
        }

        public Criteria andSourceLanEqualTo(String value) {
            addCriterion("source_lan =", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanNotEqualTo(String value) {
            addCriterion("source_lan <>", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanGreaterThan(String value) {
            addCriterion("source_lan >", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanGreaterThanOrEqualTo(String value) {
            addCriterion("source_lan >=", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanLessThan(String value) {
            addCriterion("source_lan <", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanLessThanOrEqualTo(String value) {
            addCriterion("source_lan <=", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanLike(String value) {
            addCriterion("source_lan like", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanNotLike(String value) {
            addCriterion("source_lan not like", value, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanIn(List<String> values) {
            addCriterion("source_lan in", values, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanNotIn(List<String> values) {
            addCriterion("source_lan not in", values, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanBetween(String value1, String value2) {
            addCriterion("source_lan between", value1, value2, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andSourceLanNotBetween(String value1, String value2) {
            addCriterion("source_lan not between", value1, value2, "sourceLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanIsNull() {
            addCriterion("target_lan is null");
            return (Criteria) this;
        }

        public Criteria andTargetLanIsNotNull() {
            addCriterion("target_lan is not null");
            return (Criteria) this;
        }

        public Criteria andTargetLanEqualTo(String value) {
            addCriterion("target_lan =", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanNotEqualTo(String value) {
            addCriterion("target_lan <>", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanGreaterThan(String value) {
            addCriterion("target_lan >", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanGreaterThanOrEqualTo(String value) {
            addCriterion("target_lan >=", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanLessThan(String value) {
            addCriterion("target_lan <", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanLessThanOrEqualTo(String value) {
            addCriterion("target_lan <=", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanLike(String value) {
            addCriterion("target_lan like", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanNotLike(String value) {
            addCriterion("target_lan not like", value, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanIn(List<String> values) {
            addCriterion("target_lan in", values, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanNotIn(List<String> values) {
            addCriterion("target_lan not in", values, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanBetween(String value1, String value2) {
            addCriterion("target_lan between", value1, value2, "targetLan");
            return (Criteria) this;
        }

        public Criteria andTargetLanNotBetween(String value1, String value2) {
            addCriterion("target_lan not between", value1, value2, "targetLan");
            return (Criteria) this;
        }

        public Criteria andUnitPriceIsNull() {
            addCriterion("unit_price is null");
            return (Criteria) this;
        }

        public Criteria andUnitPriceIsNotNull() {
            addCriterion("unit_price is not null");
            return (Criteria) this;
        }

        public Criteria andUnitPriceEqualTo(BigDecimal value) {
            addCriterion("unit_price =", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotEqualTo(BigDecimal value) {
            addCriterion("unit_price <>", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceGreaterThan(BigDecimal value) {
            addCriterion("unit_price >", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("unit_price >=", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceLessThan(BigDecimal value) {
            addCriterion("unit_price <", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("unit_price <=", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceIn(List<BigDecimal> values) {
            addCriterion("unit_price in", values, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotIn(List<BigDecimal> values) {
            addCriterion("unit_price not in", values, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("unit_price between", value1, value2, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("unit_price not between", value1, value2, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNull() {
            addCriterion("task_type is null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNotNull() {
            addCriterion("task_type is not null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeEqualTo(String value) {
            addCriterion("task_type =", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotEqualTo(String value) {
            addCriterion("task_type <>", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThan(String value) {
            addCriterion("task_type >", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThanOrEqualTo(String value) {
            addCriterion("task_type >=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThan(String value) {
            addCriterion("task_type <", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThanOrEqualTo(String value) {
            addCriterion("task_type <=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLike(String value) {
            addCriterion("task_type like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotLike(String value) {
            addCriterion("task_type not like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIn(List<String> values) {
            addCriterion("task_type in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotIn(List<String> values) {
            addCriterion("task_type not in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeBetween(String value1, String value2) {
            addCriterion("task_type between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotBetween(String value1, String value2) {
            addCriterion("task_type not between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andDataChar1IsNull() {
            addCriterion("data_char1 is null");
            return (Criteria) this;
        }

        public Criteria andDataChar1IsNotNull() {
            addCriterion("data_char1 is not null");
            return (Criteria) this;
        }

        public Criteria andDataChar1EqualTo(String value) {
            addCriterion("data_char1 =", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1NotEqualTo(String value) {
            addCriterion("data_char1 <>", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1GreaterThan(String value) {
            addCriterion("data_char1 >", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1GreaterThanOrEqualTo(String value) {
            addCriterion("data_char1 >=", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1LessThan(String value) {
            addCriterion("data_char1 <", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1LessThanOrEqualTo(String value) {
            addCriterion("data_char1 <=", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1Like(String value) {
            addCriterion("data_char1 like", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1NotLike(String value) {
            addCriterion("data_char1 not like", value, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1In(List<String> values) {
            addCriterion("data_char1 in", values, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1NotIn(List<String> values) {
            addCriterion("data_char1 not in", values, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1Between(String value1, String value2) {
            addCriterion("data_char1 between", value1, value2, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar1NotBetween(String value1, String value2) {
            addCriterion("data_char1 not between", value1, value2, "dataChar1");
            return (Criteria) this;
        }

        public Criteria andDataChar2IsNull() {
            addCriterion("data_char2 is null");
            return (Criteria) this;
        }

        public Criteria andDataChar2IsNotNull() {
            addCriterion("data_char2 is not null");
            return (Criteria) this;
        }

        public Criteria andDataChar2EqualTo(String value) {
            addCriterion("data_char2 =", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2NotEqualTo(String value) {
            addCriterion("data_char2 <>", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2GreaterThan(String value) {
            addCriterion("data_char2 >", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2GreaterThanOrEqualTo(String value) {
            addCriterion("data_char2 >=", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2LessThan(String value) {
            addCriterion("data_char2 <", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2LessThanOrEqualTo(String value) {
            addCriterion("data_char2 <=", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2Like(String value) {
            addCriterion("data_char2 like", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2NotLike(String value) {
            addCriterion("data_char2 not like", value, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2In(List<String> values) {
            addCriterion("data_char2 in", values, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2NotIn(List<String> values) {
            addCriterion("data_char2 not in", values, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2Between(String value1, String value2) {
            addCriterion("data_char2 between", value1, value2, "dataChar2");
            return (Criteria) this;
        }

        public Criteria andDataChar2NotBetween(String value1, String value2) {
            addCriterion("data_char2 not between", value1, value2, "dataChar2");
            return (Criteria) this;
        }
    }

    /**
     * sys_unit_price_trans
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * sys_unit_price_trans null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}