package com.sy.pangu.pm.service.impl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.PmTaskWorkload;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.entity.example.PmTaskWorkloadExample;
import com.sy.pangu.pm.entity.vo.WorkLoadQueryDto;
import com.sy.pangu.pm.entity.vo.WorkLoadVo;
import com.sy.pangu.pm.mapper.*;
import com.sy.pangu.pm.service.WorkLoadService;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import com.sy.pangu.pm.utils.enumpackage.SysEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import com.sy.pangu.pm.utils.enumpackage.WorkTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/5 16:40
 */
@Service
public class WorkLoadServiceImpl implements WorkLoadService {

    protected static final Logger logger = LoggerFactory.getLogger(WorkLoadServiceImpl.class);

    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
    @Autowired
    private PmTaskWorkloadMapper taskWorkloadMapper;
    @Autowired
    private PmTaskDataMapper taskDataMapper;
    @Autowired
    private SysUnitPriceDtpMapper unitPriceDtpMapper;
    @Autowired
    private PmProjectInfoMapper projectInfoMapper;
    @Autowired
    private TransTaskServiceImpl transTaskService;

    @Override
    public String totalStatistics(String projectId) {
        if (StringUtils.isEmpty(projectId)) {
            return "请传入项目ID";
        }
        PmTaskInfoExample taskExample = new PmTaskInfoExample();
        taskExample.createCriteria()
                .andProjectIdEqualTo(projectId)
                .andTaskStatusNotEqualTo(TaskInfoEnum.TASK_STATUS_DELETE.getValue());

        List<PmTaskInfo> taskInfoList = taskInfoMapper.selectByExample(taskExample);
        double dtpPrice = 0d;
        double transPrice = 0d;
        double qaPrice = 0d;
        double proofPrice = 0d;
        double typeSetPrice = 0d;
        for (PmTaskInfo taskInfo : taskInfoList) {
            PmTaskWorkloadExample taskWorkloadExample = new PmTaskWorkloadExample();
            taskWorkloadExample.createCriteria()
                    .andTaskIdEqualTo(taskInfo.getTaskId());
            for (PmTaskWorkload workload : taskWorkloadMapper.selectByExample(taskWorkloadExample)) {
                String calcLoad = workload.getFinalWorkload() == null ? workload.getActualWorkload() == null? workload.getEstimateWorkload() : workload.getActualWorkload() : workload.getFinalWorkload();
                if (StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(workload.getWorkType())
                        || StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(workload.getWorkType())) {
                    String dtpType = workload.getDtpType();
                    String unitPrice = unitPriceDtpMapper.selectUnitByType(dtpType);
                    if (StringUtils.isEmpty(unitPrice)) {
                        logger.error(dtpType + "类型无单价设置");
                    } else {
                        dtpPrice += Double.parseDouble(unitPrice) * Double.parseDouble(calcLoad);
                    }
                }
                if (StaffLvlEnum.TASK_TYPE_TRANS.getValue().equals(workload.getWorkType())) {
                    transPrice += Double.parseDouble(workload.getUnitPrice()) * Double.parseDouble(calcLoad) * Double.parseDouble(workload.getRatio());
                }
                if (StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue().equals(workload.getWorkType())) {
                    proofPrice += Double.parseDouble(workload.getUnitPrice()) * Double.parseDouble(calcLoad) * Double.parseDouble(workload.getRatio());
                }
                if (StaffLvlEnum.TASK_TYPE_QA.getValue().equals(workload.getWorkType())) {
                    qaPrice += Double.parseDouble(workload.getUnitPrice()) * Double.parseDouble(calcLoad) * Double.parseDouble(workload.getRatio());
                }
                if (StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue().equals(workload.getWorkType())) {
                    typeSetPrice += Double.parseDouble(workload.getUnitPrice()) * Double.parseDouble(calcLoad) * Double.parseDouble(workload.getRatio());
                }
            }
        }
        double total = dtpPrice + transPrice + qaPrice + proofPrice + typeSetPrice;
        String msgFormat = "翻译金额:{0}  审校金额：{1}  QA金额：{2}  排版金额：{3}  dtp金额：{4}  总计：{5}\n" +
                     "项目总字数：{6}  绩效字数：{7}";
        Map<String, Integer> wordMap = taskDataMapper.selectTotalWord(projectId);
        return MessageFormat.format(msgFormat, new Object[]{transPrice, proofPrice, qaPrice, typeSetPrice, dtpPrice, total, wordMap.get("acutalWord"), wordMap.get("translationWord")});
    }

    @Override
    public List<WorkLoadVo> workLoadList(String projectId) {
        String[] dtpTypeArray = {StaffLvlEnum.TASK_TYPE_BF_DTP.getValue(),StaffLvlEnum.TASK_TYPE_AF_DTP.getValue(),StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue()};
        List<WorkLoadVo> dtpWorkLoad = taskDataMapper.selectDTPLoadInfo(projectId, TaskInfoEnum.TASK_STATUS_DELETE.getValue(), dtpTypeArray);
        List<WorkLoadVo> transWorkLoad = taskDataMapper.selectTransLoadInfo(projectId, TaskInfoEnum.TASK_STATUS_DELETE.getValue(), dtpTypeArray);
        boolean success = transWorkLoad.addAll(dtpWorkLoad);
        if (success) {
            return transWorkLoad;
        } else {
            throw new RuntimeException("合并工作量异常");
        }
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor =
            Exception.class)
    public int addWorkLoad(WorkLoadQueryDto workLoadQueryDto) throws ParseException {
        PmTaskInfoExample taskExample = new PmTaskInfoExample();
        taskExample.createCriteria()
                .andProjectIdEqualTo(workLoadQueryDto.getProjectId());
        List<PmTaskInfo> taskInfos = taskInfoMapper.selectByExample(taskExample);
        //为其创建一个空任务做记录
        PmTaskInfo taskInfo = new PmTaskInfo();
        taskInfo.setTaskId(transTaskService.getTaskId());
        taskInfo.setTaskType(workLoadQueryDto.getTaskType());
        taskInfo.setStartTime(workLoadQueryDto.getStartTime());
        taskInfo.setRequireTime(workLoadQueryDto.getRequestComTime());
        taskInfo.setRealCompletTime(workLoadQueryDto.getRealComTime());
        taskInfo.setStaffNum(workLoadQueryDto.getUserCode());
        taskInfo.setProjectId(workLoadQueryDto.getProjectId());
        taskInfo.setTaskName(StaffLvlEnum.getDescByValue(workLoadQueryDto.getTaskType()));
        taskInfo.setWorkType(WorkTypeEnum.AL_WORK_TYPE.getValue());
        int success = taskInfoMapper.insertSelective(taskInfo);
        if (success > 0) {
            insertWorkLoad("taskId", workLoadQueryDto.getTaskType(), workLoadQueryDto.getRatio(), workLoadQueryDto.getWorkLoad(), "");
        }
        return 0;
    }

    /**
     *
     * @param taskId 任务id
     * @param workType 工作类型
     * @param ratio 绩效值，不传默认为100%
     * @param estimateWorkLoad 工作量
     * @param unitPrice 对应语言对和等级的单价，dtp、排版为空字符串
     */
    @Override
    public void insertWorkLoad (String taskId, String workType, String ratio, String estimateWorkLoad, String unitPrice) throws ParseException {

        if (workType.equals(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue())
                || workType.equals(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue())
                || workType.equals(StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue())) {
            List<PmTaskWorkload> workloads = new ArrayList<>();
            JSONObject jsonObject = JSON.parseObject(estimateWorkLoad);
            for (String key : jsonObject.keySet()) {
                String value = jsonObject.getString(key);
                PmTaskWorkload workload = new PmTaskWorkload();
                workload.setTaskId(taskId);
                workload.setWorkType(workType);
                workload.setEstimateWorkload(value);
                workload.setDtpType(key);
                workload.setRatio(ratio == ""? "100%" : ratio);
                workload.setAddTime(DateUtils.getNowTime());
                workload.setFinalModifierid("currentUser");
                workloads.add(workload);
            }
            taskWorkloadMapper.insertBatch(workloads);
        } else {
            PmTaskWorkload taskLoad = new PmTaskWorkload();
            taskLoad.setTaskId(taskId);
            taskLoad.setAddTime(DateUtils.getNowTime());
            taskLoad.setFinalModifierid("currentUser");
            taskLoad.setRatio(ratio == ""? "100%" : ratio);
            taskLoad.setUnitPrice(unitPrice);
            taskLoad.setEstimateWorkload(estimateWorkLoad);
            taskWorkloadMapper.insertSelective(taskLoad);
        }
    }

    @Override
    public int updateWorkLoad(PmTaskWorkload workload) {
        return taskWorkloadMapper.updateByPrimaryKey(workload);
    }


}
