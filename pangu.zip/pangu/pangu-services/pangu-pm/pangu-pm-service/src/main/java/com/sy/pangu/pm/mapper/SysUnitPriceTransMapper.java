package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.SysUnitPriceTrans;
import com.sy.pangu.pm.entity.example.SysUnitPriceTransExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysUnitPriceTransMapper {
    long countByExample(SysUnitPriceTransExample example);

    int deleteByExample(SysUnitPriceTransExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysUnitPriceTrans record);

    int insertSelective(SysUnitPriceTrans record);

    List<SysUnitPriceTrans> selectByExample(SysUnitPriceTransExample example);

    SysUnitPriceTrans selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysUnitPriceTrans record, @Param("example") SysUnitPriceTransExample example);

    int updateByExample(@Param("record") SysUnitPriceTrans record, @Param("example") SysUnitPriceTransExample example);

    int updateByPrimaryKeySelective(SysUnitPriceTrans record);

    int updateByPrimaryKey(SysUnitPriceTrans record);
}