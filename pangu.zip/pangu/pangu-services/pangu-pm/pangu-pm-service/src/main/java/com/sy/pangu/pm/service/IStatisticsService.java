package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.vo.UserTaskStatisticsVo;

/**
 * @author ：jzj
 * date ：Created in 2019/5/5 9:54
 */
public interface IStatisticsService {
    /**
     * 统计人员 任务信息
     * @param vo
     */
    void getUserTaskStatisticsInfo(UserTaskStatisticsVo vo) throws Exception;
}
