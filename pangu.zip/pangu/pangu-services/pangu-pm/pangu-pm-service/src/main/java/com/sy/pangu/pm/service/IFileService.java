package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmFile;
import org.springframework.web.multipart.MultipartFile;

public interface IFileService {
    /**
     * 根据任务id  获取上传文件信息
     * @param taskId
     * @return
     */
    public PmFile getFileInfoOfUpLoad(String taskId) throws RuntimeException;

    /**
     * 任务文件上传
     * @param taskId
     * @param fileType
     * @param multipartFile
     * @param path
     * @throws Exception
     */
    public void uploadFile(String taskId, String fileType, MultipartFile multipartFile, String path) throws Exception;

    /**根据文件id获取文件信息
     * @param fileId
     * @return
     */
    public PmFile getFileByFileId(String fileId);
}
