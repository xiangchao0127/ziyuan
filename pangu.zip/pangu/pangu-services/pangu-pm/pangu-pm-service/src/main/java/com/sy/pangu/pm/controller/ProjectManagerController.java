package com.sy.pangu.pm.controller;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.SysMatchingPm;
import com.sy.pangu.pm.entity.SysTransmanagerInfo;
import com.sy.pangu.pm.entity.vo.PmQueryVo;
import com.sy.pangu.pm.entity.vo.PmResponseVo;
import com.sy.pangu.pm.entity.vo.TransManagerVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.impl.ProjectManagerServiceImpl;
import com.sy.pangu.pm.utils.PageUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.*;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/24 14:21
 */
@RestController
@RequestMapping("/projectManager")
@Api(tags = "pm/众包/翻译经理相关接口")
@CrossOrigin
public class ProjectManagerController {

    protected static final Logger logger = LoggerFactory.getLogger(ProjectManagerController.class);

    @Autowired
    private ProjectManagerServiceImpl projectManagerService;

    @ApiOperation("查询领域相关的PM/众包人员")
    @GetMapping("/pmList")
    public ResultModel pmList(PageUtil pageUtil, PmQueryVo pmQueryVo) {
        if (StringUtils.isEmpty(pmQueryVo.getDomain())) {
            pmQueryVo.setDomain(null);
        }
        if (StringUtils.isEmpty(pmQueryVo.getPmCode())) {
            pmQueryVo.setPmCode(null);
        }
        if (StringUtils.isEmpty(pmQueryVo.getOuterCode())) {
            pmQueryVo.setDomain(null);
        }
        return projectManagerService.pmList(pageUtil, pmQueryVo);
    }

    @ApiOperation("设置领域相关的PM/众包人员")
    @PostMapping("/setPmList")
    public ResultModel setPmList(PmResponseVo pmResponseVo) {
        SysMatchingPm sysMatchingPm = new SysMatchingPm();
        if (StringUtils.isEmpty(pmResponseVo.getDomain())) {
            return ResultModel.FailWithNoData("请选择领域");
        }
        if (pmResponseVo.getPmCode().size() == 0) {
            return ResultModel.FailWithNoData("请选择pm");
        }
        if (pmResponseVo.getOuterCode().size() == 0) {
            return ResultModel.FailWithNoData("请选择外包处理人员");
        }
        String pmCode = "";
        String outerCode = "";
        for (String pmCodes : pmResponseVo.getPmCode()) {
            pmCode += pmCodes + ",";
        }
        for (String outerCodes : pmResponseVo.getOuterCode()) {
            outerCode += outerCodes + ",";
        }
        sysMatchingPm.setPmCode(pmCode);
        sysMatchingPm.setOuterCode(outerCode);
        sysMatchingPm.setDomain(pmResponseVo.getDomain());
        return ResultModel.SuccessForMsg("", projectManagerService.setPm(sysMatchingPm));
    }

    @ApiOperation("更新领域相关的PM/众包人员")
    @PostMapping("/updatePmList")
    public ResultModel updatePmList(PmResponseVo pmResponseVo) {
        SysMatchingPm sysMatchingPm = new SysMatchingPm();
        String pmCode = "";
        String outerCode = "";
        for (String pmCodes : pmResponseVo.getPmCode()) {
            pmCode += pmCodes + ",";
        }
        for (String outerCodes : pmResponseVo.getOuterCode()) {
            outerCode += outerCodes + ",";
        }
        sysMatchingPm.setPmCode(pmCode);
        sysMatchingPm.setOuterCode(outerCode);
        sysMatchingPm.setDomain(pmResponseVo.getDomain());
        sysMatchingPm.setId(pmResponseVo.getId());
        return ResultModel.SuccessForMsg("", projectManagerService.updatePm(sysMatchingPm));
    }

    @ApiOperation("设置翻译经理")
    @PostMapping("/settransMananger")
    public ResultModel settransMananger(@RequestBody TransManagerVo transManagerVo) {
        if (StringUtils.isEmpty(transManagerVo.getDomain())) {
            return ResultModel.FailWithNoData("领域不可为空");
        }
        if (StringUtils.isEmpty(transManagerVo.getSourceLanguage())) {
            return ResultModel.FailWithNoData("源语言不可为空");
        }
        if (StringUtils.isEmpty(transManagerVo.getTargetLanguage())) {
            return ResultModel.FailWithNoData("目标语言不可为空");
        }
        if (transManagerVo.getUserCode().size() == 0) {
            return ResultModel.FailWithNoData("请选择翻译经理");
        }
        return ResultModel.SuccessForMsg("", projectManagerService.setTransManager(transManagerVo));
    }

    @ApiOperation("查询翻译经理")
    @PostMapping("/transManangerList")
    public ResultModel transManangerList(PageUtil pageUtil, SysTransmanagerInfo sysTransmanagerInfo) {
        if (StringUtils.isEmpty(sysTransmanagerInfo.getUserCode())) {
            sysTransmanagerInfo.setUserCode(null);
        }
        if (StringUtils.isEmpty(sysTransmanagerInfo.getTargetLanguage())) {
            sysTransmanagerInfo.setTargetLanguage(null);
        }
        if (StringUtils.isEmpty(sysTransmanagerInfo.getSourceLanguage())) {
            sysTransmanagerInfo.setSourceLanguage(null);
        }
        if (StringUtils.isEmpty(sysTransmanagerInfo.getDomain())) {
            sysTransmanagerInfo.setDomain(null);
        }
        return ResultModel.SuccessForMsg("", projectManagerService.transManagerList(pageUtil, sysTransmanagerInfo));
    }

    @ApiOperation("更新翻译经理")
    @PostMapping("/updateMananger")
    public ResultModel updateMananger(TransManagerVo transManagerVo) {
        return ResultModel.SuccessForMsg("", projectManagerService.updateTransManager(transManagerVo));
    }

    @PostMapping("/test")
    public ResultModel test() throws Exception {
        ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("cat").build();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(5, 10, 200, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<Runnable>(5), namedThreadFactory);
        executor.execute(new cat());
        logger.info("456");
        return ResultModel.Success();
    }
}

class cat implements Runnable{
    protected static final Logger logger = LoggerFactory.getLogger(ProjectManagerController.class);
    @Override
    public void run() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        logger.info(Thread.currentThread().getName() + "runrunrun");
    }
}
