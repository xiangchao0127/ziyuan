package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmGettaskid;
import com.sy.pangu.pm.entity.example.PmGettaskidExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmGettaskidMapper {
    long countByExample(PmGettaskidExample example);

    int deleteByExample(PmGettaskidExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmGettaskid record);

    int insertSelective(PmGettaskid record);

    List<PmGettaskid> selectByExample(PmGettaskidExample example);

    PmGettaskid selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmGettaskid record, @Param("example") PmGettaskidExample example);

    int updateByExample(@Param("record") PmGettaskid record, @Param("example") PmGettaskidExample example);

    int updateByPrimaryKeySelective(PmGettaskid record);

    int updateByPrimaryKey(PmGettaskid record);
}