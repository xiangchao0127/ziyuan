package com.sy.pangu.pm.service;

import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.entity.PmSysTask;

import java.util.List;
import java.util.Map;

/**
 * @author ：jzj
 * date ：Created in 2019/4/29 9:21
 */
public interface IInitParamService {

    /**
     * 加载任务名称表
     *
     * @return
     */
    List<PmSysTask> getInitSysTask();

    /**
     * key: langEn
     * value:langZh
     *
     * @return
     */
    Map<String, String> getInitLanguageData();

    /**
     * key: staffnum
     * value:userinfo
     * @return
     */
    Map<String, UserForPM> getInitUserData();

    Map<String, String> getInitDomainData();
}
