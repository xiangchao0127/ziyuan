package com.sy.pangu.pm.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;

/**
 * @author ：jzj
 * date ：Created in 2019/4/14 10:53
 */
public class ParamStatic {
    //openoffice端口号
    public static final int OPEN_OFFICE_PORT = 8100;
    //任务未领取默认工号   ---  暂定：000000
    public static final String TASK_DEFAULT_STAFFNUM = "000000";

    //抢单中的任务包id   ---
    public static final String TASK_PACKAGEID_TEMP = "TASK_PACKAGEID_TEMP";
    //文件；临时目录
    public static final String FILE_PATH_TEMP = "pangu-services/pangu-pm/temp_file/";
    //时间格式
    public static final SimpleDateFormat SIMPLE_TIMEFORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final SimpleDateFormat SIMPLE_DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final SimpleDateFormat SIMPLE_TIME_NUM = new SimpleDateFormat("yyyyMMddHHmmss");
    public static final SimpleDateFormat SIMPLE_DATE_NUM = new SimpleDateFormat("yyyyMMdd");

}
