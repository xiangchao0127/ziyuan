package com.sy.pangu.pm.controller;

import com.sy.pangu.pm.entity.PmTaskWorkload;
import com.sy.pangu.pm.entity.vo.WorkLoadQueryDto;
import com.sy.pangu.pm.entity.vo.WorkLoadVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.WorkLoadService;
import com.sy.pangu.pm.service.impl.WorkLoadServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/5 16:20
 */
@Api(tags = "工作量与评价统计")
@RequestMapping("/workload")
@RestController
public class WorkLoadController {

    @Autowired
    private WorkLoadServiceImpl workLoadService;

    @PostMapping("/totalStatistics")
    @ApiOperation("获取全部的统计数据")
    public ResultModel totalStatistics(String projectId) {
        return ResultModel.SuccessForMsg("", workLoadService.totalStatistics(projectId));
    }

    @PostMapping("/workLoadList")
    @ApiOperation("获取工作量列表")
    public ResultModel workLoadList(String projectId) {
        return ResultModel.SuccessForMsg("", workLoadService.workLoadList(projectId));
    }

    @PostMapping("/addWorkLoad")
    @ApiOperation("添加工作量")
    public ResultModel addWorkLoad(WorkLoadQueryDto workLoadQueryDto) throws ParseException {
        int result = workLoadService.addWorkLoad(workLoadQueryDto);
        if (result == 0) {
            return ResultModel.FailWithNoData("添加失败");
        } else {
            return ResultModel.Success();
        }
    }

    @PostMapping("/updateWorkLoad")
    @ApiOperation("更新工作量")
    public ResultModel updateWorkLoad(PmTaskWorkload workload) {
        int result = workLoadService.updateWorkLoad(workload);
        if (result == 0) {
            return ResultModel.FailWithNoData("更新失败");
        } else {
            return ResultModel.Success();
        }
    }
}
