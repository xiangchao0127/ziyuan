package com.sy.pangu.pm.entity;

public class PmBlockInfo {
    /**
     * 主键id
     */
    private Integer id;

    /**
     * 项目id
     */
    private String projectsId;

    /**
     * 文件id
     */
    private String fileId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 包id
     */
    private String taskPackageId;

    /**
     * 包字数 (已删除该字段，目前存在pm_task_info的工作量字段中)
     */
    private Integer duplicateNum;

    /**
     * 是否删除
     */
    private Integer isDelete;

    /**
     * 包的自增序号（按顺序）
     */
    private Integer blockIncreaseId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjectsId() {
        return projectsId;
    }

    public void setProjectsId(String projectsId) {
        this.projectsId = projectsId == null ? null : projectsId.trim();
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getTaskPackageId() {
        return taskPackageId;
    }

    public void setTaskPackageId(String taskPackageId) {
        this.taskPackageId = taskPackageId == null ? null : taskPackageId.trim();
    }

    public Integer getDuplicateNum() {
        return duplicateNum;
    }

    public void setDuplicateNum(Integer duplicateNum) {
        this.duplicateNum = duplicateNum;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public Integer getBlockIncreaseId() {
        return blockIncreaseId;
    }

    public void setBlockIncreaseId(Integer blockIncreaseId) {
        this.blockIncreaseId = blockIncreaseId;
    }
}