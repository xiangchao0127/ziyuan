package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 9:46
 */
@Data
public class PretreatmentParams implements Serializable {
    private String projectId;
    private String languagePair;
    private List<FileInfo> fileInfoList;
    private String userCode;
    private String userName;
    private ExcelParam excelParam;
    private PPTParam pptParam;
    private WordParam wordParam;
}
