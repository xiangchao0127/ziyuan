package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 **/
@Data
public class TaskApplyVo {
    private String projectId;
    private String projectName;
    private String taskType;
    private String applyType;
    private String applySatus;
    /**
     * 申请时间
     */
    private String applyTime;
    /**
     * 申请人
     */
    private String applyStaffNum;
    private String applyName;
    /**
     * 申请原因
     */
    private  String reason;
    /**
     * 回复时间
     */
    private  String lastUpdateTime;
    /**
     * 项目经理回复
     */
    private  String replyReason;
}
