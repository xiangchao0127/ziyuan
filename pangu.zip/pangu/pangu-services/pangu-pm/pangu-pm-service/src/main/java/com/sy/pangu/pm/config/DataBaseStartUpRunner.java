package com.sy.pangu.pm.config;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.entity.PmSysTask;
import com.sy.pangu.pm.entity.vo.UserDomainVo;
import com.sy.pangu.pm.service.IInitParamService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 初始化参数类
 * 建议定义map类型 key-val形式
 * @author ：lhaotian
 * @date ：Created in 2019/4/18 9:48
 */
@Component
public class DataBaseStartUpRunner implements CommandLineRunner {

    protected static final Logger LOGGER = (Logger) LoggerFactory.getLogger(DataBaseStartUpRunner.class);

    @Autowired
    private IInitParamService initParamService;

    /**
     * 加载任务名称表
     */
    public static List<PmSysTask> initPmSysTask = new ArrayList<>();

    /**
     * key: langEn
     * value:langZh
     */
    public static Map<String, String> init_language_data = new HashMap();

    /**
     * key: staffnum
     * value:userinfo
     */
    public static Map<String, UserForPM> init_user_data = new HashMap();

    /**
     * key: staffnum
     * value:userinfo
     */
    public static Map<String, UserDomainVo> init_user_domain = new HashMap();

    public static Map<String, String> init_domain_data = new HashMap<>();

    /**
     * @param args
     * @throws Exception
     */
    @Override
    public void run(String... args) throws Exception {
        initPmSysTask = initParamService.getInitSysTask();
        init_language_data = initParamService.getInitLanguageData();
        init_user_data = initParamService.getInitUserData();
        init_domain_data = initParamService.getInitDomainData();
    }
}
