package com.sy.pangu.pm.utils.enumpackage;

/**
 * @author ：jzj
 * @date ：Created in 2019/4/26 17:13
 */
public enum FileTypeEnum {
    /**
     * 文件类型:原文
     */
    FILE_TYPE_ORIGINAL("01","原文"),
    /**
     * 文件类型:参考文
     */
    FILE_TYPE_REFERENCE("02","参考文"),
    /**
     * 文件类型:译前dtp
     */
    FILE_TYPE_BF_DTP("03","译前DTP上传文件"),
    /**
     * 文件类型:译后dtp
     */
    FILE_TYPE_AF_DTP("04","译后DTP上传文件"),
    /**
     * 文件类型:排版
     */
    FILE_TYPE_TYPESETTING("05","排版上传文件"),
    /**
     * 文件类型:排版
     */
    FILE_TYPE_DELIVER("06","交付上传文件");

    private String value;
    private String desc;

    private FileTypeEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(FileTypeEnum data : FileTypeEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知状态";
    }

    /**
     * 根据任务类型获取文件类型
     * @param taskType
     * @param fileType
     * @return
     */
    public static String getFileTypeByTaskType(String taskType,String fileType){
        if(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(taskType)){
            return FILE_TYPE_BF_DTP.getValue();
        }
        if(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(taskType)){
            return FILE_TYPE_AF_DTP.getValue();
        }
        if(StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue().equals(taskType)){
            return FILE_TYPE_TYPESETTING.getValue();
        }
        return fileType;
    }

    public static void main(String[] args) {

        System.out.println(getDescByValue("01"));
    }
}
