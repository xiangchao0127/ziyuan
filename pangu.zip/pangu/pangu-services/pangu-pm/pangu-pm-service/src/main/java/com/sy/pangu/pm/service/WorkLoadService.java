package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmTaskWorkload;
import com.sy.pangu.pm.entity.vo.WorkLoadQueryDto;
import com.sy.pangu.pm.entity.vo.WorkLoadVo;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/5 16:40
 */

public interface WorkLoadService {
    String totalStatistics(String projectId);
    List<WorkLoadVo> workLoadList(String projectId);
    int addWorkLoad(WorkLoadQueryDto workLoadQueryDto) throws ParseException;
    int updateWorkLoad(PmTaskWorkload workload);
    void insertWorkLoad(String taskId, String workType, String ratio, String estimateWorkLoad, String unitPrice) throws ParseException;
}
