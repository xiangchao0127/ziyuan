package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/26 11:42
 */
@Data
public class PmQueryVo {
    private String pmCode;
    private String outerCode;
    private String domain;
    private Integer id;
}
