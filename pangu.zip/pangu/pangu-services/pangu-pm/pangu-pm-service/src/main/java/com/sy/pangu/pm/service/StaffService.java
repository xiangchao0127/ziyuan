package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.SysStaffLvl;
import com.sy.pangu.pm.entity.vo.UserCandidateVo;
import com.sy.pangu.pm.entity.vo.UserQueryVo;
import com.sy.pangu.pm.utils.PageUtil;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/15 18:46
 */
public interface StaffService {

    int saveStaffLvl(SysStaffLvl staffLvl);

    int updateStaffLvl(SysStaffLvl staffLvl);

    int deleteStaffLvl(SysStaffLvl staffLvl);

    List<SysStaffLvl> listStaffLvl(String taskType, String lvlType);

    List<UserCandidateVo> userList(UserQueryVo userInfo, PageUtil pageUtil);
}
