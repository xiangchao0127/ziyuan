package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.SysStaffLvl;
import com.sy.pangu.pm.entity.example.SysStaffLvlExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysStaffLvlMapper {
    long countByExample(SysStaffLvlExample example);

    int deleteByExample(SysStaffLvlExample example);

    int insert(SysStaffLvl record);

    int insertSelective(SysStaffLvl record);

    List<SysStaffLvl> selectByExample(SysStaffLvlExample example);

    int updateByExampleSelective(@Param("record") SysStaffLvl record, @Param("example") SysStaffLvlExample example);

    int updateByExample(@Param("record") SysStaffLvl record, @Param("example") SysStaffLvlExample example);

    int selectTypeCount(SysStaffLvl record);

    int updateLvlNum(SysStaffLvl record);
}