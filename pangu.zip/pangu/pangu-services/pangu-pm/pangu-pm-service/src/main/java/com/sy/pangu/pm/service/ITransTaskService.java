package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmGrabsheet;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.vo.TaskDetailVo;
import com.sy.pangu.pm.model.TaskFileListModel;
import com.sy.pangu.pm.utils.PageUtil;

import java.util.List;

public interface ITransTaskService {
    /**
     * 获取未领取任务
     * @param page
     */
    public void getNotReceiveTask(PageUtil page);

    /**
     * 获取任务列表（进行中/已完成）
     * @param page
     * @throws RuntimeException
     */
    public void getTaskListByStatus(PageUtil page) throws RuntimeException;

    /**
     * 领取任务
     * @param staffNum
     * @param taskId
     * @param taskType
     * @throws RuntimeException
     */
    public void receiveCompleteTask(String staffNum, String taskId, String taskType) throws RuntimeException;

    /**
     * 申请退稿
     * @param taskId
     * @param reason
     */
    public void applyCancelTask(String taskId, String reason) throws RuntimeException;

    /**
     * 获取任务详情
     * @param taskId
     * @return
     */
    public TaskDetailVo getTaskDetail(String taskId) throws RuntimeException;

    /**
     * 申请再次编辑
     * @param taskId
     */
    public void applyEditAgain(String taskId) throws RuntimeException;

    /**
     * 更新任务状态
     * @param taskId
     * @param status
     */
    public void updateTaskStatus(String taskId, String status) throws RuntimeException;

    /**
     * 任务部分领取
     * @param workNum
     * @param taskInfo
     */
    public void receivePartTask(String workNum, PmTaskInfo taskInfo) throws Exception;

    int updateTaskStatusByPID(String projectId) throws Exception;

    int stopTaskByPId(String projectId);

    List<PmTaskInfo> getTaskStatusByPackage(String blockId);

    /**
     * 插入任务信息
     * @param taskInfo
     * @param grabsheet
     */
    void insertTaskInfo(PmTaskInfo taskInfo, PmGrabsheet grabsheet);

    /**
     * 解锁下一阶段任务
     * @param taskType
     * @param fileId
     */
    void openNextTask(String taskType, String fileId);
    /**
     * 查询任务表集合
     * @param pmTaskInfo     *
     */
    List<PmTaskInfo> getTaskInfoList(PmTaskInfo pmTaskInfo);

    void updateTaskStByFild(String fileId);
    /**
     * 根据原文件id，获取任务与任务文件信息集合
     * @param fileId
     */
    List<TaskFileListModel> getTaskinfoByFileid(Integer fileId);
    /**
     * 根据原文件id，把停止文件相关任务
     * @param fileId
     */
    void stopTaskByFileId(String fileId);
    /**
     * 根据包ID字符串集合和状态，获取任务集合
     * @param packageIDList  包ID字符串集合
     * @param taskStatus  任务状态
     */
    List<PmTaskInfo> getTaskInfoListByPackageList(String packageIDList, String taskStatus);
    /**
     * 根据包ID字符串把任务设置为失效
     * @param packageIDList  包ID字符串集合     *
     */
    void stopTaskByPackageIDlist(String packageIDList);

    /**
     * 是否有领取权限
     * @param staffNum
     * @param taskId
     */
    void hasPermissionsReceive(String staffNum, String taskId) throws Exception;

    PmTaskInfo getTaskInfoByTaskId(String taskId) throws RuntimeException;

    /**
     * 获取任务ID
     * @return
     */
    String getTaskId();

    /**
     *判断是否有权限领取自动分配的任务
     *
     * @param staffNum
     * @param taskId
     * @param langEn
     * @param domain
     * @return
     * @throws RuntimeException
     */
    boolean hasPermissionsReceiveCompleteTask(String staffNum, String taskId, String langEn, String domain) throws RuntimeException;
    //根据任务id把交付任务修改为已交付，并且更新交付时间
    void updateTaskStatusByTaskID(String taskId, String status, String real_complet_time);
    //根据原文件id，把文件下所有有效任务设置为已交付
    void updateTaskStatusByFileID(String fileId, String status);
}
