package com.sy.pangu.pm.utils.enumpackage;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/25 19:48
 */
public enum WorkTypeEnum {

    CO_WORK_TYPE("10","协同工作"),
    AL_WORK_TYPE("11", "单独工作");


    private String value;
    private String desc;

    private WorkTypeEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(WorkTypeEnum data : WorkTypeEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知状态";
    }

    public static void main(String[] args) {

        System.out.println(getDescByValue("01"));
    }

}
