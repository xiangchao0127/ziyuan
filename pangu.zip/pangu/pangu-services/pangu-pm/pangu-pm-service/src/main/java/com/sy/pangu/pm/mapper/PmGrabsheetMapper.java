package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmGrabsheet;
import com.sy.pangu.pm.entity.example.PmGrabsheetExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmGrabsheetMapper {
    long countByExample(PmGrabsheetExample example);

    int deleteByExample(PmGrabsheetExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmGrabsheet record);

    int insertSelective(PmGrabsheet record);

    List<PmGrabsheet> selectByExample(PmGrabsheetExample example);

    PmGrabsheet selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmGrabsheet record, @Param("example") PmGrabsheetExample example);

    int updateByExample(@Param("record") PmGrabsheet record, @Param("example") PmGrabsheetExample example);

    int updateByPrimaryKeySelective(PmGrabsheet record);

    int updateByPrimaryKey(PmGrabsheet record);

    /**
     * 根据taskId作更新
     * @param grabsheet
     */
    void updateByTaskIdSelective(PmGrabsheet grabsheet);

    /**
     * 批量插入抢单表
     * @return
     */
    int insertBatch(List<PmGrabsheet> records);
}