package com.sy.pangu.pm.service.impl;

import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.SysMatchingPm;
import com.sy.pangu.pm.entity.SysTransmanagerInfo;
import com.sy.pangu.pm.entity.example.SysTransmanagerInfoExample;
import com.sy.pangu.pm.entity.vo.PmQueryVo;
import com.sy.pangu.pm.entity.vo.PmResponseVo;
import com.sy.pangu.pm.entity.vo.TransManagerVo;
import com.sy.pangu.pm.mapper.SysMatchingPmMapper;
import com.sy.pangu.pm.mapper.SysTransmanagerInfoMapper;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.ProjectManagerService;
import com.sy.pangu.pm.utils.PageUtil;
import com.sy.pangu.pm.utils.ParamBuildUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/24 14:18
 */
@Service("projectManagerService")
public class ProjectManagerServiceImpl implements ProjectManagerService {

    @Autowired
    private SysMatchingPmMapper sysMatchingPmMapper;

    @Autowired
    private SysTransmanagerInfoMapper sysTransmanagerInfoMapper;

    @Override
    public ResultModel pmList(PageUtil pageUtil, PmQueryVo pmVo) {
        ParamBuildUtil.ParamBuild(pageUtil.getLink(), pmVo);
        pageUtil.setPage((pageUtil.getPage() - 1) * pageUtil.getLimit());
        List<SysMatchingPm> list = sysMatchingPmMapper.selectByPage(pageUtil);
        List<PmResponseVo> pmList = new ArrayList<>();
        for (SysMatchingPm sysMatchingPm : list) {
            PmResponseVo pmResponseVo = new PmResponseVo();
            String[] pmCodeArray = sysMatchingPm.getPmCode().split(",");
            String[] outerCodeArray = sysMatchingPm.getOuterCode().split(",");
            pmResponseVo.setDomain(sysMatchingPm.getDomain());
            pmResponseVo.setPmCode(new ArrayList<>(Arrays.asList(pmCodeArray)));
            pmResponseVo.setOuterCode(new ArrayList<>(Arrays.asList(outerCodeArray)));
            pmResponseVo.setId(sysMatchingPm.getId());
            pmList.add(pmResponseVo);
        }
        pageUtil.setList(pmList);
        pageUtil.setTotalRow(pmList.size());
        return ResultModel.SuccessForMsg("查询成功", pageUtil);
    }

    @Override
    public int setPm(SysMatchingPm sysMatchingPm) {
        return sysMatchingPmMapper.insertSelective(sysMatchingPm);
    }

    @Override
    public int updatePm(SysMatchingPm sysMatchingPm) {
        return sysMatchingPmMapper.updateByPrimaryKeySelective(sysMatchingPm);
    }


    @Override
    public PageUtil transManagerList(PageUtil pageUtil, SysTransmanagerInfo sysTransmanagerInfo) {
        ParamBuildUtil.ParamBuild(pageUtil.getLink(), sysTransmanagerInfo);
        pageUtil.setPage((pageUtil.getPage() - 1) * pageUtil.getLimit());
        List<SysTransmanagerInfo> list = sysTransmanagerInfoMapper.selectByPage(pageUtil);
        List<TransManagerVo> transManagerVos = new ArrayList<>();
       for (SysTransmanagerInfo transmanagerInfo : list) {
           String userCode = transmanagerInfo.getUserCode();
           if (userCode.contains(",")) {
               String[] userCodeArray = userCode.split(",");
               ArrayList<String> userList = new ArrayList<>(Arrays.asList(userCodeArray));
               List<UserForPM> userForPMS = new ArrayList<>();
               userList.stream().forEach(x -> userForPMS.add(DataBaseStartUpRunner.init_user_data.get(x)));
               TransManagerVo transManagerVo = new TransManagerVo();
               transManagerVo.setDomain(transmanagerInfo.getDomain());
               transManagerVo.setTargetLanguage(transmanagerInfo.getTargetLanguage());
               transManagerVo.setId(transmanagerInfo.getId());
               transManagerVo.setSourceLanguage(transmanagerInfo.getSourceLanguage());
               transManagerVo.setUserCode(userForPMS);
               transManagerVos.add(transManagerVo);
           } else {
               TransManagerVo transManagerVo = new TransManagerVo();
               transManagerVo.setDomain(transmanagerInfo.getDomain());
               transManagerVo.setTargetLanguage(transmanagerInfo.getTargetLanguage());
               transManagerVo.setId(transmanagerInfo.getId());
               transManagerVo.setSourceLanguage(transmanagerInfo.getSourceLanguage());
               List<UserForPM> userList = new ArrayList<>();
               userList.add(DataBaseStartUpRunner.init_user_data.get(userCode));
               transManagerVo.setUserCode(userList);
               transManagerVos.add(transManagerVo);
           }
       }
        pageUtil.setList(transManagerVos);
        pageUtil.setTotalRow(transManagerVos.size());
        return pageUtil;
    }

    private String getChFromEg(String source, String splitRegex, Map sourceMap) {
        String result = splitRegex;
        if (source.contains(splitRegex)) {
            String[] sourceArray = source.split(splitRegex);
            for (String index : sourceArray) {
                if (sourceMap.get(index) == null) {
                    continue;
                }
                result = result + sourceMap.get(index) + splitRegex;
            }
            result = result.substring(1, result.lastIndexOf(splitRegex));
        } else {
            return source;
        }

        return result;
    }

    @Override
    public int setTransManager(TransManagerVo transManagerVo) {
        String userCode = "";
        List<UserForPM> userList = transManagerVo.getUserCode();
        for (UserForPM user : userList) {
            userCode += user.getUserCode() + ",";
        }
        SysTransmanagerInfo sysTransmanagerInfo = new SysTransmanagerInfo();
        sysTransmanagerInfo.setUserCode(userCode);
        sysTransmanagerInfo.setDomain(transManagerVo.getDomain());
        sysTransmanagerInfo.setSourceLanguage(transManagerVo.getSourceLanguage());
        sysTransmanagerInfo.setTargetLanguage(transManagerVo.getTargetLanguage());
        return sysTransmanagerInfoMapper.insertSelective(sysTransmanagerInfo);
    }

    @Override
    public int updateTransManager(TransManagerVo transManagerVo) {
        String userCode = "";
        List<UserForPM> userList = transManagerVo.getUserCode();
        for (UserForPM user : userList) {
            userCode += user.getUserCode() + ",";
        }
        SysTransmanagerInfo sysTransmanagerInfo = new SysTransmanagerInfo();
        sysTransmanagerInfo.setUserCode(userCode);
        sysTransmanagerInfo.setDomain(transManagerVo.getDomain());
        sysTransmanagerInfo.setSourceLanguage(transManagerVo.getSourceLanguage());
        sysTransmanagerInfo.setTargetLanguage(transManagerVo.getTargetLanguage());
        sysTransmanagerInfo.setId(transManagerVo.getId());
        return sysTransmanagerInfoMapper.updateByPrimaryKeySelective(sysTransmanagerInfo);
    }

    @Override
    public String getTransManager(String sourceLan, String targetLan, String domain) {
        SysTransmanagerInfoExample example = new SysTransmanagerInfoExample();
        example.createCriteria()
                .andDomainEqualTo(domain)
                .andSourceLanguageEqualTo(sourceLan)
                .andTargetLanguageEqualTo(targetLan);
        List<SysTransmanagerInfo> infoList = sysTransmanagerInfoMapper.selectByExample(example);
        if (infoList.size() <= 0) {
            return "";
        }
        return sysTransmanagerInfoMapper.selectByExample(example).get(0).getUserCode();
    }
}
