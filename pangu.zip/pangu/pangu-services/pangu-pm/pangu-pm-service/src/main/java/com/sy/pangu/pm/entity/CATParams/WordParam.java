package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 9:48
 */
public class WordParam {
    /**
     * 是否提取隐藏内容
     */
    private int wordHiddenText;
    /**
     * 是否提取隐藏属性
     */
    private int wordProperty;
    /**
     * 是否提取超链接
     */
    private int wordHyperlink;
    /**
     * 是否提取批注
     */
    private int wordCommnet;
    /**
     * 是否提取页眉
     */
    private int wordHeader;
    /**
     * 是否提取页脚
     */
    private int wordFooter;
    /**
     * 是否提取隐藏尾注
     */
    private int wordEndnote;
    /**
     * 是否提取文档脚注
     */
    private int wordFootnote;

    public WordParam() {
        this.wordHiddenText = 0;
        this.wordProperty = 0;
        this.wordHyperlink = 0;
        this.wordCommnet = 0;
        this.wordHeader = 0;
        this.wordFooter = 0;
        this.wordEndnote = 0;
        this.wordFootnote = 0;
    }
}
