package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmProjectInfo;
import lombok.Data;

import java.util.List;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/
@Data
public class ProjectSearchModel {
    /**
     * 返稿开始时间
     */
    private String deliveryStarT;
    /**
     * 返稿结束时间
     */
    private String deliveryEndT;
    /**
     * 预估字数开始范围
     */
    private String estimateStarN;
    /**
     * 预估字数结束范围
     */
    private String estimateEndN;
    /**
     * 下单开始时间
     */
    private String orderStarT;
    /**
     * 下单结束时间
     */
    private String orderEndT;
    /**
     * 项目表实体
     */
    private PmProjectInfo pmProjectInfo;

    private List<PmProjectInfo> pmProjectInfoList;

    public String getDeliveryStarT() {
        return deliveryStarT;
    }

    public void setDeliveryStarT(String deliveryStarT) {
        this.deliveryStarT = deliveryStarT;
    }

    public String getDeliveryEndT() {
        return deliveryEndT;
    }

    public void setDeliveryEndT(String deliveryEndT) {
        this.deliveryEndT = deliveryEndT;
    }

    public String getEstimateStarN() {
        return estimateStarN;
    }

    public void setEstimateStarN(String estimateStarN) {
        this.estimateStarN = estimateStarN;
    }

    public String getEstimateEndN() {
        return estimateEndN;
    }

    public void setEstimateEndN(String estimateEndN) {
        this.estimateEndN = estimateEndN;
    }

    public String getOrderStarT() {
        return orderStarT;
    }

    public void setOrderStarT(String orderStarT) {
        this.orderStarT = orderStarT;
    }

    public String getOrderEndT() {
        return orderEndT;
    }

    public void setOrderEndT(String orderEndT) {
        this.orderEndT = orderEndT;
    }

    public PmProjectInfo getPmProjectInfo() {
        return pmProjectInfo;
    }

    public void setPmProjectInfo(PmProjectInfo pmProjectInfo) {
        this.pmProjectInfo = pmProjectInfo;
    }

    public List<PmProjectInfo> getPmProjectInfoList() {
        return pmProjectInfoList;
    }

    public void setPmProjectInfoList(List<PmProjectInfo> pmProjectInfoList) {
        this.pmProjectInfoList = pmProjectInfoList;
    }
}
