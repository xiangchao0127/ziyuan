package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class PmTaskInfoExample {
    /**
     * pm_task_info
     */
    protected String orderByClause;

    /**
     * pm_task_info
     */
    protected boolean distinct;

    /**
     * pm_task_info
     */
    protected List<Criteria> oredCriteria;

    public PmTaskInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_task_info null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andProjectIdIsNull() {
            addCriterion("project_id is null");
            return (Criteria) this;
        }

        public Criteria andProjectIdIsNotNull() {
            addCriterion("project_id is not null");
            return (Criteria) this;
        }

        public Criteria andProjectIdEqualTo(String value) {
            addCriterion("project_id =", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotEqualTo(String value) {
            addCriterion("project_id <>", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdGreaterThan(String value) {
            addCriterion("project_id >", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdGreaterThanOrEqualTo(String value) {
            addCriterion("project_id >=", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdLessThan(String value) {
            addCriterion("project_id <", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdLessThanOrEqualTo(String value) {
            addCriterion("project_id <=", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdLike(String value) {
            addCriterion("project_id like", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotLike(String value) {
            addCriterion("project_id not like", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdIn(List<String> values) {
            addCriterion("project_id in", values, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotIn(List<String> values) {
            addCriterion("project_id not in", values, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdBetween(String value1, String value2) {
            addCriterion("project_id between", value1, value2, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotBetween(String value1, String value2) {
            addCriterion("project_id not between", value1, value2, "projectId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("task_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("task_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("task_id =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("task_id <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("task_id >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_id >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("task_id <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("task_id <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("task_id like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("task_id not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("task_id in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("task_id not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("task_id between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("task_id not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdIsNull() {
            addCriterion("task_package_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdIsNotNull() {
            addCriterion("task_package_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdEqualTo(String value) {
            addCriterion("task_package_id =", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotEqualTo(String value) {
            addCriterion("task_package_id <>", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdGreaterThan(String value) {
            addCriterion("task_package_id >", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_package_id >=", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdLessThan(String value) {
            addCriterion("task_package_id <", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdLessThanOrEqualTo(String value) {
            addCriterion("task_package_id <=", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdLike(String value) {
            addCriterion("task_package_id like", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotLike(String value) {
            addCriterion("task_package_id not like", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdIn(List<String> values) {
            addCriterion("task_package_id in", values, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotIn(List<String> values) {
            addCriterion("task_package_id not in", values, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdBetween(String value1, String value2) {
            addCriterion("task_package_id between", value1, value2, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotBetween(String value1, String value2) {
            addCriterion("task_package_id not between", value1, value2, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskNameIsNull() {
            addCriterion("task_name is null");
            return (Criteria) this;
        }

        public Criteria andTaskNameIsNotNull() {
            addCriterion("task_name is not null");
            return (Criteria) this;
        }

        public Criteria andTaskNameEqualTo(String value) {
            addCriterion("task_name =", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotEqualTo(String value) {
            addCriterion("task_name <>", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameGreaterThan(String value) {
            addCriterion("task_name >", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameGreaterThanOrEqualTo(String value) {
            addCriterion("task_name >=", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameLessThan(String value) {
            addCriterion("task_name <", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameLessThanOrEqualTo(String value) {
            addCriterion("task_name <=", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameLike(String value) {
            addCriterion("task_name like", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotLike(String value) {
            addCriterion("task_name not like", value, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameIn(List<String> values) {
            addCriterion("task_name in", values, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotIn(List<String> values) {
            addCriterion("task_name not in", values, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameBetween(String value1, String value2) {
            addCriterion("task_name between", value1, value2, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskNameNotBetween(String value1, String value2) {
            addCriterion("task_name not between", value1, value2, "taskName");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNull() {
            addCriterion("task_type is null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNotNull() {
            addCriterion("task_type is not null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeEqualTo(String value) {
            addCriterion("task_type =", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotEqualTo(String value) {
            addCriterion("task_type <>", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThan(String value) {
            addCriterion("task_type >", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThanOrEqualTo(String value) {
            addCriterion("task_type >=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThan(String value) {
            addCriterion("task_type <", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThanOrEqualTo(String value) {
            addCriterion("task_type <=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLike(String value) {
            addCriterion("task_type like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotLike(String value) {
            addCriterion("task_type not like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIn(List<String> values) {
            addCriterion("task_type in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotIn(List<String> values) {
            addCriterion("task_type not in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeBetween(String value1, String value2) {
            addCriterion("task_type between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotBetween(String value1, String value2) {
            addCriterion("task_type not between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskStatusIsNull() {
            addCriterion("task_status is null");
            return (Criteria) this;
        }

        public Criteria andTaskStatusIsNotNull() {
            addCriterion("task_status is not null");
            return (Criteria) this;
        }

        public Criteria andTaskStatusEqualTo(String value) {
            addCriterion("task_status =", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotEqualTo(String value) {
            addCriterion("task_status <>", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusGreaterThan(String value) {
            addCriterion("task_status >", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusGreaterThanOrEqualTo(String value) {
            addCriterion("task_status >=", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusLessThan(String value) {
            addCriterion("task_status <", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusLessThanOrEqualTo(String value) {
            addCriterion("task_status <=", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusLike(String value) {
            addCriterion("task_status like", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotLike(String value) {
            addCriterion("task_status not like", value, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusIn(List<String> values) {
            addCriterion("task_status in", values, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotIn(List<String> values) {
            addCriterion("task_status not in", values, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusBetween(String value1, String value2) {
            addCriterion("task_status between", value1, value2, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andTaskStatusNotBetween(String value1, String value2) {
            addCriterion("task_status not between", value1, value2, "taskStatus");
            return (Criteria) this;
        }

        public Criteria andStaffNumIsNull() {
            addCriterion("staff_num is null");
            return (Criteria) this;
        }

        public Criteria andStaffNumIsNotNull() {
            addCriterion("staff_num is not null");
            return (Criteria) this;
        }

        public Criteria andStaffNumEqualTo(String value) {
            addCriterion("staff_num =", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotEqualTo(String value) {
            addCriterion("staff_num <>", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumGreaterThan(String value) {
            addCriterion("staff_num >", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumGreaterThanOrEqualTo(String value) {
            addCriterion("staff_num >=", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumLessThan(String value) {
            addCriterion("staff_num <", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumLessThanOrEqualTo(String value) {
            addCriterion("staff_num <=", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumLike(String value) {
            addCriterion("staff_num like", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotLike(String value) {
            addCriterion("staff_num not like", value, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumIn(List<String> values) {
            addCriterion("staff_num in", values, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotIn(List<String> values) {
            addCriterion("staff_num not in", values, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumBetween(String value1, String value2) {
            addCriterion("staff_num between", value1, value2, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStaffNumNotBetween(String value1, String value2) {
            addCriterion("staff_num not between", value1, value2, "staffNum");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNull() {
            addCriterion("start_time is null");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNotNull() {
            addCriterion("start_time is not null");
            return (Criteria) this;
        }

        public Criteria andStartTimeEqualTo(String value) {
            addCriterion("start_time =", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotEqualTo(String value) {
            addCriterion("start_time <>", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThan(String value) {
            addCriterion("start_time >", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThanOrEqualTo(String value) {
            addCriterion("start_time >=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThan(String value) {
            addCriterion("start_time <", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThanOrEqualTo(String value) {
            addCriterion("start_time <=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLike(String value) {
            addCriterion("start_time like", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotLike(String value) {
            addCriterion("start_time not like", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeIn(List<String> values) {
            addCriterion("start_time in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotIn(List<String> values) {
            addCriterion("start_time not in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeBetween(String value1, String value2) {
            addCriterion("start_time between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotBetween(String value1, String value2) {
            addCriterion("start_time not between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeIsNull() {
            addCriterion("require_time is null");
            return (Criteria) this;
        }

        public Criteria andRequireTimeIsNotNull() {
            addCriterion("require_time is not null");
            return (Criteria) this;
        }

        public Criteria andRequireTimeEqualTo(String value) {
            addCriterion("require_time =", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeNotEqualTo(String value) {
            addCriterion("require_time <>", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeGreaterThan(String value) {
            addCriterion("require_time >", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeGreaterThanOrEqualTo(String value) {
            addCriterion("require_time >=", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeLessThan(String value) {
            addCriterion("require_time <", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeLessThanOrEqualTo(String value) {
            addCriterion("require_time <=", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeLike(String value) {
            addCriterion("require_time like", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeNotLike(String value) {
            addCriterion("require_time not like", value, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeIn(List<String> values) {
            addCriterion("require_time in", values, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeNotIn(List<String> values) {
            addCriterion("require_time not in", values, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeBetween(String value1, String value2) {
            addCriterion("require_time between", value1, value2, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRequireTimeNotBetween(String value1, String value2) {
            addCriterion("require_time not between", value1, value2, "requireTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeIsNull() {
            addCriterion("real_complet_time is null");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeIsNotNull() {
            addCriterion("real_complet_time is not null");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeEqualTo(String value) {
            addCriterion("real_complet_time =", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeNotEqualTo(String value) {
            addCriterion("real_complet_time <>", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeGreaterThan(String value) {
            addCriterion("real_complet_time >", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeGreaterThanOrEqualTo(String value) {
            addCriterion("real_complet_time >=", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeLessThan(String value) {
            addCriterion("real_complet_time <", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeLessThanOrEqualTo(String value) {
            addCriterion("real_complet_time <=", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeLike(String value) {
            addCriterion("real_complet_time like", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeNotLike(String value) {
            addCriterion("real_complet_time not like", value, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeIn(List<String> values) {
            addCriterion("real_complet_time in", values, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeNotIn(List<String> values) {
            addCriterion("real_complet_time not in", values, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeBetween(String value1, String value2) {
            addCriterion("real_complet_time between", value1, value2, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andRealCompletTimeNotBetween(String value1, String value2) {
            addCriterion("real_complet_time not between", value1, value2, "realCompletTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeIsNull() {
            addCriterion("distribution_time is null");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeIsNotNull() {
            addCriterion("distribution_time is not null");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeEqualTo(String value) {
            addCriterion("distribution_time =", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeNotEqualTo(String value) {
            addCriterion("distribution_time <>", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeGreaterThan(String value) {
            addCriterion("distribution_time >", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeGreaterThanOrEqualTo(String value) {
            addCriterion("distribution_time >=", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeLessThan(String value) {
            addCriterion("distribution_time <", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeLessThanOrEqualTo(String value) {
            addCriterion("distribution_time <=", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeLike(String value) {
            addCriterion("distribution_time like", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeNotLike(String value) {
            addCriterion("distribution_time not like", value, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeIn(List<String> values) {
            addCriterion("distribution_time in", values, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeNotIn(List<String> values) {
            addCriterion("distribution_time not in", values, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeBetween(String value1, String value2) {
            addCriterion("distribution_time between", value1, value2, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andDistributionTimeNotBetween(String value1, String value2) {
            addCriterion("distribution_time not between", value1, value2, "distributionTime");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andWorkLoadIsNull() {
            addCriterion("work_load is null");
            return (Criteria) this;
        }

        public Criteria andWorkLoadIsNotNull() {
            addCriterion("work_load is not null");
            return (Criteria) this;
        }

        public Criteria andWorkLoadEqualTo(String value) {
            addCriterion("work_load =", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadNotEqualTo(String value) {
            addCriterion("work_load <>", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadGreaterThan(String value) {
            addCriterion("work_load >", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadGreaterThanOrEqualTo(String value) {
            addCriterion("work_load >=", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadLessThan(String value) {
            addCriterion("work_load <", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadLessThanOrEqualTo(String value) {
            addCriterion("work_load <=", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadLike(String value) {
            addCriterion("work_load like", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadNotLike(String value) {
            addCriterion("work_load not like", value, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadIn(List<String> values) {
            addCriterion("work_load in", values, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadNotIn(List<String> values) {
            addCriterion("work_load not in", values, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadBetween(String value1, String value2) {
            addCriterion("work_load between", value1, value2, "workLoad");
            return (Criteria) this;
        }

        public Criteria andWorkLoadNotBetween(String value1, String value2) {
            addCriterion("work_load not between", value1, value2, "workLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadIsNull() {
            addCriterion("real_work_load is null");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadIsNotNull() {
            addCriterion("real_work_load is not null");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadEqualTo(String value) {
            addCriterion("real_work_load =", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadNotEqualTo(String value) {
            addCriterion("real_work_load <>", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadGreaterThan(String value) {
            addCriterion("real_work_load >", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadGreaterThanOrEqualTo(String value) {
            addCriterion("real_work_load >=", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadLessThan(String value) {
            addCriterion("real_work_load <", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadLessThanOrEqualTo(String value) {
            addCriterion("real_work_load <=", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadLike(String value) {
            addCriterion("real_work_load like", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadNotLike(String value) {
            addCriterion("real_work_load not like", value, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadIn(List<String> values) {
            addCriterion("real_work_load in", values, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadNotIn(List<String> values) {
            addCriterion("real_work_load not in", values, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadBetween(String value1, String value2) {
            addCriterion("real_work_load between", value1, value2, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andRealWorkLoadNotBetween(String value1, String value2) {
            addCriterion("real_work_load not between", value1, value2, "realWorkLoad");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeIsNull() {
            addCriterion("isover_time is null");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeIsNotNull() {
            addCriterion("isover_time is not null");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeEqualTo(String value) {
            addCriterion("isover_time =", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeNotEqualTo(String value) {
            addCriterion("isover_time <>", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeGreaterThan(String value) {
            addCriterion("isover_time >", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeGreaterThanOrEqualTo(String value) {
            addCriterion("isover_time >=", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeLessThan(String value) {
            addCriterion("isover_time <", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeLessThanOrEqualTo(String value) {
            addCriterion("isover_time <=", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeLike(String value) {
            addCriterion("isover_time like", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeNotLike(String value) {
            addCriterion("isover_time not like", value, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeIn(List<String> values) {
            addCriterion("isover_time in", values, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeNotIn(List<String> values) {
            addCriterion("isover_time not in", values, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeBetween(String value1, String value2) {
            addCriterion("isover_time between", value1, value2, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andIsoverTimeNotBetween(String value1, String value2) {
            addCriterion("isover_time not between", value1, value2, "isoverTime");
            return (Criteria) this;
        }

        public Criteria andWorkTypeIsNull() {
            addCriterion("work_type is null");
            return (Criteria) this;
        }

        public Criteria andWorkTypeIsNotNull() {
            addCriterion("work_type is not null");
            return (Criteria) this;
        }

        public Criteria andWorkTypeEqualTo(String value) {
            addCriterion("work_type =", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotEqualTo(String value) {
            addCriterion("work_type <>", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeGreaterThan(String value) {
            addCriterion("work_type >", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeGreaterThanOrEqualTo(String value) {
            addCriterion("work_type >=", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeLessThan(String value) {
            addCriterion("work_type <", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeLessThanOrEqualTo(String value) {
            addCriterion("work_type <=", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeLike(String value) {
            addCriterion("work_type like", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotLike(String value) {
            addCriterion("work_type not like", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeIn(List<String> values) {
            addCriterion("work_type in", values, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotIn(List<String> values) {
            addCriterion("work_type not in", values, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeBetween(String value1, String value2) {
            addCriterion("work_type between", value1, value2, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotBetween(String value1, String value2) {
            addCriterion("work_type not between", value1, value2, "workType");
            return (Criteria) this;
        }

        public Criteria andEvaluateIsNull() {
            addCriterion("evaluate is null");
            return (Criteria) this;
        }

        public Criteria andEvaluateIsNotNull() {
            addCriterion("evaluate is not null");
            return (Criteria) this;
        }

        public Criteria andEvaluateEqualTo(String value) {
            addCriterion("evaluate =", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateNotEqualTo(String value) {
            addCriterion("evaluate <>", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateGreaterThan(String value) {
            addCriterion("evaluate >", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateGreaterThanOrEqualTo(String value) {
            addCriterion("evaluate >=", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateLessThan(String value) {
            addCriterion("evaluate <", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateLessThanOrEqualTo(String value) {
            addCriterion("evaluate <=", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateLike(String value) {
            addCriterion("evaluate like", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateNotLike(String value) {
            addCriterion("evaluate not like", value, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateIn(List<String> values) {
            addCriterion("evaluate in", values, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateNotIn(List<String> values) {
            addCriterion("evaluate not in", values, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateBetween(String value1, String value2) {
            addCriterion("evaluate between", value1, value2, "evaluate");
            return (Criteria) this;
        }

        public Criteria andEvaluateNotBetween(String value1, String value2) {
            addCriterion("evaluate not between", value1, value2, "evaluate");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeIsNull() {
            addCriterion("currency_type is null");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeIsNotNull() {
            addCriterion("currency_type is not null");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeEqualTo(String value) {
            addCriterion("currency_type =", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeNotEqualTo(String value) {
            addCriterion("currency_type <>", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeGreaterThan(String value) {
            addCriterion("currency_type >", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeGreaterThanOrEqualTo(String value) {
            addCriterion("currency_type >=", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeLessThan(String value) {
            addCriterion("currency_type <", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeLessThanOrEqualTo(String value) {
            addCriterion("currency_type <=", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeLike(String value) {
            addCriterion("currency_type like", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeNotLike(String value) {
            addCriterion("currency_type not like", value, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeIn(List<String> values) {
            addCriterion("currency_type in", values, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeNotIn(List<String> values) {
            addCriterion("currency_type not in", values, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeBetween(String value1, String value2) {
            addCriterion("currency_type between", value1, value2, "currencyType");
            return (Criteria) this;
        }

        public Criteria andCurrencyTypeNotBetween(String value1, String value2) {
            addCriterion("currency_type not between", value1, value2, "currencyType");
            return (Criteria) this;
        }

        public Criteria andTotalPriceIsNull() {
            addCriterion("total_price is null");
            return (Criteria) this;
        }

        public Criteria andTotalPriceIsNotNull() {
            addCriterion("total_price is not null");
            return (Criteria) this;
        }

        public Criteria andTotalPriceEqualTo(String value) {
            addCriterion("total_price =", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceNotEqualTo(String value) {
            addCriterion("total_price <>", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceGreaterThan(String value) {
            addCriterion("total_price >", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceGreaterThanOrEqualTo(String value) {
            addCriterion("total_price >=", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceLessThan(String value) {
            addCriterion("total_price <", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceLessThanOrEqualTo(String value) {
            addCriterion("total_price <=", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceLike(String value) {
            addCriterion("total_price like", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceNotLike(String value) {
            addCriterion("total_price not like", value, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceIn(List<String> values) {
            addCriterion("total_price in", values, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceNotIn(List<String> values) {
            addCriterion("total_price not in", values, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceBetween(String value1, String value2) {
            addCriterion("total_price between", value1, value2, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andTotalPriceNotBetween(String value1, String value2) {
            addCriterion("total_price not between", value1, value2, "totalPrice");
            return (Criteria) this;
        }

        public Criteria andFileIdIsNull() {
            addCriterion("file_id is null");
            return (Criteria) this;
        }

        public Criteria andFileIdIsNotNull() {
            addCriterion("file_id is not null");
            return (Criteria) this;
        }

        public Criteria andFileIdEqualTo(String value) {
            addCriterion("file_id =", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotEqualTo(String value) {
            addCriterion("file_id <>", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdGreaterThan(String value) {
            addCriterion("file_id >", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdGreaterThanOrEqualTo(String value) {
            addCriterion("file_id >=", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLessThan(String value) {
            addCriterion("file_id <", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLessThanOrEqualTo(String value) {
            addCriterion("file_id <=", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLike(String value) {
            addCriterion("file_id like", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotLike(String value) {
            addCriterion("file_id not like", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdIn(List<String> values) {
            addCriterion("file_id in", values, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotIn(List<String> values) {
            addCriterion("file_id not in", values, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdBetween(String value1, String value2) {
            addCriterion("file_id between", value1, value2, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotBetween(String value1, String value2) {
            addCriterion("file_id not between", value1, value2, "fileId");
            return (Criteria) this;
        }

        public Criteria andFlowIdIsNull() {
            addCriterion("flow_id is null");
            return (Criteria) this;
        }

        public Criteria andFlowIdIsNotNull() {
            addCriterion("flow_id is not null");
            return (Criteria) this;
        }

        public Criteria andFlowIdEqualTo(String value) {
            addCriterion("flow_id =", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotEqualTo(String value) {
            addCriterion("flow_id <>", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdGreaterThan(String value) {
            addCriterion("flow_id >", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdGreaterThanOrEqualTo(String value) {
            addCriterion("flow_id >=", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLessThan(String value) {
            addCriterion("flow_id <", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLessThanOrEqualTo(String value) {
            addCriterion("flow_id <=", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLike(String value) {
            addCriterion("flow_id like", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotLike(String value) {
            addCriterion("flow_id not like", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdIn(List<String> values) {
            addCriterion("flow_id in", values, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotIn(List<String> values) {
            addCriterion("flow_id not in", values, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdBetween(String value1, String value2) {
            addCriterion("flow_id between", value1, value2, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotBetween(String value1, String value2) {
            addCriterion("flow_id not between", value1, value2, "flowId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdIsNull() {
            addCriterion("upload_file_id is null");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdIsNotNull() {
            addCriterion("upload_file_id is not null");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdEqualTo(String value) {
            addCriterion("upload_file_id =", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdNotEqualTo(String value) {
            addCriterion("upload_file_id <>", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdGreaterThan(String value) {
            addCriterion("upload_file_id >", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdGreaterThanOrEqualTo(String value) {
            addCriterion("upload_file_id >=", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdLessThan(String value) {
            addCriterion("upload_file_id <", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdLessThanOrEqualTo(String value) {
            addCriterion("upload_file_id <=", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdLike(String value) {
            addCriterion("upload_file_id like", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdNotLike(String value) {
            addCriterion("upload_file_id not like", value, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdIn(List<String> values) {
            addCriterion("upload_file_id in", values, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdNotIn(List<String> values) {
            addCriterion("upload_file_id not in", values, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdBetween(String value1, String value2) {
            addCriterion("upload_file_id between", value1, value2, "uploadFileId");
            return (Criteria) this;
        }

        public Criteria andUploadFileIdNotBetween(String value1, String value2) {
            addCriterion("upload_file_id not between", value1, value2, "uploadFileId");
            return (Criteria) this;
        }
    }

    /**
     * pm_task_info
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_task_info null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}