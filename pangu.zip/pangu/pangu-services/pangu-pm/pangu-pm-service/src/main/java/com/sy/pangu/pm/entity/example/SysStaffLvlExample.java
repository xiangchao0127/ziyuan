package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class SysStaffLvlExample {
    /**
     * sys_staff_lvl
     */
    protected String orderByClause;

    /**
     * sys_staff_lvl
     */
    protected boolean distinct;

    /**
     * sys_staff_lvl
     */
    protected List<Criteria> oredCriteria;

    public SysStaffLvlExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * sys_staff_lvl null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLvlNumIsNull() {
            addCriterion("lvl_num is null");
            return (Criteria) this;
        }

        public Criteria andLvlNumIsNotNull() {
            addCriterion("lvl_num is not null");
            return (Criteria) this;
        }

        public Criteria andLvlNumEqualTo(Integer value) {
            addCriterion("lvl_num =", value, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumNotEqualTo(Integer value) {
            addCriterion("lvl_num <>", value, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumGreaterThan(Integer value) {
            addCriterion("lvl_num >", value, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("lvl_num >=", value, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumLessThan(Integer value) {
            addCriterion("lvl_num <", value, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumLessThanOrEqualTo(Integer value) {
            addCriterion("lvl_num <=", value, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumIn(List<Integer> values) {
            addCriterion("lvl_num in", values, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumNotIn(List<Integer> values) {
            addCriterion("lvl_num not in", values, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumBetween(Integer value1, Integer value2) {
            addCriterion("lvl_num between", value1, value2, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNumNotBetween(Integer value1, Integer value2) {
            addCriterion("lvl_num not between", value1, value2, "lvlNum");
            return (Criteria) this;
        }

        public Criteria andLvlNameIsNull() {
            addCriterion("lvl_name is null");
            return (Criteria) this;
        }

        public Criteria andLvlNameIsNotNull() {
            addCriterion("lvl_name is not null");
            return (Criteria) this;
        }

        public Criteria andLvlNameEqualTo(String value) {
            addCriterion("lvl_name =", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameNotEqualTo(String value) {
            addCriterion("lvl_name <>", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameGreaterThan(String value) {
            addCriterion("lvl_name >", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameGreaterThanOrEqualTo(String value) {
            addCriterion("lvl_name >=", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameLessThan(String value) {
            addCriterion("lvl_name <", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameLessThanOrEqualTo(String value) {
            addCriterion("lvl_name <=", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameLike(String value) {
            addCriterion("lvl_name like", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameNotLike(String value) {
            addCriterion("lvl_name not like", value, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameIn(List<String> values) {
            addCriterion("lvl_name in", values, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameNotIn(List<String> values) {
            addCriterion("lvl_name not in", values, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameBetween(String value1, String value2) {
            addCriterion("lvl_name between", value1, value2, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlNameNotBetween(String value1, String value2) {
            addCriterion("lvl_name not between", value1, value2, "lvlName");
            return (Criteria) this;
        }

        public Criteria andLvlTypeIsNull() {
            addCriterion("lvl_type is null");
            return (Criteria) this;
        }

        public Criteria andLvlTypeIsNotNull() {
            addCriterion("lvl_type is not null");
            return (Criteria) this;
        }

        public Criteria andLvlTypeEqualTo(String value) {
            addCriterion("lvl_type =", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeNotEqualTo(String value) {
            addCriterion("lvl_type <>", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeGreaterThan(String value) {
            addCriterion("lvl_type >", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeGreaterThanOrEqualTo(String value) {
            addCriterion("lvl_type >=", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeLessThan(String value) {
            addCriterion("lvl_type <", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeLessThanOrEqualTo(String value) {
            addCriterion("lvl_type <=", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeLike(String value) {
            addCriterion("lvl_type like", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeNotLike(String value) {
            addCriterion("lvl_type not like", value, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeIn(List<String> values) {
            addCriterion("lvl_type in", values, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeNotIn(List<String> values) {
            addCriterion("lvl_type not in", values, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeBetween(String value1, String value2) {
            addCriterion("lvl_type between", value1, value2, "lvlType");
            return (Criteria) this;
        }

        public Criteria andLvlTypeNotBetween(String value1, String value2) {
            addCriterion("lvl_type not between", value1, value2, "lvlType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNull() {
            addCriterion("task_type is null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIsNotNull() {
            addCriterion("task_type is not null");
            return (Criteria) this;
        }

        public Criteria andTaskTypeEqualTo(String value) {
            addCriterion("task_type =", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotEqualTo(String value) {
            addCriterion("task_type <>", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThan(String value) {
            addCriterion("task_type >", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeGreaterThanOrEqualTo(String value) {
            addCriterion("task_type >=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThan(String value) {
            addCriterion("task_type <", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLessThanOrEqualTo(String value) {
            addCriterion("task_type <=", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeLike(String value) {
            addCriterion("task_type like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotLike(String value) {
            addCriterion("task_type not like", value, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeIn(List<String> values) {
            addCriterion("task_type in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotIn(List<String> values) {
            addCriterion("task_type not in", values, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeBetween(String value1, String value2) {
            addCriterion("task_type between", value1, value2, "taskType");
            return (Criteria) this;
        }

        public Criteria andTaskTypeNotBetween(String value1, String value2) {
            addCriterion("task_type not between", value1, value2, "taskType");
            return (Criteria) this;
        }
    }

    /**
     * sys_staff_lvl
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * sys_staff_lvl null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}