package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.Comparator;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/30 9:16
 */
@Data
public class UserCandidateVo {
    private String staffNum;
    private String chnName;
    private String staffLvl;
    private String workType;
    private String domain;
    private String unitPrice;
    private String lastWorkLoad;

    public Comparator<UserCandidateVo> getSorted(String columns, String sorted) {
        Comparator comparator;
        switch (columns) {
            case "staffNum":
                comparator = Comparator.comparing(UserCandidateVo::getStaffNum);
                break;
            case "chnName":
                comparator = Comparator.comparing(UserCandidateVo::getChnName);
                break;
            case "staffLvl":
                comparator = Comparator.comparing(UserCandidateVo::getStaffLvl);
                break;
            default:
                comparator = Comparator.comparing(UserCandidateVo::getStaffLvl);
        }
        return comparator;
    }
}
