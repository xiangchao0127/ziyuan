package com.sy.pangu.pm.utils.enumpackage;

/**
 * @author L00928
 */
public enum OrderTypeEnum {

    /**
     * 提供工作类型选择，暂时包含以下4种：文档，证件，图书，非译类型
     */
    DOC_TRANS("1", "文档翻译"),

    CER_TRANS("2", "证件翻译"),

    BOOK_TRANS("3", "图书翻译"),

    NONE_TRANS("4", "非译"),

    CUS_LVL_NORMAL("0", "普通客户"),

    CUS_LVL_IMP("1", "重要客户"),

    CUS_LVL_BIG("2", "大客户"),

    CUS_LVL_VIP("3", "VIP客户"),

    ORDER_LVL_NORMAL("0", "标准级"),

    ORDER_LVL_IMP("1", "专业级"),

    ORDER_LVL_BIG("2", "出版级");

    private String value;
    private String desc;

    OrderTypeEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByValue(String value) {

        for(OrderTypeEnum data : OrderTypeEnum.values()) {
            if(data.getValue().equals(value)) {
                return data.desc;
            }
        }

        return "未知类型";
    }

    public static void main(String[] args) {

        System.out.println(getDescByValue("01"));
    }
}
