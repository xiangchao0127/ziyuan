package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class PmTaskDataExample {
    /**
     * pm_task_data
     */
    protected String orderByClause;

    /**
     * pm_task_data
     */
    protected boolean distinct;

    /**
     * pm_task_data
     */
    protected List<Criteria> oredCriteria;

    public PmTaskDataExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_task_data null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andProjectIdIsNull() {
            addCriterion("project_id is null");
            return (Criteria) this;
        }

        public Criteria andProjectIdIsNotNull() {
            addCriterion("project_id is not null");
            return (Criteria) this;
        }

        public Criteria andProjectIdEqualTo(String value) {
            addCriterion("project_id =", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotEqualTo(String value) {
            addCriterion("project_id <>", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdGreaterThan(String value) {
            addCriterion("project_id >", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdGreaterThanOrEqualTo(String value) {
            addCriterion("project_id >=", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdLessThan(String value) {
            addCriterion("project_id <", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdLessThanOrEqualTo(String value) {
            addCriterion("project_id <=", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdLike(String value) {
            addCriterion("project_id like", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotLike(String value) {
            addCriterion("project_id not like", value, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdIn(List<String> values) {
            addCriterion("project_id in", values, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotIn(List<String> values) {
            addCriterion("project_id not in", values, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdBetween(String value1, String value2) {
            addCriterion("project_id between", value1, value2, "projectId");
            return (Criteria) this;
        }

        public Criteria andProjectIdNotBetween(String value1, String value2) {
            addCriterion("project_id not between", value1, value2, "projectId");
            return (Criteria) this;
        }

        public Criteria andFileIdIsNull() {
            addCriterion("file_id is null");
            return (Criteria) this;
        }

        public Criteria andFileIdIsNotNull() {
            addCriterion("file_id is not null");
            return (Criteria) this;
        }

        public Criteria andFileIdEqualTo(Integer value) {
            addCriterion("file_id =", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotEqualTo(Integer value) {
            addCriterion("file_id <>", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdGreaterThan(Integer value) {
            addCriterion("file_id >", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("file_id >=", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLessThan(Integer value) {
            addCriterion("file_id <", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLessThanOrEqualTo(Integer value) {
            addCriterion("file_id <=", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdIn(List<Integer> values) {
            addCriterion("file_id in", values, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotIn(List<Integer> values) {
            addCriterion("file_id not in", values, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdBetween(Integer value1, Integer value2) {
            addCriterion("file_id between", value1, value2, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotBetween(Integer value1, Integer value2) {
            addCriterion("file_id not between", value1, value2, "fileId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("task_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("task_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("task_id =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("task_id <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("task_id >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_id >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("task_id <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("task_id <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("task_id like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("task_id not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("task_id in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("task_id not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("task_id between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("task_id not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andActualWordNumIsNull() {
            addCriterion("actual_word_num is null");
            return (Criteria) this;
        }

        public Criteria andActualWordNumIsNotNull() {
            addCriterion("actual_word_num is not null");
            return (Criteria) this;
        }

        public Criteria andActualWordNumEqualTo(Integer value) {
            addCriterion("actual_word_num =", value, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumNotEqualTo(Integer value) {
            addCriterion("actual_word_num <>", value, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumGreaterThan(Integer value) {
            addCriterion("actual_word_num >", value, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("actual_word_num >=", value, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumLessThan(Integer value) {
            addCriterion("actual_word_num <", value, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumLessThanOrEqualTo(Integer value) {
            addCriterion("actual_word_num <=", value, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumIn(List<Integer> values) {
            addCriterion("actual_word_num in", values, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumNotIn(List<Integer> values) {
            addCriterion("actual_word_num not in", values, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumBetween(Integer value1, Integer value2) {
            addCriterion("actual_word_num between", value1, value2, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andActualWordNumNotBetween(Integer value1, Integer value2) {
            addCriterion("actual_word_num not between", value1, value2, "actualWordNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumIsNull() {
            addCriterion("duplicate_num is null");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumIsNotNull() {
            addCriterion("duplicate_num is not null");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumEqualTo(Integer value) {
            addCriterion("duplicate_num =", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumNotEqualTo(Integer value) {
            addCriterion("duplicate_num <>", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumGreaterThan(Integer value) {
            addCriterion("duplicate_num >", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("duplicate_num >=", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumLessThan(Integer value) {
            addCriterion("duplicate_num <", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumLessThanOrEqualTo(Integer value) {
            addCriterion("duplicate_num <=", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumIn(List<Integer> values) {
            addCriterion("duplicate_num in", values, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumNotIn(List<Integer> values) {
            addCriterion("duplicate_num not in", values, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumBetween(Integer value1, Integer value2) {
            addCriterion("duplicate_num between", value1, value2, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumNotBetween(Integer value1, Integer value2) {
            addCriterion("duplicate_num not between", value1, value2, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumIsNull() {
            addCriterion("translation_num is null");
            return (Criteria) this;
        }

        public Criteria andTranslationNumIsNotNull() {
            addCriterion("translation_num is not null");
            return (Criteria) this;
        }

        public Criteria andTranslationNumEqualTo(Integer value) {
            addCriterion("translation_num =", value, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumNotEqualTo(Integer value) {
            addCriterion("translation_num <>", value, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumGreaterThan(Integer value) {
            addCriterion("translation_num >", value, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("translation_num >=", value, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumLessThan(Integer value) {
            addCriterion("translation_num <", value, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumLessThanOrEqualTo(Integer value) {
            addCriterion("translation_num <=", value, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumIn(List<Integer> values) {
            addCriterion("translation_num in", values, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumNotIn(List<Integer> values) {
            addCriterion("translation_num not in", values, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumBetween(Integer value1, Integer value2) {
            addCriterion("translation_num between", value1, value2, "translationNum");
            return (Criteria) this;
        }

        public Criteria andTranslationNumNotBetween(Integer value1, Integer value2) {
            addCriterion("translation_num not between", value1, value2, "translationNum");
            return (Criteria) this;
        }
    }

    /**
     * pm_task_data
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_task_data null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}