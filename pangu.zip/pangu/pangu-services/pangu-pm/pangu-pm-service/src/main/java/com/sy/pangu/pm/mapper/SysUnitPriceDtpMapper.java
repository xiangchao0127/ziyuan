package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.SysUnitPriceDtp;
import com.sy.pangu.pm.entity.example.SysUnitPriceDtpExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysUnitPriceDtpMapper {
    long countByExample(SysUnitPriceDtpExample example);

    int deleteByExample(SysUnitPriceDtpExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysUnitPriceDtp record);

    int insertSelective(SysUnitPriceDtp record);

    List<SysUnitPriceDtp> selectByExample(SysUnitPriceDtpExample example);

    SysUnitPriceDtp selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysUnitPriceDtp record, @Param("example") SysUnitPriceDtpExample example);

    int updateByExample(@Param("record") SysUnitPriceDtp record, @Param("example") SysUnitPriceDtpExample example);

    int updateByPrimaryKeySelective(SysUnitPriceDtp record);

    int updateByPrimaryKey(SysUnitPriceDtp record);

    String selectUnitByType(String unitType);
}