package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 9:48
 */
@Data
public class ExcelParam {

    /**
     * 是否提取批注
     */
    private int excelComment;
    /**
     * 是否提取隐藏内容
     */
    private int excelHidden;
    /**
     * 是否提取隐藏属性
     */
    private int excelProperty;
    /**
     * 是否提取sheetName
     */
    private int excelSheetName;

    public ExcelParam() {
        this.excelComment = 0;
        this.excelHidden = 0;
        this.excelProperty = 0;
        this.excelSheetName = 0;
    }
}
