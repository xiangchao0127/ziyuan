package com.sy.pangu.pm.entity;

import java.util.List;

public class PmTaskInfo implements Cloneable{
    /**
     * 
     */
    private Integer id;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 任务包ID
     */
    private String taskPackageId;

    /**
     * 任务名
     */
    private String taskName;

    /**
     * 任务类型
     */
    private String taskType;

    /**
     * 任务状态
     */
    private String taskStatus;

    /**
     * 对应员工
     */
    private String staffNum;

    /**
     * 开始时间
     */
    private String startTime;

    /**
     * 要求完成时间
     */
    private String requireTime;

    /**
     * 实际完成时间
     */
    private String realCompletTime;

    /**
     * 分配时间
     */
    private String distributionTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 工作量
     */
    private String workLoad;

    /**
     * 实际工作量
     */
    private String realWorkLoad;

    /**
     * 是否已超时？
     */
    private String isoverTime;

    /**
     * 工作类型(是否协同)
     */
    private String workType;

    /**
     * 评价分数
     */
    private String evaluate;

    /**
     * 币种
     */
    private String currencyType;

    /**
     * 总价
     */
    private String totalPrice;

    /**
     * 原文ID
     */
    private String fileId;

    /**
     * 流程节点id
     */
    private String flowId;

    /**
     * 上传文件ID
     */
    private String uploadFileId;

    //
    /**
     * 要求完成时间-开始
     */
    private String requireEndtimeS;
    /**
     * 要求完成时间-结束
     */
    private String requireEndtimeE;

    /**
     * 项目名称
     */
    private String projectName;

    public String getRequireEndtimeS() {
        return requireEndtimeS;
    }

    public void setRequireEndtimeS(String requireEndtimeS) {
        this.requireEndtimeS = requireEndtimeS;
    }

    public String getRequireEndtimeE() {
        return requireEndtimeE;
    }

    public void setRequireEndtimeE(String requireEndtimeE) {
        this.requireEndtimeE = requireEndtimeE;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId == null ? null : projectId.trim();
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getTaskPackageId() {
        return taskPackageId;
    }

    public void setTaskPackageId(String taskPackageId) {
        this.taskPackageId = taskPackageId == null ? null : taskPackageId.trim();
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName == null ? null : taskName.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus == null ? null : taskStatus.trim();
    }

    public String getStaffNum() {
        return staffNum;
    }

    public void setStaffNum(String staffNum) {
        this.staffNum = staffNum == null ? null : staffNum.trim();
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime == null ? null : startTime.trim();
    }

    public String getRequireTime() {
        return requireTime;
    }

    public void setRequireTime(String requireTime) {
        this.requireTime = requireTime == null ? null : requireTime.trim();
    }

    public String getRealCompletTime() {
        return realCompletTime;
    }

    public void setRealCompletTime(String realCompletTime) {
        this.realCompletTime = realCompletTime == null ? null : realCompletTime.trim();
    }

    public String getDistributionTime() {
        return distributionTime;
    }

    public void setDistributionTime(String distributionTime) {
        this.distributionTime = distributionTime == null ? null : distributionTime.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getWorkLoad() {
        return workLoad;
    }

    public void setWorkLoad(String workLoad) {
        this.workLoad = workLoad == null ? null : workLoad.trim();
    }

    public String getRealWorkLoad() {
        return realWorkLoad;
    }

    public void setRealWorkLoad(String realWorkLoad) {
        this.realWorkLoad = realWorkLoad == null ? null : realWorkLoad.trim();
    }

    public String getIsoverTime() {
        return isoverTime;
    }

    public void setIsoverTime(String isoverTime) {
        this.isoverTime = isoverTime == null ? null : isoverTime.trim();
    }

    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType == null ? null : workType.trim();
    }

    public String getEvaluate() {
        return evaluate;
    }

    public void setEvaluate(String evaluate) {
        this.evaluate = evaluate == null ? null : evaluate.trim();
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType == null ? null : currencyType.trim();
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice == null ? null : totalPrice.trim();
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId == null ? null : fileId.trim();
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId == null ? null : flowId.trim();
    }

    public String getUploadFileId() {
        return uploadFileId;
    }

    public void setUploadFileId(String uploadFileId) {
        this.uploadFileId = uploadFileId == null ? null : uploadFileId.trim();
    }

    public Object clone() {
        Object o = null;
        try {
            o = super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return o;
    }
}