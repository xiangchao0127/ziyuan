package com.sy.pangu.pm.entity;

public class PmProjectInfo {
    /**
     * 
     */
    private Integer id;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 责任类型/众包0，统管1
     */
    private String responsibilityType;

    /**
     * 客户id
     */
    private String customerId;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 预估字数
     */
    private String estimateWord;

    /**
     * 质量等级/订单等级（标准0，出版级1，职业母审2）
     */
    private String qualityGrade;

    /**
     * 订单类型 /稿件类型  （文档翻译0，证件翻译1，图书翻译2，非译订单3）
     */
    private String orderType;

    /**
     * 订单备注
     */
    private String orderRemake;

    /**
     * 源语种
     */
    private String sourceLan;

    /**
     * 源语种名字
     */
    private String sourceLanName;

    /**
     * 目标语种
     */
    private String targetLan;
    /**
     * 目标语种名字
     */
    private String targetLanName;

    /**
     * 下单人
     */
    private String orderPeople;

    /**
     * 下单时间
     */
    private String orderTime;

    /**
     * 返稿时间
     */
    private String deliveryTime;

    /**
     * 匹配pm
     */
    private String pmId;
    /**
     * 项目经理名字
     */
    private String pmName;
    /**
     * 匹配翻译经理
     */
    private String tranmgrId;
    /**
     * 翻译经理名字
     */
    private String tranmgrName;
    /**
     * 线上线下   1线上 0线下
     */
    private Boolean isOnline;

    /**
     * 状态 0待分配 、 1分配中、2已分配，3待交付， 4正常完成，5项目终止
     */
    private String projectType;

    /**
     * 实际完成时间
     */
    private String realityHandfileTime;

    /**
     * 专业领域
     */
    private String domain;
    /**
     * 领域名字
     */
    private String domainName;

    public String getSourceLanName() {
        return sourceLanName;
    }

    public void setSourceLanName(String sourceLanName) {
        this.sourceLanName = sourceLanName;
    }

    public String getTargetLanName() {
        return targetLanName;
    }

    public void setTargetLanName(String targetLanName) {
        this.targetLanName = targetLanName;
    }

    public String getPmName() {
        return pmName;
    }

    public void setPmName(String pmName) {
        this.pmName = pmName;
    }

    public String getTranmgrName() {
        return tranmgrName;
    }

    public void setTranmgrName(String tranmgrName) {
        this.tranmgrName = tranmgrName;
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId == null ? null : projectId.trim();
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName == null ? null : projectName.trim();
    }

    public String getResponsibilityType() {
        return responsibilityType;
    }

    public void setResponsibilityType(String responsibilityType) {
        this.responsibilityType = responsibilityType == null ? null : responsibilityType.trim();
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId == null ? null : customerId.trim();
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName == null ? null : customerName.trim();
    }

    public String getEstimateWord() {
        return estimateWord;
    }

    public void setEstimateWord(String estimateWord) {
        this.estimateWord = estimateWord == null ? null : estimateWord.trim();
    }

    public String getQualityGrade() {
        return qualityGrade;
    }

    public void setQualityGrade(String qualityGrade) {
        this.qualityGrade = qualityGrade == null ? null : qualityGrade.trim();
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType == null ? null : orderType.trim();
    }

    public String getOrderRemake() {
        return orderRemake;
    }

    public void setOrderRemake(String orderRemake) {
        this.orderRemake = orderRemake == null ? null : orderRemake.trim();
    }

    public String getSourceLan() {
        return sourceLan;
    }

    public void setSourceLan(String sourceLan) {
        this.sourceLan = sourceLan == null ? null : sourceLan.trim();
    }

    public String getTargetLan() {
        return targetLan;
    }

    public void setTargetLan(String targetLan) {
        this.targetLan = targetLan == null ? null : targetLan.trim();
    }

    public String getOrderPeople() {
        return orderPeople;
    }

    public void setOrderPeople(String orderPeople) {
        this.orderPeople = orderPeople == null ? null : orderPeople.trim();
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime == null ? null : orderTime.trim();
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime == null ? null : deliveryTime.trim();
    }

    public String getPmId() {
        return pmId;
    }

    public void setPmId(String pmId) {
        this.pmId = pmId == null ? null : pmId.trim();
    }

    public String getTranmgrId() {
        return tranmgrId;
    }

    public void setTranmgrId(String tranmgrId) {
        this.tranmgrId = tranmgrId == null ? null : tranmgrId.trim();
    }

    public Boolean getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline) {
        this.isOnline = isOnline;
    }

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType == null ? null : projectType.trim();
    }

    public String getRealityHandfileTime() {
        return realityHandfileTime;
    }

    public void setRealityHandfileTime(String realityHandfileTime) {
        this.realityHandfileTime = realityHandfileTime == null ? null : realityHandfileTime.trim();
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain == null ? null : domain.trim();
    }
}