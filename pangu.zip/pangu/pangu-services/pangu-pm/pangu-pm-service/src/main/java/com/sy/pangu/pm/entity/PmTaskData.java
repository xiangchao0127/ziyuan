package com.sy.pangu.pm.entity;

public class PmTaskData {
    /**
     * 
     */
    private Integer id;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 文件id
     */
    private Integer fileId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 原文实际字数
     */
    private Integer actualWordNum;

    /**
     * 原文去重字数
     */
    private Integer duplicateNum;

    /**
     * 译文字数
     */
    private Integer translationNum;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId == null ? null : projectId.trim();
    }

    public Integer getFileId() {
        return fileId;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public Integer getActualWordNum() {
        return actualWordNum;
    }

    public void setActualWordNum(Integer actualWordNum) {
        this.actualWordNum = actualWordNum;
    }

    public Integer getDuplicateNum() {
        return duplicateNum;
    }

    public void setDuplicateNum(Integer duplicateNum) {
        this.duplicateNum = duplicateNum;
    }

    public Integer getTranslationNum() {
        return translationNum;
    }

    public void setTranslationNum(Integer translationNum) {
        this.translationNum = translationNum;
    }
}