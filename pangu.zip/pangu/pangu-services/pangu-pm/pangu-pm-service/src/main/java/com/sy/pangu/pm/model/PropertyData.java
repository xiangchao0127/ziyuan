package com.sy.pangu.pm.model;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author ：jzj
 * @date ：Created in 2019/5/15 9:17
 */
@Data
public class PropertyData {
    private String upfileHost;
    private int upfilePort;
    private String upfileUsername;
    private String upfilePassword;

    public PropertyData(String upfileHost, int upfilePort, String upfileUsername, String upfilePassword) {
        this.upfileHost = upfileHost;
        this.upfilePort = upfilePort;
        this.upfileUsername = upfileUsername;
        this.upfilePassword = upfilePassword;
    }
}
