package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmBlockInfo;
import com.sy.pangu.pm.entity.example.PmBlockInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmBlockInfoMapper {
    long countByExample(PmBlockInfoExample example);

    int deleteByExample(PmBlockInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmBlockInfo record);

    int insertSelective(PmBlockInfo record);

    List<PmBlockInfo> selectByExample(PmBlockInfoExample example);

    PmBlockInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmBlockInfo record, @Param("example") PmBlockInfoExample example);

    int updateByExample(@Param("record") PmBlockInfo record, @Param("example") PmBlockInfoExample example);

    int updateByPrimaryKeySelective(PmBlockInfo record);

    int updateByPrimaryKey(PmBlockInfo record);

    List<PmBlockInfo> ListBolckByPackage(String packageIDList);

    List<PmBlockInfo> ListBolckByPackageAndFid(String packageIDList,String fileID);

    void deleteBolckByPackage(String packageIDList);

    void updateBolckByPackageid(int maxIndex, String taskPackageId);

    PmBlockInfo getBlockBypackage(String blockId);

    List<PmBlockInfo> ListBolckByfileID(String fileID);
}