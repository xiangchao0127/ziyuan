package com.sy.pangu.pm.service;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/23 13:49
 */
public interface CommonService {

}
