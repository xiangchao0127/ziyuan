package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/29 17:15
 */
@Data
public class UserQueryVo {
    private String groupId;
    private String workType;
    private String staffLevel;
    private String domain;
    private String sourceLanguage;
    private String targetLanguage;
    private String staffName;
    private String roleCode;
}
