package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 9:47
 */
@Data
public class FileInfo {
    private String fileId;
    private String fileName;
    private String filePath;
}
