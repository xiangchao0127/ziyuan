package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.SysTransmanagerInfo;
import java.util.List;

import com.sy.pangu.pm.entity.example.SysTransmanagerInfoExample;
import com.sy.pangu.pm.utils.PageUtil;
import org.apache.ibatis.annotations.Param;

public interface SysTransmanagerInfoMapper {
    long countByExample(SysTransmanagerInfoExample example);

    int deleteByExample(SysTransmanagerInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysTransmanagerInfo record);

    int insertSelective(SysTransmanagerInfo record);

    List<SysTransmanagerInfo> selectByExample(SysTransmanagerInfoExample example);

    SysTransmanagerInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysTransmanagerInfo record, @Param("example") SysTransmanagerInfoExample example);

    int updateByExample(@Param("record") SysTransmanagerInfo record, @Param("example") SysTransmanagerInfoExample example);

    int updateByPrimaryKeySelective(SysTransmanagerInfo record);

    int updateByPrimaryKey(SysTransmanagerInfo record);

    List<SysTransmanagerInfo> selectByPage(PageUtil pageUtil);
}