package com.sy.pangu.pm.service.impl;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.SysUnitPriceDtp;
import com.sy.pangu.pm.entity.SysUnitPriceTrans;
import com.sy.pangu.pm.entity.example.SysUnitPriceDtpExample;
import com.sy.pangu.pm.entity.example.SysUnitPriceTransExample;
import com.sy.pangu.pm.mapper.SysUnitPriceDtpMapper;
import com.sy.pangu.pm.mapper.SysUnitPriceTransMapper;
import com.sy.pangu.pm.service.UnitPriceService;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/16 11:30
 */
@Service("unitService")
public class UnitServiceImpl implements UnitPriceService {

    @Autowired
    private SysUnitPriceTransMapper unitPriceTransMapper;

    @Autowired
    private SysUnitPriceDtpMapper unitPriceDtpMapper;

    /**
     * 新增一条单价数据（翻译）
     * @param unitPriceTrans
     * @return
     */
    @Override
    public int saveUnitPriceTrans(SysUnitPriceTrans unitPriceTrans) {
        return unitPriceTransMapper.insert(unitPriceTrans);
    }

    /**
     * 修改单价数据（翻译）
     * @param unitPriceTrans
     * @return
     */
    @Override
    public int updateUnitPriceTrans(SysUnitPriceTrans unitPriceTrans) {
        return unitPriceTransMapper.updateByPrimaryKeySelective(unitPriceTrans);
    }

    /**
     * 查询单价数据
     * @param taskType 工作类型（翻译，审校，质检）
     * @param staffType 译员类型（专职，兼职）
     * @return
     */
    @Override
    public List<SysUnitPriceTrans> listUnitPriceTrans(String taskType, String staffType) {
        SysUnitPriceTransExample example = new SysUnitPriceTransExample();
        example.createCriteria()
                .andTaskTypeEqualTo(taskType)
                .andStaffTypeEqualTo(staffType);
        return unitPriceTransMapper.selectByExample(example);
    }

    /**
     * dtp工价
     * @return
     */
    @Override
    public int saveUnitPriceDTP(SysUnitPriceDtp unitPriceDtp) {
        unitPriceDtp.setDataChar1(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
        return unitPriceDtpMapper.insert(unitPriceDtp);
    }

    @Override
    public int updateUnitPriceDtp(SysUnitPriceDtp unitPriceDtp) {
        return unitPriceDtpMapper.updateByPrimaryKeySelective(unitPriceDtp);
    }

    @Override
    public List<SysUnitPriceDtp> listUnitPriceDtp(String taskType) {
        SysUnitPriceDtpExample example = new SysUnitPriceDtpExample();
        example.createCriteria()
                .andDataChar1EqualTo(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
        return unitPriceDtpMapper.selectByExample(example);
    }

    /**
     * 排版工价
     * @return
     */
    @Override
    public int saveUnitPriceTypeSetting(SysUnitPriceDtp unitPriceDtp) {
        if (StringUtils.isEmpty(unitPriceDtp.getDataChar1())) {
            return 0;
        }
        SysUnitPriceDtpExample example = new SysUnitPriceDtpExample();
        example.createCriteria()
                .andDataChar1EqualTo(StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue());
        return unitPriceDtpMapper.updateByExampleSelective(unitPriceDtp, example);
    }

    @Override
    public List<SysUnitPriceDtp> listUnitPriceTypeSetting() {
        SysUnitPriceDtpExample example = new SysUnitPriceDtpExample();
        example.createCriteria()
                .andDataChar1EqualTo(StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue());
        return unitPriceDtpMapper.selectByExample(example);
    }
}
