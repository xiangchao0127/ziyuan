package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.example.PmFileExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmFileMapper {
    long countByExample(PmFileExample example);

    int deleteByExample(PmFileExample example);

    int deleteByPrimaryKey(Integer fileId);

    int insert(PmFile record);

    int insertSelective(PmFile record);

    List<PmFile> selectByExample(PmFileExample example);

    PmFile selectByPrimaryKey(Integer fileId);

    int updateByExampleSelective(@Param("record") PmFile record, @Param("example") PmFileExample example);

    int updateByExample(@Param("record") PmFile record, @Param("example") PmFileExample example);

    int updateByPrimaryKeySelective(PmFile record);

    int updateByPrimaryKey(PmFile record);

    /**
     * 插入  返回主键
     * @param file
     * @return
     */
    int insertSelectKey(PmFile file);

    /**
     * 获取项目下所有参考文件
     * @param projectId  项目id     *
     */
    List<PmFile> getFileReferenceList(String projectId);

    /**
     * 获取项目下所有参考文件
     * @param fileidList  文件id集合     *
     */
    //项目详情—参考文件--删除参考文件
    int deleteFileReferenceById(String [] fileidList);


    List<PmFile> getProjectFileBypid(@Param("projectId") String projectId, @Param("fileType") String fileType);


}