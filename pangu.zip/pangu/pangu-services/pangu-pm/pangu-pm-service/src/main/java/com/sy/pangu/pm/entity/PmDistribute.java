package com.sy.pangu.pm.entity;

import java.util.Date;

public class PmDistribute {
    /**
     * 
     */
    private Integer id;

    /**
     * 标志属于什么等级的流程路线
     */
    private String flowId;

    /**
     * 专职等级
     */
    private String fullStaffLvl;

    /**
     * 兼职译员的要求等级
     */
    private String freeStaffLvl;

    /**
     * 时间比例
     */
    private Double timePer;

    /**
     * 通知时间
     */
    private String notifyTime;

    /**
     * 属于什么流程节点
     */
    private Integer nodeId;

    /**
     * 
     */
    private String lastEditor;

    /**
     * 
     */
    private Date lastEditTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId == null ? null : flowId.trim();
    }

    public String getFullStaffLvl() {
        return fullStaffLvl;
    }

    public void setFullStaffLvl(String fullStaffLvl) {
        this.fullStaffLvl = fullStaffLvl == null ? null : fullStaffLvl.trim();
    }

    public String getFreeStaffLvl() {
        return freeStaffLvl;
    }

    public void setFreeStaffLvl(String freeStaffLvl) {
        this.freeStaffLvl = freeStaffLvl == null ? null : freeStaffLvl.trim();
    }

    public Double getTimePer() {
        return timePer;
    }

    public void setTimePer(Double timePer) {
        this.timePer = timePer;
    }

    public String getNotifyTime() {
        return notifyTime;
    }

    public void setNotifyTime(String notifyTime) {
        this.notifyTime = notifyTime == null ? null : notifyTime.trim();
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public String getLastEditor() {
        return lastEditor;
    }

    public void setLastEditor(String lastEditor) {
        this.lastEditor = lastEditor == null ? null : lastEditor.trim();
    }

    public Date getLastEditTime() {
        return lastEditTime;
    }

    public void setLastEditTime(Date lastEditTime) {
        this.lastEditTime = lastEditTime;
    }
}