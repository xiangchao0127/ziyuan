package com.sy.pangu.pm.entity;

public class SysMatchingPm {
    /**
     * 
     */
    private Integer id;

    /**
     * 项目经理
     */
    private String pmCode;

    /**
     * 外包处理人员
     */
    private String outerCode;

    /**
     * 领域
     */
    private String domain;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPmCode() {
        return pmCode;
    }

    public void setPmCode(String pmCode) {
        this.pmCode = pmCode == null ? null : pmCode.trim();
    }

    public String getOuterCode() {
        return outerCode;
    }

    public void setOuterCode(String outerCode) {
        this.outerCode = outerCode == null ? null : outerCode.trim();
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain == null ? null : domain.trim();
    }
}