package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.SysMatchingPm;
import com.sy.pangu.pm.entity.example.SysMatchingPmExample;
import com.sy.pangu.pm.utils.PageUtil;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SysMatchingPmMapper {
    long countByExample(SysMatchingPmExample example);

    int deleteByExample(SysMatchingPmExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysMatchingPm record);

    int insertSelective(SysMatchingPm record);

    List<SysMatchingPm> selectByExample(SysMatchingPmExample example);

    SysMatchingPm selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysMatchingPm record, @Param("example") SysMatchingPmExample example);

    int updateByExample(@Param("record") SysMatchingPm record, @Param("example") SysMatchingPmExample example);

    int updateByPrimaryKeySelective(SysMatchingPm record);

    int updateByPrimaryKey(SysMatchingPm record);

    List<SysMatchingPm> selectByPage(PageUtil pageUtil);

}