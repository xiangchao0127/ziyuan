package com.sy.pangu.pm.controller;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.SysUnitPriceDtp;
import com.sy.pangu.pm.entity.SysUnitPriceTrans;
import com.sy.pangu.pm.entity.vo.UnitPriceVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.impl.UnitServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/16 11:27
 */
@RestController
@RequestMapping("/unitprice")
@Api("单价设置")
@CrossOrigin
public class UnitPriceController {

    @Autowired
    private UnitServiceImpl unitService;

    @ApiOperation("设置翻译/审校/质检单价")
    @PostMapping("/saveUnitPriceTrans")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "员工类型，fulltime，freelancer", name = "staffType", required = true),
            @ApiImplicitParam(value = "任务类型：翻译审校质检等", name = "taskType", required = true),
            @ApiImplicitParam(value = "单价对应的等级，专职传等级值，兼职传文档等级", name = "level", required = true),
            @ApiImplicitParam(value = "工作类型：证件图书文档非译等", name = "workType", required = true)}
    )
    public ResultModel saveUnitPriceTrans(UnitPriceVo unitPriceVo) {
        if (StringUtils.isEmpty(unitPriceVo.getLevel())) {
           throw new RuntimeException("请输入等级");
        }
        SysUnitPriceTrans sysUnitPriceTrans = new SysUnitPriceTrans();
        sysUnitPriceTrans.setLevel(unitPriceVo.getLevel());
        sysUnitPriceTrans.setSourceLan(unitPriceVo.getSourceLan());
        sysUnitPriceTrans.setStaffType(unitPriceVo.getStaffType());
        sysUnitPriceTrans.setUnitPrice(unitPriceVo.getUnitPrice());
        sysUnitPriceTrans.setWorkType(unitPriceVo.getWorkType());
        sysUnitPriceTrans.setTargetLan(unitPriceVo.getTargetLan());
        sysUnitPriceTrans.setTaskType(unitPriceVo.getTaskType());
        return ResultModel.SuccessForMsg("",unitService.saveUnitPriceTrans(sysUnitPriceTrans));
    }

    @ApiOperation("修改翻译/审校/质检单价")
    @PostMapping("/updateUnitPriceTrans")
    public ResultModel updateUnitPriceTrans(SysUnitPriceTrans sysUnitPriceTrans) {
        return ResultModel.SuccessForMsg("",unitService.updateUnitPriceTrans(sysUnitPriceTrans));
    }

    @ApiOperation("翻译，审校，质检单价列表")
    @GetMapping("/listUnitPriceTrans")
    public ResultModel listUnitPriceTrans(String taskType, String staffType) {
        return ResultModel.SuccessForMsg("",unitService.listUnitPriceTrans(taskType, staffType));
    }

    @ApiOperation("设置DTP/排版单价")
    @PostMapping("/saveUnitPriceDTP")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "员工类型，fulltime，freelancer", name = "staffType", required = true),
            @ApiImplicitParam(value = "任务类型：翻译审校质检等", name = "taskType", required = true),
            @ApiImplicitParam(value = "单价对应的等级，专职传等级值，兼职传文档等级", name = "level", required = true),
            @ApiImplicitParam(value = "工作类型：证件图书文档非译等", name = "workType", required = true)}
    )
    public ResultModel saveUnitPriceDTP(SysUnitPriceDtp unitPriceDtp) {
        return ResultModel.SuccessForMsg("",unitService.saveUnitPriceDTP(unitPriceDtp));
    }

    @ApiOperation("修改DTP单价")
    @PostMapping("/updateUnitPriceDtp")
    public ResultModel updateUnitPriceDtp(SysUnitPriceDtp unitPriceDtp) {
        return ResultModel.SuccessForMsg("",unitService.updateUnitPriceDtp(unitPriceDtp));
    }

    @ApiOperation("DTP单价列表")
    @PostMapping("/listUnitPriceDtp")
    public ResultModel listUnitPriceDtp(String taskType) {
        return ResultModel.SuccessForMsg("",unitService.listUnitPriceDtp(taskType));
    }

    @ApiOperation("排版列表")
    @PostMapping("/listUnitPriceTypeSetting")
    public ResultModel listUnitPriceTypeSetting() {
        return ResultModel.SuccessForMsg("",unitService.listUnitPriceTypeSetting());
    }

    @ApiOperation("更新排版单价")
    @PostMapping("/saveUnitPriceTypeSetting")
    public ResultModel saveUnitPriceTypeSetting(SysUnitPriceDtp unitPriceDtp) {
        return ResultModel.SuccessForMsg("",unitService.saveUnitPriceTypeSetting(unitPriceDtp));
    }

}
