package com.sy.pangu.pm.entity;

public class PmAutomatching {
    /**
     * 
     */
    private Integer id;

    /**
     * 订单等级
     */
    private String orderLvl;

    /**
     * 
     */
    private String orderType;

    /**
     * 客户类型
     */
    private String cusType;

    /**
     * 预估工作量
     */
    private Integer wordCount;

    /**
     * 是否自动分配
     */
    private Integer useAuto;

    /**
     * 是否匹配pm
     */
    private Integer matchingPm;

    /**
     * 是否匹配翻译经理
     */
    private Integer matchingTranspm;

    /**
     * 是否匹配外包工作人员
     */
    private Integer matchingOutsaler;

    /**
     * 默认翻译工具
     */
    private String defaultCat;

    /**
     * 字数范围(上限）
     */
    private Integer higherCount;

    /**
     * 字数范围(下限）
     */
    private Integer lowerCount;

    /**
     * 
     */
    private String remark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderLvl() {
        return orderLvl;
    }

    public void setOrderLvl(String orderLvl) {
        this.orderLvl = orderLvl == null ? null : orderLvl.trim();
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType == null ? null : orderType.trim();
    }

    public String getCusType() {
        return cusType;
    }

    public void setCusType(String cusType) {
        this.cusType = cusType == null ? null : cusType.trim();
    }

    public Integer getWordCount() {
        return wordCount;
    }

    public void setWordCount(Integer wordCount) {
        this.wordCount = wordCount;
    }

    public Integer getUseAuto() {
        return useAuto;
    }

    public void setUseAuto(Integer useAuto) {
        this.useAuto = useAuto;
    }

    public Integer getMatchingPm() {
        return matchingPm;
    }

    public void setMatchingPm(Integer matchingPm) {
        this.matchingPm = matchingPm;
    }

    public Integer getMatchingTranspm() {
        return matchingTranspm;
    }

    public void setMatchingTranspm(Integer matchingTranspm) {
        this.matchingTranspm = matchingTranspm;
    }

    public Integer getMatchingOutsaler() {
        return matchingOutsaler;
    }

    public void setMatchingOutsaler(Integer matchingOutsaler) {
        this.matchingOutsaler = matchingOutsaler;
    }

    public String getDefaultCat() {
        return defaultCat;
    }

    public void setDefaultCat(String defaultCat) {
        this.defaultCat = defaultCat == null ? null : defaultCat.trim();
    }

    public Integer getHigherCount() {
        return higherCount;
    }

    public void setHigherCount(Integer higherCount) {
        this.higherCount = higherCount;
    }

    public Integer getLowerCount() {
        return lowerCount;
    }

    public void setLowerCount(Integer lowerCount) {
        this.lowerCount = lowerCount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
}