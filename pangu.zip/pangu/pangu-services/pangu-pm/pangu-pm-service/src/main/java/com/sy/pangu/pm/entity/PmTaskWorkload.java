package com.sy.pangu.pm.entity;

public class PmTaskWorkload {
    /**
     * 
     */
    private Integer id;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 工作类型
     */
    private String workType;

    /**
     * 预估工作量
     */
    private String estimateWorkload;

    /**
     * 实际工作量
     */
    private String actualWorkload;

    /**
     * 最后工作量
     */
    private String finalWorkload;

    /**
     * 添加时间
     */
    private String addTime;

    /**
     * 最后修改人
     */
    private String finalModifierid;

    /**
     * 绩效系数
     */
    private String ratio;

    /**
     * 单价
     */
    private String unitPrice;

    /**
     * dtp的类型（列表从dtp单价中取）
     */
    private String dtpType;

    /**
     * 
     */
    private String datachar1;

    /**
     * 
     */
    private String datachar2;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType == null ? null : workType.trim();
    }

    public String getEstimateWorkload() {
        return estimateWorkload;
    }

    public void setEstimateWorkload(String estimateWorkload) {
        this.estimateWorkload = estimateWorkload == null ? null : estimateWorkload.trim();
    }

    public String getActualWorkload() {
        return actualWorkload;
    }

    public void setActualWorkload(String actualWorkload) {
        this.actualWorkload = actualWorkload == null ? null : actualWorkload.trim();
    }

    public String getFinalWorkload() {
        return finalWorkload;
    }

    public void setFinalWorkload(String finalWorkload) {
        this.finalWorkload = finalWorkload == null ? null : finalWorkload.trim();
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime == null ? null : addTime.trim();
    }

    public String getFinalModifierid() {
        return finalModifierid;
    }

    public void setFinalModifierid(String finalModifierid) {
        this.finalModifierid = finalModifierid == null ? null : finalModifierid.trim();
    }

    public String getRatio() {
        return ratio;
    }

    public void setRatio(String ratio) {
        this.ratio = ratio == null ? null : ratio.trim();
    }

    public String getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(String unitPrice) {
        this.unitPrice = unitPrice == null ? null : unitPrice.trim();
    }

    public String getDtpType() {
        return dtpType;
    }

    public void setDtpType(String dtpType) {
        this.dtpType = dtpType == null ? null : dtpType.trim();
    }

    public String getDatachar1() {
        return datachar1;
    }

    public void setDatachar1(String datachar1) {
        this.datachar1 = datachar1 == null ? null : datachar1.trim();
    }

    public String getDatachar2() {
        return datachar2;
    }

    public void setDatachar2(String datachar2) {
        this.datachar2 = datachar2 == null ? null : datachar2.trim();
    }
}