package com.sy.pangu.pm.model;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/

public class TaskFileListModel {
    /**
     *
     */
    private Integer id;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 任务包ID
     */
    private String taskPackageId;

    /**
     * 任务名
     */
    private String taskName;

    /**
     * 任务类型
     */
    private String taskType;

    /**
     * 任务状态
     */
    private String taskStatus;

    /**
     * 对应员工
     */
    private String staffNum;

    /**
     * 开始时间
     */
    private String startTime;

    /**
     * 要求完成时间
     */
    private String requireTime;

    /**
     * 实际完成时间
     */
    private String realCompletTime;

    /**
     * 分配时间
     */
    private String distributionTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 工作量
     */
    private String workLoad;

    /**
     * 实际工作量
     */
    private String realWorkLoad;

    /**
     * 是否已超时？
     */
    private String isoverTime;

    /**
     * 工作类型(是否协同)
     */
    private String workType;

    /**
     * 评价分数
     */
    private String evaluate;

    /**
     * 币种
     */
    private String currencyType;

    /**
     * 总价
     */
    private String totalPrice;

    /**
     * 原文ID
     */
    private String fileId;

    /**
     * 流程节点id
     */
    private String flowId;

    /**
     * 上传文件ID
     */
    private String uploadFileId;

    //
    /**
     * 要求完成时间-开始
     */
    private String requireEndtimeS;
    /**
     * 要求完成时间-结束
     */
    private String requireEndtimeE;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 项目id
     */
    private String projectsId;

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 文件地址
     */
    private String filePath;

    /**
     * 是否删除 0未删 ， 1已删
     */
    private String isDel;

    /**
     * 文件类型
     */
    private String fileType;

    /**
     * 上传时间
     */
    private String uploadTime;

    /**
     * 上传人
     */
    private String uploadSuff;

    /**
     * 文件大小(单位kb)
     */

}
