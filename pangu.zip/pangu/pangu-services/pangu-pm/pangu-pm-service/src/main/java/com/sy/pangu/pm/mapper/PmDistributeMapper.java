package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmDistribute;
import com.sy.pangu.pm.entity.example.PmDistributeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PmDistributeMapper {
    long countByExample(PmDistributeExample example);

    int deleteByExample(PmDistributeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmDistribute record);

    int insertSelective(PmDistribute record);

    int insertBatch(List<PmDistribute> records);

    int updateBatch(List<PmDistribute> records);

    List<PmDistribute> selectByExample(PmDistributeExample example);

    PmDistribute selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmDistribute record, @Param("example") PmDistributeExample example);

    int updateByExample(@Param("record") PmDistribute record, @Param("example") PmDistributeExample example);

    int updateByPrimaryKeySelective(PmDistribute record);

    int updateByPrimaryKey(PmDistribute record);

    List<String> selectId(PmDistributeExample example);

    void deleteByFlowId(String flowId);
}