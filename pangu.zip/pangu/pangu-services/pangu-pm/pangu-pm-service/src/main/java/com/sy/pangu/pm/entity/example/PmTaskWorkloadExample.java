package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class PmTaskWorkloadExample {
    /**
     * pm_task_workload
     */
    protected String orderByClause;

    /**
     * pm_task_workload
     */
    protected boolean distinct;

    /**
     * pm_task_workload
     */
    protected List<Criteria> oredCriteria;

    public PmTaskWorkloadExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_task_workload null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("task_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("task_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("task_id =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("task_id <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("task_id >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_id >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("task_id <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("task_id <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("task_id like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("task_id not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("task_id in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("task_id not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("task_id between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("task_id not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andWorkTypeIsNull() {
            addCriterion("work_type is null");
            return (Criteria) this;
        }

        public Criteria andWorkTypeIsNotNull() {
            addCriterion("work_type is not null");
            return (Criteria) this;
        }

        public Criteria andWorkTypeEqualTo(String value) {
            addCriterion("work_type =", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotEqualTo(String value) {
            addCriterion("work_type <>", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeGreaterThan(String value) {
            addCriterion("work_type >", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeGreaterThanOrEqualTo(String value) {
            addCriterion("work_type >=", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeLessThan(String value) {
            addCriterion("work_type <", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeLessThanOrEqualTo(String value) {
            addCriterion("work_type <=", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeLike(String value) {
            addCriterion("work_type like", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotLike(String value) {
            addCriterion("work_type not like", value, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeIn(List<String> values) {
            addCriterion("work_type in", values, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotIn(List<String> values) {
            addCriterion("work_type not in", values, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeBetween(String value1, String value2) {
            addCriterion("work_type between", value1, value2, "workType");
            return (Criteria) this;
        }

        public Criteria andWorkTypeNotBetween(String value1, String value2) {
            addCriterion("work_type not between", value1, value2, "workType");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadIsNull() {
            addCriterion("estimate_workload is null");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadIsNotNull() {
            addCriterion("estimate_workload is not null");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadEqualTo(String value) {
            addCriterion("estimate_workload =", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadNotEqualTo(String value) {
            addCriterion("estimate_workload <>", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadGreaterThan(String value) {
            addCriterion("estimate_workload >", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadGreaterThanOrEqualTo(String value) {
            addCriterion("estimate_workload >=", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadLessThan(String value) {
            addCriterion("estimate_workload <", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadLessThanOrEqualTo(String value) {
            addCriterion("estimate_workload <=", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadLike(String value) {
            addCriterion("estimate_workload like", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadNotLike(String value) {
            addCriterion("estimate_workload not like", value, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadIn(List<String> values) {
            addCriterion("estimate_workload in", values, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadNotIn(List<String> values) {
            addCriterion("estimate_workload not in", values, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadBetween(String value1, String value2) {
            addCriterion("estimate_workload between", value1, value2, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andEstimateWorkloadNotBetween(String value1, String value2) {
            addCriterion("estimate_workload not between", value1, value2, "estimateWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadIsNull() {
            addCriterion("actual_workload is null");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadIsNotNull() {
            addCriterion("actual_workload is not null");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadEqualTo(String value) {
            addCriterion("actual_workload =", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadNotEqualTo(String value) {
            addCriterion("actual_workload <>", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadGreaterThan(String value) {
            addCriterion("actual_workload >", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadGreaterThanOrEqualTo(String value) {
            addCriterion("actual_workload >=", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadLessThan(String value) {
            addCriterion("actual_workload <", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadLessThanOrEqualTo(String value) {
            addCriterion("actual_workload <=", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadLike(String value) {
            addCriterion("actual_workload like", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadNotLike(String value) {
            addCriterion("actual_workload not like", value, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadIn(List<String> values) {
            addCriterion("actual_workload in", values, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadNotIn(List<String> values) {
            addCriterion("actual_workload not in", values, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadBetween(String value1, String value2) {
            addCriterion("actual_workload between", value1, value2, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andActualWorkloadNotBetween(String value1, String value2) {
            addCriterion("actual_workload not between", value1, value2, "actualWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadIsNull() {
            addCriterion("final_workload is null");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadIsNotNull() {
            addCriterion("final_workload is not null");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadEqualTo(String value) {
            addCriterion("final_workload =", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadNotEqualTo(String value) {
            addCriterion("final_workload <>", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadGreaterThan(String value) {
            addCriterion("final_workload >", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadGreaterThanOrEqualTo(String value) {
            addCriterion("final_workload >=", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadLessThan(String value) {
            addCriterion("final_workload <", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadLessThanOrEqualTo(String value) {
            addCriterion("final_workload <=", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadLike(String value) {
            addCriterion("final_workload like", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadNotLike(String value) {
            addCriterion("final_workload not like", value, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadIn(List<String> values) {
            addCriterion("final_workload in", values, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadNotIn(List<String> values) {
            addCriterion("final_workload not in", values, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadBetween(String value1, String value2) {
            addCriterion("final_workload between", value1, value2, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andFinalWorkloadNotBetween(String value1, String value2) {
            addCriterion("final_workload not between", value1, value2, "finalWorkload");
            return (Criteria) this;
        }

        public Criteria andAddTimeIsNull() {
            addCriterion("add_time is null");
            return (Criteria) this;
        }

        public Criteria andAddTimeIsNotNull() {
            addCriterion("add_time is not null");
            return (Criteria) this;
        }

        public Criteria andAddTimeEqualTo(String value) {
            addCriterion("add_time =", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotEqualTo(String value) {
            addCriterion("add_time <>", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeGreaterThan(String value) {
            addCriterion("add_time >", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeGreaterThanOrEqualTo(String value) {
            addCriterion("add_time >=", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeLessThan(String value) {
            addCriterion("add_time <", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeLessThanOrEqualTo(String value) {
            addCriterion("add_time <=", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeLike(String value) {
            addCriterion("add_time like", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotLike(String value) {
            addCriterion("add_time not like", value, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeIn(List<String> values) {
            addCriterion("add_time in", values, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotIn(List<String> values) {
            addCriterion("add_time not in", values, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeBetween(String value1, String value2) {
            addCriterion("add_time between", value1, value2, "addTime");
            return (Criteria) this;
        }

        public Criteria andAddTimeNotBetween(String value1, String value2) {
            addCriterion("add_time not between", value1, value2, "addTime");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridIsNull() {
            addCriterion("final_modifierid is null");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridIsNotNull() {
            addCriterion("final_modifierid is not null");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridEqualTo(String value) {
            addCriterion("final_modifierid =", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridNotEqualTo(String value) {
            addCriterion("final_modifierid <>", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridGreaterThan(String value) {
            addCriterion("final_modifierid >", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridGreaterThanOrEqualTo(String value) {
            addCriterion("final_modifierid >=", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridLessThan(String value) {
            addCriterion("final_modifierid <", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridLessThanOrEqualTo(String value) {
            addCriterion("final_modifierid <=", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridLike(String value) {
            addCriterion("final_modifierid like", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridNotLike(String value) {
            addCriterion("final_modifierid not like", value, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridIn(List<String> values) {
            addCriterion("final_modifierid in", values, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridNotIn(List<String> values) {
            addCriterion("final_modifierid not in", values, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridBetween(String value1, String value2) {
            addCriterion("final_modifierid between", value1, value2, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andFinalModifieridNotBetween(String value1, String value2) {
            addCriterion("final_modifierid not between", value1, value2, "finalModifierid");
            return (Criteria) this;
        }

        public Criteria andRatioIsNull() {
            addCriterion("ratio is null");
            return (Criteria) this;
        }

        public Criteria andRatioIsNotNull() {
            addCriterion("ratio is not null");
            return (Criteria) this;
        }

        public Criteria andRatioEqualTo(String value) {
            addCriterion("ratio =", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioNotEqualTo(String value) {
            addCriterion("ratio <>", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioGreaterThan(String value) {
            addCriterion("ratio >", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioGreaterThanOrEqualTo(String value) {
            addCriterion("ratio >=", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioLessThan(String value) {
            addCriterion("ratio <", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioLessThanOrEqualTo(String value) {
            addCriterion("ratio <=", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioLike(String value) {
            addCriterion("ratio like", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioNotLike(String value) {
            addCriterion("ratio not like", value, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioIn(List<String> values) {
            addCriterion("ratio in", values, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioNotIn(List<String> values) {
            addCriterion("ratio not in", values, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioBetween(String value1, String value2) {
            addCriterion("ratio between", value1, value2, "ratio");
            return (Criteria) this;
        }

        public Criteria andRatioNotBetween(String value1, String value2) {
            addCriterion("ratio not between", value1, value2, "ratio");
            return (Criteria) this;
        }

        public Criteria andUnitPriceIsNull() {
            addCriterion("unit_price is null");
            return (Criteria) this;
        }

        public Criteria andUnitPriceIsNotNull() {
            addCriterion("unit_price is not null");
            return (Criteria) this;
        }

        public Criteria andUnitPriceEqualTo(String value) {
            addCriterion("unit_price =", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotEqualTo(String value) {
            addCriterion("unit_price <>", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceGreaterThan(String value) {
            addCriterion("unit_price >", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceGreaterThanOrEqualTo(String value) {
            addCriterion("unit_price >=", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceLessThan(String value) {
            addCriterion("unit_price <", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceLessThanOrEqualTo(String value) {
            addCriterion("unit_price <=", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceLike(String value) {
            addCriterion("unit_price like", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotLike(String value) {
            addCriterion("unit_price not like", value, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceIn(List<String> values) {
            addCriterion("unit_price in", values, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotIn(List<String> values) {
            addCriterion("unit_price not in", values, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceBetween(String value1, String value2) {
            addCriterion("unit_price between", value1, value2, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andUnitPriceNotBetween(String value1, String value2) {
            addCriterion("unit_price not between", value1, value2, "unitPrice");
            return (Criteria) this;
        }

        public Criteria andDtpTypeIsNull() {
            addCriterion("dtp_type is null");
            return (Criteria) this;
        }

        public Criteria andDtpTypeIsNotNull() {
            addCriterion("dtp_type is not null");
            return (Criteria) this;
        }

        public Criteria andDtpTypeEqualTo(String value) {
            addCriterion("dtp_type =", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeNotEqualTo(String value) {
            addCriterion("dtp_type <>", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeGreaterThan(String value) {
            addCriterion("dtp_type >", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeGreaterThanOrEqualTo(String value) {
            addCriterion("dtp_type >=", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeLessThan(String value) {
            addCriterion("dtp_type <", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeLessThanOrEqualTo(String value) {
            addCriterion("dtp_type <=", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeLike(String value) {
            addCriterion("dtp_type like", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeNotLike(String value) {
            addCriterion("dtp_type not like", value, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeIn(List<String> values) {
            addCriterion("dtp_type in", values, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeNotIn(List<String> values) {
            addCriterion("dtp_type not in", values, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeBetween(String value1, String value2) {
            addCriterion("dtp_type between", value1, value2, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDtpTypeNotBetween(String value1, String value2) {
            addCriterion("dtp_type not between", value1, value2, "dtpType");
            return (Criteria) this;
        }

        public Criteria andDatachar1IsNull() {
            addCriterion("datachar1 is null");
            return (Criteria) this;
        }

        public Criteria andDatachar1IsNotNull() {
            addCriterion("datachar1 is not null");
            return (Criteria) this;
        }

        public Criteria andDatachar1EqualTo(String value) {
            addCriterion("datachar1 =", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotEqualTo(String value) {
            addCriterion("datachar1 <>", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1GreaterThan(String value) {
            addCriterion("datachar1 >", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1GreaterThanOrEqualTo(String value) {
            addCriterion("datachar1 >=", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1LessThan(String value) {
            addCriterion("datachar1 <", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1LessThanOrEqualTo(String value) {
            addCriterion("datachar1 <=", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1Like(String value) {
            addCriterion("datachar1 like", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotLike(String value) {
            addCriterion("datachar1 not like", value, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1In(List<String> values) {
            addCriterion("datachar1 in", values, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotIn(List<String> values) {
            addCriterion("datachar1 not in", values, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1Between(String value1, String value2) {
            addCriterion("datachar1 between", value1, value2, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar1NotBetween(String value1, String value2) {
            addCriterion("datachar1 not between", value1, value2, "datachar1");
            return (Criteria) this;
        }

        public Criteria andDatachar2IsNull() {
            addCriterion("datachar2 is null");
            return (Criteria) this;
        }

        public Criteria andDatachar2IsNotNull() {
            addCriterion("datachar2 is not null");
            return (Criteria) this;
        }

        public Criteria andDatachar2EqualTo(String value) {
            addCriterion("datachar2 =", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotEqualTo(String value) {
            addCriterion("datachar2 <>", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2GreaterThan(String value) {
            addCriterion("datachar2 >", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2GreaterThanOrEqualTo(String value) {
            addCriterion("datachar2 >=", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2LessThan(String value) {
            addCriterion("datachar2 <", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2LessThanOrEqualTo(String value) {
            addCriterion("datachar2 <=", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2Like(String value) {
            addCriterion("datachar2 like", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotLike(String value) {
            addCriterion("datachar2 not like", value, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2In(List<String> values) {
            addCriterion("datachar2 in", values, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotIn(List<String> values) {
            addCriterion("datachar2 not in", values, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2Between(String value1, String value2) {
            addCriterion("datachar2 between", value1, value2, "datachar2");
            return (Criteria) this;
        }

        public Criteria andDatachar2NotBetween(String value1, String value2) {
            addCriterion("datachar2 not between", value1, value2, "datachar2");
            return (Criteria) this;
        }
    }

    /**
     * pm_task_workload
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_task_workload null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}