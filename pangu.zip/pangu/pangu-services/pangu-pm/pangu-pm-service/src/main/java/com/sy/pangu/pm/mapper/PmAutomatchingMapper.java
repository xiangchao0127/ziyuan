package com.sy.pangu.pm.mapper;

import com.sun.javafx.collections.MappingChange;
import com.sy.pangu.pm.entity.PmAutomatching;
import com.sy.pangu.pm.entity.example.PmAutomatchingExample;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sy.pangu.pm.entity.vo.AutoRuleVo;
import org.apache.ibatis.annotations.Param;

public interface PmAutomatchingMapper {
    long countByExample(PmAutomatchingExample example);

    int deleteByExample(PmAutomatchingExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmAutomatching record);

    int insertSelective(PmAutomatching record);

    List<PmAutomatching> selectByExample(PmAutomatchingExample example);

    PmAutomatching selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmAutomatching record, @Param("example") PmAutomatchingExample example);

    int updateByExample(@Param("record") PmAutomatching record, @Param("example") PmAutomatchingExample example);

    int updateByPrimaryKeySelective(PmAutomatching record);

    int updateByPrimaryKey(PmAutomatching record);

    List<AutoRuleVo> ruleMatchList(@Param("orderType")String orderType, @Param("orderLvl") String qualityLvl);

    List<Map<String,String>> ruleMatchTypes();

}