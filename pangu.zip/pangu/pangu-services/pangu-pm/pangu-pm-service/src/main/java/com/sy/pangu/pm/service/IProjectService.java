package com.sy.pangu.pm.service;

import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmFileFlow;
import com.sy.pangu.pm.entity.PmProjectInfo;
import com.sy.pangu.pm.entity.PmTaskApplyRecord;
import com.sy.pangu.pm.entity.vo.*;
import com.sy.pangu.pm.utils.PageUtil;

import java.text.ParseException;
import java.util.List;

public interface IProjectService {
    List<PmProjectInfo> listProject(ProjectSearchModel projectSearchModel );

    int inseretProject(PmProjectInfo pmProjectInfo) throws Exception;

    PmProjectInfo getPorjectById(String projectId) throws Exception;

    List<PmTaskApplyRecord> getTaskApplyById(String projectId) throws Exception;

    List<PmFile> getProjectFileBypid(String projectId ,String fileType) throws Exception;

    void getProjectFlowBypid(String projectId) throws Exception;

    List<PmFile> getFileReferenceList(String projectId) throws Exception;

    int deleteFileReferenceById(String[] fileidList) throws Exception;

    int updateProjectLine(String projectId, String projectType) throws Exception;

    int stopProject(String projectId, String projectType);

    /**
     * 保存审核记录结果
     *
     * @param applyRecord
     */
    public void saveAuditResult(PmTaskApplyRecord applyRecord) throws Exception;

    int createProject(CreateProjectParams params) throws ParseException;
    /**
     * 根据文件名获取项目翻译流程
     *
     * @param fileId 文件名
     */
    List<PmFileFlow> getProjectTranslateFlow(Integer fileId);
    /**
     * @param projectId 项目id
     * @create: EC根据项目id，来下载译文
     **/
    List<ManuscriptToEcVo> getManuscriptToEc(String projectId);
    /*
     * @create:  获取任务申请列表
     **/
    List<TaskApplyVo> getTaskApplyList(String pmID, String taskType, String applyType, String applySatus)throws Exception;;
//    /**
//     * @param pmId   项目经理id
//     * @create: 根据项目经理id查询项目议员申请列表
//     **/
//    List<PmProjectInfo> getProjectListByApply(String pmId);
}