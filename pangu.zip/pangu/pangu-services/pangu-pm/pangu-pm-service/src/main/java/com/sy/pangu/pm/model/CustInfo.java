package com.sy.pangu.pm.model;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/5 14:31
 */
@Data
public class CustInfo {
    private String custName;
    private Integer custID;
}
