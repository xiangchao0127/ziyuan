package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmDistribute;
import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/14 16:09
 */
@Data
public class DistributeResponseParams {
    /**
     * 流程顺序
     */
    private String workFlow;
    /**
     * 订单类型
     */
    private String orderType;
    /**
     * 订单等级
     */
    private String qualityLvl;
    /**
     * 具体的分领信息
     */
    private List<PmDistribute> distributes;
}
