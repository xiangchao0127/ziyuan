package com.sy.pangu.pm.entity;

import java.math.BigDecimal;

public class SysUnitPriceTrans {
    /**
     * 
     */
    private Integer id;

    /**
     * 兼职：10，专职：11
     */
    private String staffType;

    /**
     * 对专职：职称等级，对兼职：订单等级
     */
    private String level;

    /**
     * 源语言
     */
    private String sourceLan;

    /**
     * 目标语言
     */
    private String targetLan;

    /**
     * 单价
     */
    private BigDecimal unitPrice;

    /**
     * 任务类型：主要包含翻译任务（翻译，审校，质检）
     */
    private String taskType;

    /**
     * 工作类型（文档，证件，图书，非译）
     */
    private String workType;

    /**
     * 保留字段
     */
    private String dataChar1;

    /**
     * 保留字段
     */
    private String dataChar2;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStaffType() {
        return staffType;
    }

    public void setStaffType(String staffType) {
        this.staffType = staffType == null ? null : staffType.trim();
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level == null ? null : level.trim();
    }

    public String getSourceLan() {
        return sourceLan;
    }

    public void setSourceLan(String sourceLan) {
        this.sourceLan = sourceLan == null ? null : sourceLan.trim();
    }

    public String getTargetLan() {
        return targetLan;
    }

    public void setTargetLan(String targetLan) {
        this.targetLan = targetLan == null ? null : targetLan.trim();
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType == null ? null : workType.trim();
    }

    public String getDataChar1() {
        return dataChar1;
    }

    public void setDataChar1(String dataChar1) {
        this.dataChar1 = dataChar1 == null ? null : dataChar1.trim();
    }

    public String getDataChar2() {
        return dataChar2;
    }

    public void setDataChar2(String dataChar2) {
        this.dataChar2 = dataChar2 == null ? null : dataChar2.trim();
    }
}