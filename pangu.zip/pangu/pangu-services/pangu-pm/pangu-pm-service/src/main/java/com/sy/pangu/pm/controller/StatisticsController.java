package com.sy.pangu.pm.controller;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.vo.UserTaskStatisticsVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.IStatisticsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ：jzj
 * date ：Created in 2019/5/5 9:38
 */
@Api(tags = "统计Controller")
@RestController
@RequestMapping("statistics")
public class StatisticsController {
    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IStatisticsService statisticsService;

    /**
     * @param staffNum
     * @return
     */
    @ApiOperation("统计人员的订单和项目信息")
    @RequestMapping(value = "/getUserTaskStatisticsInfo/{userCode}", method = RequestMethod.GET)
    public ResultModel getUserTaskStatisticsInfo(@PathVariable("userCode") String staffNum){
        if(StringUtils.isEmpty(staffNum)){
            return ResultModel.FailWithNoData("未获取到userCode");
        }
        UserTaskStatisticsVo vo = new UserTaskStatisticsVo();
        vo.setUserCode(staffNum);
        try {
            statisticsService.getUserTaskStatisticsInfo(vo);
        }catch (Exception e){
            logger.error("用户：{} --> 统计出错：{}",staffNum,e);
            return ResultModel.FailWithNoData(e.getMessage());
        }

        return ResultModel.SuccessForMsg("",vo);
    }
}
