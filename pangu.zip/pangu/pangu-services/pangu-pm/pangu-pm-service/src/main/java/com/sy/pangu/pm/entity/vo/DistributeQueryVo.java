package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.pm.entity.PmDistribute;
import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/12 15:04
 */
@Data
public class DistributeQueryVo {

    /**
     * 标志属于什么等级的流程路线
     */
    private String flowId;

    private List<PmDistributeVo> distributes;

}
