package com.sy.pangu.pm.entity.vo;

import lombok.Data;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/10 16:13
 */
@Data
public class DefaultFlowQueryVo {
    private String orderType;
    private String qualityLvl;
    private String defaultCat;
    private List<String> workFlow;
}
