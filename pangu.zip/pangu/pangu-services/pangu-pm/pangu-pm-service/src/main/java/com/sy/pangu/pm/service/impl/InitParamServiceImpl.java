package com.sy.pangu.pm.service.impl;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.permission.client.UserClient;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.permission.model.UserForPMParam;
import com.sy.pangu.pm.entity.PmSysTask;
import com.sy.pangu.pm.mapper.PmSysTaskMapper;
import com.sy.pangu.pm.service.IInitParamService;
import com.sy.pangu.rm.client.DomainClient;
import com.sy.pangu.rm.client.LanguageClient;
import com.sy.pangu.rm.model.DomainData;
import com.sy.pangu.rm.model.LanguageData;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ：jzj
 * date ：Created in 2019/4/29 9:21
 */
@Service
public class InitParamServiceImpl implements IInitParamService {

    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(InitParamServiceImpl.class);
    @Autowired
    private PmSysTaskMapper pmSysTaskMapper;
    @Autowired
    private LanguageClient languageClient;
    @Autowired
    private UserClient userClient;
    @Autowired
    private DomainClient domainClient;

    /**
     * 加载任务名称表
     *
     * @return
     */
    @Override
    public List<PmSysTask> getInitSysTask() {
        List<PmSysTask> initPmSysTask = new ArrayList<>();
        try {
            LOGGER.info("-------读取常量数据--------");
            initPmSysTask = pmSysTaskMapper.selectByExample(null);
            LOGGER.info("-------读取常量数据结束--------");

        } catch (Exception e) {
            //保证启动正常
            LOGGER.error("！！！-------系统启动初始化参数失败--------！！！");
            LOGGER.error("！！！-------系统启动初始化参数失败--------！！！");
            LOGGER.error("-------系统启动初始化参数失败-------- {}", e);
        }
        return initPmSysTask;
    }

    /**
     * key: langEn
     * value:langZh
     *
     * @return
     */
    @Override
    public Map<String, String> getInitLanguageData() {
        Map<String, String> init_language_data = new HashMap<>();
        try {
            LOGGER.info("-------读取语言对信息--------");
            List<LanguageData> languageData = languageClient.listLanguage();
            for (LanguageData data : languageData) {
                if (!data.getIsEnable()) {
                    continue;
                }
                init_language_data.put(data.getEnglishName(), data.getChineseName());
            }
            LOGGER.info("-------读取语言对信息结束--------");
        } catch (Exception e) {
            //保证启动正常
            LOGGER.error("！！！-------系统启动初始化语言对失败--------！！！");
            LOGGER.error("！！！-------系统启动初始化语言对失败--------！！！");
            LOGGER.error("-------系统启动初始化语言对失败-------- {}", e);
        }
        return init_language_data;
    }


    @Override
    public Map<String, String> getInitDomainData() {
        Map<String, String> init_domain_data = new HashMap<>();
        try {
            LOGGER.info("-------读取领域信息--------");
            List<DomainData> domainData = domainClient.listDomain();
            for (DomainData data : domainData) {
                if(!data.getState()) {
                    continue;
                }
                init_domain_data.put(data.getSpecialtyId().toString(), data.getFullSpecialtyName());
            }
            LOGGER.info("-------读取领域信息结束--------");
        } catch (Exception e) {
            //保证启动正常
            LOGGER.error("！！！-------系统启动初始化领域失败--------！！！");
            LOGGER.error("！！！-------系统启动初始化领域失败--------！！！");
            LOGGER.error("-------系统启动初始化领域失败-------- {}",e);
        }
        return init_domain_data;
    }

    /**
     * key: staffnum
     * value:userinfo
     *
     * @return
     */
    @Override
    public Map<String, UserForPM> getInitUserData() {
        Map<String, UserForPM> usermap = new HashMap<>();
        try {
            LOGGER.info("-------读取用户数据--------");
            List<UserForPM> allUserInfo = (List<UserForPM>) userClient.getAllUserInfo(new UserForPMParam()).getList();
            LOGGER.info("-------读取用户数据结束--------");
            for (UserForPM data : allUserInfo){
                usermap.put(data.getUserCode(),data);
            }
        } catch (Exception e) {
            //保证启动正常
            LOGGER.error("！！！-------系统启动初始化用户数据失败--------！！！");
            LOGGER.error("！！！-------系统启动初始化用户数据失败--------！！！");
            LOGGER.error("-------系统启动初始化用户数据失败-------- {}", e);
        }
        return usermap;
    }
}
