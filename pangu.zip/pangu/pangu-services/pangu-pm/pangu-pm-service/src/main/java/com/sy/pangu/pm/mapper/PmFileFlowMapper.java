package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmFileFlow;
import com.sy.pangu.pm.entity.example.PmFileFlowExample;
import java.util.List;

import lombok.val;
import org.apache.ibatis.annotations.Param;

public interface PmFileFlowMapper {

    long countByExample(PmFileFlowExample example);

    int deleteByExample(PmFileFlowExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmFileFlow record);

    int insertSelective(PmFileFlow record);

    int insertBatch(List<PmFileFlow> record);

    List<PmFileFlow> selectByExample(PmFileFlowExample example);

    PmFileFlow selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PmFileFlow record, @Param("example") PmFileFlowExample example);

    int updateByExample(@Param("record") PmFileFlow record, @Param("example") PmFileFlowExample example);

    int updateByPrimaryKeySelective(PmFileFlow record);

    int updateByPrimaryKey(PmFileFlow record);

    /**
     * 根据源文件id查询流程
     * @param fileId
     * @return
     */
    List<PmFileFlow> selectFileFlowByFileId(@Param(value = "fileId") String fileId);

    void deleteFileFlowByFID(Integer fileId ,String flowID);
    /**
     * 根据文件名获取项目翻译流程     *
     * @param fileId 文件名
     */
    List<PmFileFlow> getProjectTranslateFlow(Integer fileId) ;
}