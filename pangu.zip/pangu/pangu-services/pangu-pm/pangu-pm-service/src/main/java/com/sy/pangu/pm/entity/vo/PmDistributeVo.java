package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：lhaotian
 * @date ：Created in 2019/5/17 14:26
 */
@Data
public class PmDistributeVo {

    /**
     * 专职等级
     */
    private String[] fullStaffLvl;

    /**
     * 兼职译员的要求等级
     */
    private String[] freeStaffLvl;

    /**
     * 时间比例
     */
    private Double timePer;

    /**
     * 通知时间
     */
    private String notifyTime;

    /**
     * 属于什么流程节点
     */
    private Integer nodeId;
}
