package com.sy.pangu.pm.controller;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.model.UserExtend;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.vo.TaskDetailVo;
import com.sy.pangu.pm.model.PropertyData;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.IFileService;
import com.sy.pangu.pm.service.ITransTaskService;
import com.sy.pangu.pm.utils.FtpUtils;
import com.sy.pangu.pm.utils.PageUtil;
import com.sy.pangu.pm.utils.ParamBuildUtil;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Api(tags = "翻译任务")
@RestController
//@CrossOrigin
@RequestMapping("/transTask")
public class TransTaskController {

    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ITransTaskService transTaskService;
    @Autowired
    private IFileService fileService;
    @Value("${file-upload-path}")
    private String fileUploadPath;
    @Value("${upfile.host}")
    private String upfileHost;
    @Value("${upfile.port}")
    private int upfilePort;
    @Value("${upfile.username}")
    private String upfileUsername;
    @Value("${upfile.password}")
    private String upfilePassword;

    /**
     * @param page      分页信息
     * @param staffNum  员工号
     * @param taskInfo  任务信息（查询条件）
     * @return
     */
    @ApiOperation("分页查询未领取任务")
    @RequestMapping(value = "/getNotReceiveTask",method = RequestMethod.GET)
    @ApiImplicitParams({
        @ApiImplicitParam(value = "分页：当前页", name = "page", required = true),
        @ApiImplicitParam(value = "分页：分页单位", name = "limit", required = true),
        @ApiImplicitParam(value = "分页：排序", name = "sort", required = false),
        @ApiImplicitParam(value = "分页：是否降序（非降序，不设值；降序设值desc）", name = "desc", required = false),
        @ApiImplicitParam(value = "员工号", name = "staffNum", required = true),
        @ApiImplicitParam(value = "查询：任务名", name = "taskName", required = false),
        @ApiImplicitParam(value = "查询：项目名", name = "projectName", required = false),
        @ApiImplicitParam(value = "查询：要求完成时间-开始", name = "requireEndtimeS", required = false),
        @ApiImplicitParam(value = "查询：要求完成时间-结束", name = "requireEndtimeE", required = false)
    })
    public ResultModel getNotReceiveTask(PageUtil page, String staffNum, PmTaskInfo taskInfo) {
        if (StringUtils.isEmpty(staffNum)) {
            return ResultModel.Fail("请传入员工工号", page);
        }
        //添加查询的任务类型
        List taskTypes = new ArrayList();
        taskTypes.add(StaffLvlEnum.TASK_TYPE_TRANS.getValue());
        taskTypes.add(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
        taskTypes.add(StaffLvlEnum.TASK_TYPE_QA.getValue());
        taskTypes.add(StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue());
        /* 设置查询参数 */
        Map param = page.getLink();
        param.put("staffNum",staffNum);
        param.put("taskTypes",taskTypes);
        try {
//            param.put("translateType", DataBaseStartUpRunner.init_user_data.get(staffNum).getTranslateType());
//            param.put("skillLv", DataBaseStartUpRunner.init_user_data.get(staffNum).getUserExtendList());
            //测试
            UserExtend extend = new UserExtend("1","001","zh-cy","cy-zh","P6","P6","001","哈哈哈领域","2","翻译");
            UserExtend extend1 = new UserExtend("2","001","zh-cy","cy-zh","P7","P6","002","哈哈哈领域","2","翻译");
            UserExtend extend2 = new UserExtend("3","001","zh-cy","cy-zh","P8","P6","003","哈哈哈领域","2","翻译");
            UserExtend extend3 = new UserExtend("4","001","zh-cy","cy-zh","P9","P6","004","哈哈哈领域","2","翻译");
            List<UserExtend> anExtends = new ArrayList<>(); anExtends.add(extend);anExtends.add(extend1);anExtends.add(extend2);anExtends.add(extend3);
            UserForPM user = new UserForPM();
            user.setUserCode("J001");
            user.setRealName("J001");
            user.setTranslateType(1);
            user.setUserExtendList(anExtends);
            param.put("translateType", user.getTranslateType());
            param.put("skillLv", user.getUserExtendList());
            //            param.put("taskTypes", Arrays.asList("2","5","6").stream().filter(x -> taskTypes.contains(x)).collect(Collectors.toList()));
//            param.put("taskTypes", DataBaseStartUpRunner.init_user_data.get(staffNum).getRoleCodeList().stream().filter(x -> taskTypes.contains(x)).collect(Collectors.toList()));
        }catch (Exception e) {
            logger.error("获取角色失败 -> {}",e);
            return ResultModel.Fail("获取用户信息失败", page);
        }
        ParamBuildUtil.ParamBuild(param,taskInfo);

        try{
            transTaskService.getNotReceiveTask(page);
        }catch (Exception e){
            logger.error("查询出错  >>>>>>>>>>  {}",e);
            return ResultModel.Fail("查询出错",page);
        }
        return ResultModel.SuccessForMsg("查询成功",page);
    }

    /**
     * 获取任务列表，根据员工号、状态、查询条件查询
     * @param page
     * @param staffNum
     * @param status 查询状态：1：进行中 2：已完成
     * @param isDTP 任务类型（是否是dtp true or false）
     * @param taskInfo
     * @return
     */
    @ApiOperation("查询任务列表")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "分页：当前页", name = "page", required = true),
            @ApiImplicitParam(value = "分页：分页单位", name = "limit", required = true),
            @ApiImplicitParam(value = "分页：排序", name = "sort", required = false),
            @ApiImplicitParam(value = "分页：是否降序（非降序，不设值；降序设值desc）", name = "desc", required = false),
            @ApiImplicitParam(value = "员工号", name = "staffNum", required = true),
            @ApiImplicitParam(value = "查询状态：1：进行中 2：已完成", name = "status", required = true),
            @ApiImplicitParam(value = "任务类型（是否是dtp true or false）", name = "isDTP", required = true),
            @ApiImplicitParam(value = "查询：任务名", name = "taskName", required = false),
            @ApiImplicitParam(value = "查询：项目名", name = "projectName", required = false),
            @ApiImplicitParam(value = "查询：要求完成时间-开始", name = "requireEndtimeS", required = false),
            @ApiImplicitParam(value = "查询：要求完成时间-结束", name = "requireEndtimeE", required = false)
    })
    @RequestMapping(value = "/getTaskList", method = RequestMethod.GET)
    public ResultModel getTaskList(PageUtil page,String staffNum, String status,String isDTP, PmTaskInfo taskInfo) {
        if (StringUtils.isEmpty(staffNum)) {
            return ResultModel.Fail("请传入员工工号", page);
        }
        if (StringUtils.isEmpty(status)) {
            return ResultModel.Fail("请传入查询状态", page);
        }
        //添加查询的任务类型
        List taskTypes = new ArrayList();
        if ("true".equals(isDTP)) {
            taskTypes.add(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue());
            taskTypes.add(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
        } else if ("false".equals(isDTP)) {
            taskTypes.add(StaffLvlEnum.TASK_TYPE_TRANS.getValue());
            taskTypes.add(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
            taskTypes.add(StaffLvlEnum.TASK_TYPE_QA.getValue());
            taskTypes.add(StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue());
        } else {
            return ResultModel.Fail("请传入正确的任务类型", page);
        }

        /* 设置查询参数 */
        Map param = page.getLink();
        param.put("staffNum",staffNum);
        param.put("status",status);
        param.put("taskTypes",taskTypes);
        ParamBuildUtil.ParamBuild(param,taskInfo);

        try{
            transTaskService.getTaskListByStatus(page);
        }catch (Exception e){
            logger.error("查询出错  >>>>>>>>>>  {}",e);
            return ResultModel.Fail("查询出错",page);
        }

        return ResultModel.SuccessForMsg("查询成功",page);
    }

    /**
     * 判断是否有权限领取自动分配的任务
     * @param staffNum
     * @param taskId
     * @param langEn
     * @param domain
     * @return
     */
    @ApiOperation("判断是否有权限领取自动分配的任务")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "员工号", name = "staffNum", required = true),
            @ApiImplicitParam(value = "任务ID", name = "taskId", required = true),
            @ApiImplicitParam(value = "语言对", name = "langEn", required = true),
            @ApiImplicitParam(value = "领域", name = "domain", required = true)

    })
    public ResultModel hasPermissionsReceiveCompleteTask(String staffNum, String taskId,String langEn, String domain){
        if(StringUtils.isEmpty(staffNum) || StringUtils.isEmpty(taskId) || StringUtils.isEmpty(langEn)){
            return ResultModel.FailWithNoData("请传入译员ID和任务ID、语言对、领域ID");
        }
        boolean res = false;
        try{
           res = transTaskService.hasPermissionsReceiveCompleteTask(staffNum, taskId, langEn, domain);
        }catch (Exception e){
            return ResultModel.FailWithNoData(e.getMessage());
        }
        if(!res){
            return ResultModel.FailWithNoData("没有权限领取");
        }

        return ResultModel.Success();
    }

    /**
     * 领取任务，参数：人员id、任务id
     * @param staffNum
     * @param taskId
     * @param taskType
     * @return
     */
    @ApiOperation("领取任务")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "员工号", name = "staffNum", required = true),
            @ApiImplicitParam(value = "任务类型", name = "taskType", required = true),
            @ApiImplicitParam(value = "任务ID", name = "taskId", required = true)
    })
    @RequestMapping(value = "/receiveCompleteTask", method = RequestMethod.GET)
    public ResultModel receiveCompleteTask(String staffNum, String taskId, String taskType) {
        if (StringUtils.isEmpty(staffNum)) {
            return ResultModel.FailWithNoData("请传入员工工号");
        }
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        if (StringUtils.isEmpty(taskType)) {
            return ResultModel.FailWithNoData("请传入任务类型");
        }

        //判断是否有领取权限
//        try {
//            transTaskService.hasPermissionsReceive(staffNum, taskId);
//        }catch (Exception e){
//            logger.error("无权领取该任务 >>>>>>>>>> {}",e);
//            return ResultModel.FailWithNoData("无权领取该任务");
//        }

        try {
            transTaskService.receiveCompleteTask(staffNum,taskId, taskType);
        }catch (RuntimeException e){
            logger.error("任务已被领取 >>>>>>>>>> {}",e);
            return ResultModel.FailWithNoData("任务领取失败，可能已被领取");
        }

        return ResultModel.Success();
    }

    /**
     * TODO 领取部分任务
     * 领取部分任务，参数：人员id、任务id、字数
     */
//    @ApiOperation("领取部分任务")
//    @RequestMapping("/receivePartTask")
    public ResultModel receivePartTask(String workNum, PmTaskInfo taskInfo) {
        if(null == taskInfo){
            return ResultModel.FailWithNoData("请传入参数");
        }
        if (StringUtils.isEmpty(taskInfo.getStaffNum())) {
            return ResultModel.FailWithNoData("请传入员工工号");
        }
        if (StringUtils.isEmpty(taskInfo.getTaskId())) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        if (StringUtils.isEmpty(workNum)) {
            return ResultModel.FailWithNoData("请传入领取字数");
        }

        try {
            transTaskService.receivePartTask(workNum,taskInfo);
        }catch (Exception e){
            logger.error("任务领取失败 >>>>>>>>>> {}",e);
            return ResultModel.FailWithNoData("任务可能已被领取");
        }

        return ResultModel.Success();
    }

    /**
     *
     * 获取任务详情 参数：任务id
     * @param taskId
     * @return
     */
    @ApiOperation("任务详情")
    @RequestMapping(value = "/getTaskDetail", method = RequestMethod.GET)
    public ResultModel getTaskDetail(String taskId) {
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        TaskDetailVo taskDetail = null;
        try {
            taskDetail = transTaskService.getTaskDetail(taskId);
        } catch (Exception e) {
            logger.error("{}",e);
            return ResultModel.FailWithNoData("查询任务详情失败");
        }

        return ResultModel.SuccessForMsg("", taskDetail);
    }

    /**
     *
     *任务提交 参数：任务ID
     */
    @ApiOperation("任务提交")
    @RequestMapping(value = "/submitTask", method = RequestMethod.POST)
    public ResultModel submitTask(String taskId){
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }

        try {
            transTaskService.updateTaskStatus(taskId, TaskInfoEnum.TASK_STATUS_SUBMIT.getValue());
        }catch (Exception e){
            logger.error("任务状态更新失败 >>>>>>>>>> {}",e);
            return ResultModel.FailWithNoData("任务状态更新失败");
        }
        return ResultModel.Success();
    }

    /**
     *
     *导出文件 参数：任务ID
     * @param fileId
     * @param staffNum
     * @param request
     * @param resp
     * @throws Exception
     */
    @ApiOperation("导出文件")
    @RequestMapping(value = "/tasking/exportFile", method = RequestMethod.GET)
    public void exportFile(String fileId, String staffNum, HttpServletRequest request, HttpServletResponse resp) throws Exception {
        if(StringUtils.isEmpty(fileId)){
            throw new Exception("文件导出失败：请传入文件id");
        }

        PmFile pmFile = new PmFile();
        try {
            pmFile = fileService.getFileByFileId(fileId);
        }catch (Exception e){
            logger.error("根据文件ID获取文件失败 --> {}",e);
            throw new Exception("根据文件ID获取文件失败");
        }

        if("1".equals(pmFile.getIsDel())){
            throw new Exception("该文件已被删除");
        }
        /**
         *  TODO
         * 测试
         */
//        pmFile.setFileName("数据库设计文档V2.0.doc");
//        pmFile.setFilePath("D:\\\\工作文档\\\\数据库设计文档V2.0.doc");
        //转码
        String fileName = pmFile.getFileName();
//        try {
//            fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
////            fileName = new String(fileName.getBytes("utf-8"), "ISO-8859-1");
//        } catch (UnsupportedEncodingException e) {
//            logger.error("{}",e);
//        }
        String userAgent = request.getHeader("USER-AGENT");
        try {
            if(StringUtils.contains(userAgent, "MSIE")){//IE浏览器
                fileName = URLEncoder.encode(fileName,"UTF8");
            }else if(StringUtils.contains(userAgent, "Mozilla")){//google,火狐浏览器
                fileName = new String(fileName.getBytes(), "ISO8859-1");
            }else{
                fileName = URLEncoder.encode(fileName,"UTF8");//其他浏览器
            }
        } catch (UnsupportedEncodingException e) {
            logger.error("{}",e);
        }

        String path = pmFile.getFilePath();
        boolean res = FtpUtils.download(upfileHost, upfilePort, upfileUsername, upfilePassword, path, ParamStatic.FILE_PATH_TEMP + staffNum+ "/" + path.substring(path.lastIndexOf("/"), path.length()));
        if(!res){
            throw new Exception("文件下载失败");
        }
        File file = new File(ParamStatic.FILE_PATH_TEMP + staffNum+ "/" + path.substring(path.lastIndexOf("/"), path.length()));
        resp.reset();
        resp.setContentType("application/octet-stream");
        resp.setCharacterEncoding("utf-8");
        resp.setContentLength((int) file.length());
        resp.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        byte[] buff = new byte[1024];
        BufferedInputStream bis = null;
        OutputStream os = null;
        try {
            os = resp.getOutputStream();
            bis = new BufferedInputStream(new FileInputStream(file));
            int i = 0;
            while ((i = bis.read(buff)) != -1) {
                os.write(buff, 0, i);
                os.flush();
            }
        } catch (IOException e) {
            logger.error("{}",e);
        } finally {
            try {
                bis.close();
                if(file.exists()){
                    file.delete();
                }
            } catch (IOException e) {
                logger.error("{}",e);
            }
        }
    }

//    @RequestMapping("/editOffline")
    public ResultModel editOffline(){
        /**
         * TODO 离线编辑
         *离线编辑 参数：任务ID
         */
        return ResultModel.Success();
    }

    /**
     *
     *申请退稿 : 任务id
     */
    @ApiOperation("退稿申请")
    @RequestMapping(value = "/applyCancelTask", method = RequestMethod.GET)
    public ResultModel applyCancelTask(String taskId,String reason) {
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }

        try{
            transTaskService.applyCancelTask(taskId,reason);
        }catch (Exception e){
            logger.error("{} >>>>>>>>>> {}",e.getMessage(),e);
            return ResultModel.FailWithNoData(e.getMessage());
        }

        return ResultModel.SuccessForMsg("提交申请成功",null);
    }

//    @RequestMapping("/tasking/editTask")
    public ResultModel editTask(){
        /**
         * TODO 编辑任务
         * 编辑任务： 任务id
         */
        return ResultModel.Success();
    }

    /**
     * TODO 上传
     * 上传： 任务id
     */
    @ApiOperation("上传文件")
    @RequestMapping(value = "/tasking/upLoad", method = RequestMethod.POST)
    public ResultModel upLoadTask(String taskId, MultipartFile multipartFile, String fileType){
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        if (null == multipartFile) {
            return ResultModel.FailWithNoData("请上传文件");
        }

        try {
            fileService.uploadFile(taskId,fileType,multipartFile,fileUploadPath+"task/"+taskId+"/"+multipartFile.getOriginalFilename());
        }catch (Exception e){
            logger.error("文件上传失败 >>>>>>>>>> ",e);
            return ResultModel.FailWithNoData("文件上传失败");
        }
        return ResultModel.Success();
    }

    /**
     * 查看已上传文件： 任务id
     */
    @ApiOperation("查看已上传文件")
    @RequestMapping(value = "/tasking/viewUpFile", method = RequestMethod.GET)
    public ResultModel viewUpFile(String taskId){
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }

        PmFile file = new PmFile();
        try{
            file = fileService.getFileInfoOfUpLoad(taskId);
        }catch (Exception e){
            logger.error("{} >>>>>>>>>> {}",e.getMessage(),e);
            return ResultModel.FailWithNoData(e.getMessage());
        }
        return ResultModel.SuccessForMsg("查询成功",file);
    }

    /**
     * 申请再次编辑： 任务id
     */
    @ApiOperation("申请再次编辑")
    @RequestMapping(value = "/applyEditAgain", method = RequestMethod.GET)
    public ResultModel applyEditAgain(String taskId) {
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }

        try{
            transTaskService.applyEditAgain(taskId);
        }catch (Exception e){
            logger.error("{} >>>>>>>>>> {}",e.getMessage(),e);
            return ResultModel.FailWithNoData("申请再次编辑失败");
        }

        return ResultModel.SuccessForMsg("提交申请成功",null);
    }
}
