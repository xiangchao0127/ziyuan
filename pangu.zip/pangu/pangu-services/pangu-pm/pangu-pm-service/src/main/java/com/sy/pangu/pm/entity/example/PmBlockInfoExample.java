package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.List;

public class PmBlockInfoExample {
    /**
     * pm_block_info
     */
    protected String orderByClause;

    /**
     * pm_block_info
     */
    protected boolean distinct;

    /**
     * pm_block_info
     */
    protected List<Criteria> oredCriteria;

    public PmBlockInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_block_info null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andProjectsIdIsNull() {
            addCriterion("projects_id is null");
            return (Criteria) this;
        }

        public Criteria andProjectsIdIsNotNull() {
            addCriterion("projects_id is not null");
            return (Criteria) this;
        }

        public Criteria andProjectsIdEqualTo(String value) {
            addCriterion("projects_id =", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdNotEqualTo(String value) {
            addCriterion("projects_id <>", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdGreaterThan(String value) {
            addCriterion("projects_id >", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdGreaterThanOrEqualTo(String value) {
            addCriterion("projects_id >=", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdLessThan(String value) {
            addCriterion("projects_id <", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdLessThanOrEqualTo(String value) {
            addCriterion("projects_id <=", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdLike(String value) {
            addCriterion("projects_id like", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdNotLike(String value) {
            addCriterion("projects_id not like", value, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdIn(List<String> values) {
            addCriterion("projects_id in", values, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdNotIn(List<String> values) {
            addCriterion("projects_id not in", values, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdBetween(String value1, String value2) {
            addCriterion("projects_id between", value1, value2, "projectsId");
            return (Criteria) this;
        }

        public Criteria andProjectsIdNotBetween(String value1, String value2) {
            addCriterion("projects_id not between", value1, value2, "projectsId");
            return (Criteria) this;
        }

        public Criteria andFileIdIsNull() {
            addCriterion("file_id is null");
            return (Criteria) this;
        }

        public Criteria andFileIdIsNotNull() {
            addCriterion("file_id is not null");
            return (Criteria) this;
        }

        public Criteria andFileIdEqualTo(Integer value) {
            addCriterion("file_id =", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotEqualTo(Integer value) {
            addCriterion("file_id <>", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdGreaterThan(Integer value) {
            addCriterion("file_id >", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("file_id >=", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLessThan(Integer value) {
            addCriterion("file_id <", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdLessThanOrEqualTo(Integer value) {
            addCriterion("file_id <=", value, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdIn(List<Integer> values) {
            addCriterion("file_id in", values, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotIn(List<Integer> values) {
            addCriterion("file_id not in", values, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdBetween(Integer value1, Integer value2) {
            addCriterion("file_id between", value1, value2, "fileId");
            return (Criteria) this;
        }

        public Criteria andFileIdNotBetween(Integer value1, Integer value2) {
            addCriterion("file_id not between", value1, value2, "fileId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("task_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("task_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("task_id =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("task_id <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("task_id >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_id >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("task_id <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("task_id <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("task_id like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("task_id not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("task_id in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("task_id not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("task_id between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("task_id not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdIsNull() {
            addCriterion("task_package_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdIsNotNull() {
            addCriterion("task_package_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdEqualTo(String value) {
            addCriterion("task_package_id =", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotEqualTo(String value) {
            addCriterion("task_package_id <>", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdGreaterThan(String value) {
            addCriterion("task_package_id >", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_package_id >=", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdLessThan(String value) {
            addCriterion("task_package_id <", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdLessThanOrEqualTo(String value) {
            addCriterion("task_package_id <=", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdLike(String value) {
            addCriterion("task_package_id like", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotLike(String value) {
            addCriterion("task_package_id not like", value, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdIn(List<String> values) {
            addCriterion("task_package_id in", values, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotIn(List<String> values) {
            addCriterion("task_package_id not in", values, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdBetween(String value1, String value2) {
            addCriterion("task_package_id between", value1, value2, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andTaskPackageIdNotBetween(String value1, String value2) {
            addCriterion("task_package_id not between", value1, value2, "taskPackageId");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumIsNull() {
            addCriterion("duplicate_num is null");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumIsNotNull() {
            addCriterion("duplicate_num is not null");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumEqualTo(Integer value) {
            addCriterion("duplicate_num =", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumNotEqualTo(Integer value) {
            addCriterion("duplicate_num <>", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumGreaterThan(Integer value) {
            addCriterion("duplicate_num >", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("duplicate_num >=", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumLessThan(Integer value) {
            addCriterion("duplicate_num <", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumLessThanOrEqualTo(Integer value) {
            addCriterion("duplicate_num <=", value, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumIn(List<Integer> values) {
            addCriterion("duplicate_num in", values, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumNotIn(List<Integer> values) {
            addCriterion("duplicate_num not in", values, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumBetween(Integer value1, Integer value2) {
            addCriterion("duplicate_num between", value1, value2, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andDuplicateNumNotBetween(Integer value1, Integer value2) {
            addCriterion("duplicate_num not between", value1, value2, "duplicateNum");
            return (Criteria) this;
        }

        public Criteria andIsDeleteIsNull() {
            addCriterion("is_delete is null");
            return (Criteria) this;
        }

        public Criteria andIsDeleteIsNotNull() {
            addCriterion("is_delete is not null");
            return (Criteria) this;
        }

        public Criteria andIsDeleteEqualTo(Integer value) {
            addCriterion("is_delete =", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteNotEqualTo(Integer value) {
            addCriterion("is_delete <>", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteGreaterThan(Integer value) {
            addCriterion("is_delete >", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_delete >=", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteLessThan(Integer value) {
            addCriterion("is_delete <", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteLessThanOrEqualTo(Integer value) {
            addCriterion("is_delete <=", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteIn(List<Integer> values) {
            addCriterion("is_delete in", values, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteNotIn(List<Integer> values) {
            addCriterion("is_delete not in", values, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteBetween(Integer value1, Integer value2) {
            addCriterion("is_delete between", value1, value2, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("is_delete not between", value1, value2, "isDelete");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdIsNull() {
            addCriterion("block_increase_id is null");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdIsNotNull() {
            addCriterion("block_increase_id is not null");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdEqualTo(Integer value) {
            addCriterion("block_increase_id =", value, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdNotEqualTo(Integer value) {
            addCriterion("block_increase_id <>", value, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdGreaterThan(Integer value) {
            addCriterion("block_increase_id >", value, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("block_increase_id >=", value, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdLessThan(Integer value) {
            addCriterion("block_increase_id <", value, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdLessThanOrEqualTo(Integer value) {
            addCriterion("block_increase_id <=", value, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdIn(List<Integer> values) {
            addCriterion("block_increase_id in", values, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdNotIn(List<Integer> values) {
            addCriterion("block_increase_id not in", values, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdBetween(Integer value1, Integer value2) {
            addCriterion("block_increase_id between", value1, value2, "blockIncreaseId");
            return (Criteria) this;
        }

        public Criteria andBlockIncreaseIdNotBetween(Integer value1, Integer value2) {
            addCriterion("block_increase_id not between", value1, value2, "blockIncreaseId");
            return (Criteria) this;
        }
    }

    /**
     * pm_block_info
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_block_info null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}