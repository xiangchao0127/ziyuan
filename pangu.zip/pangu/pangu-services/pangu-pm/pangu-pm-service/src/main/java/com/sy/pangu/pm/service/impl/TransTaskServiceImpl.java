package com.sy.pangu.pm.service.impl;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.model.UserExtend;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmFileFlow;
import com.sy.pangu.pm.entity.PmGettaskid;
import com.sy.pangu.pm.entity.PmGrabsheet;
import com.sy.pangu.pm.entity.PmProjectInfo;
import com.sy.pangu.pm.entity.PmTaskApplyRecord;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.example.PmFileExample;
import com.sy.pangu.pm.entity.example.PmFileFlowExample;
import com.sy.pangu.pm.entity.example.PmGettaskidExample;
import com.sy.pangu.pm.entity.example.PmGrabsheetExample;
import com.sy.pangu.pm.entity.example.PmProjectInfoExample;
import com.sy.pangu.pm.entity.example.PmTaskApplyRecordExample;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.entity.vo.TaskDetailVo;
import com.sy.pangu.pm.entity.vo.TaskInfoVo;
import com.sy.pangu.pm.mapper.PmFileFlowMapper;
import com.sy.pangu.pm.mapper.PmFileMapper;
import com.sy.pangu.pm.mapper.PmGettaskidMapper;
import com.sy.pangu.pm.mapper.PmGrabsheetMapper;
import com.sy.pangu.pm.mapper.PmProjectInfoMapper;
import com.sy.pangu.pm.mapper.PmTaskApplyRecordMapper;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.model.TaskFileListModel;
import com.sy.pangu.pm.service.ITransTaskService;
import com.sy.pangu.pm.utils.PageUtil;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.ApplyRecordEnum;
import com.sy.pangu.pm.utils.enumpackage.GrabsheetEnum;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import com.sy.pangu.pm.utils.enumpackage.SysEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import com.sy.pangu.pm.utils.enumpackage.WorkTypeEnum;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransTaskServiceImpl implements ITransTaskService {

    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
    @Autowired
    private PmTaskApplyRecordMapper applyRecordMapper;
    @Autowired
    private PmFileMapper fileMapper;
    @Autowired
    private PmFileFlowMapper fileFlowMapper;
    @Autowired
    private PmProjectInfoMapper projectInfoMapper;
    @Autowired
    private PmGrabsheetMapper grabsheetMapper;
    @Autowired
    private PmGettaskidMapper gettaskidMapper;

    @Override
    public void getNotReceiveTask(PageUtil page) {

        List<TaskInfoVo> list = taskInfoMapper.selectPageNotReceiveTask(page);
        long total = taskInfoMapper.selectCountNotReceiveTask(page);
        page.setList(list);
        page.setTotalRow(total);

        //转译 语言对
        for (TaskInfoVo vo : list) {
            //任务类型
            vo.setTaskTypeZh(StaffLvlEnum.getDescByValue(vo.getTaskType()));
            //语言对
            String[] langs = vo.getLanguageEn().split(" -> ");
            if (langs.length != 2) {//避免抛错
                continue;
            }
            String lanS = DataBaseStartUpRunner.init_language_data.get(langs[0]) == null ? "系统未知语言" : DataBaseStartUpRunner.init_language_data.get(langs[0]);
            String lanE = DataBaseStartUpRunner.init_language_data.get(langs[1]) == null ? "系统未知语言" : DataBaseStartUpRunner.init_language_data.get(langs[1]);
            vo.setLanguageZn(lanS + " -> " + lanE);
        }
    }

    @Override
    public void getTaskListByStatus(PageUtil page) throws RuntimeException {
        List<TaskInfoVo> list = new ArrayList();
        long total = 0;

        List taskStatus = new ArrayList();
        //判断状态
        //进行中
        if ("1".equals(page.getLink().get("status"))) {
            taskStatus.add(TaskInfoEnum.TASK_STATUS_ING.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_WAIT_UPLOAD.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_WAIT_SUBMIT.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_CANCEL_TASK.getValue());
        } else if ("2".equals(page.getLink().get("status"))) {
            //已结束
            taskStatus.add(TaskInfoEnum.TASK_STATUS_DELIVERY.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_TERMINATION.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_REJECT_FILE.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_SUBMIT.getValue());
            taskStatus.add(TaskInfoEnum.TASK_STATUS_CONFIRM.getValue());
        } else {
            throw new RuntimeException("参数错误，未知的任务状态");
        }
        page.getLink().put("taskStatusList", taskStatus);

        //分页查询对应状态的任务
        list = taskInfoMapper.selectPageTaskListByStatus(page);
        total = taskInfoMapper.selectCountTaskListByStatus(page);

        //转译
        for (TaskInfoVo vo : list) {
            //任务类型
            vo.setTaskTypeZh(StaffLvlEnum.getDescByValue(vo.getTaskType()));
            //任务状态
            vo.setTaskStatusZh(TaskInfoEnum.getDescByValue(vo.getTaskStatus()));
            //语言对
            String[] langs = vo.getLanguageEn().split(" -> ");
            if (langs.length != 2) {//避免抛错
                continue;
            }
            String lanS = DataBaseStartUpRunner.init_language_data.get(langs[0]) == null ? "系统未知语言" : DataBaseStartUpRunner.init_language_data.get(langs[0]);
            String lanE = DataBaseStartUpRunner.init_language_data.get(langs[1]) == null ? "系统未知语言" : DataBaseStartUpRunner.init_language_data.get(langs[1]);
            vo.setLanguageZn(lanS + " -> " + lanE);
//            vo.setLanguageZn(DataBaseStartUpRunner.init_language_data.get(langs[0]) + " -> " + DataBaseStartUpRunner.init_language_data.get(langs[1]));
        }

        page.setList(list);
        page.setTotalRow(total);
    }

    /**
     * 领取任务
     * 简单采用乐观锁实现抢单操作
     *
     * @param staffNum
     * @param taskId
     * @param taskType
     * @throws RuntimeException
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor = Exception.class)
    public void receiveCompleteTask(String staffNum, String taskId, String taskType) throws RuntimeException {
        PmTaskInfo taskInfo = new PmTaskInfo();
        PmTaskInfoExample example = new PmTaskInfoExample();

        List<String> transList = Arrays.asList(StaffLvlEnum.TASK_TYPE_TRANS.getValue(),StaffLvlEnum.TASK_TYPE_QA.getValue(),StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
        //build param
        taskInfo.setTaskId(taskId);
        taskInfo.setStaffNum(staffNum);
        taskInfo.setTaskStatus(transList.contains(taskType) ? TaskInfoEnum.TASK_STATUS_ING.getValue() : TaskInfoEnum.TASK_STATUS_WAIT_UPLOAD.getValue()); //翻译生产 进行中  其他为待上传

        //设置条件
        example.createCriteria().andTaskIdEqualTo(taskId).andStaffNumEqualTo(ParamStatic.TASK_DEFAULT_STAFFNUM);

        //更新
        int result = taskInfoMapper.updateByExampleSelective(taskInfo, example);

        logger.info("{} --- >>> 领取任务结果：{}", staffNum, result);
        /**
         * 根据结果 选择是否抛异常
         */
        if (0 == result) {
            throw new RuntimeException("任务已被别人领取了");
        }

        //更新抢单表
        PmGrabsheet grabsheet = new PmGrabsheet();
        grabsheet.setTaskId(taskId);
        grabsheet.setTaskStatus(GrabsheetEnum.IS_RECEIVE_YES.getValue());
        grabsheetMapper.updateByTaskIdSelective(grabsheet);
    }

    /**
     * 申请退稿
     *
     * @param taskId
     * @param reason
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor = Exception.class)
    public void applyCancelTask(String taskId, String reason) throws RuntimeException {
        Date date = new Date();

        PmTaskInfo info = getTaskInfoByTaskId(taskId);

        //校验状态 是否为 进行中状态 ---
        // TODO 只有进行中的数据可以退稿
        if (!TaskInfoEnum.TASK_STATUS_ING.getValue().equals(info.getTaskStatus())
                || !TaskInfoEnum.TASK_STATUS_WAIT_UPLOAD.getValue().equals(info.getTaskStatus())
                || !TaskInfoEnum.TASK_STATUS_WAIT_SUBMIT.getValue().equals(info.getTaskStatus())) {
            throw new RuntimeException("任务状态为不可退稿状态");
        }
        if (ParamStatic.TASK_DEFAULT_STAFFNUM.equals(info.getStaffNum())) {
            throw new RuntimeException("该任务尚未分配人员");
        }

        //校验 每天退稿不能超过2次
        String dateS = ParamStatic.SIMPLE_DATEFORMAT.format(date) + " 00:00:00";
        String dateE = ParamStatic.SIMPLE_DATEFORMAT.format(date) + " 23:59:59";
        PmTaskApplyRecordExample example = new PmTaskApplyRecordExample();
        example.createCriteria().andApplySatusEqualTo(ApplyRecordEnum.APPLY_SATUS_AGREE.getValue())
                .andApplyTypeEqualTo(ApplyRecordEnum.APPLY_TYPE_CANCEL_TASK.getValue())
                .andApplyStaffNumEqualTo(info.getStaffNum())
                .andLastUpdateTimeBetween(dateS, dateE);
        long cancelCount = applyRecordMapper.countByExample(example);
        if (cancelCount >= 2) {
            throw new RuntimeException("每天退稿不能超过2次");
        }

        //更新
        //添加申请记录
        PmTaskApplyRecord taskApply = new PmTaskApplyRecord();
        taskApply.setProjectId(info.getProjectId());
        taskApply.setApplyStaffNum(info.getStaffNum());
        taskApply.setTaskId(taskId);
        taskApply.setApplyTime(ParamStatic.SIMPLE_TIMEFORMAT.format(date));
        taskApply.setLastUpdateTime(ParamStatic.SIMPLE_TIMEFORMAT.format(date));
        taskApply.setApplyType(ApplyRecordEnum.APPLY_TYPE_CANCEL_TASK.getValue());
        taskApply.setReason(reason);
        applyRecordMapper.insert(taskApply);

        //退稿中状态
        info.setTaskStatus(TaskInfoEnum.TASK_STATUS_CANCEL_TASK.getValue());
        taskInfoMapper.updateByPrimaryKeySelective(info);
    }

    /**
     * 获取任务详情
     *
     * @param taskId
     * @return
     */
    @Override
    public TaskDetailVo getTaskDetail(String taskId) throws RuntimeException {
        //详情总和
        TaskDetailVo detailVo = new TaskDetailVo();

        //设置任务信息
        PmTaskInfo taskInfo = getTaskInfoByTaskId(taskId);
        detailVo.setTaskId(taskId);
        detailVo.setTaskName(taskInfo.getTaskName());

        String projectId = taskInfo.getProjectId();
        //项目信息
        PmProjectInfoExample example = new PmProjectInfoExample();
        example.createCriteria().andProjectIdEqualTo(projectId);
        List<PmProjectInfo> projectInfos = projectInfoMapper.selectByExample(example);
        if (null == projectInfos || projectInfos.size() < 1) {
            throw new RuntimeException("获取项目信息失败");
        }
        PmProjectInfo projectInfo = projectInfos.get(0);
        detailVo.setPmId(projectInfo.getPmId());
        detailVo.setTranmgrId(projectInfo.getTranmgrId());

        //文件信息
        PmFileExample fileExample = new PmFileExample();
        fileExample.createCriteria().andProjectsIdEqualTo(projectId)
                .andIsDelEqualTo("0");
        List<PmFile> files = fileMapper.selectByExample(fileExample);
        if (null == files || files.size() < 1) {
            throw new RuntimeException("获取文件信息失败");
        }
        detailVo.setFiles(files);

        //流程信息
        String fileId = taskInfo.getFileId();
        List<PmFileFlow> flows = fileFlowMapper.selectFileFlowByFileId(fileId);
        if (null == flows || flows.size() < 1) {
            throw new RuntimeException("获取任务流程信息失败");
        }
        detailVo.setFlows(flows);

        /**
         * 具体翻译要求  走接口
         * TODO 具体翻译要求
         */

        return detailVo;
    }

    /**
     * 申请再次编辑
     *
     * @param taskId
     */
    @Override
    public void applyEditAgain(String taskId) throws RuntimeException {
        Date date = new Date();
        PmTaskInfo info = getTaskInfoByTaskId(taskId);

        //校验状态 是否为 进行中状态 ---
        // 只有交付的数据可以申请再次编辑
        if (!TaskInfoEnum.TASK_STATUS_DELIVERY.getValue().equals(info.getTaskStatus())
                && !TaskInfoEnum.TASK_STATUS_SUBMIT.getValue().equals(info.getTaskStatus())) {
            throw new RuntimeException("只有已交付和已提交的任务可申请再次编辑");
        }

        //更新
        //添加申请记录
        PmTaskApplyRecord taskApply = new PmTaskApplyRecord();
        taskApply.setProjectId(info.getProjectId());
        taskApply.setApplyStaffNum(info.getStaffNum());
        taskApply.setTaskId(taskId);
        taskApply.setApplyTime(ParamStatic.SIMPLE_TIMEFORMAT.format(date));
        taskApply.setApplyType(ApplyRecordEnum.APPLY_TYPE_EDIT_AGAIN.getValue());
        applyRecordMapper.insert(taskApply);
    }

    /**
     * 更新任务状态
     *
     * @param taskId
     * @param status
     */
    @Override
    public void updateTaskStatus(String taskId, String status) throws RuntimeException {
        PmTaskInfo info = new PmTaskInfo();
        info = getTaskInfoByTaskId(taskId);
        PmTaskInfoExample example = new PmTaskInfoExample();
        if(WorkTypeEnum.CO_WORK_TYPE.getValue().equals(info.getWorkType())){
            example.createCriteria().andTaskTypeEqualTo(info.getTaskType()).andFileIdEqualTo(info.getFileId())
                    .andTaskStatusNotIn(Arrays.asList(TaskInfoEnum.TASK_STATUS_REJECT_FILE.getValue(),TaskInfoEnum.TASK_STATUS_DELETE.getValue()));
        }else {
            example.createCriteria().andTaskIdEqualTo(taskId);
        }

        if (TaskInfoEnum.TASK_STATUS_SUBMIT.getValue().equals(status)) {
            //译前dtp、译后dtp、排版任务只有待提交状态的任务才能提交
            if ((StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(info.getTaskType())
                    || StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(info.getTaskType())
                    || StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue().equals(info.getTaskType()))
                    && !TaskInfoEnum.TASK_STATUS_WAIT_SUBMIT.getValue().equals(info.getTaskStatus())) {
                throw new RuntimeException("译前dtp、译后dtp、排版任务只有待提交状态的任务才能提交");
            }

            if ((StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(info.getTaskType())
                    || StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(info.getTaskType()))
                    && StringUtils.isEmpty(info.getRealWorkLoad())) {
                throw new RuntimeException("译前dtp、译后dtp任务只有设置了工作量的任务才能提交");
            }
        }

        PmTaskInfo info_up = new PmTaskInfo();
        info_up.setTaskStatus(status);

        taskInfoMapper.updateByExampleSelective(info_up, example);
        //解锁下一个流程阶段
        openNextTask(info.getTaskType(),info.getFileId());
    }

    /**
     * 任务部分领取
     *
     * @param workNum
     * @param taskInfo
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor = Exception.class)
    public void receivePartTask(String workNum, PmTaskInfo taskInfo) throws Exception {
        //原任务信息
        PmTaskInfo info = new PmTaskInfo();
        //更新条件信息
        PmTaskInfoExample example = new PmTaskInfoExample();

        while (true) {
            //抢单失败  重新抢单 读取新任务信息
            info = getTaskInfoByTaskId(taskInfo.getTaskId());
            //字数够
            if (Integer.parseInt(workNum) <= Integer.parseInt(info.getWorkLoad())) {
                if (ParamStatic.TASK_PACKAGEID_TEMP.equals(info.getTaskPackageId())) {//抢后还没更新包id 临时id
                    continue;
                }
                //新字数
                int new_word = Integer.parseInt(info.getWorkLoad()) - Integer.parseInt(workNum);
                //更新任务
//                info.setWorkLoad(new_word+"");
                PmTaskInfo info_up = new PmTaskInfo();
                info_up.setWorkLoad(new_word + "");
                example.createCriteria().andTaskIdEqualTo(info.getTaskId()).andWorkLoadEqualTo(info.getWorkLoad())
                        .andTaskPackageIdEqualTo(info.getTaskPackageId());
                //只更新字数
                int res = taskInfoMapper.updateByExampleSelective(info_up, example);
                if (res == 1) {//更新成功  -- 表示抢单成功
                    /**
                     * TODO 部分领取  暂时不用
                     * 调cat接口  获取新的包id
                     */
                    //待新增任务
                    PmTaskInfo info_ins = (PmTaskInfo) info.clone();
                    info_ins.setStaffNum(taskInfo.getStaffNum());
                    info_ins.setTaskStatus(TaskInfoEnum.TASK_STATUS_ING.getValue());
                    info_ins.setWorkLoad(workNum);
                    info_ins.setId(null);
                    info_ins.setTaskId(getTaskId());
                    info_ins.setTaskPackageId("");
                    //新增任务
                    taskInfoMapper.insertSelective(info_ins);
                    //更新原包
                    info.setTaskPackageId("");
                    taskInfoMapper.updateByPrimaryKeySelective(info);
                    //跳出死循环
                    break;
                }

            } else {
                logger.info("抢单失败 -->  字数不够了");
                throw new Exception("你没抢到，运气撇到爆！！！");
            }
        }

    }

    /**
     * 项目转线下修改任务表把项目相关任务全部设置为删除状态 除开交付    *
     *
     * @param projectId 项目id
     */
    @Override
    public int updateTaskStatusByPID(String projectId) {
        return taskInfoMapper.updateTaskStatusByPID(projectId);
    }
    /**
     * 终止任务    *
     * @param projectId      项目id
     */
    @Override
    public int stopTaskByPId(String projectId) {
        return taskInfoMapper.stopTaskByPId(projectId);
    }

    @Override
    public List<PmTaskInfo> getTaskStatusByPackage(String blockId) {
        return taskInfoMapper.getTaskStatusByPackage(blockId);
    }
    /**
     * 查询任务表集合
     * @param pmTaskInfo      任务实体
     */
    @Override
    public List<PmTaskInfo> getTaskInfoList(PmTaskInfo pmTaskInfo) {
        return taskInfoMapper.getTaskInfoList(pmTaskInfo);
    }

    /**
     * 更新任务信息
     *插入抢单信息
     * @param taskInfo
     * @param grabsheet
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor =
            Exception.class)
    public void insertTaskInfo(PmTaskInfo taskInfo, PmGrabsheet grabsheet) {
        if (null != grabsheet) {
            grabsheetMapper.insertSelective(grabsheet);
        }
        taskInfoMapper.updateByPrimaryKeySelective(taskInfo);
    }

    /**
     * 解锁下一阶段任务
     *
     * @param taskType
     * @param fileId
     */
    @Override
    @Async
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor =
            Exception.class)
    public void openNextTask(String taskType, String fileId) {
        //待更新列表
        List<PmTaskInfo> taskInfos_up = new ArrayList<>();
        //翻译生产类型
        List<String> types = new ArrayList<>();
        types.add(StaffLvlEnum.TASK_TYPE_TRANS.getValue());
        types.add(StaffLvlEnum.TASK_TYPE_PROOFREADING.getValue());
        types.add(StaffLvlEnum.TASK_TYPE_QA.getValue());

        //查找下一个节点
        String nextFlow = "";
        PmFileFlowExample flowExample = new PmFileFlowExample();
        flowExample.createCriteria().andFileIdEqualTo(fileId).andIsUseEqualTo("00");
        flowExample.setOrderByClause("id asc");
        List<PmFileFlow> flows = fileFlowMapper.selectByExample(flowExample);
        for (int i=0; i<flows.size(); i++) {
            if(taskType.equals(flows.get(i).getFlowId())){
                nextFlow = flows.get(i+1).getFlowId();
                continue;
            }
        }
        //当前节点不在翻译生产且下个节点为翻译生产
        if (types.contains(nextFlow) && !types.contains(taskType)) {
            // 解锁翻译生产环节
            PmTaskInfoExample example = new PmTaskInfoExample();
            example.createCriteria().andFileIdEqualTo(fileId)
                    .andTaskTypeIn(types)
                    .andTaskStatusNotEqualTo(TaskInfoEnum.TASK_STATUS_DELETE.getValue());
            taskInfos_up = taskInfoMapper.selectByExample(example);
//            taskInfos_up = taskInfos.stream().filter(x -> types.contains(x.getTaskType())).collect(Collectors.toList());
        }

        if(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(nextFlow) || StaffLvlEnum.TASK_TYPE_TYPESETTING.getValue().equals(nextFlow)){
            // 解锁译后环节
            PmTaskInfoExample example = new PmTaskInfoExample();
            example.createCriteria().andFileIdEqualTo(fileId)
                    .andTaskTypeEqualTo(nextFlow)
                    .andTaskStatusNotEqualTo(TaskInfoEnum.TASK_STATUS_DELETE.getValue());
            taskInfos_up = taskInfoMapper.selectByExample(example);
        }

        for (PmTaskInfo data : taskInfos_up) {
            //未分配员工 -- 初始状态   分配了员工 -- 进行中
            if (ParamStatic.TASK_DEFAULT_STAFFNUM.equals(data.getStaffNum())) {
                data.setTaskStatus(TaskInfoEnum.TASK_STATUS_INIT.getValue());
            } else {
                data.setTaskStatus(TaskInfoEnum.TASK_STATUS_ING.getValue());
            }
        }

        //最后更新状态
        if (taskInfos_up.size() > 0) {
            taskInfoMapper.updateByTaskIdSelectiveForBatch(taskInfos_up);
        }
    }

    @Override
    public void updateTaskStByFild(String fileId) {
        taskInfoMapper.updateTaskStByFild(fileId);
    }
    /**
     * 根据原文件id，获取任务与任务文件信息集合
     * @param fileId
     */
    @Override
    public List<TaskFileListModel> getTaskinfoByFileid(Integer fileId) {
        return taskInfoMapper.getTaskinfoByFileid(fileId);
    }
    /**
     * 根据文件id把任务设置为终止
     * @param fileId
     */
    @Override
    public void stopTaskByFileId(String fileId) {
        taskInfoMapper.stopTaskByFileId(fileId);
    }
    /**
     * 根据包ID字符串集合和状态，获取任务集合
     * @param packageIDList  包ID字符串集合
     * @param taskStatus  任务状态
     */
    @Override
    public  List<PmTaskInfo> getTaskInfoListByPackageList(String packageIDList, String taskStatus) {

        return  taskInfoMapper.getTaskInfoListByPackageList(packageIDList , taskStatus);
    }
    /**
     * 根据包ID字符串把任务设置为失效
     * @param packageIDList  包ID字符串集合
     */
    @Override
    public void stopTaskByPackageIDlist(String packageIDList) {
        taskInfoMapper.stopTaskByPackageIDlist(packageIDList);
    }

    /**
     * 是否有领取权限
     *
     * @param staffNum
     * @param taskId
     */
    @Override
    public void hasPermissionsReceive(String staffNum, String taskId) throws Exception {
        PmGrabsheet grabsheet = new PmGrabsheet();
        PmGrabsheetExample example = new PmGrabsheetExample();
        example.createCriteria().andTaskIdEqualTo(taskId);
        List<PmGrabsheet> list = grabsheetMapper.selectByExample(example);
        if (list.size() < 1) {
            throw new Exception("未查询到抢单信息");
        }

        grabsheet = list.get(0);
        //自动
        if (SysEnum.AUTO_ALLOT.getValue().equals(grabsheet.getAllotType())) {
            //TODO 获取人员等级
            String lv = DataBaseStartUpRunner.init_user_data.get(staffNum) + "";
            if (grabsheet.getChooseLv().indexOf(lv) == -1) {
                throw new Exception("没有领取任务权限");
            }
        }
        //手动
        if (SysEnum.HAND_ALLOT.getValue().equals(grabsheet.getAllotType())) {
            if (grabsheet.getStaffNum().indexOf(staffNum) == -1) {
                throw new Exception("没有领取任务权限");
            }
        }
    }

    @Override
    public PmTaskInfo getTaskInfoByTaskId(String taskId) throws RuntimeException {
        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andTaskIdEqualTo(taskId);
        List<PmTaskInfo> taskInfos = taskInfoMapper.selectByExample(example);
        if (taskInfos.size() < 1) {
            throw new RuntimeException("未获取到任务信息");
        }
        return taskInfos.get(0);
    }

    /**
     * 获取任务ID
     *
     * @return
     */
    @Override
    public String getTaskId() {
        Date date = new Date();
        int key = 0;
        while (key == 0){
            key = getTaskKey();
        }
        return ParamStatic.SIMPLE_TIME_NUM.format(date) + String.format("%0" + 10 + "d",key);
    }

    /**
     * 判断是否有权限领取自动分配的任务
     *
     *
     * @param staffNum
     * @param taskId
     * @param domain
     * @return
     */
    @Override
    public boolean hasPermissionsReceiveCompleteTask(String staffNum, String taskId, String langEn, String domain) throws RuntimeException {

        PmGrabsheetExample example = new PmGrabsheetExample();
        example.createCriteria().andTaskIdEqualTo(taskId);

        PmGrabsheet grabsheet = grabsheetMapper.selectByExample(example).get(0);
        if(!SysEnum.AUTO_ALLOT.getValue().equals(grabsheet.getAllotType())){
            throw new RuntimeException("非自动分配任务不需要判断");
        }
        UserForPM userForPM = DataBaseStartUpRunner.init_user_data.get(staffNum);
        List<UserExtend> userExtends = userForPM.getUserExtendList().stream()
                .filter(x -> x.getAreaId().equals(domain))
                .filter(x -> (x.getSourceLangauge() + " - " + x.getTargetLangauge()).equals(langEn))
                .filter(x -> userForPM.getTranslateType().equals(SysEnum.JOB_FULL.getValue()) ? grabsheet.getChooseLv().indexOf(x.getLevelId()) != -1 : grabsheet.getDatachar1().indexOf(x.getLevelId()) != -1)
                .collect(Collectors.toList());
        return userExtends.size() > 0;
    }


    /**
     * 根据任务id把交付任务状态，并且更新交付时间
     * @param status 任务状态
     * @param taskId 任务id
     * @param realCompletTime  任务实际完成时间
     * @return
     */
    @Override
    public void updateTaskStatusByTaskID(String taskId, String status, String realCompletTime) {
        taskInfoMapper.updateTaskStatusByTaskID(taskId,status,realCompletTime);
    }
    /**
     * 根据原文件id，把文件下所有有效任务设置状态
     * @param fileId 原文件id
     * @param status 任务状态
     * @return
     */
    @Override
    public void updateTaskStatusByFileID(String fileId, String status) {
        taskInfoMapper.updateTaskStatusByFileID(fileId,status);
    }

    public synchronized int getTaskKey(){
        int key = 0;
        PmGettaskid gettaskid = gettaskidMapper.selectByPrimaryKey(1);

        PmGettaskid gettask_up = new PmGettaskid();
        gettask_up.setTaskId(gettaskid.getTaskId()+1);
        PmGettaskidExample example = new PmGettaskidExample();
        example.createCriteria().andIdEqualTo(1).andTaskIdEqualTo(gettaskid.getTaskId());
        long res = gettaskidMapper.updateByExampleSelective(gettask_up,example);
        if(res == 1){
            key = gettask_up.getTaskId();
        }
        return key;
    }
    public static void main(String[] args) {
        String a = String.format("%0" + 3 + "d", Integer.parseInt("50"));
        System.out.println(a);
    }
}
