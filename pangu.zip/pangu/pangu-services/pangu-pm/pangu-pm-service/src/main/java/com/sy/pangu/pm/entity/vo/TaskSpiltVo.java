package com.sy.pangu.pm.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/5/6 16:54
 */
@Data
public class TaskSpiltVo {

    private List<TaskPackageVo> taskPackages;

}
