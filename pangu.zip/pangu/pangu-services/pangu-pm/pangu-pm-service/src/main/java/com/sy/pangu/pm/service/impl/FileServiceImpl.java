package com.sy.pangu.pm.service.impl;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.util.StringUtils;
//import com.sy.pangu.file.client.FileClient;
import com.sy.pangu.file.client.FileClient;
import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.entity.example.PmTaskInfoExample;
import com.sy.pangu.pm.mapper.PmFileMapper;
import com.sy.pangu.pm.mapper.PmTaskInfoMapper;
import com.sy.pangu.pm.model.PropertyData;
import com.sy.pangu.pm.service.IFileService;
import com.sy.pangu.pm.utils.FtpUtils;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.FileTypeEnum;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import com.sy.pangu.pm.utils.enumpackage.TaskInfoEnum;
import com.sy.pangu.pm.utils.enumpackage.WorkTypeEnum;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * @author ：jzj
 * date ：Created in 2019/4/15 16:58
 */
@Service
public class FileServiceImpl implements IFileService {

    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PmFileMapper fileMapper;
    @Autowired
    private PmTaskInfoMapper taskInfoMapper;
    @Autowired
    private FileClient fileClient;
    @Autowired
    private TransTaskServiceImpl taskService;
    @Value("${upfile.host}")
    private String upfileHost;
    @Value("${upfile.port}")
    private int upfilePort;
    @Value("${upfile.username}")
    private String upfileUsername;
    @Value("${upfile.password}")
    private String upfilePassword;

    /**
     * 根据任务id  获取上传文件信息
     *
     * @param taskId
     * @return
     */
    @Override
    public PmFile getFileInfoOfUpLoad(String taskId) throws RuntimeException {
        PmTaskInfoExample example = new PmTaskInfoExample();
        example.createCriteria().andTaskIdEqualTo(taskId);
        List<PmTaskInfo> taskInfos = taskInfoMapper.selectByExample(example);
        if (taskInfos.size() < 1) {
            throw new RuntimeException("未获取到任务信息");
        }
        PmTaskInfo taskInfo = taskInfos.get(0);

        String fileId = taskInfo.getUploadFileId();
        if(StringUtils.isEmpty(fileId)){
            throw new RuntimeException("该任务还没上传文件");
        }
        return fileMapper.selectByPrimaryKey(Integer.parseInt(fileId));
    }

    /**
     * 任务文件上传
     *  @param taskId
     * @param fileType
     * @param multipartFile
     * @param path
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30, rollbackFor = Exception.class)
    public void uploadFile(String taskId, String fileType, MultipartFile multipartFile, String path) throws Exception {
        Date date = new Date();
        //上传文件
//        String realPath = "";
//        String realPath = fileClient.fileUpload(multipartFile, path);

        boolean res = FtpUtils.upload(upfileHost, upfilePort, upfileUsername, upfilePassword, multipartFile.getInputStream(), path);
        if (!res) {
            throw new Exception("FTP文件上传失败");
        }
        //获取任务信息
        PmTaskInfo taskInfo = taskService.getTaskInfoByTaskId(taskId);
            //如果上传的文件不是原文或者参考文件，就把任务上传的文件更新为失效
            if (fileType != "01" || fileType != "02") {
                //将旧文件记录更新为不可用
                if (StringUtils.isEmpty(taskInfo.getUploadFileId())) {
                    PmFile file_Up = new PmFile();
                    file_Up.setFileId(Integer.parseInt(taskInfo.getUploadFileId()));
                    file_Up.setIsDel("1");//已删除
                    fileMapper.updateByPrimaryKeySelective(file_Up);
                }

            //设置文件保存记录
            PmFile file = new PmFile();
            file.setFileName(multipartFile.getOriginalFilename());
            file.setFilePath(path);
            file.setIsDel("0");//未删除
            file.setProjectsId(taskInfo.getProjectId());
            file.setTaskType(taskInfo.getTaskType());
            file.setFileType(FileTypeEnum.getFileTypeByTaskType(taskInfo.getTaskType(), fileType));//TODO
            file.setUploadTime(ParamStatic.SIMPLE_TIMEFORMAT.format(date));
            file.setUploadSuff(taskInfo.getStaffNum());
            //单位kb
            file.setFileSize(multipartFile.getSize() / 1024 + "");
            //新增返回id
            fileMapper.insertSelectKey(file);
            int fileId = file.getFileId();
            //如果上传的文件不是原文或者参考文件，就更新任务
            if (fileType != "01" || fileType != "02") {
                //更新任务上传文件id
                PmTaskInfo taskInfo_up = new PmTaskInfo();
                taskInfo_up.setUploadFileId(fileId + "");
                taskInfo_up.setTaskStatus(TaskInfoEnum.TASK_STATUS_WAIT_SUBMIT.getValue());
                taskInfo.setUploadFileId(fileId + "");
                taskInfo.setTaskStatus(TaskInfoEnum.TASK_STATUS_WAIT_SUBMIT.getValue());

                //译前  译后  协作任务  同步更新
                if (StaffLvlEnum.TASK_TYPE_BF_DTP.getValue().equals(taskInfo.getTaskType())
                        || StaffLvlEnum.TASK_TYPE_AF_DTP.getValue().equals(taskInfo.getTaskType())) {
                    PmTaskInfoExample example = new PmTaskInfoExample();
                    example.createCriteria().andFileIdEqualTo(taskInfo.getFileId())
                            .andTaskTypeEqualTo(taskInfo.getTaskType())
                            .andWorkTypeEqualTo(WorkTypeEnum.CO_WORK_TYPE.getValue());

                    taskInfoMapper.updateByExampleSelective(taskInfo_up, example);
                } else {
                    taskInfoMapper.updateByPrimaryKeySelective(taskInfo);
                }
            }
        }
    }
        /**
         * 根据文件id获取文件信息
         *
         * @param fileId
         * @return
         */
        @Override
        public PmFile getFileByFileId(String fileId){
            return fileMapper.selectByPrimaryKey(Integer.parseInt(fileId));
        }

}
