package com.sy.pangu.pm.entity;

public class SysTransmanagerInfo {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private String sourceLanguage;

    /**
     * 
     */
    private String targetLanguage;

    /**
     * 
     */
    private String domain;

    /**
     * 翻译经理的code
     */
    private String userCode;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSourceLanguage() {
        return sourceLanguage;
    }

    public void setSourceLanguage(String sourceLanguage) {
        this.sourceLanguage = sourceLanguage == null ? null : sourceLanguage.trim();
    }

    public String getTargetLanguage() {
        return targetLanguage;
    }

    public void setTargetLanguage(String targetLanguage) {
        this.targetLanguage = targetLanguage == null ? null : targetLanguage.trim();
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain == null ? null : domain.trim();
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode == null ? null : userCode.trim();
    }
}