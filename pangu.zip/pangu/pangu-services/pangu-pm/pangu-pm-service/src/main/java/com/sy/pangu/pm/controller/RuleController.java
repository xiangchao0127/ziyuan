package com.sy.pangu.pm.controller;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.pm.entity.vo.AutoRuleQuery;
import com.sy.pangu.pm.entity.vo.DefaultFlowQueryVo;
import com.sy.pangu.pm.entity.vo.DistributeQueryVo;
import com.sy.pangu.pm.entity.vo.FlowQueryVo;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.AutoRuleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * @author L00928
 */
@Api(tags = "管理员后台：规则设置")
@RestController
@RequestMapping("/rule")
@CrossOrigin
public class RuleController {

    protected static final Logger logger = LoggerFactory.getLogger(RuleController.class);

    @Autowired
    private AutoRuleService autoRuleService;



    @ApiOperation("设置默认流程")
    @PostMapping("/setDefaultFlow")
    public ResultModel setDefaultFlow(DefaultFlowQueryVo defaultQuery) {
        if(!StringUtils.notEmpty(defaultQuery.getOrderType())) {
            return ResultModel.FailWithNoData("请填写订单类型");
        }
        if(!StringUtils.notEmpty(defaultQuery.getQualityLvl())) {
            return ResultModel.FailWithNoData("请填写订单等级");
        }
        if(!StringUtils.notEmpty(defaultQuery.getDefaultCat())) {
            return ResultModel.FailWithNoData("请选择生产工具");
        }
        if(defaultQuery.getWorkFlow().size() == 0) {
            return ResultModel.FailWithNoData("请配置流程");
        }
        try {
            autoRuleService.setDefaultFlow(defaultQuery.getOrderType(), defaultQuery.getQualityLvl(), defaultQuery.getDefaultCat(), defaultQuery.getWorkFlow());
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new RuntimeException("流程设置失败");
        }
        return ResultModel.Success();
    }

    @ApiOperation("删除指定的流程")
    @DeleteMapping("/delDefaultFlow")
    public ResultModel delDefaultFlow(FlowQueryVo flow) {
        return ResultModel.SuccessForMsg("删除成功", autoRuleService.delDefaultFlow(flow.getOrderType(), flow.getQualityLvl(), flow.getDefaultCat()));
    }

    @ApiOperation("流程列表获取具体某流程数据")
    @GetMapping("/getFlow")
    public ResultModel getDefaultFlow(FlowQueryVo flow) {
        return ResultModel.SuccessForMsg("", autoRuleService.getFlow(flow));
    }

    @ApiOperation("流程列表，按照订单等级/订单类型/生产工具分组")
    @GetMapping("/listFlow")
    public ResultModel getDefaultFlowList() {
        return autoRuleService.listFlow();
    }

    @ApiOperation("设置默认匹配规则")
    @PostMapping("/setAutoMatchRule")

    public ResultModel setAutoMatch(@RequestBody AutoRuleQuery automatching) {
        if (automatching.getAutoRuleVos().size() < 1) {
            return ResultModel.FailWithNoData("请至少填写一条规则");
        }
        return autoRuleService.setAutoRules(automatching);
    }

    @ApiOperation("读取匹配规则列表")
    @PostMapping("/matchRuleList")
    public ResultModel matchRuleList(String orderType, String orderLvl) {
        return ResultModel.SuccessForMsg("获取成功", autoRuleService.autoRuleList(orderType, orderLvl));
    }

    @ApiOperation("匹配列表")
    @GetMapping("/ruleTypeList")
    public ResultModel matchTypeList() {
        return ResultModel.SuccessForMsg("", autoRuleService.ruleMatchTypes());
    }

    @ApiOperation("修改匹配规则")
    @PostMapping("/updateMatchRule")
    public ResultModel updateMatchRule(@RequestBody AutoRuleQuery automatching) {
        autoRuleService.updateRules(automatching);
        return ResultModel.Success();
    }

    @ApiOperation("设置分领规则")
    @PostMapping("/setDistributeRule")
    public ResultModel setDistributeRule(@RequestBody DistributeQueryVo distributeModel) {
        if (distributeModel.getDistributes().size() < 1) {
            return ResultModel.FailWithNoData("请至少填写一条规则");
        }
        return autoRuleService.setDistributeRule(distributeModel);
    }

    @ApiOperation("根据订单等级和文档类型获取分领规则")
    @GetMapping("/getDistributeRule")
    public ResultModel getDistributeRule() {
//        if(StringUtils.isEmpty(flow.getOrderType())) {
//            return ResultModel.FailWithNoData("缺少订单类型");
//        }
//        if(StringUtils.isEmpty(flow.getQualityLvl())) {
//            return ResultModel.FailWithNoData("缺少质量等级");
//        }
        return autoRuleService.getDistributeRule();
    }


    @ApiOperation("返回可选的任务节点")
    @GetMapping("/allNode")
    public ResultModel allNode() {
        return autoRuleService.allNode();
    }


}
