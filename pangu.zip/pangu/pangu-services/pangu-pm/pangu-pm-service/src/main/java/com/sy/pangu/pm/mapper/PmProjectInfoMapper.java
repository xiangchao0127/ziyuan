package com.sy.pangu.pm.mapper;

import com.sy.pangu.pm.entity.PmProjectInfo;
import java.util.List;

import com.sy.pangu.pm.entity.example.PmProjectInfoExample;
import com.sy.pangu.pm.entity.vo.FileTaskSpiltVo;
import com.sy.pangu.pm.entity.vo.ManuscriptToEcVo;
import com.sy.pangu.pm.entity.vo.ProjectSearchModel;
import com.sy.pangu.pm.entity.vo.TaskPackageVo;
import org.apache.ibatis.annotations.Param;

public interface PmProjectInfoMapper {
    long countByExample(PmProjectInfoExample example);

    int deleteByExample(PmProjectInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PmProjectInfo record);

    int insertSelective(PmProjectInfo record);

    List<PmProjectInfo> selectByExample(PmProjectInfoExample example);

    PmProjectInfo selectByPrimaryKey(String projectId);

    int updateByExampleSelective(@Param("record") PmProjectInfo record, @Param("example") PmProjectInfoExample example);

    int updateByExample(@Param("record") PmProjectInfo record, @Param("example") PmProjectInfoExample example);

    int updateByPrimaryKeySelective(PmProjectInfo record);

    int updateByPrimaryKey(PmProjectInfo record);
    //查询已完成项目列表
    List<PmProjectInfo> listProject(@Param("projectSearchModel")ProjectSearchModel projectSearchModel ,@Param("sort")String sort);
    //查询待分配列表
    List<PmProjectInfo>  listProjectBySplit( ProjectSearchModel projectSearchModel);
    //项目详情——文件详情——项目转线下
    int updateProjectLine( @Param("projectId")String projectId ,@Param("projectType") String projectType);
    //项目详情——任务分配——项目终止
    int stopProject(@Param("projectId") String projectId,@Param("projectId") String projectType);

    /**
     * 根据项目id获取任务分配情况
     * @param projectId
     * @return
     */
    List<FileTaskSpiltVo> getTaskSpiltListByProjectId(String projectId);

    /**
     * @param projectId 项目id
     * @create: EC根据项目id，来下载译文
     * @return
     **/
    List<ManuscriptToEcVo> getManuscriptToEc(String projectId);
    /**
     * @param projectSearchModel 搜索集合
     * @create: 根据项目经理id查询项目议员申请列表
     **/
    List<PmProjectInfo> getProjectListByApply(ProjectSearchModel projectSearchModel);
}