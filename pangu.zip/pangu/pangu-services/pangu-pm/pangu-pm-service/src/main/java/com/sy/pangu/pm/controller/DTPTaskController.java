package com.sy.pangu.pm.controller;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.permission.model.UserExtend;
import com.sy.pangu.permission.model.UserForPM;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.entity.PmFile;
import com.sy.pangu.pm.entity.PmTaskInfo;
import com.sy.pangu.pm.model.PropertyData;
import com.sy.pangu.pm.model.ResultModel;
import com.sy.pangu.pm.service.IDTPTaskService;
import com.sy.pangu.pm.service.IFileService;
import com.sy.pangu.pm.service.ITransTaskService;
import com.sy.pangu.pm.utils.ConvertToPdfUtil;
import com.sy.pangu.pm.utils.PageUtil;
import com.sy.pangu.pm.utils.ParamBuildUtil;
import com.sy.pangu.pm.utils.ParamStatic;
import com.sy.pangu.pm.utils.enumpackage.StaffLvlEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.io.FileUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author ：jzj
 * @date ：Created in 2019/4/17 10:43
 */

@Api(tags = "DPT任务")
@RestController
//@CrossOrigin
@RequestMapping("DTPTask")
public class DTPTaskController {

    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IDTPTaskService dtpTaskService;
    @Autowired
    private IFileService fileService;
    @Autowired
    ITransTaskService transTaskService;
    @Value("${upfile.host}")
    private String upfileHost;
    @Value("${upfile.port}")
    private int upfilePort;
    @Value("${upfile.username}")
    private String upfileUsername;
    @Value("${upfile.password}")
    private String upfilePassword;

    /**
     * @param page     分页信息
     * @param staffNum  员工号
     * @param taskInfo  任务信息（查询条件）
     * @return
     */
    @ApiOperation("分页查询未领取任务")
    @RequestMapping(value = "/getNotReceiveTask",method = RequestMethod.GET)
    public ResultModel getNotReceiveTask(PageUtil page, String staffNum, PmTaskInfo taskInfo) {
        if (StringUtils.isEmpty(staffNum)) {
            return ResultModel.Fail("请传入员工工号", page);
        }
        //添加查询的任务类型
        List taskTypes = new ArrayList();
        taskTypes.add(StaffLvlEnum.TASK_TYPE_AF_DTP.getValue());
        taskTypes.add(StaffLvlEnum.TASK_TYPE_BF_DTP.getValue());
        /* 设置查询参数 */
        Map param = page.getLink();
        param.put("staffNum",staffNum);
        try {
//            param.put("translateType", DataBaseStartUpRunner.init_user_data.get(staffNum).getTranslateType());
//            param.put("skillLv", DataBaseStartUpRunner.init_user_data.get(staffNum).getUserExtendList());
            //测试
            UserExtend extend = new UserExtend("1","001","zh-cy","cy-zh","P6","P6","001","哈哈哈领域","2","翻译");
            UserExtend extend1 = new UserExtend("2","001","zh-cy","cy-zh","P7","P6","002","哈哈哈领域","2","翻译");
            UserExtend extend2 = new UserExtend("3","001","zh-cy","cy-zh","P8","P6","003","哈哈哈领域","2","翻译");
            UserExtend extend3 = new UserExtend("4","001","zh-cy","cy-zh","P9","P6","004","哈哈哈领域","2","翻译");
            List<UserExtend> anExtends = new ArrayList<>(); anExtends.add(extend);anExtends.add(extend1);anExtends.add(extend2);anExtends.add(extend3);
            UserForPM user = new UserForPM();
            user.setUserCode("J001");
            user.setRealName("J001");
            user.setTranslateType(1);
            user.setUserExtendList(anExtends);
            param.put("translateType", user.getTranslateType());
            param.put("skillLv", user.getUserExtendList());
            //            param.put("taskTypes", Arrays.asList("2","5","6").stream().filter(x -> taskTypes.contains(x)).collect(Collectors.toList()));
//            param.put("taskTypes", DataBaseStartUpRunner.init_user_data.get(staffNum).getRoleCodeList().stream().filter(x -> taskTypes.contains(x)).collect(Collectors.toList()));
        }catch (Exception e) {
            logger.error("获取角色失败 -> {}",e);
            return ResultModel.Fail("获取用户信息失败", page);
        }
        ParamBuildUtil.ParamBuild(param,taskInfo);

        try{
            transTaskService.getNotReceiveTask(page);
        }catch (Exception e){
            logger.error("查询出错  >>>>>>>>>>  {}",e);
            return ResultModel.Fail("查询出错",page);
        }
        return ResultModel.SuccessForMsg("查询成功",page);
    }

    /**
     * 文件在线预览
     * @param fileId
     * @param path
     * @param staffNum
     * @param request
     * @param response
     * @throws Exception
     */
    @ApiOperation("文件在线预览")
    @RequestMapping(value = "/view", method = RequestMethod.GET)
    public void preview(String fileId, String path, String staffNum, HttpServletRequest request, HttpServletResponse response) throws Exception {
//        path = "D:\\工作文档\\数据库设计文档V2.0.doc";
        //获取路径
//        String path = "";
        //没获取到文件路径 通过文件id获取
        if(StringUtils.isEmpty(path)){
            if(StringUtils.isEmpty(fileId)){
                throw new RuntimeException("文件路径和文件id不可同时为空");
            }
            //通过文件id获取
            PmFile pmFile = fileService.getFileByFileId(fileId);
            if(pmFile == null){
                throw new Exception("文件为找到");
            }
            path = pmFile.getFilePath();
        }

        //转pdf
        File file = null;
        if(path.indexOf(".pdf") == -1 && path.indexOf(".PDF") == -1){
            if(!ConvertToPdfUtil.isConvertible(path)){
                throw new Exception("格式不支持");
            }

//            String sourceName = new File(path).getName();
            String fileName = path.substring(path.lastIndexOf("/") + 1, path.lastIndexOf("."));
            String pdfPath = ParamStatic.FILE_PATH_TEMP + staffNum + "/" +fileName + ".pdf";
            PropertyData data = new PropertyData(upfileHost, upfilePort, upfileUsername, upfilePassword);
            file = ConvertToPdfUtil.office2PDF(path, pdfPath, data)?new File(pdfPath) : null;
        }else {
            file = new File(path);
        }

        InputStream input=null;

        OutputStream out=null;

        //文件流
        input=new ByteArrayInputStream(FileUtils.readFileToByteArray(file));
        response.setContentType("application/pdf");
        out = response.getOutputStream();

        //512字节搬砖
        byte[] b = new byte[512];
        if(out!=null) {
            if(input!=null) {
                while ((input.read(b))!=-1) {
                    out.write(b);
                }
            }else {
                logger.info("InputStream为空。。。");
                System.out.println("InputStream为空。。。");
            }
        }else {
            logger.info("OutputStream为空。。。");
        }

        if(file.exists()){
            file.delete();
        }

        //刷缓存、关流
        out.flush();
        input.close();
        out.close();
    }

    /**
     * 预领译后dtp，参数：任务id
     * @param taskId
     * @return
     */
    @ApiOperation("预领译后dtp")
    @RequestMapping(value = "/preGetAfterDTP", method = RequestMethod.GET)
    public ResultModel preGetAfterDTP(String taskId){
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }

        try {
            dtpTaskService.getAfterDTPTask(taskId);
        }catch (Exception e){
            logger.error("预领取译后DTP失败 >>>>>>>>>> {}",e);
            return ResultModel.FailWithNoData("预领取译后DTP失败");
        }
        return ResultModel.Success();
    }

    /**
     * 判断是否可以领取译后dtp
     * @param taskId
     * @return
     */
    @ApiOperation("判断是否可以预取译后dtp")
    @RequestMapping(value = "/hasPermissionsForAfterDTPTask", method = RequestMethod.GET)
    public ResultModel hasPermissionsForAfterDTPTask(String taskId){
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }

        try {
            dtpTaskService.hasPermissionsForAfterDTPTask(taskId);
        }catch (Exception e){
            logger.error("查询预领取权限失败 >>>>>>>>>> {}",e);
            return ResultModel.FailWithNoData("查询预领取权限失败");
        }
        return ResultModel.Success();
    }

    /**
     * 设置工作量
     * @param taskId
     * @param wordload
     * @return
     */
    @ApiOperation("设置工作量")
    @RequestMapping(value = "/setWordload",method = RequestMethod.POST)
    public ResultModel setWordLoad(String taskId, String wordload){
        if (StringUtils.isEmpty(taskId)) {
            return ResultModel.FailWithNoData("请传入任务ID");
        }
        if (StringUtils.isEmpty(wordload)) {
            return ResultModel.FailWithNoData("请传入工作量");
        }

        try{
            dtpTaskService.setWordLoad(taskId, wordload);
        }catch (Exception e){
            logger.error("更新工作量失败 >>>>>>>>>> {}",e);
            return ResultModel.FailWithNoData("更新工作量失败");
        }

        return ResultModel.Success();
    }

    /**
     * 导出文件
     * @param fileId
     * @return
     */
    @ApiOperation("导出文件")
    @RequestMapping(value = "/exportFile", method = RequestMethod.GET)
    public ResponseEntity<byte[]> exportFile(String fileId) throws Exception {
//        String path = "D:\\pangu_pm\\阿里巴巴Java开发...1528268103.pdf";
        PmFile fileInfo = fileService.getFileByFileId(fileId);
        String path = fileInfo.getFilePath();

        File file = new File(path);
        HttpHeaders headers = new HttpHeaders();
        String downFileName = new String(file.getName().getBytes("utf-8"),"iso-8859-1");
        headers.setContentDispositionFormData("attachment",downFileName);
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        byte[] bytes = FileUtils.readFileToByteArray(file);

        return new ResponseEntity<>(bytes,headers, HttpStatus.OK);
    }

    /**
     * 任务详情
     * @param fileId
     * @return
     */
//    @RequestMapping(value = "/taskDetail", method = RequestMethod.GET)
    public ResultModel taskDetail(String fileId) {
        /**
         * TODO 任务详情
         */
        return ResultModel.Success();
    }


    public static void main(String[] args) throws IOException {
        String path = "\\\\192.168.2.251\\技术中心\\项目文件\\CAT_R2共享文件夹\\每晚汇总-在线编辑器问题.xlsx";
        File file = new File(path);
        System.out.println(file.getName());
        System.out.println(System.getProperty("user.dir"));
        System.out.println(file.getCanonicalPath());//获取标准的路径
        System.out.println(file.getAbsolutePath());
        String filename = new File(path).getName();
        System.out.println(filename.substring(0, filename.lastIndexOf(".")));
    }
}
