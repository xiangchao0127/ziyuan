package com.sy.pangu.pm.entity.example;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PmDistributeExample {
    /**
     * pm_distribute
     */
    protected String orderByClause;

    /**
     * pm_distribute
     */
    protected boolean distinct;

    /**
     * pm_distribute
     */
    protected List<Criteria> oredCriteria;

    public PmDistributeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * pm_distribute null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andFlowIdIsNull() {
            addCriterion("flow_id is null");
            return (Criteria) this;
        }

        public Criteria andFlowIdIsNotNull() {
            addCriterion("flow_id is not null");
            return (Criteria) this;
        }

        public Criteria andFlowIdEqualTo(String value) {
            addCriterion("flow_id =", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotEqualTo(String value) {
            addCriterion("flow_id <>", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdGreaterThan(String value) {
            addCriterion("flow_id >", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdGreaterThanOrEqualTo(String value) {
            addCriterion("flow_id >=", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLessThan(String value) {
            addCriterion("flow_id <", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLessThanOrEqualTo(String value) {
            addCriterion("flow_id <=", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLike(String value) {
            addCriterion("flow_id like", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotLike(String value) {
            addCriterion("flow_id not like", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdIn(List<String> values) {
            addCriterion("flow_id in", values, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotIn(List<String> values) {
            addCriterion("flow_id not in", values, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdBetween(String value1, String value2) {
            addCriterion("flow_id between", value1, value2, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotBetween(String value1, String value2) {
            addCriterion("flow_id not between", value1, value2, "flowId");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlIsNull() {
            addCriterion("full_staff_lvl is null");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlIsNotNull() {
            addCriterion("full_staff_lvl is not null");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlEqualTo(String value) {
            addCriterion("full_staff_lvl =", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlNotEqualTo(String value) {
            addCriterion("full_staff_lvl <>", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlGreaterThan(String value) {
            addCriterion("full_staff_lvl >", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlGreaterThanOrEqualTo(String value) {
            addCriterion("full_staff_lvl >=", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlLessThan(String value) {
            addCriterion("full_staff_lvl <", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlLessThanOrEqualTo(String value) {
            addCriterion("full_staff_lvl <=", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlLike(String value) {
            addCriterion("full_staff_lvl like", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlNotLike(String value) {
            addCriterion("full_staff_lvl not like", value, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlIn(List<String> values) {
            addCriterion("full_staff_lvl in", values, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlNotIn(List<String> values) {
            addCriterion("full_staff_lvl not in", values, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlBetween(String value1, String value2) {
            addCriterion("full_staff_lvl between", value1, value2, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFullStaffLvlNotBetween(String value1, String value2) {
            addCriterion("full_staff_lvl not between", value1, value2, "fullStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlIsNull() {
            addCriterion("free_staff_lvl is null");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlIsNotNull() {
            addCriterion("free_staff_lvl is not null");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlEqualTo(String value) {
            addCriterion("free_staff_lvl =", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlNotEqualTo(String value) {
            addCriterion("free_staff_lvl <>", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlGreaterThan(String value) {
            addCriterion("free_staff_lvl >", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlGreaterThanOrEqualTo(String value) {
            addCriterion("free_staff_lvl >=", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlLessThan(String value) {
            addCriterion("free_staff_lvl <", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlLessThanOrEqualTo(String value) {
            addCriterion("free_staff_lvl <=", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlLike(String value) {
            addCriterion("free_staff_lvl like", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlNotLike(String value) {
            addCriterion("free_staff_lvl not like", value, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlIn(List<String> values) {
            addCriterion("free_staff_lvl in", values, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlNotIn(List<String> values) {
            addCriterion("free_staff_lvl not in", values, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlBetween(String value1, String value2) {
            addCriterion("free_staff_lvl between", value1, value2, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andFreeStaffLvlNotBetween(String value1, String value2) {
            addCriterion("free_staff_lvl not between", value1, value2, "freeStaffLvl");
            return (Criteria) this;
        }

        public Criteria andTimePerIsNull() {
            addCriterion("time_per is null");
            return (Criteria) this;
        }

        public Criteria andTimePerIsNotNull() {
            addCriterion("time_per is not null");
            return (Criteria) this;
        }

        public Criteria andTimePerEqualTo(Double value) {
            addCriterion("time_per =", value, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerNotEqualTo(Double value) {
            addCriterion("time_per <>", value, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerGreaterThan(Double value) {
            addCriterion("time_per >", value, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerGreaterThanOrEqualTo(Double value) {
            addCriterion("time_per >=", value, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerLessThan(Double value) {
            addCriterion("time_per <", value, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerLessThanOrEqualTo(Double value) {
            addCriterion("time_per <=", value, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerIn(List<Double> values) {
            addCriterion("time_per in", values, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerNotIn(List<Double> values) {
            addCriterion("time_per not in", values, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerBetween(Double value1, Double value2) {
            addCriterion("time_per between", value1, value2, "timePer");
            return (Criteria) this;
        }

        public Criteria andTimePerNotBetween(Double value1, Double value2) {
            addCriterion("time_per not between", value1, value2, "timePer");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeIsNull() {
            addCriterion("notify_time is null");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeIsNotNull() {
            addCriterion("notify_time is not null");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeEqualTo(String value) {
            addCriterion("notify_time =", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeNotEqualTo(String value) {
            addCriterion("notify_time <>", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeGreaterThan(String value) {
            addCriterion("notify_time >", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeGreaterThanOrEqualTo(String value) {
            addCriterion("notify_time >=", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeLessThan(String value) {
            addCriterion("notify_time <", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeLessThanOrEqualTo(String value) {
            addCriterion("notify_time <=", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeLike(String value) {
            addCriterion("notify_time like", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeNotLike(String value) {
            addCriterion("notify_time not like", value, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeIn(List<String> values) {
            addCriterion("notify_time in", values, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeNotIn(List<String> values) {
            addCriterion("notify_time not in", values, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeBetween(String value1, String value2) {
            addCriterion("notify_time between", value1, value2, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNotifyTimeNotBetween(String value1, String value2) {
            addCriterion("notify_time not between", value1, value2, "notifyTime");
            return (Criteria) this;
        }

        public Criteria andNodeIdIsNull() {
            addCriterion("node_id is null");
            return (Criteria) this;
        }

        public Criteria andNodeIdIsNotNull() {
            addCriterion("node_id is not null");
            return (Criteria) this;
        }

        public Criteria andNodeIdEqualTo(Integer value) {
            addCriterion("node_id =", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotEqualTo(Integer value) {
            addCriterion("node_id <>", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdGreaterThan(Integer value) {
            addCriterion("node_id >", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("node_id >=", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdLessThan(Integer value) {
            addCriterion("node_id <", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdLessThanOrEqualTo(Integer value) {
            addCriterion("node_id <=", value, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdIn(List<Integer> values) {
            addCriterion("node_id in", values, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotIn(List<Integer> values) {
            addCriterion("node_id not in", values, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdBetween(Integer value1, Integer value2) {
            addCriterion("node_id between", value1, value2, "nodeId");
            return (Criteria) this;
        }

        public Criteria andNodeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("node_id not between", value1, value2, "nodeId");
            return (Criteria) this;
        }

        public Criteria andLastEditorIsNull() {
            addCriterion("last_editor is null");
            return (Criteria) this;
        }

        public Criteria andLastEditorIsNotNull() {
            addCriterion("last_editor is not null");
            return (Criteria) this;
        }

        public Criteria andLastEditorEqualTo(String value) {
            addCriterion("last_editor =", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotEqualTo(String value) {
            addCriterion("last_editor <>", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorGreaterThan(String value) {
            addCriterion("last_editor >", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorGreaterThanOrEqualTo(String value) {
            addCriterion("last_editor >=", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorLessThan(String value) {
            addCriterion("last_editor <", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorLessThanOrEqualTo(String value) {
            addCriterion("last_editor <=", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorLike(String value) {
            addCriterion("last_editor like", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotLike(String value) {
            addCriterion("last_editor not like", value, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorIn(List<String> values) {
            addCriterion("last_editor in", values, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotIn(List<String> values) {
            addCriterion("last_editor not in", values, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorBetween(String value1, String value2) {
            addCriterion("last_editor between", value1, value2, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditorNotBetween(String value1, String value2) {
            addCriterion("last_editor not between", value1, value2, "lastEditor");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeIsNull() {
            addCriterion("last_edit_time is null");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeIsNotNull() {
            addCriterion("last_edit_time is not null");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeEqualTo(Date value) {
            addCriterion("last_edit_time =", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotEqualTo(Date value) {
            addCriterion("last_edit_time <>", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeGreaterThan(Date value) {
            addCriterion("last_edit_time >", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("last_edit_time >=", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeLessThan(Date value) {
            addCriterion("last_edit_time <", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeLessThanOrEqualTo(Date value) {
            addCriterion("last_edit_time <=", value, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeIn(List<Date> values) {
            addCriterion("last_edit_time in", values, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotIn(List<Date> values) {
            addCriterion("last_edit_time not in", values, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeBetween(Date value1, Date value2) {
            addCriterion("last_edit_time between", value1, value2, "lastEditTime");
            return (Criteria) this;
        }

        public Criteria andLastEditTimeNotBetween(Date value1, Date value2) {
            addCriterion("last_edit_time not between", value1, value2, "lastEditTime");
            return (Criteria) this;
        }
    }

    /**
     * pm_distribute
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * pm_distribute null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}