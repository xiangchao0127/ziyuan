package com.sy.pangu.pm.model;

import java.util.List;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/

public class PackInfoModel {
    /**
     * 顺序
     */
   private int id;
    /**
     * 拆分字数，给CAT
     */
   private int requireWordCount;
    /**
     * 是否是最后一个
     */
   private  boolean lastTask;

   private List<PackInfoModel> packInfoList;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRequireWordCount() {
        return requireWordCount;
    }

    public void setRequireWordCount(int requireWordCount) {
        this.requireWordCount = requireWordCount;
    }

    public boolean isLastTask() {
        return lastTask;
    }

    public void setLastTask(boolean lastTask) {
        this.lastTask = lastTask;
    }

    public List<PackInfoModel> getPackInfoList() {
        return packInfoList;
    }

    public void setPackInfoList(List<PackInfoModel> packInfoList) {
        this.packInfoList = packInfoList;
    }
}
