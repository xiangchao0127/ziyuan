package com.sy.pangu.pm.entity.vo;

import com.sy.pangu.permission.model.UserForPM;
import lombok.Data;

import java.util.List;

/**
 * @author ：lhaotian
 * date ：Created in 2019/4/29 14:50
 */
@Data
public class TransManagerVo {
    /**
     *
     */
    private String sourceLanguage;

    /**
     *
     */
    private String targetLanguage;

    /**
     *
     */
    private String domain;

    /**
     * 翻译经理的code
     */
    private List<UserForPM> userCode;

    private Integer id;
}
