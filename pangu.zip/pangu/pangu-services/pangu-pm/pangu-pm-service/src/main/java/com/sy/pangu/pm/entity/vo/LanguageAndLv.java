package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @author ：jzj
 * @date ：Created in 2019/5/10 14:14
 */
@Data
public class LanguageAndLv{
    /**
     * 源语言Code
     */
    private String sourceLangauge;

    /**
     * 目标语言Code
     */
    private String targetLangauge;

    /**
     * 等级Id
     */
    private String levelId;

    /**
     * 等级名称
     */
    private String levelName;

    public LanguageAndLv(String sourceLangauge, String targetLangauge, String levelId, String levelName) {
        this.sourceLangauge = sourceLangauge;
        this.targetLangauge = targetLangauge;
        this.levelId = levelId;
        this.levelName = levelName;
    }
}
