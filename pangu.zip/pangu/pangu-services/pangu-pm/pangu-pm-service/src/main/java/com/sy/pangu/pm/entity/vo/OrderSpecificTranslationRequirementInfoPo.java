package com.sy.pangu.pm.entity.vo;

import lombok.Data;

/**
 * @program: pangu_pm
 * @author: zhonglin
 * @create: 2019-04-10
 **/
@Data
public class OrderSpecificTranslationRequirementInfoPo {
    private String id; // 订单id
    private int translateTheTextOnThePicture; // 是否翻译图片上的文字
    private int typesettingFormat; // 排版格式
    private int typesetting; // 译文排版
    private int pPicture; // 是否p图
    private int style; // 文风语气
    private String remark; // 翻译需求备注
    private String attention; // 注意事项
    private int statusCode; // 数据使用状态
}
