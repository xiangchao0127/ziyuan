package com.sy.pangu.pm.schedule;

import ch.qos.logback.classic.Logger;
import com.sy.pangu.pm.config.DataBaseStartUpRunner;
import com.sy.pangu.pm.service.IInitParamService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * @author ：jzj
 * date ：Created in 2019/4/28 16:06
 */
@Configuration
public class InitParamSchedule {

    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
    @Autowired
    private IInitParamService initParamService;

    //添加定时任务

    //每分钟刷新一次系统参数
    @Scheduled(fixedRate = 1000 * 60)
    private void initPartParam() {
        //
        if (DataBaseStartUpRunner.initPmSysTask.size() == 0) {
            DataBaseStartUpRunner.initPmSysTask = initParamService.getInitSysTask();
        }
        //语言对
        if (DataBaseStartUpRunner.init_language_data.size() == 0) {
            DataBaseStartUpRunner.init_language_data = initParamService.getInitLanguageData();
        }
        //user
        DataBaseStartUpRunner.init_user_data = initParamService.getInitUserData();


        if (DataBaseStartUpRunner.init_domain_data.size() == 0) {
            DataBaseStartUpRunner.init_domain_data = initParamService.getInitDomainData();
        }

    }

    //每天0点定时刷新一次系统参数
    @Scheduled(cron = "0 0 0 * * ?")
    private void initAllParam() {
        logger.info("===============系统每日刷新系统参数开始===============");
        DataBaseStartUpRunner.initPmSysTask = initParamService.getInitSysTask();
        DataBaseStartUpRunner.init_language_data = initParamService.getInitLanguageData();
        DataBaseStartUpRunner.init_user_data = initParamService.getInitUserData();
        DataBaseStartUpRunner.init_domain_data = initParamService.getInitDomainData();
        logger.info("===============系统每日刷新系统参数结束===============");
    }

    public static void main(String[] args) {
    }
}
