package com.sy.pangu.pm.entity.CATParams;

import lombok.Data;

/**
 * @author ：lhaotian
 * date ：Created in 2019/5/8 14:11
 * 向cat请求解析状态的返回结果
 */
@Data
public class PreResultInfo {
    /**
     * 解析状态信息
     * 1：解析成功
     * 2：去重成功
     * 3：封包成功
     * 0：文件不存在
     * -1：解析失败
     * -2：去重失败
     * -3：封包失败
     */
    private int code;
    private String msg;
    private Object data;
    private String fileId;
    private String projectId;
    private boolean success;
}
