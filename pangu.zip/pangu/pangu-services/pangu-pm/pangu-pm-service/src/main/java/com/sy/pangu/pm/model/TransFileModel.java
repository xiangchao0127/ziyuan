package com.sy.pangu.pm.model;

import java.util.List;

/**
 * program: pangu_pm
 * @author: zhonglin
 * create: 2019-04-10
 **/

public class TransFileModel {
    // 文件名
    private String FileName;
    //拆分字数
    private int WordCount;

    private List<TransFileModel> TransFileList;

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String fileName) {
        FileName = fileName;
    }

    public int getWordCount() {
        return WordCount;
    }

    public void setWordCount(int wordCount) {
        WordCount = wordCount;
    }

    public List<TransFileModel> getTransFileList() {
        return TransFileList;
    }

    public void setTransFileList(List<TransFileModel> transFileList) {
        TransFileList = transFileList;
    }
}
