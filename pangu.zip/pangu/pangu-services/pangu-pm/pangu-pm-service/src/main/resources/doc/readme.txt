1、openoffice 启动
    //安装目录
    cd D:\Program Files (x86)\OpenOffice 4\program
    soffice -headless -accept="socket,host=127.0.0.1,port=8100;urp;" -nofirststartwizard
    //linux
    cd /opt/openoffice4/program
     ./soffice "-accept=socket,host=localhost,port=8100;urp;StarOffice.ServiceManager" -nologo -headless -nofirststartwizard &