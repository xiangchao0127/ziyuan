package com.sy.pangu.pm.client;

import com.sy.pangu.pm.model.ResultModel;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author ：jzj
 * @date ：Created in 2019/5/5 15:17
 */
@FeignClient(name = "pangu-pm", path = "/pm")
public interface StatisticsUserTaskInfoClient {
    /**
     * data : UserTaskStatisticsVo
     * @param userCode
     * @return
     */
    @GetMapping("/statistics/getUserTaskStatisticsInfo/{userCode}")
    ResultModel getUserTaskStatisticsInfo(@PathVariable("userCode") String userCode);
}
