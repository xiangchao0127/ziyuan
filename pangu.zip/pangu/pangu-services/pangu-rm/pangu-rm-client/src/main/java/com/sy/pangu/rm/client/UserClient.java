package com.sy.pangu.rm.client;

public interface UserClient {
}
