package com.sy.pangu.rm.client;

import com.sy.pangu.rm.model.BaseResponse;
import com.sy.pangu.rm.model.BussinessLog;
import com.sy.pangu.rm.model.CommentAndReplyData;
import com.sy.pangu.rm.model.PageResults;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author XiangChao
 * @date 2019/5/8
 */
@FeignClient(name = "pangu-rm", path = "/rm")
public interface CommentAndLogClient {
    /**
     * 添加评论
     * @param bussinessId 业务id
     * @param nickName 昵称
     * @param commentContent 评论内容
     * @return
     */
    @PostMapping(value = "/commentAndLog/addComment")
    BaseResponse addComment(@RequestParam("bussinessId")String bussinessId, @RequestParam("nickName")String nickName,
                            @RequestParam("commentContent")String commentContent);

    /**
     * 添加回复
     * @param commentId 评论id
     * @param nickName 昵称
     * @param replyTarget 回复对象
     * @param replyContent 回复内容
     * @return
     */
    @PostMapping(value = "/commentAndLog/addCommentReply")
    BaseResponse addCommentReply(@RequestParam("commentId")String commentId,@RequestParam("nickName")String nickName,
                                 @RequestParam("replyTarget")String replyTarget,@RequestParam("replyContent")String replyContent);

    /**
     * 获取评论以及回复列表
     * @param bussinessId
     * @return
     */
    @PostMapping(value = "/commentAndLog/getCommentAndReply")
    PageResults<CommentAndReplyData> getCommentAndReply(@RequestParam("bussinessId")String bussinessId, @RequestParam("pageNo")int pageNo,
                                                        @RequestParam("pageSize") int pageSize);

    /**
     * 添加业务日志(存入elasticsearch)
     * @param bussinessId 业务id
     * @param operateUserId 操作人id
     * @param content 内容
     * @return
     */
    @PostMapping(value = "/commentAndLog/addBussinessLog")
    BaseResponse addBussinessLog(@RequestParam("bussinessId")String bussinessId,@RequestParam("operateUserId")String operateUserId,
                                 @RequestParam("content")String content);

    /**
     * 获取日志列表 (获取所有日志pageSize写100000)
     * @param bussinessId 业务id
     * @return
     */
    @PostMapping(value = "/commentAndLog/getBussinessLogs")
    PageResults<BussinessLog> getBussinessLogs(@RequestParam("bussinessId")String bussinessId,@RequestParam("pageNo") int pageNo,
                                               @RequestParam("pageSize")int pageSize);

}
