package com.sy.pangu.rm.client;


import com.sy.pangu.rm.model.LevelRelation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "pangu-rm", path = "/rm")
public interface LevelRelationClient {

    @GetMapping("/userExtension/listAllLevelRelation")
    List<LevelRelation> listAllLevelRelation();

}
