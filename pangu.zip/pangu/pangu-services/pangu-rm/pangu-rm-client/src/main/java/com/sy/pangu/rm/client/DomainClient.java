package com.sy.pangu.rm.client;

import com.sy.pangu.rm.model.DomainData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/10
 */
@FeignClient(name = "pangu-rm", path = "/rm")
public interface DomainClient {
    /**
     * 获取一级领域
     */
    @GetMapping("/feign/domain/listDomain")
    List<DomainData> listDomain();

    /**
     * 获取二级领域
     * @param pSpecialtyId 以及领域id
     * @return
     */
    @GetMapping("/feign/domain/listSub")
    List<DomainData> listsubDomain(Integer pSpecialtyId);

    /**
     * 获取所有领域
     * @return
     */
    @GetMapping("/feign/domain/listAll")
    List<DomainData> listAll();
  ;
}
