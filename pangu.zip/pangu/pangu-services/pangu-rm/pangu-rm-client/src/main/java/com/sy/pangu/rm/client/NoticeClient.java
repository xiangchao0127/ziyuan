package com.sy.pangu.rm.client;

import com.sy.pangu.rm.model.BaseResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author XiangChao
 * @date 2019/4/26
 */
@FeignClient(name = "pangu-rm", path = "/rm")
public interface NoticeClient {
    /**
     * 向某人发消息
     *
     * @param sendPerson     发送人
     * @param sendToPersonId 接收人id
     * @param messageType    消息类型
     * @param content        内容
     * @return
     */
    @PostMapping(value = "/feign/notice/sendToSomeOne")
    BaseResponse sendToSomeOne(@RequestParam("sendPerson") String sendPerson, @RequestParam("sendToPersonId") String sendToPersonId,
                               @RequestParam("messageType") String messageType, @RequestParam("content") String content);
}
