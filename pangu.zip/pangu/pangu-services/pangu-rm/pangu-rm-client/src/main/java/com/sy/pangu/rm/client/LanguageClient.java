package com.sy.pangu.rm.client;

import com.sy.pangu.rm.model.LanguageData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/10
 */
@FeignClient(name = "pangu-rm", path = "/rm")
public interface LanguageClient {
    @GetMapping("/feign/language/listAll")
    List<LanguageData> listLanguage();
}
