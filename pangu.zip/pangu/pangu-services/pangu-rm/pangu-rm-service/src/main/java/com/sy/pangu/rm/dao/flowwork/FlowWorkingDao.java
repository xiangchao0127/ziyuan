package com.sy.pangu.rm.dao.flowwork;

import com.sy.pangu.rm.entity.flowwork.FlowWorking;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/16
 * Time:15:42
 */
public interface FlowWorkingDao extends JpaRepository<FlowWorking,String> {
}
