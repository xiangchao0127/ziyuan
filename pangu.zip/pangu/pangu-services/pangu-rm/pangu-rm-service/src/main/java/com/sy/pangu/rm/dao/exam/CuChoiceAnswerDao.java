package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.CuChoiceAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/15
 * Time:9:09
 */
public interface CuChoiceAnswerDao extends JpaRepository<CuChoiceAnswer,String> {
    List<CuChoiceAnswer> findByRecordIdOrderByQuestionIndexAsc(String recordId);
}
