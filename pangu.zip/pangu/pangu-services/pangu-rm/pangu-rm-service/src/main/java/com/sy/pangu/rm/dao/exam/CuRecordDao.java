package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.CuRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/11
 * Time:13:41
 */
public interface CuRecordDao extends JpaRepository<CuRecord,String> {
    List<CuRecord> findAllByUserId(String userId);
    List<CuRecord> findAllByUserIdAndExamType(String userId,String examType);
}
