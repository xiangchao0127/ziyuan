package com.sy.pangu.rm.controller;

import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.rm.datamodel.request.AddInterpreterArticleParam;
import com.sy.pangu.rm.entity.article.OfficialArticle;
import com.sy.pangu.rm.service.OfficialArticleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author XiangChao
 * @date 2019/5/8
 */
@Api(tags = {"官方文章管理"})
@RestController
@RequestMapping("/officialArticle")
public class OfficialArticleController {
    @Autowired
    OfficialArticleService officialArticleService;

    /**
     *  官方文章列表
     * @param articleTitle 文章标题
     * @param publishStartTime 发布开始时间(yyyy-MM-dd HH:mm:ss)
     * @param publishEndTime 发布结束时间(yyyy-MM-dd HH:mm:ss)
     * @return
     */
    @ApiOperation("官方文章列表")
    @GetMapping("/listOfficialArticle")
    public ResponseEntity<Page<OfficialArticle>> listOfficialArticle(String articleTitle, String publishStartTime, String publishEndTime, Integer pageNo, Integer pageSize) {
        if (StringUtils.notEmpty(publishStartTime) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, publishStartTime)) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "开始时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if (StringUtils.notEmpty(publishEndTime) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, publishEndTime)) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "结束时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if(pageNo==null || pageSize==null){
            throw new CustomException(ExceptionEnum.Params_Empty,"pageNo和pageSize不能为空");
        }
        return ResponseEntity.ok().body(officialArticleService.listOfficialArticle(articleTitle,publishStartTime,publishEndTime,pageNo,pageSize));
    }

    /**
     * 添加官方文章
     * @param addOfficialArticleParam
     * @return
     */
    @ApiOperation("添加官方文章")
    @PostMapping("/addOfficialArticle")
    public ResponseEntity<Integer> addOfficialArticle(AddInterpreterArticleParam addOfficialArticleParam) {
        return ResponseEntity.ok().body(officialArticleService.addOfficialArticle(addOfficialArticleParam));
    }

    /**
     * 编辑官方文章
     * @param addOfficialArticleParam
     * @return
     */
    @ApiOperation("编辑官方文章")
    @PutMapping("/editOfficialArticle")
    public ResponseEntity<Integer> editOfficialArticle(AddInterpreterArticleParam addOfficialArticleParam) {
        return ResponseEntity.ok().body(officialArticleService.editOfficialArticle(addOfficialArticleParam));
    }

    /**
     * 官方文章详情
     * @param articleId 文章id
     * @return
     */
    @ApiOperation("官方文章详情")
    @GetMapping("/officialArticleDetails")
    public ResponseEntity<OfficialArticle> officialArticleDetails(String articleId) {
        return ResponseEntity.ok().body(officialArticleService.officialArticleDetails(articleId));
    }

    /**
     * 运营数据修改
     * @param articleId 官方文章id
     * @param viewBase 浏览量基数
     * @param likeBase 点赞量基数
     * @return
     */
    @ApiOperation("运营数据修改")
    @PutMapping("/updateArticleBaseData")
    public ResponseEntity<Integer> updateArticleBaseData(String articleId, Integer viewBase, Integer likeBase) {
        return ResponseEntity.ok().body(officialArticleService.updateArticleBaseData(articleId,viewBase,likeBase));
    }

    /**
     * 置顶文章
     * @param articleId 文章id
     * @return
     */
    @ApiOperation("置顶文章")
    @PutMapping("/toppingArticle")
    public ResponseEntity<Integer> toppingArticle(String articleId) {
        return ResponseEntity.ok().body(officialArticleService.toppingArticle(articleId));
    }

    /**
     * 删除文章
     * @param articleId 文章id
     * @return
     */
    @ApiOperation("删除文章")
    @DeleteMapping("/deleteArticle")
    public ResponseEntity<Integer> deleteArticle(String articleId) {
        return ResponseEntity.ok().body(officialArticleService.deleteArticle(articleId));
    }
}
