package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

/**
 * @author XiangChao
 * @date 2019/5/7
 */
@Data
public class AddInterpreterArticleParam {
    /**
     * 文章id
     */
    private String articleId;
    /**
     * 文章标题
     */
    private String articleTitle;
    /**
     * 标签
     */
    private String label;
    /**
     * 封面id
     */
    private String coverId;
    /**
     * 文章内容
     */
    private String content;
    /**
     * 浏览基数
     */
    private Integer viewCount;
    /**
     * 点赞基数
     */
    private Integer likeCount;
    /**
     * 发布状态(0 草稿箱     1 发布)
     */
    private Integer status;
}
