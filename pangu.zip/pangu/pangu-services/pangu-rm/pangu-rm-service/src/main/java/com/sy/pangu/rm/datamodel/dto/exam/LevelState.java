package com.sy.pangu.rm.datamodel.dto.exam;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/11
 * Time:9:09
 */
public interface LevelState {
    void handle(CurrentLevelState currentLevelState);
    String getNextLevelName();
    Integer getPrimaryLevel();
    Integer getMiddleLevel();
    Integer getHighLevel();

}
