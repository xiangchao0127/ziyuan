package com.sy.pangu.rm.controller;

import com.sy.pangu.rm.datamodel.request.W3.W3LevelInfoParam;
import com.sy.pangu.rm.datamodel.request.W3.W3UserParam;
import com.sy.pangu.rm.service.W3UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = {"对接W3专职信息"})
@RestController
@RequestMapping("w3UserController")
public class W3UserController {


    @Autowired
    W3UserService w3UserService;

    @ApiOperation("同步W3人员基本信息")
    @PostMapping("synW3UserBasicInfo")
    public ResponseEntity<Boolean> saveUserInfo(W3UserParam w3UserParam) {
         return ResponseEntity.ok().body(w3UserService.saveUserInfo(w3UserParam));
    }

    @ApiOperation("同步W3人员等级等信息")
    @PostMapping("synW3UserLevelInfo")
    public ResponseEntity<Boolean> saveUserLevelInfo(W3LevelInfoParam w3LevelInfoParam) {
        return ResponseEntity.ok().body(w3UserService.saveUserLevelInfo(w3LevelInfoParam));
    }


}
