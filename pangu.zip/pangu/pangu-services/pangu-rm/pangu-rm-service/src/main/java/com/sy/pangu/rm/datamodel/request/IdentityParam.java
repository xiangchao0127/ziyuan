package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class IdentityParam implements Serializable {

    /**
     * 用户id
     */
    private String userId;
    /**
     * 姓名
     */
    private String realName;
    /**
     * 证件类型(目前只传：身份证)
     */
    private String certificateType;
    /**
     * 身份证号码
     */
    private String identifyId;

}
