package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.TranslationQuestionDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * @author XiangChao
 * @date 2019/4/9
 */
public interface TranslationQuestionDao extends JpaRepository<TranslationQuestionDO,String>, JpaSpecificationExecutor<TranslationQuestionDO> {
    /**
     * 通过题号获取试题
     * @param questionNo
     * @return
     */
    TranslationQuestionDO findAllByQuestionNo(String questionNo);


    /**
     * 根据原文译文内容获取试题
     */
    TranslationQuestionDO findAllByOrignLanguageAndTargetLanguageAndOrignContent(String orignLanguage,String targetLanguage,String orignContent);
}
