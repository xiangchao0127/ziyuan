package com.sy.pangu.rm.dao.article;

import com.sy.pangu.rm.entity.article.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

/**
 * @author XiangChao
 * @date 2019/5/7
 */
public interface CommentDao extends JpaRepository<Comment,String>, JpaSpecificationExecutor<Comment> {
    @Query(nativeQuery = true,value = "select user_name from sys_user where id=?")
    String getRealNameById(String userId);

    @Query(nativeQuery = true,value = "select nick_name from sys_user where id=?")
    String getNickNameById(String userId);
}
