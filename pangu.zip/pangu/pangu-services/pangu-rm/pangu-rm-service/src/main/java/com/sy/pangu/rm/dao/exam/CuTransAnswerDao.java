package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.CuTransAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/15
 * Time:9:15
 */
public interface CuTransAnswerDao extends JpaRepository<CuTransAnswer,String> {
    List<CuTransAnswer> findAllByRecordId(String recodeId);
}
