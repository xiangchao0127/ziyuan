package com.sy.pangu.rm.datamodel.dto.exam;

import com.sy.pangu.rm.entity.exam.CuRecord;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/17
 * Time:13:59
 */
@Data
public class CreateExamDto<T>{
    private String questionIds;
    private List<Map<String,T>> questions;
    private CuRecord cuRecord;
    private String cuRecordId;
}
