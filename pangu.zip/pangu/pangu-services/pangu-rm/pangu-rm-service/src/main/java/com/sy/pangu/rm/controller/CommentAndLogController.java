package com.sy.pangu.rm.controller;


import com.sy.pangu.rm.model.BaseResponse;
import com.sy.pangu.rm.model.BussinessLog;
import com.sy.pangu.rm.model.CommentAndReplyData;
import com.sy.pangu.rm.model.PageResults;
import com.sy.pangu.rm.service.CommentAndLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author XiangChao
 * @date 2019/5/8
 */
@Api(tags = {"评论及日志"})
@RestController
@RequestMapping("/commentAndLog")
public class CommentAndLogController {
    @Autowired
    CommentAndLogService commentAndLogService;

    /**
     * 添加评论
     * @param bussinessId 业务id
     * @param nickName 昵称
     * @param commentContent 评论内容
     * @return     */

    @ApiOperation("添加评论")
    @PostMapping("/addComment")
    public BaseResponse addComment(String bussinessId, String nickName, String commentContent) {
        return commentAndLogService.addComment(bussinessId,nickName,commentContent);
    }

    /**
     * 添加回复
     * @param commentId 评论id
     * @param nickName 昵称
     * @param replyTarget 回复对象
     * @param replyContent 回复内容
     * @return
     */
    @ApiOperation("添加回复")
    @PostMapping("/addCommentReply")
    public BaseResponse addCommentReply(String commentId,String nickName,String replyTarget,String replyContent) {
        return commentAndLogService.addCommentReply(commentId,nickName,replyTarget,replyContent);
    }

    /**
     * 获取评论以及回复列表
     * @param bussinessId
     * @return
     */
    @ApiOperation("获取评论以及回复列表")
    @PostMapping("/getCommentAndReply")
    public PageResults<CommentAndReplyData> getCommentAndReply(String bussinessId, int pageNo, int pageSize) {
        return commentAndLogService.getCommentAndReply(bussinessId,pageNo,pageSize);
    }

    /**
     * 添加业务日志
     * @param bussinessId 业务id
     * @param operateUserId 操作人id
     * @param content 内容
     * @return
     */
    @ApiOperation("添加业务日志")
    @PostMapping("/addBussinessLog")
    public BaseResponse addBussinessLog(String bussinessId,String operateUserId,String content) {
        return commentAndLogService.addBussinessLog(bussinessId,operateUserId,content);
    }

    /**
     * 获取日志列表
     * @param bussinessId 业务id
     * @param pageNo 页码
     * @param pageSize 一页大小
     * @return
     */
    @ApiOperation("获取日志列表")
    @PostMapping("/getBussinessLogs")
    public PageResults<BussinessLog> getBussinessLogs(String bussinessId, int pageNo, int pageSize) {
        return commentAndLogService.getBussinessLogs(bussinessId,pageNo,pageSize);
    }
}
