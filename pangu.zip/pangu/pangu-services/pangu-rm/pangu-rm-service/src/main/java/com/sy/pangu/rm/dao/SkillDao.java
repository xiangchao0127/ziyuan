package com.sy.pangu.rm.dao;


import com.sy.pangu.rm.entity.UserSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * @author Q00596
 */
public interface SkillDao extends JpaRepository<UserSkill, String>, JpaSpecificationExecutor<UserSkill> {

    UserSkill findByUserIdAndUserCertificateType(String userId, String userSkillType);
}
