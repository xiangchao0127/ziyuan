package com.sy.pangu.rm.dao.article;

import com.sy.pangu.rm.entity.article.CommentReply;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * @author XiangChao
 * @date 2019/5/7
 */
public interface CommentReplyDao extends JpaRepository<CommentReply,String>, JpaSpecificationExecutor<CommentReply> {
}
