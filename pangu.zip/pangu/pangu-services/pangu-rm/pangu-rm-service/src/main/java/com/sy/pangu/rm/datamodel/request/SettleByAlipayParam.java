package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class SettleByAlipayParam implements Serializable {
    private  String id;
    private String userId;
    private String realName;
    private String alipayCode;
}
