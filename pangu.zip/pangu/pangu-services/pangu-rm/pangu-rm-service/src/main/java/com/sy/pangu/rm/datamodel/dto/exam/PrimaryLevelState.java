package com.sy.pangu.rm.datamodel.dto.exam;

import com.sy.pangu.rm.constant.TranslatorLevelConstant;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/11
 * Time:9:12
 */
public class PrimaryLevelState implements LevelState {

    @Override
    public void handle(CurrentLevelState currentLevelState) {
        currentLevelState.setNextLevelState(new MiddleLevelState());
    }

    @Override
    public Integer getPrimaryLevel() {
        return TranslatorLevelConstant.P1;
    }

    @Override
    public Integer getMiddleLevel() {
        return TranslatorLevelConstant.P2;
    }

    @Override
    public Integer getHighLevel() {
        return TranslatorLevelConstant.P3;
    }

    @Override
    public String getNextLevelName() {
        return "中级测试";
    }
}
