package com.sy.pangu.rm.controller;

import com.alibaba.fastjson.JSON;
import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.rm.entity.exam.CuOverview;
import com.sy.pangu.rm.service.ExamService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/9
 * Time:17:17
 */
@Api(tags = {"评测用户端"})
@RestController
@RequestMapping("/exam/customer")
public class ExamCustomerController {
    @Autowired
    private ExamService examService;
    @ApiOperation("获取擅长语言")
    @GetMapping("/listAdeptLanguages")
    public ResponseEntity<List<CuOverview>> listAdeptLanguages(){
        return ResponseEntity.ok().body(examService.listAdeptLanguages());
    }
    @ApiOperation("创建擅长语言")
    @PostMapping("/createAdepetLanguage")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "originLanguageCode",value = "原语言code"),
            @ApiImplicitParam(name = "originLanguageName",value = "原语言name"),
            @ApiImplicitParam(name = "secondLuanguageCode",value = "翻译语言code"),
            @ApiImplicitParam(name = "secondLuanguageName",value = "翻译语言name")
    })
    public ResponseEntity<Integer> createAdepetLanguage(String originLanguageCode,
                                                        String originLanguageName,
                                                        String secondLuanguageCode,
                                                        String secondLuanguageName){

        return ResponseEntity.ok().body(examService.createAdepetLanguage(originLanguageCode,
                originLanguageName,secondLuanguageCode,secondLuanguageName));
    }
    @ApiOperation("删除擅长语言")
    @DeleteMapping("/deleteAdepetLanguage")
    @ApiImplicitParam(name = "id",value = "所属id")
    public ResponseEntity<Integer>  deleteAdepetLanguage(String id){
        return ResponseEntity.ok().body(examService.deleteAdepetLanguage(id));

    }

    @ApiOperation("创建选择题测试")
    @PostMapping("/createChoiceExam")
    @ApiImplicitParam(name = "id",value = "所属id")
    public ResponseEntity<Object> createChoiceExam(String id){
        return ResponseEntity.ok().body(examService.createChoiceExam(id));
    }

    @ApiOperation("创建翻译题测试")
    @PostMapping("/createTranSExam")
    @ApiImplicitParam(name = "id",value = "所属id")
    public ResponseEntity<Object> createTranSExam(String id){
        return ResponseEntity.ok().body(examService.createTranSExam(id));
    }
    @ApiOperation("设置翻译领域")
    @PostMapping("/setTransField")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "所属id"),
            @ApiImplicitParam(name = "domainIds",value = "领域id json数组"),
            @ApiImplicitParam(name = "domainNames",value = "领域名称 json数组"),
            @ApiImplicitParam(name = "force",value = "强制更改")
    })
    public ResponseEntity<Integer> setTransField(String id,String domainIds,String domainNames,boolean force){
        if(StringUtils.isEmpty(domainIds)){
            throw new CustomException(ExceptionEnum.Other_Exception,"所选领域不能为空");
        }

        List<String> domainList = JSON.parseArray(domainIds,String.class);
        if(domainList.size()>5){
            throw new CustomException(ExceptionEnum.Other_Exception,"提交领域不能超过5个");
        }
        return ResponseEntity.ok().body(examService.setTransField(id,domainIds,domainNames,force));
    }

    @ApiOperation("获取考试剩余时间")
    @GetMapping("/getLeastTime")
    public ResponseEntity<Map<String, Object>> getLeastTime(String recordId){
        return ResponseEntity.ok().body(examService.getLeastTime(recordId));
    }

    @ApiOperation("提交单题答案")
    @PostMapping("/selectCommitOne")
    public ResponseEntity<Integer> selectCommitOne(String recordId,String answerId,String answer){
        return ResponseEntity.ok().body(examService.selectCommitOne(recordId,answerId,answer));
    }
    @ApiOperation("提交翻译题答案")
    @PostMapping("/transCommitOne")
    public ResponseEntity<Integer> transCommitOne(String recordId,String answerId,String answer){
        return ResponseEntity.ok().body(examService.transCommitOne(recordId,answerId,answer));
    }
    @ApiOperation("确认交卷")
    @PostMapping("/commitConfirm")
    public ResponseEntity<Integer> commitConfirm(String recordId){
        return ResponseEntity.ok().body(examService.commitConfirm(recordId));
    }
    @ApiOperation("获取选择题测试结果")
    @PostMapping("/getSelectExamResult")
    public ResponseEntity<Object> getSelectExamResult(String recordId){
        return ResponseEntity.ok().body(examService.getSelectExamResult(recordId));
    }
}
