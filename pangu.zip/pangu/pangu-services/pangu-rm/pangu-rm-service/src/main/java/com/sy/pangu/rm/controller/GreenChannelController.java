package com.sy.pangu.rm.controller;

import com.sy.pangu.rm.datamodel.request.greenchannel.StaffByGreenParam;
import com.sy.pangu.rm.service.GreenChannelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = {"兼职译员绿色通道"})
@RestController
@RequestMapping("greenChannel")
public class GreenChannelController {

    @Autowired
    GreenChannelService greenChannelService;

    @ApiOperation("通过绿色通道添加译员")
    @PostMapping("savePartTimeStaffByGreenChannel")
    public ResponseEntity<Boolean> savePartTimeStaff(StaffByGreenParam staffByGreenParam) {
        return ResponseEntity.ok().body(greenChannelService.savePartTimeStaff(staffByGreenParam));
    }


}
