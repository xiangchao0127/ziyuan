package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.ApplyCondition;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/25
 * Time:9:48
 */
public interface ApplyConditionDao extends JpaRepository<ApplyCondition,String> {
    ApplyCondition findByCurrentLevel(Integer currenLevel);
}
