package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.UserExtend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface UserExtendDao extends JpaRepository<UserExtend, String>, JpaSpecificationExecutor<UserExtend> {
    UserExtend findByRecordId(String recordId);
}
