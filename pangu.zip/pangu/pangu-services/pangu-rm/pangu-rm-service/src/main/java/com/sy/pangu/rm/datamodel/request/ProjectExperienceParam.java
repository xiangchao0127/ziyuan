package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

/**
 * 项目经验
 */
@Data
public class ProjectExperienceParam implements Serializable {
    String id;
    private String userId;
    private  String projectName;
    private String companyName;
    private String startDatetime;
    private String endDatetime;
    private String describe;
}
