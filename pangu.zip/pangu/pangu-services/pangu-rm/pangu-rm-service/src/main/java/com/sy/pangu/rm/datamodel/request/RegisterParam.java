package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class RegisterParam implements Serializable {

    private String tel;
    private  String pass;

}
