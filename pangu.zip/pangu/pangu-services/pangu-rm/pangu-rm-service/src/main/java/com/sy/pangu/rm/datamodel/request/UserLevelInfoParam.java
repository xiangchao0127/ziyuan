package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserLevelInfoParam implements Serializable {

    /**
     * 用户id
     */
    private String userId;

    /**
     * 来源于W3或者其他模块
     */
    private String recordId;
    /**
     * 源语言Code  格式zh-CN
     */
    private String sourceLangaugeCode;

    /**
     * 源语言Name
     */
    private String sourceLanguageName;

    /**
     * 目标语言Code 格式zh-CN
     */
    private String targetLangaugeCode;

    /**
     * 目标语言Name
     */
    private String targetLanguageName;
    /**
     * 等级Id
     */
    private String levelId;
    /**
     * 等级名称
     */
    private String levelName;

    /**
     * 领域Id
     */
    private String areaId;

    /**
     * 领域名称
     */
    private String areaName;

    /**
     * 岗位 角色Id
     */
    private String serviceId;

    /**
     * 岗位 角色Name
     */
    private String serviceName;

    /**
     * 是否删除
     */
    private Integer deleted;

}
