package com.sy.pangu.rm.datamodel.dto.exam;

import com.sy.pangu.rm.constant.TranslatorLevelConstant;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/11
 * Time:9:13
 */
public class highLevelState implements LevelState {
    @Override
    public void handle(CurrentLevelState currentLevelState) {
        currentLevelState.setNextLevelState(new highLevelState());
    }

    @Override
    public Integer getPrimaryLevel() {
        return TranslatorLevelConstant.P7;
    }

    @Override
    public Integer getMiddleLevel() {
        return TranslatorLevelConstant.P8;
    }

    @Override
    public Integer getHighLevel() {
        return TranslatorLevelConstant.P9;
    }

    @Override
    public String getNextLevelName() {
        return "完成";
    }
}
