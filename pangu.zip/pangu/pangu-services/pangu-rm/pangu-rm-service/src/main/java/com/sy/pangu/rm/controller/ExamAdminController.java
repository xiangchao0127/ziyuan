package com.sy.pangu.rm.controller;

import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.rm.datamodel.request.exam.ExamAuditDetail;
import com.sy.pangu.rm.datamodel.request.exam.ExamSelectSearch;
import com.sy.pangu.rm.datamodel.request.exam.ExamTransSearch;
import com.sy.pangu.rm.datamodel.request.exam.ExamTransWorkingSearch;
import com.sy.pangu.rm.datamodel.vo.AuditInfo;
import com.sy.pangu.rm.entity.UserDO;
import com.sy.pangu.rm.entity.exam.AdChoiceResult;
import com.sy.pangu.rm.entity.exam.AdTransResult;
import com.sy.pangu.rm.service.ExamLevelService;
import com.sy.pangu.rm.service.ExamService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/9
 * Time:17:17
 */
@Api(tags = {"评测管理端"})
@RestController
@RequestMapping("/exam/admin")
public class ExamAdminController {
    @Autowired
    private ExamService examService;
    @Autowired
    private ExamLevelService examLevelService;

    @ApiOperation("获取选择题结果列表")
    @GetMapping("/listSelectResult")
    public ResponseEntity<Page<AdChoiceResult>> listSelectResult(ExamSelectSearch examSelectSearch) {
        return ResponseEntity.ok().body(examService.listSelectResult(examSelectSearch));
    }

    @ApiOperation("获取翻译题结果列表")
    @GetMapping("/listTransResult")
    public ResponseEntity<Page<AdTransResult>> listTransResult(ExamTransSearch examTransSearch) {
        return ResponseEntity.ok().body(examService.listTransResult(examTransSearch));
    }


    @ApiOperation("获取待审列表（自己）")
    @GetMapping("/getWorkingList")
    public ResponseEntity<Page<AdTransResult>> getWorkingList(ExamTransWorkingSearch examTransWorkingSearch) {
        return ResponseEntity.ok().body(examService.getWorkingList(examTransWorkingSearch));
    }

    @ApiOperation("获取审核人列表")
    @GetMapping("/getAuditorList")
    public ResponseEntity<List<AuditInfo>> getAuditorList(String originLanguageCode, String targetLanguageCode, String fields) {
        List<String> ids = null;
        if(StringUtils.isNotEmpty(fields)){
            ids = Arrays.asList(fields.split(","));
        }
        return ResponseEntity.ok().body(examService.getAuditorList(originLanguageCode, targetLanguageCode, ids));
    }

    @ApiOperation("分配审核人")
    @PutMapping("/allocationAuditor")
    public ResponseEntity<Integer> allocationAuditor(String tranResultId, String auditorId, String userName, String positionType) {
        return ResponseEntity.ok().body(examService.allocationAuditor(tranResultId, auditorId, userName, positionType));
    }

    @ApiOperation("获取详情选择题")
    @GetMapping("/getExamDetailSelect")
    public ResponseEntity getExamDetailSelect(String resultId) {
        return ResponseEntity.ok().body(examService.getExamDetailSelect(resultId));

    }

    @ApiOperation("获取详情翻译题")
    @GetMapping("/getExamDetailTrans")
    public ResponseEntity getExamDetailTrans(String resultId) {
        return ResponseEntity.ok().body(examService.getExamDetailTrans(resultId));
    }

    @ApiOperation("提交审核结果")
    @PostMapping("/commitAuditTransResult")
    public ResponseEntity<Integer> commitAuditTransResult(ExamAuditDetail examAuditDetail) {
        return ResponseEntity.ok().body(examService.commitAuditTransResult(examAuditDetail));
    }

    @ApiOperation("根据得分获取结果")
    @GetMapping("/getResultByScore")
    public ResponseEntity<Map<String, Object>> getResultByScore(Integer currentLevle, Integer grade) {
        return ResponseEntity.ok().body(examLevelService.calculateLevelByGrade(currentLevle, grade));
    }


}
