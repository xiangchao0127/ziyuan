package com.sy.pangu.rm.dao;




import com.sy.pangu.rm.entity.Domain;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/28
 * Time:15:48
 */
public interface DomainDao extends JpaRepository<Domain, String> {
    List<Domain> findAllByPSpecialtyId(Integer pSpecialtyId);
    List<Domain> findAllByIdIn(List<String> ids);
    List<Domain> findAllBySpecialtyNameIn(List<String> specialNames);
}
