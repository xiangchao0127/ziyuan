package com.sy.pangu.rm.controller;


import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = {"结算相关"})
@RestController
@RequestMapping(value = "settlement")
public class SettlementController {




}
