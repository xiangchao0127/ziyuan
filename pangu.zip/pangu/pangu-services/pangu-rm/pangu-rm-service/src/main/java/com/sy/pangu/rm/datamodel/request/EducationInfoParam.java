package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

/**
 * 教育经历
 */
@Data
public class EducationInfoParam implements Serializable {

    private String id;
    /**
     * 用户id
     */
    private String userId;
    /**
     * 毕业学校名
     */
    private  String graduatedSchoolName;
    /**
     * 学校类型(国内，海外)
     */
    private  String schoolType;

    /**
     * 专业
     */
    private  String major;
    /**
     * 学位
     */
    private  String degree;
    /**
     * 毕业时间(格式:2015-12-12 00:00:00)
     */
    private  String graduatedDate;

}
