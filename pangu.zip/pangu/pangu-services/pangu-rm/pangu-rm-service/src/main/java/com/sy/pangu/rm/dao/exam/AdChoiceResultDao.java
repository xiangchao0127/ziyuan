package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.AdChoiceResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/15
 * Time:17:28
 */
public interface AdChoiceResultDao extends JpaRepository<AdChoiceResult,String>, JpaSpecificationExecutor<AdChoiceResult> {
    AdChoiceResult findByRecordIdAndUserId(String recordId,String userId);
}
