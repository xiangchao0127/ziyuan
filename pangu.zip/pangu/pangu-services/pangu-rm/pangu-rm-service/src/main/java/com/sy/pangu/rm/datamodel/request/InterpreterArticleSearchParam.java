package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

/**
 * @author XiangChao
 * @date 2019/5/8
 */
@Data
public class InterpreterArticleSearchParam {
    /**
     * 发布人id
     */
    private String publishUserId;
    /**
     * 文章标题
     */
    private String articleTitle;
    /**
     * 发布状态(0 草稿箱     1 待审核  2 审核不通过    3已发布 4发布撤回)
     */
    private Integer status;
    /**
     * 标签
     */
    private String label;
    /**
     * 提交开始时间
     */
    private String submitStartTime;
    /**
     * 提交结束时间
     */
    private String submitEndTime;
    /**
     * 发布时间
     */
    private String publishStartTime;
    /**
     * 结束时间
     */
    private String publishEndTime;
    /**
     * 页码
     */
    private Integer pageNo;
    /**
     * 一页大小
     */
    private Integer pageSize;

}
