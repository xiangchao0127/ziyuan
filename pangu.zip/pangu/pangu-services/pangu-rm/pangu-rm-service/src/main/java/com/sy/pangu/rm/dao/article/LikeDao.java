package com.sy.pangu.rm.dao.article;

import com.sy.pangu.rm.entity.article.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * @author XiangChao
 * @date 2019/5/7
 */
public interface LikeDao extends JpaRepository<Like,String>, JpaSpecificationExecutor<Like> {
    /**
     * 通过昵称查找赞
     * @param bussinessId
     * @param nickname
     * @return
     */
    Like findAllByBussinessIdAndUserNickName(String bussinessId,String nickname);
}
