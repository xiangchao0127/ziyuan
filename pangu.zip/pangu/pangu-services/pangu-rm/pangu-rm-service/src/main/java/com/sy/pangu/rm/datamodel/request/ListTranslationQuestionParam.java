package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.util.List;

/** 翻译查询参数
 * @author XiangChao
 * @date 2019/4/9
 */
@Data
public class ListTranslationQuestionParam {
    /**
     * 题号
     */
    private String questionNo;
    /**
     * 原文语言
     */
    private String orignLanguage;
    /**
     * 原文语言
     */
    private String targetLanguage;
    /**
     * 原文内容
     */
    private String orignContent;
    /**
     * 译文内容
     */
    private String targetContent;
    /**
     * 状态 (0 禁用 1 启用)
     */
    private String status;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private String endTime;
    /**
     * 难度等级
     */
    private String difficultLevel;
    /**
     * 领域id集合
     */
    private List<String> domainIds;
    /**
     * 时态占比
     */
    private String temporalRatio;
    /**
     * 词汇占比
     */
    private String vocabularyRatio;
    /**
     * 语法占比
     */
    private String grammarRatio;
    /**
     * 页码
     */
    private Integer pageNo;
    /**
     * 条数
     */
    private Integer pageSize;
}
