package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.WorkExperience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface WorkExperienceDao extends JpaRepository<WorkExperience,String>, JpaSpecificationExecutor<WorkExperience> {


    @Query(value = "select companyName from WorkExperience where userId=?1")
    List<String> findCompanyNameByUserId(String userId);

    WorkExperience findByUserIdAndCompanyName(String userId,String companyName);

}
