package com.sy.pangu.rm.dao;


import com.sy.pangu.rm.entity.Language;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/9
 * Time:11:35
 */
public interface LanguageDao extends JpaRepository<Language,String>, JpaSpecificationExecutor<Language> {
//    List<Language> findAllByOrOrderByOrderDesc();
}
