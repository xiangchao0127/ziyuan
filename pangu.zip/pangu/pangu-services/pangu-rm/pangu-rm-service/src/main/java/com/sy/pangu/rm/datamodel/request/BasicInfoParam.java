package com.sy.pangu.rm.datamodel.request;


import lombok.Data;

import java.io.Serializable;

/**
 * 个人基本信息
 */
@Data
public class BasicInfoParam implements Serializable {

    private String userId;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 真实姓名
     */
    private String realName;
    /**
     * 性别
     */
    private String sex;
    /**
     * 国籍
     */
    private String nationality;
    /**
     * 母语
     */
    private String motherTogue;
    /**
     * 生日
     */
    private String birthday;
    /**
     * 翻译年限
     */
    private String tranlateYear;

    /**
     * 邮箱
     */
    private  String email;
    /**
     * QQ
     */
    private  String QQ;
}
