package com.sy.pangu.rm.datamodel.dto.exam;

import com.sy.pangu.rm.datamodel.dto.ExamRequestParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/17
 * Time:14:14
 */
@Component
public class CreateExamFactory {
    @Autowired
    @Qualifier("choiceExamCreater")
    public ExamCreater choiceExamCreater;
    @Autowired
    @Qualifier("transExamCreater")
    public ExamCreater transExamCreater;
    public ExamCreater getExamCreater(String examType){
        switch (examType){
            case ExamRequestParam.examType_select:
                return choiceExamCreater;
            case ExamRequestParam.examType_trans:
                return transExamCreater;
                default:
        }
        return null;
    }
}
