package com.sy.pangu.rm.controller;

import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.rm.datamodel.request.ListTranslationQuestionParam;
import com.sy.pangu.rm.entity.TranslationQuestionDO;
import com.sy.pangu.rm.service.TranslationQuestionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/9
 */
@Api(tags = {"翻译题库管理"})
@RestController
@RequestMapping("/translationQuestion")
public class TranslationQuestionController {
    @Autowired
    TranslationQuestionService translationQuestionService;

    /**\
     * 翻译题列表查询
     * @param translationQuestionParam
     * @return
     */
    @ApiOperation("翻译题列表查询")
    @GetMapping("/addChoiceQuestion")
    public ResponseEntity<Page<TranslationQuestionDO>> listTranslationQuestions(ListTranslationQuestionParam translationQuestionParam) {
        if (StringUtils.notEmpty(translationQuestionParam.getStartTime()) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, translationQuestionParam.getStartTime())) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "开始时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if (StringUtils.notEmpty(translationQuestionParam.getEndTime()) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, translationQuestionParam.getEndTime())) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "结束时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if(translationQuestionParam.getPageNo()==null || translationQuestionParam.getPageSize()==null){
            throw new CustomException(ExceptionEnum.Params_Empty,"pageNo和pageSize不能为空");
        }
        return ResponseEntity.ok().body(translationQuestionService.listTranslationQuestions(translationQuestionParam));
    }

    /**
     * 单个添加翻译题
     * @param translationQuestionDO
     * @return
     */
    @ApiOperation("单个添加翻译题")
    @PostMapping("/addTranslationQuestion")
    public ResponseEntity<Integer> addTranslationQuestion(TranslationQuestionDO translationQuestionDO) {
        return ResponseEntity.ok().body(translationQuestionService.addTranslationQuestion(translationQuestionDO));
    }

    /**
     * 翻译题详情
     * @param id
     * @return
     */
    @ApiOperation("翻译题详情")
    @GetMapping("/TranslationQuestionDetails")
    public ResponseEntity<TranslationQuestionDO> TranslationQuestionDetails(String id) {
        return ResponseEntity.ok().body(translationQuestionService.TranslationQuestionDetails(id));
    }

    /**
     * 翻译题编辑
     * @param translationQuestionDO
     * @return
     */
    @ApiOperation("翻译题编辑")
    @PutMapping("/updateTranslationQuestion")
    public ResponseEntity<Integer> updateTranslationQuestion(TranslationQuestionDO translationQuestionDO) {
        return ResponseEntity.ok().body(translationQuestionService.updateTranslationQuestion(translationQuestionDO));
    }

    /**
     * 批量导入
     * @param multipartFile
     * @return
     */
    @ApiOperation("批量导入")
    @PostMapping("/batchAddTranslationQuestions")
    public ResponseEntity<Integer> batchAddTranslationQuestions(MultipartFile multipartFile) {
        return ResponseEntity.ok().body(translationQuestionService.batchAddTranslationQuestions(multipartFile));
    }

    /**
     * 批量删除翻译题
     * @param ids
     * @return
     */
    @ApiOperation("批量删除翻译题")
    @DeleteMapping("/deleteTranslationQuestion")
    public ResponseEntity<Integer> deleteTranslationQuestion(@RequestParam(value = "ids") List<String> ids) {
        return ResponseEntity.ok().body(translationQuestionService.deleteTranslationQuestion(ids));
    }

    /**
     * 批量启用
     * @param ids
     * @return
     */
    @ApiOperation("批量启用")
    @PutMapping("/enableTranslation")
    public ResponseEntity<Integer> enableTranslation(@RequestParam(value = "ids") List<String> ids) {
        return ResponseEntity.ok().body(translationQuestionService.enableTranslation(ids));
    }

    /**
     * 批量禁用
     * @param ids
     * @return
     */
    @ApiOperation("批量禁用")
    @PutMapping("/disableTranslation")
    public ResponseEntity<Integer> disableTranslation(@RequestParam(value = "ids") List<String> ids) {
        return ResponseEntity.ok().body(translationQuestionService.disableTranslation(ids));
    }

    /**
     * 翻译题模板下载
     * @return url
     */
    @ApiOperation("翻译题模板下载")
    @GetMapping("/downloadTranslationQuestionModel")
    public ResponseEntity<String> downloadTranslationQuestionModel() {
        return ResponseEntity.ok().body(translationQuestionService.downloadTranslationQuestionModel());
    }
}
