package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

/**
 * 获取专职员工信息查询参数
 */
@Data
public class FullTimeStaffParam implements Serializable {


    private Integer pageNo;


    private Integer pageSize;

    /**
     * 专职员工Id
     */
    private String staffId;
    /**
     * 姓名
     */
    private String realName;
    /**
     * 在职 1
     * 离职 0
     */
    private String onLeave;

    /**
     * 状态
     */
    private String status;
}
