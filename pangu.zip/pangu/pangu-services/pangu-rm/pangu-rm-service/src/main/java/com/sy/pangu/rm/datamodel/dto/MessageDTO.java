package com.sy.pangu.rm.datamodel.dto;

import lombok.Data;

/**
 * @author XiangChao
 * @date 2019/4/26
 */
@Data
public class MessageDTO {
    String sendPerson;
    String sendToPersonId;
    String messageType;
    String content;
}
