package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class PartTimeStaffParam implements Serializable {

    private  Integer pageNo;

    private  Integer pageSize;

    /**
     * 译员ID
     */
    private  String staffId;
    /**
     * 登录账号
     */
    private  String account;
    /**
     * 译员昵称
     */
    private  String nickName;
    /**
     * 译员姓名
     */
    private  String realName;
    /**
     * 语种
     */
    private  String language;
    /**
     * 翻译年限
     */
    private  String translateYear;
    /**
     * 是否通过身份认证
     */
    private  String identityPassed;
    /**
     * 是否通过财务认证
     */
    private  String accountPassed;

    /**
     * 开始时间
     */
    private  String strStartDateTime;


    /**
     * 结束时间
     */
    private String strEndDateTime;

    /**
     * 状态
     */
    private String status;

}
