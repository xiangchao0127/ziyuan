package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/1/3
 * Time:17:07
 */
@Data
public class UeditorParam {
    private String action;
    private String filename;
    private String start;
    private String callback;
}
