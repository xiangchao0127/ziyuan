package com.sy.pangu.rm.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author XiangChao
 * @date 2019/4/17
 */
@Configuration
//@Order(1)
public class BastPathConfig {
//    @Value("${pangu.rm.basepath}")
//    private String basepath;

    @Bean
    public String basePath() {
        String system = System.getProperty("os.name");
        if (system.toLowerCase().startsWith("win")) {
            return "D:\\pangu\\" + "rm" + "\\";
        }
        return "/opt/pangu/" + "rm" + "/";
    }
}
