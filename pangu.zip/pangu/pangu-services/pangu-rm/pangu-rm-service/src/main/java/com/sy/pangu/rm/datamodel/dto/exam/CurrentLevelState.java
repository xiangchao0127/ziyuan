package com.sy.pangu.rm.datamodel.dto.exam;

import lombok.Data;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/10
 * Time:15:38
 */
@Data
public class CurrentLevelState {
    private LevelState nextLevelState;
    private Integer currentLevel;
    public CurrentLevelState(Integer currentLevel){
        this.currentLevel = currentLevel;
    }
    public Integer calculateLevelUp(Integer grade){
        if(grade<80){
            return currentLevel;
        }
        if(grade>95){
            return nextLevelState.getHighLevel();
        }
        if(grade<=90){
            return nextLevelState.getPrimaryLevel();
        }
        if(grade<=95){
            return nextLevelState.getMiddleLevel();
        }
        return currentLevel;
    }
}
