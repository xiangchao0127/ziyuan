package com.sy.pangu.rm.constant;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/16
 * Time:17:14
 */
public class FlowWorkConstant {
    public static final String SINGLE="SINGLE";
    public static final String MANAY_ONE="MANAY_ONE";
    public static final String MANAY_ALL="MANAY_ALL";

}
