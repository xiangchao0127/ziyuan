package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class SignParam implements Serializable {
    private  String userId;
    /**
     * 签到时间（签到时间 格式 2015-12-12 12:45:35）
     */
    private  String signDate;
}
