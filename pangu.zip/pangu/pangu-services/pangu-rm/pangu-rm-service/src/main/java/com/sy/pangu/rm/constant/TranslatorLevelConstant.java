package com.sy.pangu.rm.constant;

import com.sy.pangu.rm.datamodel.dto.exam.CurrentLevelState;
import com.sy.pangu.rm.datamodel.dto.exam.LevelStateFactory;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/10
 * Time:15:02
 */
public class TranslatorLevelConstant {
    public static final int P0=0;
    public static final int P1=1;
    public static final int P2=2;
    public static final int P3=3;
    public static final int P4=4;
    public static final int P5=5;
    public static final int P6=6;
    public static final int P7=7;
    public static final int P8=8;
    public static final int P9=9;

    public static CurrentLevelState getCurrentLevelState(Integer level){
        CurrentLevelState currentLevelState = new CurrentLevelState(level);
        switch (level){
            case TranslatorLevelConstant.P0:
                currentLevelState.setNextLevelState(LevelStateFactory.primaryLevelState);
                break;
            case TranslatorLevelConstant.P1:
            case TranslatorLevelConstant.P2:
            case TranslatorLevelConstant.P3:
                currentLevelState.setNextLevelState(LevelStateFactory.middleLevelState);
                break;
            case TranslatorLevelConstant.P4:
            case TranslatorLevelConstant.P5:
            case TranslatorLevelConstant.P6:
                currentLevelState.setNextLevelState(LevelStateFactory.highLevelState);
                break;
            default:
                currentLevelState.setNextLevelState(LevelStateFactory.highLevelState);
        }
        return currentLevelState;
    }

}
