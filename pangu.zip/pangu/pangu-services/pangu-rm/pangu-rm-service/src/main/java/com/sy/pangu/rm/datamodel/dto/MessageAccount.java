package com.sy.pangu.rm.datamodel.dto;

import lombok.Data;

/** 消息通知账号信息
 * @author XiangChao
 * @date 2019/4/26
 */
@Data
public class MessageAccount {
    /**
     * id
     */
    private String userId;
    /**
     * 工号
     */
    private String userNumber;
    /**
     * 微信号
     */
    private String weixin;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 电话号码
     */
    private String telephone;
}
