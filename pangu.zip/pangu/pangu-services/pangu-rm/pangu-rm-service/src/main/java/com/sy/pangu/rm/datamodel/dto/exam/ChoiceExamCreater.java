package com.sy.pangu.rm.datamodel.dto.exam;

import com.alibaba.fastjson.JSON;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.common.util.EntityUtil;
import com.sy.pangu.rm.constant.TranslatorLevelConstant;
import com.sy.pangu.rm.dao.SysConfigDao;
import com.sy.pangu.rm.dao.exam.*;
import com.sy.pangu.rm.datamodel.dto.ExamRequestParam;
import com.sy.pangu.rm.entity.ChoiceQuestionDO;
import com.sy.pangu.rm.entity.exam.*;
import com.sy.pangu.rm.service.RandomQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.*;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/17
 * Time:14:22
 */
@Component("choiceExamCreater")
public class ChoiceExamCreater implements ExamCreater {
    @Autowired
    private CuRecordDao cuRecordDao;
    @Autowired
    private RandomQuestionService randomQuestionService;
    @Autowired
    private CuChoiceAnswerDao cuChoiceAnswerDao;
    @Autowired
    private AdChoiceResultDao adChoiceResultDao;
    @Autowired
    private CuLevelDao cuLevelDao;
    @Autowired
    private CuOverviewDao cuOverviewDao;
    @Autowired
    private SysConfigDao sysConfigDao;
    @Value("${spring.application.name}")
    private String applicationName;


    @Override
    public List<String> getUsedQuestions(String userId) {
        List<CuRecord> cuRecords = cuRecordDao.findAllByUserIdAndExamType(userId,ExamRequestParam.examType_select);
        return this.getUsedQuestionsDefault(cuRecords);
    }

    @Override
    public CreateExamDto getquestions(ExamRequestParam examRequestParam, String userId, String recordId) {
        CreateExamDto<Object> createExamDto = new CreateExamDto();
        Timestamp create = DateUtils.getCurrentTimeStamp();
        List<ChoiceQuestionDO> choiceQuestionDOS = randomQuestionService.getRandomChoiceQuestion(10,
                examRequestParam.getExamLevel(),examRequestParam.getTargetLanguageName(),
                examRequestParam.getFieldIds(),examRequestParam.getUsedQuestionIds());

        List<String> ids = new ArrayList<>();
        List<Map<String,Object>> questions = new ArrayList<>();
        createExamDto.setQuestions(questions);
        int index = 1;
        for(ChoiceQuestionDO e:choiceQuestionDOS){
            ids.add(e.getId());
            CuChoiceAnswer choiceAnswer = new CuChoiceAnswer();
            choiceAnswer.setQuesstionId(e.getId());
            choiceAnswer.setCorrectAnswer(e.getCorrectAnswer());
            choiceAnswer.setGmtCreate(create);
            choiceAnswer.setQuestionIndex(index++);
            choiceAnswer.setRecordId(recordId);
            choiceAnswer.setQuestionCode(e.getQuestionNo());
            choiceAnswer.setUserId(userId);
            Map<String,Object> question = new HashMap<>();
            question.put("questionRequirement",e.getQuestionRequirement());
            question.put("questionHead",e.getQuestionHead());
            question.put("A:",e.getOptiona());
            question.put("B:",e.getOptionb());
            question.put("C:",e.getOptionc());
            question.put("D:",e.getOptiond());
            choiceAnswer.setQuestion(JSON.toJSONString(question));
            cuChoiceAnswerDao.save(choiceAnswer);
            question.put("answerId",choiceAnswer.getId());
            question.put("answer",null);

            questions.add(question);
        }
        createExamDto.setQuestionIds(String.join(",",ids));
        return createExamDto;
    }
    @Override
    public CreateExamDto getCurrentQuestions(String curecordId){
        CreateExamDto<Object> createExamDto = new CreateExamDto();
        List<CuChoiceAnswer> cuChoiceAnswers = cuChoiceAnswerDao.findByRecordIdOrderByQuestionIndexAsc(curecordId);
        List<String> ids = new ArrayList<>();
        List<Map<String,Object>> questions = new ArrayList<>();
        createExamDto.setQuestions(questions);
        cuChoiceAnswers.forEach( e->{
            Map<String,Object> question = JSON.parseObject(e.getQuestion());
            question.put("answerId",e.getId());
            question.put("answer",e.getAnswer());
            questions.add(question);
            ids.add(e.getId());
        });
        createExamDto.setQuestionIds(String.join(",",ids));
        return createExamDto;
    }



    @Override
    public Integer examCommitOne(String recordId, String answerId, String answer) {
        CuChoiceAnswer cuChoiceAnswer = EntityUtil.getEntityById(answerId,cuChoiceAnswerDao);
        cuChoiceAnswer.setAnswer(answer.toUpperCase());
        return 1;
    }

    @Override
    public void handleResult(CuRecord cuRecord,boolean systemCtl) {
        CuLevel cuLevel = EntityUtil.getEntityById(cuRecord.getLevelId(),cuLevelDao);
        cuLevel.setExamTimes(cuLevel.getExamTimes()+1);
        cuLevel.setExamRecordId(null);
        AdChoiceResult adChoiceResult = new AdChoiceResult();
        adChoiceResult.setUserId(cuRecord.getUserId());
        adChoiceResult.setTranslatorCode(cuLevel.getTranslatorCode());
        adChoiceResult.setExamStartTime(cuRecord.getExamStartTime());
        adChoiceResult.setRecordId(cuRecord.getId());
        adChoiceResult.setOriginLanguageCode(cuLevel.getOriginLanguageCode());
        adChoiceResult.setOriginLanguageName(cuLevel.getOriginLanguageName());
        adChoiceResult.setTargetLanguageCode(cuLevel.getTargetLanguageCode());
        adChoiceResult.setTargetLanguageName(cuLevel.getTargetLanguageName());
        adChoiceResult.setExamTimes(cuLevel.getExamTimes());
        adChoiceResult.setTranslatorCode(cuLevel.getTranslatorCode());
        adChoiceResult.setGmtCreate(DateUtils.getCurrentTimeStamp());
        //计算选择题结果
        this.handleChoiceResult(adChoiceResult,cuLevel,systemCtl);
        adChoiceResultDao.save(adChoiceResult);
    }

    private void handleChoiceResult(AdChoiceResult adChoiceResult,CuLevel cuLevel,boolean systemCtl){
        if(systemCtl){
            adChoiceResult.setExamResult("不合格");
            String periodTime = "1";
            if(cuLevel.getExamTimes()>1){
                periodTime = sysConfigDao.findByApplicationNameAndSysCode(applicationName,"selectFirstNextTime").getSysValue();
            }else{
                periodTime = sysConfigDao.findByApplicationNameAndSysCode(applicationName,"selectPeriodTime").getSysValue();
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(adChoiceResult.getExamStartTime().getTime());
            calendar.add(Calendar.DATE,Integer.parseInt(periodTime));
            cuLevel.setNextExamTime(new Timestamp(calendar.getTimeInMillis()));
            cuLevel.setPassedStatue("未通过");
            adChoiceResult.setExamOverview("超时");
            return;
        }
        List<CuChoiceAnswer> cuChoiceAnswers = cuChoiceAnswerDao.findByRecordIdOrderByQuestionIndexAsc(adChoiceResult.getRecordId());
        int count = 0;
        for(CuChoiceAnswer cuChoiceAnswer:cuChoiceAnswers){
            if(cuChoiceAnswer.getCorrectAnswer().equals(cuChoiceAnswer.getAnswer())){
                count++;
            }
        }
        if(count>=6){
            adChoiceResult.setExamResult("合格");
            cuLevel.setLevel(TranslatorLevelConstant.P0);
            cuLevel.setPassedStatue("已通过");
            cuLevel.setExamPassTime(DateUtils.getCurrentTimeStamp());

            CuOverview cuOverview = cuOverviewDao.findOneByChoiceId(cuLevel.getId());
            cuOverview.setIsEnableCancle(false);
            CuLevel sToFLevel = cuOverview.getSToFLevel();
            sToFLevel.setIsEnableExam(true);
            sToFLevel.setLevel(0);
            CuLevel fToSlevel = cuOverview.getFToSLevel();
            fToSlevel.setIsEnableExam(true);
            fToSlevel.setLevel(0);
            cuOverviewDao.save(cuOverview);
        }else{
            adChoiceResult.setExamResult("不合格");
            String periodTime = "1";
            if(cuLevel.getExamTimes()>1){
                periodTime = sysConfigDao.findByApplicationNameAndSysCode(applicationName,"selectFirstNextTime").getSysValue();
            }else{
                periodTime = sysConfigDao.findByApplicationNameAndSysCode(applicationName,"selectPeriodTime").getSysValue();
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(adChoiceResult.getExamStartTime().getTime());
            calendar.add(Calendar.DATE,Integer.parseInt(periodTime));
            cuLevel.setNextExamTime(new Timestamp(calendar.getTimeInMillis()));
            cuLevel.setPassedStatue("未通过");
        }
        adChoiceResult.setExamOverview(count+"/"+cuChoiceAnswers.size());
    }

    @Override
    public Map<String,Object> getResultDetail(String resultId){
        AdChoiceResult adChoiceResult = EntityUtil.getEntityById(resultId,adChoiceResultDao);
        List<CuChoiceAnswer> cuChoiceAnswers = cuChoiceAnswerDao.findByRecordIdOrderByQuestionIndexAsc(adChoiceResult.getRecordId());

        Map<String,Object> result = new HashMap<>();
        result.put("adChoiceResult",adChoiceResult);
        result.put("cuChoiceAnswers",cuChoiceAnswers);
        return result;
    }



}
