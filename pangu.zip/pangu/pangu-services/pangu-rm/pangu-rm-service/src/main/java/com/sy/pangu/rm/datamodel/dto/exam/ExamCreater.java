package com.sy.pangu.rm.datamodel.dto.exam;

import com.sy.pangu.rm.datamodel.dto.ExamRequestParam;
import com.sy.pangu.rm.entity.exam.CuRecord;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/17
 * Time:14:19
 */
public interface ExamCreater {

    List<String> getUsedQuestions(String userId);

    default List<String> getUsedQuestionsDefault(List<CuRecord> cuRecords) {
        List<String> result = new ArrayList<>();
        cuRecords.forEach(e -> {
            String questions = e.getQuestionIds();
            if (questions != null) {
                String[] ids = questions.split(",");
                for (int i = 0, j = ids.length; i < j; i++) {
                    result.add(ids[i]);
                }
            }
        });
        return result;
    }

    ;

    CreateExamDto getquestions(ExamRequestParam examRequestParam, String userId, String recordId);
    CreateExamDto getCurrentQuestions(String curecordId);

    Integer examCommitOne(String recordId, String answerId, String answer);


    void handleResult(CuRecord cuRecord,boolean systemCtl);

    Map<String, Object> getResultDetail(String resultId);
}
