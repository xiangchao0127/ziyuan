package com.sy.pangu.rm.controller;


import com.sy.pangu.rm.entity.Language;
import com.sy.pangu.rm.service.LanguageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/9
 * Time:11:10
 */
@Api(tags = {"语言信息"})
@RestController
@RequestMapping("/language")
public class LanguageController {
    @Autowired
    private LanguageService languageService;

    @ApiOperation("获取语言")
    @GetMapping("/listAll")
    public ResponseEntity<List<Language>> listLanguage() {
        return ResponseEntity.ok().body(languageService.listAll());
    }

}
