package com.sy.pangu.rm.controller;

import com.sy.pangu.rm.datamodel.request.UeditorParam;
import com.sy.pangu.rm.service.UeditorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

/**
 * 用于处理关于ueditor插件相关的请求
 *
 * @author Guoqing
 * @date 2017-11-29
 */
@SuppressWarnings("ALL")
@Api(tags = {"ueditor控制器"})
@RestController
@CrossOrigin
@RequestMapping("/ueditor")
public class UeditorController {
    @Autowired
    UeditorService ueditorService;

    /**
     * 富文本编辑
     * @param request
     * @param upfile 上传文件
     * @param ueditorParam
     * @return
     */
    @ApiOperation("富文本编辑")
    @PostMapping(value = "/exec")
    public ResponseEntity<String> exec(HttpServletRequest request, MultipartFile upfile, UeditorParam ueditorParam) {
        return ResponseEntity.ok().body(ueditorService.exec(request, upfile, ueditorParam));
    }

    @GetMapping("/getFile")
    public void getFile(String url) {
        ueditorService.getFile(url);
    }


}
