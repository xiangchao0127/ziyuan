package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.AdTransResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/15
 * Time:17:28
 */
public interface AdTransResultDao extends JpaRepository<AdTransResult,String>, JpaSpecificationExecutor<AdTransResult> {
}
