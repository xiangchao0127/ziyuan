package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.SkillType;
import com.sy.pangu.rm.entity.UserSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface SkillTypeDao extends JpaRepository<SkillType, String>, JpaSpecificationExecutor<SkillType> {


}
