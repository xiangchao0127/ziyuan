package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.SysNotice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * @author XiangChao
 * @date 2019/4/25
 */
public interface SysNoticeDao extends JpaRepository<SysNotice,String>, JpaSpecificationExecutor<SysNotice> {
}
