package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.UserExtension;
import jdk.internal.org.objectweb.asm.tree.analysis.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * @author Q00596
 * @date 2019-04-10
 */
public interface UserExtensionDao extends JpaRepository<UserExtension,String>, JpaSpecificationExecutor<UserExtension> {

    @Query(value = "select userExtension from UserExtension userExtension  where userId = ?1")
    List<UserExtension> findByUserId(String userId);



}
