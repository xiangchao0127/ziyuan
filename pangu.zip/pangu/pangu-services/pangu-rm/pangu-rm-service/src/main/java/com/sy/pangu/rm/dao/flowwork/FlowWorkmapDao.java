package com.sy.pangu.rm.dao.flowwork;

import com.sy.pangu.rm.entity.flowwork.FlowWorkmap;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/16
 * Time:15:24
 */
public interface FlowWorkmapDao extends JpaRepository<FlowWorkmap,String> {
    List<FlowWorkmap> findAllByTaskCode(String taskCode);
}
