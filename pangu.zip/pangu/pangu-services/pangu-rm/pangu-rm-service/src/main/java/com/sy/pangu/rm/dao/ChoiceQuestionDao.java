package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.ChoiceQuestionDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/9
 */
public interface ChoiceQuestionDao extends JpaRepository<ChoiceQuestionDO,String>, JpaSpecificationExecutor<ChoiceQuestionDO> {
    /**
     * 通过题号获取试题
     * @param questionNo
     * @return
     */
    ChoiceQuestionDO  findAllByQuestionNo(String questionNo);

    /**
     * 获取随机选择题
     * @param level
     * @param ids
     * @param specialtyName
     * @param number
     * @return
     */
    @Query(nativeQuery = true,value = "select * from q_choice_question c  JOIN q_choice_domain cd on c.id = cd.choice_question_id left join domain d on d.id = cd.domain_id " +
            "where c.difficult_level in (?) AND c.id not in (?) AND d.specialty_name in (?) ORDER BY RAND() LIMIT ?")
    List<ChoiceQuestionDO> getRandomQuestion(String level,String ids,String specialtyName,Integer number);

    /**
     * 根据题目要求和题目查询试题
     * @param questionRequrement
     * @param questionHead
     * @return
     */
    ChoiceQuestionDO findAllByQuestionRequirementAndQuestionHead(String questionRequrement,String questionHead);
}
