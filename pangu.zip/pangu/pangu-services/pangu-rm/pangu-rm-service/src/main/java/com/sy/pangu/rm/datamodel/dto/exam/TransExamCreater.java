package com.sy.pangu.rm.datamodel.dto.exam;

import com.alibaba.fastjson.JSON;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.common.util.EntityUtil;
import com.sy.pangu.rm.dao.DomainDao;
import com.sy.pangu.rm.dao.exam.AdTransResultDao;
import com.sy.pangu.rm.dao.exam.CuLevelDao;
import com.sy.pangu.rm.dao.exam.CuRecordDao;
import com.sy.pangu.rm.dao.exam.CuTransAnswerDao;
import com.sy.pangu.rm.datamodel.dto.ExamRequestParam;
import com.sy.pangu.rm.entity.Domain;
import com.sy.pangu.rm.entity.TranslationQuestionDO;
import com.sy.pangu.rm.entity.exam.AdTransResult;
import com.sy.pangu.rm.entity.exam.CuLevel;
import com.sy.pangu.rm.entity.exam.CuRecord;
import com.sy.pangu.rm.entity.exam.CuTransAnswer;
import com.sy.pangu.rm.enums.ExamCons;
import com.sy.pangu.rm.service.RandomQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/17
 * Time:14:22
 */
@Component("transExamCreater")
public class TransExamCreater implements ExamCreater{
    @Autowired
    private CuRecordDao cuRecordDao;
    @Autowired
    private RandomQuestionService randomQuestionService;
    @Autowired
    private CuTransAnswerDao cuTransAnswerDao;
    @Autowired
    private CuLevelDao cuLevelDao;
    @Autowired
    private AdTransResultDao adTransResultDao;
    private DomainDao domainDao;
    @Override
    public List<String> getUsedQuestions(String userId) {
        List<CuRecord> cuRecords = cuRecordDao.findAllByUserIdAndExamType(userId,ExamRequestParam.examType_trans);
        return this.getUsedQuestionsDefault(cuRecords);
    }
    @Override
    public CreateExamDto getquestions(ExamRequestParam examRequestParam, String userId, String recordId) {
        CreateExamDto<Object> createExamDto = new CreateExamDto();
        Timestamp create = DateUtils.getCurrentTimeStamp();
        List<TranslationQuestionDO> translationQuestionDOS = randomQuestionService.getRandomTranslationQuestion(1,
                examRequestParam.getExamLevel(),examRequestParam.getOriginLanguageName(),examRequestParam.getTargetLanguageName(),
                examRequestParam.getFieldIds(),examRequestParam.getUsedQuestionIds());
        List<Map<String, Object>> questions = new ArrayList<>();
        createExamDto.setQuestions(questions);
        List<String> ids = new ArrayList<>();
        translationQuestionDOS.forEach(e->{
            ids.add(e.getId());
            CuTransAnswer cuTransAnswer = new CuTransAnswer();
            cuTransAnswer.setGmtCreate(create);
            cuTransAnswer.setRecordId(recordId);
            cuTransAnswer.setUserId(userId);
            cuTransAnswer.setQuestion(e.getOrignContent());
            cuTransAnswer.setCorrectAnswer(e.getTargetContent());
            cuTransAnswer.setQuestionLevel(String.valueOf(e.getDifficultLevel()));

            Map<String,Object> questionWeight = new HashMap<>();
            questionWeight.put("temporalTatio",e.getTemporalTatio());
            questionWeight.put("vocabularyRatio",e.getVocabularyRatio());
            questionWeight.put("grammarRatio",e.getGrammarRatio());
            cuTransAnswer.setQuestionWeight(JSON.toJSONString(questionWeight));
            List<String> domains = new ArrayList<>();
            e.getDomains().forEach(e2->{
                domains.add(e2.getSpecialtyName());
            });
            cuTransAnswer.setQuestionFields(JSON.toJSONString(domains));
            cuTransAnswerDao.save(cuTransAnswer);

            Map<String, Object> map = new HashMap();
            map.put("answerId",cuTransAnswer.getId());
            map.put("question",e.getOrignContent());
            map.put("answer",null);
            questions.add(map);
        });
        createExamDto.setQuestionIds(String.join(",",ids));
        return createExamDto;
    }
    @Override
    public CreateExamDto getCurrentQuestions(String curecordId){
        CreateExamDto<Object> createExamDto = new CreateExamDto();
        List<CuTransAnswer>  cuTransAnswers = cuTransAnswerDao.findAllByRecordId(curecordId);
        List<Map<String, Object>> questions = new ArrayList<>();
        createExamDto.setQuestions(questions);
        List<String> ids = new ArrayList<>();
        cuTransAnswers.forEach(e->{
            ids.add(e.getId());
            Map<String,Object> map = new HashMap<>();
            map.put("answerId",e.getId());
            map.put("question",e.getQuestion());
            map.put("answer",e.getAnswer());
            questions.add(map);
        });
        createExamDto.setQuestionIds(String.join(",",ids));
        return createExamDto;
    }

    @Override
    public Integer examCommitOne(String recordId, String answerId, String answer) {
        CuTransAnswer cuTransAnswer = EntityUtil.getEntityById(answerId,cuTransAnswerDao);
        cuTransAnswer.setAnswer(answer);
        return 1;
    }

    @Override
    public void handleResult(CuRecord cuRecord,boolean systemCtl) {
        CuLevel cuLevel = EntityUtil.getEntityById(cuRecord.getLevelId(),cuLevelDao);
        cuLevel.setExamTimes(cuLevel.getExamTimes()+1);
        cuLevel.setExamRecordId(null);

        AdTransResult adTransResult = new AdTransResult();
        adTransResult.setUserId(cuRecord.getUserId());
        adTransResult.setTranslatorLevel(cuLevel.getLevel());
        adTransResult.setExamStartTime(cuRecord.getExamStartTime());
        adTransResult.setRecordId(cuRecord.getId());
        adTransResult.setOriginLanguageCode(cuLevel.getOriginLanguageCode());
        adTransResult.setOriginLanguageName(cuLevel.getOriginLanguageName());
        adTransResult.setTargetLanguageCode(cuLevel.getTargetLanguageCode());
        adTransResult.setTargetLanguageName(cuLevel.getTargetLanguageName());
        adTransResult.setExamTimes(cuLevel.getExamTimes());
        adTransResult.setTranslatorCode(cuLevel.getTranslatorCode());
        adTransResult.setGmtCreate(DateUtils.getCurrentTimeStamp());
        adTransResult.setSkillFields(cuLevel.getSkillFields());
        adTransResult.setQuestionLevel(cuLevel.getNextExamLevel());
        adTransResult.setTranslatorLevel(cuLevel.getLevel());
        adTransResult.setTranslatorCode(cuLevel.getTranslatorCode());
        adTransResult.setAuditState(ExamCons.未分.message);

        List<Domain> domains = new ArrayList<>();
        List<String> ids = JSON.parseArray(cuLevel.getSkillFieldsIds(),String.class);
        if(ids!=null){
            ids.forEach(e->{
                domains.add(domainDao.getOne(e));
            });
        }
        adTransResult.setDomains(domains);
        adTransResultDao.save(adTransResult);
    }

    public Map<String,Object> getExamDetail(String id){
        AdTransResult adTransResult = EntityUtil.getEntityById(id,adTransResultDao);
        List<CuTransAnswer>  cuTransAnswers = cuTransAnswerDao.findAllByRecordId(adTransResult.getRecordId());
        Map<String,Object> map = new HashMap<>();
        map.put("adTransResult",adTransResult);
        map.put("cuTransAnswers",cuTransAnswers);
        return map;
    }

    @Override
    public Map<String, Object> getResultDetail(String resultId) {
        AdTransResult adTransResult = EntityUtil.getEntityById(resultId,adTransResultDao);
        List<CuTransAnswer> cuTransAnswers = cuTransAnswerDao.findAllByRecordId(adTransResult.getRecordId());
        Map<String,Object> result = new HashMap<>();
        result.put("adTransResult",adTransResult);
        result.put("cuTransAnswers",cuTransAnswers);
        return result;
    }
}
