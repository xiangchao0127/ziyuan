package com.sy.pangu.rm.config;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.concurrent.TimeUnit;

/**
 * @author XiangChao
 * @date 2019/3/11
 */
@Configuration
public class CacheConfig {
    @Bean
    public Cache<String, String> getCache() {
        return CacheBuilder.newBuilder().expireAfterWrite(5L, TimeUnit.MINUTES).build();
    }


    @Bean
    public BCryptPasswordEncoder getPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
