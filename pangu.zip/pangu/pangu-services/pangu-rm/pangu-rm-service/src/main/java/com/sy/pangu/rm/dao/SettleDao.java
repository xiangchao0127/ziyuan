package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.Settle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * 结算
 */
public interface SettleDao extends JpaRepository<Settle,String>, JpaSpecificationExecutor<Settle> {

    Settle findBySettleAccount(String account);

}
