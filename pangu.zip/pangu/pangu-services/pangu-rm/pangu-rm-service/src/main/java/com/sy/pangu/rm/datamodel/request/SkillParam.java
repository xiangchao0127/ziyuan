package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

/**
 * 技能证书
 */
@Data
public class SkillParam implements Serializable {
    private  String id;
    private String userId;
    //证书类型
    private String userCertificateType;
/*    //证书名称
    private String userCertificateName;
    //证书保存路径
    private String userCertificatePath;*/
}
