package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.UserDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserDao extends JpaRepository<UserDO, String>, JpaSpecificationExecutor<UserDO> {


    UserDO findByAccount(String account);

    UserDO findByTelephone(String telephone);

    List<UserDO> findAllByTelephoneIn(List<String> telphoneLst);

    UserDO findByEmail(String email);

    UserDO findUserDOByUserName(String userName);

    /**
     * 判断昵称是否存在
     * @param nickName
     * @return
     */
    Boolean existsByNickName(String nickName);

    UserDO findByNickName(String nickName);

    UserDO findByTelephoneAndUserTypeAndDeleted(String telephone, String usertype, Boolean deleted);

    UserDO findByAccountAndUserTypeAndDeleted(String account, String usertype, Boolean deleted);

    UserDO findByEmailAndUserTypeAndDeleted(String email, String usertype, Boolean deleted);

    @Query(nativeQuery = true, value = "insert into sys_role_user (user_id,role_id) values (?,?)")
    void addRole(String userId, String roleId);

    @Query(nativeQuery = true, value = "delete from sys_role_user where user_id=? and role_id=?")
    void deleteRole(String userId, String roleId);

    @Query(nativeQuery = true, value = "insert into sys_user_position (user_id,position_id) values (?,?)")
    void addPosition(String userId, String positionId);

    @Query(nativeQuery = true, value = "delete from sys_user_position where user_id=? and position_id=?")
    void deletePosition(String userId, String positionId);

    @Query(nativeQuery = true, value = "insert into sys_user_orgnize (user_id,orgnize_id) values (?,?)")
    void addOrgnize(String userId, String roleId);

    @Query(nativeQuery = true, value = "delete from sys_user_orgnize where user_id=? and orgnize_id=?")
    void deleteOrgnize(String userId, String roleId);

    /**
     * 伪删除
     */
    @Transactional
    @Modifying
    @Query(nativeQuery = true, value = "update sys_user set deleted = 1 where id =?")
    int isDeleted(String id);

    /**
     * 是否启用
     */
    @Transactional
    @Modifying
    @Query(nativeQuery = true, value = "update sys_user set is_enabled = ?2 where id =?1")
    int isEnabled(String id, String code);
}
