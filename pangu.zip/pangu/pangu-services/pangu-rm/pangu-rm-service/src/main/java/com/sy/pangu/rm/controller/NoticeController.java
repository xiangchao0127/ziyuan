package com.sy.pangu.rm.controller;

import com.sy.pangu.rm.datamodel.request.PublishNoticeParam;
import com.sy.pangu.rm.entity.Notice;
import com.sy.pangu.rm.entity.SysNotice;
import com.sy.pangu.rm.service.NoticeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author XiangChao
 * @date 2019/4/26
 */
@Api(tags = {"消息通知"})
@RestController
@RequestMapping("/notice")
public class NoticeController {
    @Autowired
    NoticeService noticeService;
    /**
     * 消息通知列表
     *
     * @param noticeType 通知类型
     * @param status     状态
     * @return
     */
    @ApiOperation("通知列表")
    @GetMapping("/noticeList")
    public ResponseEntity<Page<Notice>> noticeList(Integer noticeType, Integer status, Integer pageNo, Integer pageSize){
        return ResponseEntity.ok().body(noticeService.noticeList(noticeType,status,pageNo,pageSize));
    }
    /**
     * 已发布消息通知-管理员用
     *
     * @param noticeType 消息通知类型
     * @param personType 接收人员类型
     * @param startTime  开始时间
     * @param endTime    结束时间
     * @return
     */
    @ApiOperation("已发布消息通知-管理员用")
    @GetMapping("/alreadyPublishSysNoticeList")
    public ResponseEntity<Page<SysNotice>> alreadyPublishSysNoticeList(Integer noticeType, Integer personType, String startTime, String endTime,Integer pageNo,Integer pageSize){
        return ResponseEntity.ok().body(noticeService.alreadyPublishSysNoticeList(noticeType,personType,startTime,endTime,pageNo,pageSize));
    }
    /**
     * 保存消息通知
     *
     * @param publishNoticeParam
     * @return
     */
    @ApiOperation("保存消息通知")
    @GetMapping("/publishNotice")
    public ResponseEntity<Integer> publishNotice(PublishNoticeParam publishNoticeParam){
        return ResponseEntity.ok().body(noticeService.publishNotice(publishNoticeParam));
    }


    /**
     * 消息状态更改(已读，回收站)
     * @param noticeId 消息id
     * @param status 状态
     * @return
     */
    @ApiOperation("消息状态更改")
    @PutMapping
    public ResponseEntity<Integer> updateNoticeStatus(String noticeId,Integer status){
        return ResponseEntity.ok().body(noticeService.updateNoticeStatus(noticeId,status));
    }
}
