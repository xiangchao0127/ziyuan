package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.ProjectExperience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * @author Q00596
 */
public interface ProjectDao extends JpaRepository<ProjectExperience,String>, JpaSpecificationExecutor<ProjectExperience> {

       ProjectExperience findByUserIdAndCompanyNameAndProjectName(String userId,String companyName,String projectName);
}
