package com.sy.pangu.rm.datamodel.request.W3;

import lombok.Data;

import java.io.Serializable;

/**
 * W3同步的专职等级语言对等信息
 */
@Data
public class W3LevelInfoParam implements Serializable {


    /**
     * 工号
     */
    private String staffNo;

    /**
     * 等级表Id 或者来自W3的Id
     */
    private String recordId;
    /**
     * 源语言Code
     */
    private String sourceLanguageCode;
    /**
     * 源语言Name
     */
    private String sourceLanguageName;
    /**
     * 目标语言Code
     */
    private String targetLanguageCode;
    /**
     * 目标语言Name
     */
    private String targetLanguageName;
    /**
     * 岗位Code
     */
    private String serviceCode;
    /**
     * 岗位Name
     */
    private String serviceName;
    /**
     * 等级Code
     */
    private String levelCode;


    private String levelName;
    /**
     * 领域Code
     */
    private String areaCode;


    private String areaName;

}
