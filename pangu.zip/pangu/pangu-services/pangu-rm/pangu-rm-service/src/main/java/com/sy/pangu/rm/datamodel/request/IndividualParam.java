package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.io.Serializable;

/**
 * 个性化标签
 */
@Data
public class IndividualParam implements Serializable {
    private String userId;
    private String individualization;
    private String area;
}
