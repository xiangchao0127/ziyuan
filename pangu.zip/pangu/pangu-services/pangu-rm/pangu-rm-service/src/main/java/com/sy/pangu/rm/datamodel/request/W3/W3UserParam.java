package com.sy.pangu.rm.datamodel.request.W3;

import lombok.Data;

import java.io.Serializable;

/**
 * W3同步过来的基本信息
 */
@Data
public class W3UserParam implements Serializable {
    /**
     * 所属组别
     */
    private String ownGroup;
    /**
     * 工号
     */
    private String staffNo;
    /**
     * 真实姓名
     */
    private String userName;
    /**
     * 岗位
     */
    private String station;
    /**
     * 是否离职
     */
    private Integer levelOrNot;
}
