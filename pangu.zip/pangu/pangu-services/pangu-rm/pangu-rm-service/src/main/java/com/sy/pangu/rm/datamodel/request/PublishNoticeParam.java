package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.util.List;

/** 发布消息
 * @author XiangChao
 * @date 2019/4/26
 */
@Data
public class PublishNoticeParam {
    /**
     * 消息通知类型
     */
    private Integer noticeType;
    /**
     * 消息通知标题
     */
    private String noticeHead;
    /**
     * 消息通知内容
     */
    private String content;
    /**
     * 接收类型
     */
    private List<String> receiveType;
    /**
     * 接受人员类型
     */
    private List<String> receivePersonType;
    /**
     * 具体人员id
     */
    private List<String> personIds;
    /**
     * 是否立即发布
     */
    private Boolean isImmediatelyPublish;
    /**
     * 定时发布时间
     */
    private String delayPublishTime;
}
