package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.ProjectExperience;
import com.sy.pangu.rm.entity.Sign;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.sql.Timestamp;
import java.util.List;

/**
 * 积分
 */
public interface SignDao extends JpaRepository<Sign,String>, JpaSpecificationExecutor<Sign> {

   /**
    * 查询本月签到情况
    * @param yearMonth
    * @return
    */
   List<Sign> findBySignYearMonth(String yearMonth);


   /**
    * 获取某日签到情况
    * @param signDate
    * @return
    */
   Sign findBySignDate(String signDate);
}
