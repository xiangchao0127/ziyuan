package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.SysConfig;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/15
 * Time:10:29
 */
public interface SysConfigDao extends JpaRepository<SysConfig,String> {
    SysConfig findByApplicationNameAndSysCode(String applicationName,String sysCode);
}
