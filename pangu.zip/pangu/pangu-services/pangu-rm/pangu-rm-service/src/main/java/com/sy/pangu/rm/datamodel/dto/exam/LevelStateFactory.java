package com.sy.pangu.rm.datamodel.dto.exam;

import lombok.Data;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/11
 * Time:9:30
 */
@Data
public class LevelStateFactory {
    public static LevelState primaryLevelState = new PrimaryLevelState();
    public static LevelState middleLevelState = new MiddleLevelState();
    public static LevelState highLevelState = new highLevelState();
}
