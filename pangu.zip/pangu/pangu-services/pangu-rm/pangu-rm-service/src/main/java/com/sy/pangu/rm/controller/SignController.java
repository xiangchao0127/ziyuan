package com.sy.pangu.rm.controller;


import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.rm.dao.SignDao;
import com.sy.pangu.rm.datamodel.request.SignParam;
import com.sy.pangu.rm.entity.Sign;
import com.sy.pangu.rm.service.SignService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.List;

@Api(tags = {"签到"})
@RestController
@RequestMapping(value = "sign")
public class SignController {

    @Autowired
    SignService signService;

    @Autowired
    SignDao signDao;

    @ApiOperation("签到")
    @PostMapping("sign")
    public ResponseEntity<Sign> sign(SignParam signParam) throws ParseException {
        return ResponseEntity.ok().body(signService.sign(signParam));
    }

    @ApiOperation("当月已签到列表")
    @GetMapping("listSignInfoThisMonth")
    public ResponseEntity<List<Sign>> listSignInfoByMonth(String timeStamp) throws ParseException {
        String yearMonth = DateUtils.getYearMonth(timeStamp);
        return ResponseEntity.ok().body(signDao.findBySignYearMonth(yearMonth));
    }


}
