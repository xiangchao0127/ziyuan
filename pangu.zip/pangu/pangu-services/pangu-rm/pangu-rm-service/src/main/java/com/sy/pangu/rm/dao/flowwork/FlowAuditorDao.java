package com.sy.pangu.rm.dao.flowwork;

import com.sy.pangu.rm.entity.flowwork.FlowAuditor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/16
 * Time:16:53
 */
public interface FlowAuditorDao extends JpaRepository<FlowAuditor,String> {
    List<FlowAuditor> findAllByWorkmapId(String workmapId);
}
