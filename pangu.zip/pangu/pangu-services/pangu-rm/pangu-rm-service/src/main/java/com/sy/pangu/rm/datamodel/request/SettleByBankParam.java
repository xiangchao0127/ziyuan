package com.sy.pangu.rm.datamodel.request;


import lombok.Data;

import java.io.Serializable;

/**
 * 设置结算方式
 * 通过银行卡号
 */
@Data
public class SettleByBankParam implements Serializable {
    private String id;
    private String userId;
    private String realName;
    private String identityId;
    private String bankNo;
    private String bankDeposit;
    private String bankBranch;

}
