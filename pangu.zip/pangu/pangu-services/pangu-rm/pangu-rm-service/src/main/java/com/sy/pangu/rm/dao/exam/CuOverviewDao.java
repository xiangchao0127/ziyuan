package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.CuOverview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/10
 * Time:9:08
 */
public interface CuOverviewDao extends JpaRepository<CuOverview,String>, JpaSpecificationExecutor<CuOverview> {
    List<CuOverview> findAllByUserId(String userId);
    @Query(nativeQuery = true,value = "select * from exam_customer_overview e where e.choice_question_id = ?")
    CuOverview findOneByChoiceId(String choiceId);
}
