package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.Education;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface EducationDao extends JpaRepository<Education, String>, JpaSpecificationExecutor<Education> {


    Education findByUserId(String userId);

    Education findByUserIdAndGraduatedSchoolNameAndDegree(String userId,String schoolName,String degree);

}
