package com.sy.pangu.rm.controller;

import com.sy.pangu.common.entity.dto.BaseResponse;
import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.ExcelUtils;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.file.client.FileClient;
import com.sy.pangu.rm.datamodel.request.ListChoiceQuestionParam;
import com.sy.pangu.rm.entity.ChoiceQuestionDO;
import com.sy.pangu.rm.service.ChoiceQuestionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/9
 */
@SuppressWarnings("ALL")
@Api(tags = {"选择题库管理"})
@RestController
@RequestMapping("/choiceQuestion")
public class ChoiceQuestionController {
    @Autowired
    ChoiceQuestionService choiceQuestionService;
    @Autowired
    FileClient fileClient;

    /**
     * 选择题列表查询
     *
     * @param choiceQuestionParam
     * @return
     */
    @ApiOperation("选择题列表查询")
    @GetMapping("/listChoiceQuestions")
    public ResponseEntity<Page<ChoiceQuestionDO>> listChoiceQuestions(ListChoiceQuestionParam choiceQuestionParam) {
        if (StringUtils.notEmpty(choiceQuestionParam.getStartTime()) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, choiceQuestionParam.getStartTime())) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "开始时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if (StringUtils.notEmpty(choiceQuestionParam.getEndTime()) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, choiceQuestionParam.getEndTime())) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "结束时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if(choiceQuestionParam.getPageNo()==null || choiceQuestionParam.getPageSize()==null){
            throw new CustomException(ExceptionEnum.Params_Empty,"pageNo和pageSize不能为空");
        }
        return ResponseEntity.ok().body(choiceQuestionService.listChoiceQuestions(choiceQuestionParam));
    }

    /**
     * 单个添加选择题
     *
     * @param choiceQuestionDO
     * @return
     */
    @ApiOperation("单个添加选择题")
    @PostMapping("/addChoiceQuestion")
    public ResponseEntity<Integer> addChoiceQuestion(ChoiceQuestionDO choiceQuestionDO) {
        return ResponseEntity.ok().body(choiceQuestionService.addChoiceQuestion(choiceQuestionDO));
    }

    /**
     * 选择题详情
     *
     * @param id
     * @return
     */
    @ApiOperation("选择题详情")
    @GetMapping("/choiceQuestionDetails")
    public ResponseEntity<ChoiceQuestionDO> choiceQuestionDetails(String id) {
        return ResponseEntity.ok().body(choiceQuestionService.choiceQuestionDetails(id));
    }

    /**
     * 选择题编辑
     *
     * @param choiceQuestionDO
     * @return
     */
    @ApiOperation("选择题编辑")
    @PutMapping("/updateChoiceQuestion")
    public ResponseEntity<Integer> updateChoiceQuestion(ChoiceQuestionDO choiceQuestionDO) {
        return ResponseEntity.ok().body(choiceQuestionService.updateChoiceQuestion(choiceQuestionDO));
    }

    /**
     * 批量导入
     *
     * @param multipartFile
     * @return
     */
    @ApiOperation("批量导入")
    @PostMapping("/batchAddChoiceQuestions")
    public ResponseEntity<Integer> batchAddChoiceQuestions(MultipartFile multipartFile) {
        return ResponseEntity.ok().body(choiceQuestionService.batchAddChoiceQuestions(multipartFile));
    }

    /**
     * 批量删除选择题
     *
     * @param ids
     * @return
     */
    @ApiOperation("批量删除选择题")
    @DeleteMapping("/deleteChoiceQuestion")
    public ResponseEntity<Integer> deleteChoiceQuestion(@RequestParam(value = "ids") List<String> ids) {
        return ResponseEntity.ok().body(choiceQuestionService.deleteChoiceQuestion(ids));
    }

    /**
     * 批量启用
     *
     * @param ids
     * @return
     */
    @ApiOperation("批量启用")
    @PutMapping("/enableChoice")
    public ResponseEntity<Integer> enableChoice(@RequestParam(value = "ids") List<String> ids) {
        return ResponseEntity.ok().body(choiceQuestionService.enableChoice(ids));
    }

    /**
     * 批量禁用
     *
     * @param ids
     * @return
     */
    @ApiOperation("批量禁用")
    @PutMapping("/disableChoice")
    public ResponseEntity<Integer> disableChoice(@RequestParam(value = "ids") List<String> ids) {
        return ResponseEntity.ok().body(choiceQuestionService.disableChoice(ids));
    }


    /**
     * 选择题模板下载
     *
     * @return url
     */
    @ApiOperation("选择题模板下载")
    @GetMapping("/downloadChoiceQuestionModel")
    public ResponseEntity<String> downloadChoiceQuestionModel() {
        return ResponseEntity.ok().body(choiceQuestionService.downloadChoiceQuestionModel());
    }

    @ApiOperation("上传模板")
    @PostMapping("/upload")
    public void uploadModel(@RequestParam("multipartFile") MultipartFile multipartFile) {
        fileClient.fileUpload(multipartFile, "/opt/docker/nginx/html/rm/images/qq.jpg");
//        fileClient.fileUpload(multipartFile, "d:\\opt\\docker\\nginx\\html\\rm\\images\\qq.jpg");
    }

    @ApiOperation("获取文件流")
    @GetMapping("/getFileInputstream")
    public void getFileInputstream(@RequestParam("path") String  path) {
        List<List<String>> excelContent = fileClient.getExcelContent("D:\\11.xlsx");
        System.out.println(excelContent);
//        fileClient.fileUpload(multipartFile, "d:\\opt\\docker\\nginx\\html\\rm\\images\\qq.jpg");
    }

    @ApiOperation("test")
    @PostMapping("/test")
    public void test() {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode("200");
        baseResponse.setMsg("000");
        baseResponse.setObj(1);
        fileClient.getTest(baseResponse);
    }
}
