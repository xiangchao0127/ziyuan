package com.sy.pangu.rm.controller;


import com.sy.pangu.common.util.BeanUtils;
import com.sy.pangu.common.util.DateUtils;
import com.sy.pangu.rm.entity.Domain;
import com.sy.pangu.rm.service.DomainService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2018/12/28
 * Time:15:44
 */
@Api(tags = "领域操作")
@RestController
@RequestMapping("/domain")
public class DomainController {
    @Autowired
    private DomainService domainService;

    /**
     * 获取一级领域
     * @return
     */
    @ApiOperation("获取一级领域")
    @GetMapping("/listDomain")
    public ResponseEntity<List<Domain>> listDomain() {
        return ResponseEntity.ok().body(domainService.listDomain());
    }

    /**
     * 获取二级领域
     * @param pSpecialtyId 父领域id
     * @return
     */
    @ApiOperation("获取二级领域")
    @GetMapping("/listSub")
    public ResponseEntity<List<Domain>> listsubDomain(Integer pSpecialtyId) {
        return ResponseEntity.ok().body(domainService.listsubDomain(pSpecialtyId));
    }

    /**
     * 获取所有领域
     * @return
     */
    @ApiOperation("获取所有领域")
    @GetMapping("/listAll")
    public ResponseEntity<List<Domain>> listAll() {
        return ResponseEntity.ok().body(domainService.listAll());
    }


}
