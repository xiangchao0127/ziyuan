package com.sy.pangu.rm.dao;

import com.sy.pangu.rm.entity.SchduleTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/4/25
 */
public interface SchduleTaskDao extends JpaRepository<SchduleTask,String>, JpaSpecificationExecutor<SchduleTask> {
    /**
     * 根据状态获取定时任务
     * @param isCarriedOut
     * @return
     */
    List<SchduleTask> getByIsCarriedOut(Boolean isCarriedOut);

}
