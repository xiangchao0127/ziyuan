package com.sy.pangu.rm.controller;

import com.sy.pangu.common.entity.dto.CustomException;
import com.sy.pangu.common.enums.exception.ExceptionEnum;
import com.sy.pangu.common.util.PageResults;
import com.sy.pangu.common.util.StringUtils;
import com.sy.pangu.rm.datamodel.request.AddInterpreterArticleParam;
import com.sy.pangu.rm.datamodel.request.InterpreterArticleSearchParam;
import com.sy.pangu.rm.entity.article.InterpreterArticle;
import com.sy.pangu.rm.entity.article.Like;
import com.sy.pangu.rm.service.InterpreterArticleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author XiangChao
 * @date 2019/5/8
 */
@Api(tags = {"译员文章管理"})
@RestController
@RequestMapping("/interpreterArticle")
public class InterpreterArticleController {
    @Autowired
    InterpreterArticleService interpreterArticleService;

    /**
     * 译员文章列表
     *
     * @param interpreterArticleSearchParam
     * @return
     */
    @ApiOperation("译员文章列表")
    @GetMapping("/interpreterArticleList")
    public ResponseEntity<Page<InterpreterArticle>> interpreterArticleList(InterpreterArticleSearchParam interpreterArticleSearchParam) {
        if (StringUtils.notEmpty(interpreterArticleSearchParam.getPublishStartTime()) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, interpreterArticleSearchParam.getPublishStartTime())) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "开始时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if (StringUtils.notEmpty(interpreterArticleSearchParam.getPublishEndTime()) && !StringUtils.isMatcher(StringUtils.TIME_FORMAT, interpreterArticleSearchParam.getPublishEndTime())) {
            throw new CustomException(ExceptionEnum.PARAM_EXCEPTION, "结束时间格式不正确,请确保为型如1992-12-12 00:00:00格式");
        }
        if (interpreterArticleSearchParam.getPageNo() == null || interpreterArticleSearchParam.getPageSize() == null) {
            throw new CustomException(ExceptionEnum.Params_Empty, "pageNo和pageSize不能为空");
        }
        return ResponseEntity.ok().body(interpreterArticleService.interpreterArticleList(interpreterArticleSearchParam));
    }

    /**
     * 译员发布文章
     *
     * @param addInterpreterArticleParam
     * @return
     */
    @ApiOperation("译员发布文章")
    @PostMapping("/addInterpreterArticle")
    public ResponseEntity<Integer> addInterpreterArticle(AddInterpreterArticleParam addInterpreterArticleParam) {
        return ResponseEntity.ok().body(interpreterArticleService.addInterpreterArticle(addInterpreterArticleParam));
    }

    /**
     * 编辑文章
     *
     * @param addInterpreterArticleParam
     * @return
     */
    @ApiOperation("编辑文章")
    @PutMapping("/editInterpreterArticle")
    public ResponseEntity<Integer> editInterpreterArticle(AddInterpreterArticleParam addInterpreterArticleParam) {
        return ResponseEntity.ok().body(interpreterArticleService.editInterpreterArticle(addInterpreterArticleParam));
    }

    /**
     * 文章详情
     *
     * @param articleId 文章id
     * @return
     */
    @ApiOperation("文章详情")
    @GetMapping("/InterpreterArticle")
    public ResponseEntity<InterpreterArticle> interpreterArticleDetails(String articleId) {
        return ResponseEntity.ok().body(interpreterArticleService.interpreterArticleDetails(articleId));
    }

    /**
     * 上传文章封面图
     *
     * @param multipartFile 文件
     * @return
     */
    @ApiOperation("上传文章封面图")
    @PostMapping("/uploadCover")
    public ResponseEntity<String> uploadCover(@RequestParam("multipartFile") MultipartFile multipartFile) {
        return ResponseEntity.ok().body(interpreterArticleService.uploadCover(multipartFile));
    }

    /**
     * 设为精选
     *
     * @param articleId 文章id
     * @return
     */
    @ApiOperation("设为精选")
    @PutMapping("/setSelection")
    public ResponseEntity<Integer> setSelection(String articleId) {
        return ResponseEntity.ok().body(interpreterArticleService.setSelection(articleId));
    }

    /**
     * 审核
     *
     * @param articleId 文章id
     * @param status    2 不通过 3 通过
     * @param desc      通过或不通过描述
     * @return
     */
    @ApiOperation("审核")
    @PutMapping("/reviewArticle")
    public ResponseEntity<Integer> reviewArticle(String articleId, Integer status, String desc) {
        return ResponseEntity.ok().body(interpreterArticleService.reviewArticle(articleId, status, desc));
    }

    /**
     * 取消发布
     *
     * @param articleId 文章id
     * @return
     */
    @ApiOperation("取消发布")
    @PutMapping("/cancelPulish")
    public ResponseEntity<Integer> cancelPulish(String articleId) {
        return ResponseEntity.ok().body(interpreterArticleService.cancelPulish(articleId));
    }

    /**
     * 点赞列表
     *
     * @param articleId 文章id
     * @param pageNo    页码
     * @param pageSize  一页大小
     * @return
     */
    @ApiOperation("点赞列表")
    @GetMapping("/likeList")
    public ResponseEntity<PageResults<Like>> likeList(String articleId, int pageNo, int pageSize) {
        return ResponseEntity.ok().body(interpreterArticleService.likeList(articleId, pageNo, pageSize));
    }

    /**
     * 文章点赞
     *
     * @param articleId 文章id
     * @param type      0 译员文章点赞 1 官方文章点赞
     * @return
     */
    @ApiOperation("文章点赞")
    @PutMapping("/articleLike")
    public ResponseEntity<Integer> articleLike(String articleId, Integer type) {
        return ResponseEntity.ok().body(interpreterArticleService.articleLike(articleId, type));
    }

    /**
     * 删除回复
     *
     * @param replyId 回复id
     * @return
     */
    @ApiOperation("删除回复")
    @DeleteMapping("/deleteReply")
    public ResponseEntity<Integer> deleteReply(String replyId) {
        return ResponseEntity.ok().body(interpreterArticleService.deleteReply(replyId));
    }

    /**
     * 添加标签
     *
     * @param labelName 标签名称
     * @return
     */
    @ApiOperation("添加标签")
    @PostMapping("/addArticleLabel")
    public ResponseEntity<Integer> addArticleLabel(String labelName) {
        return ResponseEntity.ok().body(interpreterArticleService.addArticleLabel(labelName));
    }

    /**
     * 删除标签
     *
     * @param labelId 标签id
     * @return
     */
    @ApiOperation("删除标签")
    @DeleteMapping("/deleteArticleLabel")
    public ResponseEntity<Integer> deleteArticleLabel(String labelId) {
        return ResponseEntity.ok().body(interpreterArticleService.deleteArticleLabel(labelId));
    }
}
