package com.sy.pangu.rm.datamodel.dto;

import lombok.Data;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/12
 * Time:13:58
 */
@Data
public class ExamRequestParam {
    public static final String examType_select="select";
    public static final String examType_trans="trans";
    private String examType;
    private String originLanguageCode;
    private String originLanguageName;
    private String targetLanguageCode;
    private String targetLanguageName;
    private List<String> fieldIds;
    private List<String> usedQuestionIds;
    private String examLevel;
}
