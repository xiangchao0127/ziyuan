package com.sy.pangu.rm.datamodel.request;

import lombok.Data;

import java.util.List;

/** 选择题查询参数
 * @author XiangChao
 * @date 2019/4/9
 */
@Data
public class ListChoiceQuestionParam {
    /**
     * 题号
     */
    private String questionNo;
    /**
     * 语言
     */
    private String language;
    /**
     * 题目
     */
    private String questionHead;
    /**
     * 状态 (0 禁用 1 启用)
     */
    private String status;
    /**
     * 创建人
     */
    private String createUserNo;
    /**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private String endTime;
    /**
     * 难度等级
     */
    private String difficultLevel;
    /**
     * 领域id集合
     */
    private List<String> domainIds;
    /**
     * 类型(选择 填空)
     */
    private String type;
    /**
     * 页码
     */
    private Integer pageNo;
    /**
     * 条数
     */
    private Integer pageSize;
    /**
     * 选项A
     */
    private String optionA;
    /**
     * 选项B
     */
    private String optionB;
    /**
     * 选项C
     */
    private String optionC;
    /**
     * 选项D
     */
    private String optionD;
}
