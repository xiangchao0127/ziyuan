package com.sy.pangu.rm.controller;


import com.google.common.cache.Cache;
import com.sy.pangu.rm.dao.LevelRelationDao;
import com.sy.pangu.rm.dao.SkillTypeDao;
import com.sy.pangu.rm.dao.WorkExperienceDao;
import com.sy.pangu.rm.datamodel.request.*;
import com.sy.pangu.rm.datamodel.vo.NoticeInfo;
import com.sy.pangu.rm.datamodel.vo.UserInfo;
import com.sy.pangu.rm.entity.*;
import com.sy.pangu.rm.model.LevelRelation;
import com.sy.pangu.rm.service.UserExtensionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;


@Api(tags = {"个人基本信息"})
@RestController
@RequestMapping(value = "/userExtension")
public class UserExtensionController {

    @Autowired
    UserExtensionService userExtensionService;

    @Autowired
    SkillTypeDao skillTypeDao;

    @Autowired
    WorkExperienceDao workExperienceDao;

    @Autowired
    Cache<String, String> cache;

    @Autowired
    LevelRelationDao levelRelationDao;

    @ApiOperation("根据UserId获取电话号码")
    @PostMapping("getTelByUserId")
    public ResponseEntity<String> getTelByUserId(String userId) {
        return ResponseEntity.ok().body(userExtensionService.getTelByUserId(userId));
    }


    @ApiOperation("添加基本信息")
    @PostMapping("addBasicInfo")
    public ResponseEntity<UserExtension> addBasicInfo(BasicInfoParam basicInfoParam) {
        return ResponseEntity.ok().body(userExtensionService.addPersonalInfo(basicInfoParam));
    }


    @ApiOperation("判断是否完善简历")
    @GetMapping("judgeCompleteResume")
    public ResponseEntity<Boolean> judgeCompleteResume(String userId) {
        return ResponseEntity.ok().body(userExtensionService.judgeCompleteResume(userId));
    }

    @ApiOperation("上传头像")
    @PostMapping("uploadHeaderImg")
    public ResponseEntity<String> uploadHeaderImg(String userId, @RequestParam("multipartFile") MultipartFile multipartFile) {
        return ResponseEntity.ok().body(userExtensionService.uploadHeaderImg(userId, multipartFile));
    }


    @ApiOperation("检查昵称是否存在")
    @GetMapping("findUserByNickName")
    public ResponseEntity<Integer> findUserByNickName(String nickName) {
        return ResponseEntity.ok().body(userExtensionService.findUserByNickName(nickName));

    }

    @ApiOperation("根据用户Id获取User信息")
    @GetMapping("findUserByUserId")
    public ResponseEntity<UserInfo> findByUserId(String userId) {
        return ResponseEntity.ok().body(userExtensionService.findByUserId(userId));
    }

    @ApiOperation("发送邮件")
    @PostMapping("verifyEmail")
    public ResponseEntity<Integer> verifyEmail(String email) {
        return ResponseEntity.ok().body(userExtensionService.sendEmail(email));
    }

    @ApiOperation("添加学历信息")
    @PostMapping("addEducationInfo")
    public ResponseEntity<Education> addEducationInfo(EducationInfoParam educationInfoParam) {
        return ResponseEntity.ok().body(userExtensionService.addEducationInfo(educationInfoParam));
    }

    @ApiOperation("删除学历信息")
    @DeleteMapping("deleteEducationInfo")
    public ResponseEntity<Boolean> deleteEducationInfo(String id) {
        return ResponseEntity.ok().body(userExtensionService.deleteEducationInfo(id));
    }


    @ApiOperation("添加技能证书")
    @PostMapping("addSkillInfo")
    public ResponseEntity<UserSkill> addSkillInfo(SkillParam skillParam, @RequestParam("multipartFile") MultipartFile multipartFile) {
        return ResponseEntity.ok().body(userExtensionService.addSkillInfo(skillParam, multipartFile));
    }

    @ApiOperation("删除技能证书信息")
    @DeleteMapping("deleteSkillInfo")
    public ResponseEntity<Boolean> deleteSkillInfo(String id) {
        return ResponseEntity.ok().body(userExtensionService.deleteSkillInfo(id));
    }


    @ApiOperation("添加工作经历")
    @PostMapping("addWorkExperience")
    public ResponseEntity<WorkExperience> addWorkExperience(WorkExperienceParam workExperienceParam) {
        return ResponseEntity.ok().body(userExtensionService.addWorkExperience(workExperienceParam));
    }

    @ApiOperation("删除工作经验信息")
    @DeleteMapping("deleteWorkExperienceInfo")
    public ResponseEntity<Boolean> deleteWorkExperienceInfo(String id) {
        return ResponseEntity.ok().body(userExtensionService.deleteWorkExperienceInfo(id));
    }


    @ApiOperation("添加项目经验")
    @PostMapping("addProgramExperience")
    public ResponseEntity<ProjectExperience> addProgramExperience(ProjectExperienceParam projectExperienceParam) {
        return ResponseEntity.ok().body(userExtensionService.addProjectExperience(projectExperienceParam));
    }

    @ApiOperation("删除项目经验信息")
    @DeleteMapping("deleteProjectExperienceInfo")
    public ResponseEntity<Boolean> deleteProjectExperienceInfo(String id) {
        return ResponseEntity.ok().body(userExtensionService.deleteProjectExperienceInfo(id));
    }


    @ApiOperation("添加个性标签及擅长领域")
    @PostMapping("addIndividualInfo")
    public ResponseEntity<UserExtension> addIndividualInfo(IndividualParam individualParam) {
        return ResponseEntity.ok().body(userExtensionService.addIndividualExperience(individualParam));
    }


    @ApiOperation("查询所有的证书类型")
    @GetMapping("listAllSkillType")
    public ResponseEntity<List<SkillType>> listSkillType() {
        return ResponseEntity.ok().body(skillTypeDao.findAll().stream().filter(x -> x.getDeleted() == 0).collect(Collectors.toList()));
    }

    @ApiOperation("根据UserId获取工作过的公司名")
    @GetMapping("listWorkExperienceByUserId")
    public ResponseEntity<List<String>> listWorkExperienceByUserId(String userId) {
        List<String> companyNameLst = workExperienceDao.findCompanyNameByUserId(userId);
        return ResponseEntity.ok().body(companyNameLst);
    }

    @ApiOperation("根据UserId获取个人简历信息")
    @GetMapping("findResumeByUserId")
    public ResponseEntity<UserDO> findResumeByUserId(String userId) {
        return ResponseEntity.ok().body(userExtensionService.findResumeByUserId(userId));
    }

    @ApiOperation("身份认证")
    @PostMapping("identityUser")
    public ResponseEntity<Boolean> idendifyUser(IdentityParam identityParam) {
        return ResponseEntity.ok().body(userExtensionService.identifyUser(identityParam));
    }

    @ApiOperation("结算方式银行卡")
    @PostMapping("setSettleByBank")
    public ResponseEntity<Boolean> setSettleWayByBank(SettleByBankParam settleByBankParam) {
        return ResponseEntity.ok().body(userExtensionService.setSettleByBank(settleByBankParam));
    }

    @ApiOperation("设置Alipay")
    @PostMapping("setSettleByAlipay")
    public ResponseEntity<Settle> setSettleWayByAlipay(SettleByAlipayParam settleByAlipayParam) {
        return ResponseEntity.ok().body(userExtensionService.setSettleByAlipay(settleByAlipayParam));
    }

    @ApiOperation("获取结算方式和认证信息")
    @GetMapping("findSettleByUserId")
    public ResponseEntity<UserExtension> listSettleInfo(String userId) {
        return ResponseEntity.ok().body(userExtensionService.findSettleInfoByUserId(userId));
    }

    @ApiOperation("设置或者修改结算密码")
    @PutMapping("/setSettlePassword")
    public ResponseEntity<Integer> setSettlePassword(String userId, String telphone, String verifyCode, String selttlePassword, String reSettlePassword) {
        return ResponseEntity.ok().body(userExtensionService.setSettlePassword(userId, telphone, verifyCode, selttlePassword, reSettlePassword));
    }

    @ApiOperation("绑定邮箱")
    @PutMapping("/bindEmail")
    public ResponseEntity<Integer> bindEmail(String userId, String verifyCode, String email) {
        return ResponseEntity.ok().body(userExtensionService.bindEmail(userId, verifyCode, email));
    }

    @GetMapping("/sendCode")
    @ApiOperation("发送短信验证码")
    public ResponseEntity<Integer> sendCode(String telephone) {
        return ResponseEntity.ok().body(userExtensionService.sendCode(telephone));
    }


    @ApiOperation("获取邀请码")
    @PostMapping("/generatedInvitationCode")
    public ResponseEntity<String> generatedInvitationCode(String userId) {
        return ResponseEntity.ok().body(userExtensionService.generatedInvitationCode(userId));
    }


    @ApiOperation("获取通知通信录")
    @GetMapping("/getNoticeInfo")
    public ResponseEntity<List<NoticeInfo>> getNoticeInfo(List<Integer> noticeReceivePersonTypeLst, @RequestParam(value = "userNameLst", required = false) List<String> userNameLst) {
        return ResponseEntity.ok().body(userExtensionService.getALlNoticeInfo(noticeReceivePersonTypeLst, userNameLst));
    }


    @ApiOperation("获取所有兼职人员信息")
    @GetMapping("/getPartTimeStaffInfo")
    public ResponseEntity<Page<UserDO>> getALlPartTimeStaff(PartTimeStaffParam partTimeStaffParam) {
        return ResponseEntity.ok().body(userExtensionService.getALlPartTimeStaff(partTimeStaffParam));
    }


    @ApiOperation("获取所有专职人员信息")
    @GetMapping("/getFullTimeStaffInfo")
    public ResponseEntity<Page<UserDO>> getAllFullTimeStaff(FullTimeStaffParam fullTimeStaffParam) {
        return ResponseEntity.ok().body(userExtensionService.getALlFullTimeStaff(fullTimeStaffParam));
    }

    @ApiOperation("根据UserId获取兼职详情")
    @GetMapping("/getPartTimeStaffByUserId")
    public ResponseEntity<UserDO> getUserDetailInfo(String userId) {
        return ResponseEntity.ok().body(userExtensionService.getUserDetailInfo(userId));
    }

    @ApiOperation("设置默认结算方式")
    @PutMapping("setDefaultSettle")
    public ResponseEntity<Settle> saveDefaultSettle(String settleId) {
        return ResponseEntity.ok().body(userExtensionService.saveDefaultSettle(settleId));
    }

    @ApiOperation("保存更新兼职语种等级等信息")
    @PostMapping("saveUserExtend")
    public ResponseEntity<Boolean> saveUserExtend(UserLevelInfoParam userLevelInfoParam) {
        return ResponseEntity.ok().body(userExtensionService.saveUserExtend(userLevelInfoParam));
    }

    @ApiOperation("列举所有的等级Id和名称")
    @GetMapping("/listAllLevelRelation")
    public List<LevelRelation> listAllLevelRelation() {
        return userExtensionService.listAllLevelRelation();
    }


}
