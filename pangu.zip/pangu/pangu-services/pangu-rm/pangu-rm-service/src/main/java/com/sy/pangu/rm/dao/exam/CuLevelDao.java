package com.sy.pangu.rm.dao.exam;

import com.sy.pangu.rm.entity.exam.CuLevel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/10
 * Time:11:16
 */
public interface CuLevelDao extends JpaRepository<CuLevel,String> {
    List<CuLevel> findAllByIsApplyPass(Boolean isApplyPass);
}
