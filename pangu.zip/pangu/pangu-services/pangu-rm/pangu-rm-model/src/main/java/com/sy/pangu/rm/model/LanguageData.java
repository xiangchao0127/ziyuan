package com.sy.pangu.rm.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created with IDEA
 * author:lhang
 * Date:2019/4/9
 * Time:11:28
 */
@Data
public class LanguageData {
    private String id;
    private String chineseName;
    private String chineseSimpleName;
    private String englishName;
    private Boolean isEnable;
    /**
     * 排序
     */
    private Integer order;

}

