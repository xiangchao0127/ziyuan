package com.sy.pangu.rm.model;

import lombok.Data;

/**
 * @author XiangChao
 * @date 2019/5/7
 */
@Data
public class Reply {
    /**
     * 用户昵称
     */
    private String userNickName;
    /**
     * 回复对象
     */
    private String replyTarget;
    /**
     * 回复时间
     */
    private String replyTime;
    /**
     * 回复内容
     */
    private String content;
}
