package com.sy.pangu.rm.model;

import lombok.Data;

/** 业务日志
 * @author XiangChao
 * @date 2019/5/7
 */
@Data
public class BussinessLog {
    /**
     * 业务id
     */
    private String bussinessId;
    /**
     * 操作人id
     */
    private String operateUserId;
    /**
     * 操作人
     */
    private String operateUser;
    /**
     * 操作时间
     */
    private String operateTime;
    /**
     * 操作内容
     */
    private String content;
}
