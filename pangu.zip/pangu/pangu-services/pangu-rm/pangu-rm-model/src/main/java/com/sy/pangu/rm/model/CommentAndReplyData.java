package com.sy.pangu.rm.model;

import lombok.Data;

import java.util.List;

/**
 * @author XiangChao
 * @date 2019/5/7
 */
@Data
public class CommentAndReplyData {
    /**
     * 业务id(文章id)
     */
    private String bussinessId;
    /**
     * 用户昵称
     */
    private String userNickName;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 评论内容
     */
    private String content;
    /**
     * 回复集合
     */
    private List<Reply> replies;
}
