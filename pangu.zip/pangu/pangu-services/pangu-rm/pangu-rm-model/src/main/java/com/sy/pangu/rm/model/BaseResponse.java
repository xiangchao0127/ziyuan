package com.sy.pangu.rm.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author XiangChao
 * @date 2019/4/26
 */
@Data
public class BaseResponse implements Serializable {

    private String code;
    private String msg;
    private Object obj;

}
