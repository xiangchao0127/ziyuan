package com.sy.pangu.rm.model;

import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
public class LevelRelation implements Serializable {
    private String id;
    private String levelId;
    private String levelName;
    private String translatorType;
    private Timestamp gmtCreate;
    private Timestamp gmtUpdate;
    private Integer deleted;
}
